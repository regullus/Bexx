# Vialoc API
API para a plataforma de locação de carretas da ViaLoc

## Recursos utilizados

- Laravel 5.8
- Redis

### Sobre o Redis

- `redis-cli ping` - Para verificar se o Redis Cli está instalado e funcional
- `redis-cli monitor` - Para abrir a fila de processos em execução do Redis


## Ambiente de Desenvolvimento

O ambiente de desenvolvimento utiliza o Laradock, com os seguintes módulos ativados:

- nginx - webserver;
- mysql - banco de dados;
- redis - in-memory data structure store;
- workspace;
- php-worker - supervisor
- laravel-echo-server - servidor para o; Laravel Echo que gerencia as notificações/broadcasting da aplicação.

No diretório `_laradock-files` estão os arquivos de configuração de alguns módulos

Para iniciar, vá para o diretório onde o laradock está instalado e rode o comando abaixo:

```
docker-compose up -d nginx mysql redis workspace php-worker laravel-echo-server
```

Para interagir com o ambiente
```
docker-compose exec workspace bash
```

### Horizon

O Horizon <https://horizon.laravel.com> / <https://laravel.com/docs/5.6/horizon> está instalado para ajudar no gerenciamento da fila de processos. Para executar:

- `php artisan horizon` - Para executar o serviço
- `php artisan horizon:pause` - Pausa o serviço
- `php artisan horizon:continue` - Reinicia o serviço
- `php artisan horizon:terminate` - Encerra o serviço terminando os serviços em execução

O painel do horizon pode ser acessado - a princípio - apenas no ambiente de desenvolvimento, através do link <http://localhost:8000/horizon>


### PHP Worker (supervisor)

### Laravel Echo Server

Para referência - configurar o larave-echo-server com o Nginx no Laradock <https://github.com/laradock/laradock/issues/1340#issuecomment-390484505>

## Ambiente de Homologação

Estruturado da seguinte forma:

- [vialoc-api.c7net.com.br](https://vialoc-api.c7net.com.br)  
Laravel
- [vialoc.c7net.com.br](https://vialoc.c7net.com.br)  
Nuxt rodando através do PM2 (serviço vialoc_site) "proxeado" no Nginx pela porta 3001
- [vialoc-socket.c7net.com.br](https://vialoc-socket.c7net.com.br)  
Laravel Echo Server rodando através do PM2 (serviço echo) "proxeado" no Nginx pela porta 6001

A configuração dos módulos, é a mesma do que está descrito no Ambiente Produção.


## Ambiente de Produção


### Supervisor

Para mais informações <https://laravel.com/docs/5.6/queues#supervisor-configuration>.

Arquivo de configuração em: `/etc/supervisor/conf.d/vialoc-api-worker.conf`

Comandos básicos:

- `sudo supervisorctl reread`

- `sudo supervisorctl update`

- `sudo supervisorctl start vialoc-api-worker:*`

- `sudo supervisorctl stop vialoc-api-worker:*`

- `sudo supervisorctl status all`


### Laravel Echo Server

Siga as instruções aqui para instalar <https://github.com/tlaverdure/laravel-echo-server>

Veja também estas dicas: 
- <https://komelin.com/articles/realtime-apps-laravel-echo-tips-and-tricks/>
- <https://medium.com/@vipercodegames/nuxt-deploy-809eda0168fc>
- https://github.com/tlaverdure/laravel-echo-server/issues/264 (atualmente rodando no pm2)

Para rodar:

- Vá até o diretório `laravel-echo-server`
- Execute o comando `pm2 start echo.json`


