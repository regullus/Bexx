<?php

return [
    'webapp_url' => env('WEBAPP_URL', 'http://localhost:3000'),

    'platform_version' => env('PLATFORM_VERSION', '0.5.0'),

    'contact' => [
        'phone_sac' => '(11) 99999-9999',
    ],

    'notifications' => [
        // TENANT TO TENANT
        'order-payment-done' => 'Olá <strong>%user%</strong>, seu pagamento da reserva para <strong>%context%</strong> foi efetuado com sucesso.',

        // TENANT TO LOCATOR
        'product-question' => '<strong>%user%</strong> enviou uma pergunta sobre <strong>%context%</strong>.',
        'order-created' => '<strong>%user%</strong> fez um pedido de reserva de <strong>%context%</strong>.',
        'order-canceled' => '<strong>%user%</strong> cancelou o pedido de reserva para <strong>%context%</strong>.',
        'order-payment-received' => '<strong>%user%</strong> efetuou o pagamento da reserva para <strong>%context%</strong>.',
        'order-confirm-takeout' => '<strong>%user%</strong> confirmou a retirada da carreta referente a <strong>%context%</strong>.',
        'order-inform-devolution' => '<strong>%user%</strong> informou que você recebeu a devolução da carreta referente a <strong>%context%</strong>. Por favor, confirme.',

        // LOCATOR TO TENANT
        'product-answer' => '<strong>%user%</strong> respondeu à sua pergunta sobre <strong>%context%</strong>.',
        'order-confirmed' => '<strong>%user%</strong> autorizou o seu pedido de reserva para <strong>%context%</strong>.',
        'order-refused' => '<strong>%user%</strong> recusou o seu pedido de reserva para <strong>%context%</strong>.',
        'order-inform-takeout' => '<strong>%user%</strong> informou que você retirou a carreta referente a <strong>%context%</strong>. Por favor, confirme.',
        'order-confirm-devolution' => '<strong>%user%</strong> confirmou que recebeu a devolução da carreta referente a <strong>%context%</strong>.',
    ],

    'image-unavailable' => [
        'small' => '/assets/images/img-unavailable-360.png',
        'medium' => '/assets/images/img-unavailable-520.png',
        'large' => '/assets/images/img-unavailable-720x400.png',
        'square' => '/assets/images/img-unavailable.png',
    ],

    'payment-status' => [
        'cielo' => [
            'transactional' => [ // conforme https://developercielo.github.io/manual/cielo-ecommerce#sobre-os-c%C3%B3digos
                'code-0' => [
                    'slug' => 'processing',
                    'message' => 'Aguardando atualização de status',
                ],
                'code-1' => [
                    'slug' => 'authorized',
                    'message' => 'Pagamento apto a ser capturado ou definido como pago',
                ],
                'code-2' => [
                    'slug' => 'finished',
                    'message' => 'Pagamento confirmado e finalizado',
                ],
                'code-3' => [
                    'slug' => 'denied',
                    'message' => 'Pagamento negado pelo Autorizador',
                ],
                'code-10' => [
                    'slug' => 'voided',
                    'message' => 'Pagamento cancelado',
                ],
                'code-11' => [
                    'slug' => 'refunded',
                    'message' => 'Pagamento cancelado após 23:59 do dia de autorização',
                ],
                'code-12' => [
                    'slug' => 'pending',
                    'message' => 'Aguardando Status de instituição financeira',
                ],
                'code-13' => [
                    'slug' => 'aborted',
                    'message' => 'Pagamento cancelado por falha no processamento ou por ação do AF',
                ],
                'code-20' => [
                    'slug' => 'scheduled',
                    'message' => 'Recorrência agendada',
                ],
            ],
        ],
    ],

    // 'error' => [
    //     'no_permission_resource' => 'Você não tem permissão para acessar este recurso.',
    //     'product_unavailable' => 'Carreta indisponível.',
    // ],

    'user' => [
        'status' => [
            'pending' => 'pending',
            'active' => 'active',
            'inactive' => 'inactive',
        ],
    ],

    'profile' => [
        'type' => [
            'person' => 'tenant',
            'company' => 'company',
        ],
    ],

    'order' => [
        'status' => [
            'pending-confirmation' => 'pending-confirmation',
            'pending-payment' => 'pending-payment',
            'refused' => 'refused',
            'pending-takeout' => 'pending-takeout',
            'active' => 'active',
            'finished' => 'finished',
            'canceled' => 'canceled',
        ],
    ],

    'product' => [
        'status' => [
            'draft' => 'draft',
            'active' => 'active',
            'inactive' => 'inactive',
        ],
    ],

    'rows_per_page' => 20,

    'thumbs_sizes' => [
        'default' => [
            'w' => 240,
            'h' => 240,
            'crop' => true,
            'auto' => true,
        ],
        'small' => [
            'w' => 360,
            'h' => null,
            'crop' => false,
            'auto' => true,
        ],
        'medium' => [
            'w' => 520,
            'h' => null,
            'crop' => false,
            'auto' => true,
        ],
        // 'square-medium' => [
        //     'w' => 640,
        //     'h' => 640,
        //     'crop' => true,
        //     'auto' => false,
        // ],
        'retangle-small' => [
            'w' => 360,
            'h' => 200,
            'crop' => true,
            'auto' => true,
        ],
        'retangle-medium' => [
            'w' => 720,
            'h' => 400,
            'crop' => true,
            'auto' => true,
        ],
    ],

    'login_expires' => env('LOGIN_EXPIRES', 1), // tempo de expiração em horas

    'seeder_products_qty' => (int) env('SEEDER_PRODUCTS_QTY', 30),

    'notifications_count' => 3,
];
