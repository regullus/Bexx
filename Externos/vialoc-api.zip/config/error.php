<?php

return [
    // message
    'message_already_read' => 'A mensagem já foi lida.',
    'message_cannot_be_owner' => 'O proprietário da carreta não pode publicar uma questão.',

    // order
    'order_already_confirmed' => 'O pedido já foi confirmado/recusado pelo locador.',
    'order_confirmation_not_allowed' => 'Confirmação de pedido não permitida.',
    'order_not_available_to_payment' => 'Pedido indisponível para pagamento.',
    'order_rating_product_already_done' => 'Uma avaliação já foi feita para esta carreta.',
    'order_rating_user_already_done' => 'Uma avaliação já foi feita para este usuário.',
    'order_status_not_allowed' => 'O status do pedido não permite esta ação.',

    // product
    'product_already_confirmed' => 'Produto já confirmado.',
    'product_not_found' => 'Carreta não encontrada.',
    'product_unavailable' => 'Carreta não disponível.',
    'product_unavailable_to_rent' => 'Carreta não disponível para locação no período solicitado.',

    //payment // conforme https://developercielo.github.io/manual/cielo-ecommerce#sobre-os-c%C3%B3digos
    'payment_processing' => 'Aguardando atualização de status',
    'payment_authorized' => 'Pagamento apto a ser capturado ou definido como pago',
    'payment_finished' => 'Pagamento confirmado e finalizado',
    'payment_denied' => 'Pagamento negado pelo Autorizador',
    'payment_voided' => 'Pagamento cancelado',
    'payment_refunded' => 'Pagamento cancelado após 23:59 do dia de autorização',
    'payment_pending' => 'Aguardando Status de instituição financeira',
    'payment_aborted' => 'Pagamento cancelado por falha no processamento ou por ação do AF',
    'payment_scheduled' => 'Recorrência agendada',

    // Usuário
    'user_must_be_active' => 'Usuário precisa estar ativo',

    // resource
    'resource_not_allowed' => 'Sem permissão para acessar o recurso.',
    'resource_exists' => 'Recurso já existe',
    'update_not_allowed' => 'Atualização não permitida.',
    'email_not_allowed' => 'Alteração de email não permitida.',
    'password_not_allowed' => 'Alteração de senha não permitida.',
    'email_already_exists' => 'Email já existe.',
    'not_found_resource' => 'Recurso não encontrado',
    'unauthorization_resource' => 'Recurso não autorizado',
    'not_allow_refuse' => 'Recusa não permitida',
    'login_expired' => 'Login expirado para esta funcionalidade',
    'invalid_argumet' => 'Argumento inválido para esta funcionalidade',
    'not_allow_question' => 'Proprietário não pode fazer perguntas para ele mesmo.',
    'not_allow_answer' => 'Apenas o proprietário pode responder perguntas.',
];
