@extends('emails.layouts.master')

@section ('content')

	<h1 style="font-size: 20px; line-height: 1.2; letter-spacing: 7.5px; color: #252C65; text-align: center; margin: 0 0 60px 0; white-space: nowrap; text-transform: uppercase;">– Confirme o seu cadastro –</h1>
	<p style="font-size: 19px;">Olá, <strong>{{ $user->profile->name }}</strong>,</p>
	<p>
		Para confirmar este e-mail no seu perfil da Vialoc, basta clicar no botão abaixo:
	</p>

	<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="30">

	<a href="{{ config('c7.webapp_url') }}/?ativar-conta={{ $token }}" style="display: block; background-color: #409EFF; text-align: center; color: #fff; font-size: 14px; line-height: 40px; font-weight: bold; text-decoration: none; max-width: 350px; margin: 0 auto;">Ativar o meu cadastro</a>

	<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="30">
	<hr size="1" color="#BCBCBC">
	<p>Caso esteja com dificuldade, em acessar pelo botão acima, copie o endereço abaixo e cole em seu navegador:</p>
	<code>{{ config('c7.webapp_url') }}/?ativar-conta={{ $token }}</code>
	<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="30">
	<hr size="1" color="#BCBCBC">
	<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="15">
	<p>Dúvidas? Fale com a nossa Central de Atendimento.</p>
	@include ('emails.partials.signature')

@endsection