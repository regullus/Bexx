@extends('emails.layouts.master')

@section ('content')

	<h1 style="font-size: 20px; line-height: 1.2; letter-spacing: 7.5px; color: #252C65; text-align: center; margin: 0 0 60px 0; white-space: nowrap; text-transform: uppercase;">– Pergunta recebida –</h1>
	<p style="font-size: 19px;">Olá, <strong>{{ $questionAnswer->product->user->name }}</strong>,</p>
	<p>
		Você recebeu uma pergunta de {{ $questionAnswer->user->short_name }}:
	</p>

	<blockquote style="font-style: italic; border-left: 5px solid #F5A623; padding:30px; margin-left: 0;">
		{!! autop($questionAnswer->content) !!}
	</blockquote>

	<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="30">

    <p>Referente à carreta:</p>

    <table border="0" cellpadding="5" cellspacing="0" width="400">
        <tr>
            <td><img src="{{ asset($product_featured_image) }}" alt="{{ $questionAnswer->product->name }}" height="60"></td>
            <td><img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="10"></td>
            <td><a href="{{ config('c7.webapp_url') }}/carreta/{{ $questionAnswer->product->slug }}" target="_blank" style="font-size: 14px; font-weight: bold; color: #777; text-decoration: none;">{{ $questionAnswer->product->name }}</a></td>
        </tr>
    </table>

    <img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="30">

	<a href="{{ config('c7.webapp_url') }}/locador/carretas/{{ $questionAnswer->product->uid }}/mensagens#pergunta-{{ $questionAnswer->id }}" style="display: block; background-color: #409EFF; text-align: center; color: #fff; font-size: 14px; line-height: 40px; font-weight: bold; text-decoration: none; max-width: 350px; margin: 0 auto;">Responder à pergunta</a>

	<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="30">
	<hr size="1" color="#BCBCBC">
	<p>Caso esteja com dificuldade, em acessar pelo botão acima, copie o endereço abaixo e cole em seu navegador:</p>
	<code>{{ config('c7.webapp_url') }}/locador/carretas/{{ $questionAnswer->product->uid }}/mensagens#pergunta-{{ $questionAnswer->id }}</code>
	<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="30">
	<hr size="1" color="#BCBCBC">
	<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="15">
	<p>Dúvidas? Fale com a nossa Central de Atendimento.</p>
	@include ('emails.partials.signature')

@endsection