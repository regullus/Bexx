<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>{{ config('app.name') }}</title>
</head>
<body>
	<div align="center">
		<font face="Arial, Helvetica, sans-serif" style="font-size: 16px; line-height: 1.5;">
			<table border="0" cellpadding="0" cellspacing="0" width="600" align="center">
				<tr>
					<td><a href="{{ config('c7.webapp_url') }}"><img src="{{ asset('assets/images/email/header.png') }}" alt="{{ config('app.name') }}"></a></td>
				</tr>

				@yield('extra-row')

				<tr>
					<td bgcolor="#F7F7F7">
						<table border="0" cellpadding="0" cellspacing="0" width="600">
							<tr>
								<td width="40" rowspan="3"><img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" width="40"></td>
								<td width="520"><img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="40"></td>
								<td width="40" rowspan="3"><img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" width="40"></td>
							</tr>
							<tr>
								<td>

									@yield ('content')

								</td>
							</tr>
							<tr>
								<td><img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="40"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table border="0" cellpadding="0" cellspacing="0" width="600">
							<tr>
								<td width="40" rowspan="3"><img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" width="40"></td>
							</tr>
							{{--
							<tr>
								<td>
									<font style="font-size: 12px; color: #4a4a4a;">
										<table border="0" cellpadding="0" cellspacing="0" width="480" align="center">
											<tr>
												<td width="110"><img src="{{ asset('assets/images/email/ssl-seal.png') }}" alt="SSL" style="display: block;"></td>
												<td>
													<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="5">
													Meios de pagamento:
													<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="5">
													<img src="{{ asset('assets/images/email/payment-seals.png') }}" alt="Meios de pagamento aceitos" style="display: block;">
												</td>
												<td>
													<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="5">
													Fale conosco:
													<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="5">
													<font style="font-size: 24px; font-weight: bold;">11 9999-9999</font>
												</td>
											</tr>
										</table>
									</font>
									<img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="15">
									<hr size="1" color="#BCBCBC">
								</td>
							</tr>
							--}}
							<tr>
								<td><img src="{{ asset('assets/images/email/transp.png') }}" alt="{{ config('app.name') }}" style="display: block;" height="40"></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</font>
	</div>
</body>
</html>