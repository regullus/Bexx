	<p>
		<strong>Equipe Vialoc</strong><br>
		<em><a href="mailto:contato@vialoc.net" style="text-decoration: none;">contato@vialoc.net</a></em>
	</p>
