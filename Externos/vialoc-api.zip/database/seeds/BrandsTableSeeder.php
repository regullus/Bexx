<?php

use Illuminate\Database\Seeder;

use App\Models\Brand;

class BrandsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $brands = [
            ['name' => 'Bertolini'],
            ['name' => 'Facchini'],
            ['name' => 'Figobras'],
            ['name' => 'Gotti'],
            ['name' => 'Guerra'],
            ['name' => 'Librelato'],
            ['name' => 'Niju'],
            ['name' => 'Noma'],
            ['name' => 'Randon'],
            ['name' => 'Rodofort'],
            ['name' => 'Shiffer'],
            ['name' => 'Triel-HT'],
            ['name' => 'Outros'],
        ];

        foreach ($brands as $brand) {
            Brand::create($brand);
        }
    }
}
