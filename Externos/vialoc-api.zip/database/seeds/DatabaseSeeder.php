<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            RolesAndPermissionsTableSeeder::class,
            StatesTableSeeder::class,
            CitiesTableSeeder::class,
            BrandsTableSeeder::class,
            UsersTableSeeder::class,
            ProductsTableSeeder::class,
            FaqTableSeeder::class,
            PaymentMethodsTableSeeder::class,
        ]);
    }
}
