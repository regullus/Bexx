<?php

use Illuminate\Database\Seeder;

use App\Models\State;

class StatesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::statement('SET FOREIGN_KEY_CHECKS=0');

        \DB::table('states')->truncate();

        State::create(['name' => 'Acre', 'code' => 'AC']);
        State::create(['name' => 'Alagoas', 'code' => 'AL']);
        State::create(['name' => 'Amapá', 'code' => 'AP']);
        State::create(['name' => 'Amazonas', 'code' => 'AM']);
        State::create(['name' => 'Bahia', 'code' => 'BA']);
        State::create(['name' => 'Ceará', 'code' => 'CE']);
        State::create(['name' => 'Distrito Federal', 'code' => 'DF']);
        State::create(['name' => 'Espírito Santo', 'code' => 'ES']);
        State::create(['name' => 'Goiás', 'code' => 'GO']);
        State::create(['name' => 'Maranhão', 'code' => 'MA']);
        State::create(['name' => 'Mato Grosso', 'code' => 'MT']);
        State::create(['name' => 'Mato Grosso do Sul', 'code' => 'MS']);
        State::create(['name' => 'Minas Gerais', 'code' => 'MG']);
        State::create(['name' => 'Pará', 'code' => 'PA']);
        State::create(['name' => 'Paraíba', 'code' => 'PB']);
        State::create(['name' => 'Paraná', 'code' => 'PR']);
        State::create(['name' => 'Pernambuco', 'code' => 'PE']);
        State::create(['name' => 'Piauí', 'code' => 'PI']);
        State::create(['name' => 'Rio de Janeiro', 'code' => 'RJ']);
        State::create(['name' => 'Rio Grande do Norte', 'code' => 'RN']);
        State::create(['name' => 'Rio Grande do Sul', 'code' => 'RS']);
        State::create(['name' => 'Rondônia', 'code' => 'RO']);
        State::create(['name' => 'Roraima', 'code' => 'RR']);
        State::create(['name' => 'Santa Catarina', 'code' => 'SC']);
        State::create(['name' => 'São Paulo', 'code' => 'SP']);
        State::create(['name' => 'Sergipe', 'code' => 'SE']);
        State::create(['name' => 'Tocantins', 'code' => 'TO']);
    }
}
