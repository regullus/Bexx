<?php

use App\Models\PaymentMethod;
use Illuminate\Database\Seeder;

class PaymentMethodsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $paymentMethods = [
            'bank-slip' => [
                'name' => 'Boleto bancário',
                'slug' => 'bank-slip',
                'status' => 'active',
            ],
            'credit-card' => [
                'name' => 'Cartão de crédito',
                'slug' => 'credit-card',
                'options' => [
                    'visa' => [
                        'name' => 'Visa',
                        'slug' => 'visa',
                        'status' => 'active',
                        'description' => '',
                    ],
                    'mastercard' => [
                        'name' => 'Mastercard',
                        'slug' => 'mastercard',
                        'status' => 'active',
                        'description' => '',
                    ],
                    'american-express' => [
                        'name' => 'American Express',
                        'slug' => 'american-express',
                        'status' => 'active',
                        'description' => '',
                    ],
                    'elo' => [
                        'name' => 'Elo',
                        'slug' => 'elo',
                        'status' => 'active',
                        'description' => '',
                    ],
                    'aura' => [
                        'name' => 'Aura',
                        'slug' => 'aura',
                        'status' => 'inactive',
                        'description' => '',
                    ],
                    'jcb' => [
                        'name' => 'Jcb',
                        'slug' => 'jcb',
                        'status' => 'active',
                        'description' => '',
                    ],
                    'diners-club' => [
                        'name' => 'Diners',
                        'slug' => 'diners-club',
                        'status' => 'active',
                        'description' => '',
                    ],
                    'discover' => [
                        'name' => 'Discover',
                        'slug' => 'discover',
                        'status' => 'active',
                        'description' => '',
                    ],
                    'hipercard' => [
                        'name' => 'Hipercard',
                        'slug' => 'hipercard',
                        'status' => 'active',
                        'description' => '',
                    ],
                ],
                'status' => 'active',
            ],

            'debit-card' => [
                'name' => 'Cartão de débito',
                'slug' => 'debit-card',
                'options' => [
                    'visa-electron' => [
                        'name' => 'Visa Electron',
                        'slug' => 'visa-electron',
                        'status' => 'active',
                        'description' => '',
                    ],
                    'maestro' => [
                        'name' => 'Maestro',
                        'slug' => 'maestro',
                        'status' => 'active',
                        'description' => '',
                    ],
                ],
                'status' => 'active',
            ],
        ];

        foreach ($paymentMethods as $pm) {
            $paymentMethod = PaymentMethod::create($pm);
        }
    }
}
