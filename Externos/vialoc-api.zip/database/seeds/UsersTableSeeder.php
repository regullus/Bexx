<?php

use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Illuminate\Database\Seeder;

use App\Models\User;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = [
            [
                'uid' => (string) Str::uuid(),
                'name' => 'Alexandre',
                'last_name' => 'Vargas',
                'email' => 'webmaster@citrus7.com.br',
                'password' => 'teste123',
                // 'type' => 'tenant',
                'email_confirmed' => 1,
                'agree_terms' => 1,
                'receive_news' => 1,
                'role' => [
                    'name' => 'admin',
                    'guard_name' => 'api',
                ],
                'status' => 'active',
                'address' => [
                    'zipcode' => '01319001',
                    'address' => 'Rua Maria Paula',
                    'address_number' => '279',
                    'address_complement' => 'ap605',
                    'city_id' => '5271',
                    'district' => 'Bela Vista',
                    'latitude' => -23.551540,
                    'longitude' => -46.640290,
                    'is_main' => 1,
                ],
                'profile' => [
                    'cpf' => '30487276809',
                    'birthdate' => '10/10/1980',
                    'phones' => ['phone_1' => '(11) 99999-9999'],
                ],
            ],
            [
                'uid' => (string) Str::uuid(),
                'name' => 'Kan',
                'last_name' => 'Ishigami',
                'email' => 'kan@citrus7.com.br',
                'password' => 'teste123',
                // 'type' => 'tenant',
                'email_confirmed' => 1,
                'agree_terms' => 1,
                'receive_news' => 1,
                'role' => 'admin',
                'status' => 'active',
                'address' => [
                    'zipcode' => '01319001',
                    'address' => 'Rua Maria Paula',
                    'address_number' => '279',
                    'address_complement' => 'ap605',
                    'city_id' => '5271',
                    'district' => 'Bela Vista',
                    'latitude' => -23.551540,
                    'longitude' => -46.640290,
                    'is_main' => 1,
                ],
                'profile' => [
                    'cpf' => '15698868816',
                    'birthdate' => '15/08/1978',
                    'phones' => ['phone_1' => '(11) 99999-9999'],
                ],
            ],
        ];

        foreach ($users as $u) {
            $user = User::create(Arr::except($u, ['role', 'profile', 'address']));
            $user->load(['profile']);
            $user->profile->update($u['profile']);
            $user->addresses()->create($u['address']);
            $user->assignRole('admin');
        }

        factory(App\Models\User::class, 30)->create()->each(function ($user) {
            // $user->load(['profile']);
            $profile = factory(App\Models\Profile::class)->make()->toArray();
            $profile['phones'] = json_encode($profile['phones']);
            $user->profile()->update($profile);
            $user->addresses()->save(factory(App\Models\Address::class)->make());
            $user->assignRole('user');
        });
    }
}
