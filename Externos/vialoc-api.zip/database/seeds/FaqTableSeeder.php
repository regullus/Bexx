<?php

use Illuminate\Database\Seeder;
use Faker\Generator as Faker;

use App\Models\Faq;

class FaqTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(Faker $faker)
    {
        factory(Faq::class, 20)->create();
    }
}
