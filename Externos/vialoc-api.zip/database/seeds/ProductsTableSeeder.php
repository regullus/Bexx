<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Faker\Generator as Faker;

use App\Traits\DefineSearchFiltersTrait;
use App\Services\v1\Site\MediaLibraryService;

class ProductsTableSeeder extends Seeder
{
    use DefineSearchFiltersTrait;

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(Faker $faker, MediaLibraryService $mediaLibraryService)
    {
        \DB::statement('SET FOREIGN_KEY_CHECKS=0');

        factory(App\Models\Product::class, config('c7.seeder_products_qty'))->create()->each(function ($product) use ($faker, $mediaLibraryService) {

            // $faker->addProvider(new Bluemmb\Faker\PicsumPhotosProvider($faker));
            $faker->addProvider(new Xvladqt\Faker\LoremFlickrProvider($faker));

            // Images
            for ($i = 0; $i < 3; $i++) {
                // $image = $faker->image(storage_path('framework/cache'), 800, 600);
                // $path = 'products' . DIRECTORY_SEPARATOR . $product->created_at->format('Y' . DIRECTORY_SEPARATOR . 'm') . DIRECTORY_SEPARATOR . $product->uid;
                // $filename = Str::slug($product->name) . '-' . Str::random(10);
                // $image_stored = $mediaLibraryService->create($image, [
                //     'path' => $path,
                //     'filename' => $filename,
                //     'thumbnails' => [
                //         'sizes_only' => ['default', 'retangle-small', 'retangle-medium']
                //     ]
                // ]);

                // $image = $faker->imageUrl(800, 600, false, true); // para PicsumPhotosProvider
                $image = $faker->imageUrl(800, 600, ['truck'], true); // para LoremFlickrProvider
                $image_file = storage_path('framework/cache/'.$product->slug.'-'.$i.'.jpg');

                \Image::make($image)->save($image_file);

                $path = 'products'.DIRECTORY_SEPARATOR.$product->created_at->format('Y'.DIRECTORY_SEPARATOR.'m').DIRECTORY_SEPARATOR.$product->uid;
                $filename = Str::slug($product->name).'-'.Str::random(5);
                $image_stored = $mediaLibraryService->create($image_file, [
                    'path' => $path,
                    'filename' => $filename,
                    'thumbnails' => [
                        'sizes_only' => ['default', 'retangle-small', 'retangle-medium'],
                    ],
                ]);

                $product->attachMedia($image_stored, 'product-image');

                // se o produto não tem nenhuma imagem de destaque, é definida a primeira imagem como destaque
                if (! $product->hasMedia('product-featured-image')) {
                    $product->attachMedia($image_stored, 'product-featured-image');
                }
            }

            // Documento CRLV - pega a ultima imagem gerada e usa para o documento
            // $document = \C7Upload::productDocument($image, 'doc_crlv', $product);
            // $product->attachMedia($document, 'doc_crlv');

            // Gera as imagens das Vistas das carretas
            foreach ($product->list_image_views as $view => $view_desc) {
                // $image = $faker->imageUrl(800, 600, false, true); // para PicsumPhotosProvider
                $image = $faker->imageUrl(800, 600, ['truck'], true); // para LoremFlickrProvider
                $image_file = storage_path('framework/cache/'.$product->slug.'-'.$view.'.jpg');

                \Image::make($image)->save($image_file);

                $path = 'products'.DIRECTORY_SEPARATOR.$product->created_at->format('Y'.DIRECTORY_SEPARATOR.'m').DIRECTORY_SEPARATOR.$product->uid;

                $filename = Str::slug($product->name).'-view-'.$view;
                $image_stored = $mediaLibraryService->create($image_file, [
                    'path' => $path,
                    'filename' => $filename,
                    'thumbnails' => [
                        'sizes_only' => ['default', 'retangle-small', 'retangle-medium'],
                    ],
                ]);

                $product->attachMedia($image_stored, $view);
            }

            // price
            $product->prices()->save(factory(App\Models\Price::class)->make());
            $product->prices()->save(factory(App\Models\Price::class)->states('week')->make());
            $product->prices()->save(factory(App\Models\Price::class)->states('month')->make());
        });

        // Gera os caches
        self::cacheBrandsList();
        self::cachePriceRange();
        self::cacheYearRange();
        self::cacheTypesList();
    }
}
