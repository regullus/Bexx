<?php

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolesAndPermissionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Reset cached roles and permissions
        // https://docs.spatie.be/laravel-permission/v3/advanced-usage/seeding/
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        $user_role = Role::create(['name' => 'user']);
        $user_permission = Permission::create(['name' => 'create orders']);
        $user_role->givePermissionTo($user_permission);

        $admin_role = Role::create(['name' => 'admin']);
        $admin_permission = Permission::create(['name' => 'edit users']);
        $admin_role->givePermissionTo($admin_permission);
    }
}
