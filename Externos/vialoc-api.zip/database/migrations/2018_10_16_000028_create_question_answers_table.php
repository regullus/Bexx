<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateQuestionAnswersTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'question_answers';

    /**
     * Run the migrations.
     * @table question_answers
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('parent_id')->default(0);
            $table->unsignedInteger('user_id')->comment('Qualquer usuário que possui cadastro pode fazer uma
pergunta.');
            $table->unsignedInteger('product_id');
            $table->text('content');
            $table->string('status', 15)->default('active')->comment('active
inactive');

            $table->index(['product_id'], 'fk_questions_items1_idx');

            $table->index(['user_id'], 'fk_questions_answers_users1_idx');
            $table->timestamp('read_at')->nullable()->comment('destinado para a contraparte da questao - no caso se o criador da questao leu');
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('user_id', 'fk_questions_answers_users1_idx')
                ->references('id')->on('users')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('product_id', 'fk_questions_items1_idx')
                ->references('id')->on('products')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
