<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrderPaymentsTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'order_payments';

    /**
     * Run the migrations.
     * @table order_payments
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('order_id');
            $table->string('payment_method_slug')->index();
            $table->string('payment_method_option', 191)->nullable(); // num primeiro momento será utilizado para armazenar qual a bandeira de cartão foi feito o pagamento
            $table->string('gateway_payment_id', 191)->nullable()->index(); // o payment_id retornado pelo gateway
            $table->string('gateway_transaction_id', 191)->nullable()->index(); // o transaction_id retornado pelo gateway
            $table->string('status', 191)->default('pending')->comment('status geral do pagamento');
            $table->string('status_authorization', 191)->nullable()->comment('status do cartão de crédito
processing (processando autorização)
authorized
denied
comunication_error
');
            $table->string('status_capture', 191)->nullable()->comment('status do cartão de crédito para captura
pending
captured
not_captured');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
