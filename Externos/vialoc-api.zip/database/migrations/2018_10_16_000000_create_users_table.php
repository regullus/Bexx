<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'users';

    /**
     * Run the migrations.
     * @table users
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('uid', 200)->nullable();
            $table->string('name', 200)->nullable();
            $table->string('last_name', 200)->nullable()->default(null);
            $table->string('email')->nullable();
            $table->string('slug', 100)->nullable();
            $table->string('password')->nullable()->comment('Deixei o tamanho 255 pois é o tamanho sugerido na documentação do Laravel e ');
            $table->string('type', 50)->nullable()->comment('Tenant (locatário)
Locator (locador)
Esse campo não informa o que o usuário é de fato visto que, caso ele possua
um pedido eu  o considero locatário e caso possua uma carreta cadastrada
eu o considero locador. Este campo apenas armazena a escolha que o usuário
fez no preenchimento do cadastro.');
            $table->tinyInteger('email_confirmed')->default('0')->comment('Este campo é marcado com 1 quando o usuário que se cadastrou
clica no link enviado ao seu email. Caso o usuário altere seu email
então este campo é retornado para 0, um novo email com link é
enviado e o processo se repete.');
            $table->rememberToken();
            $table->string('email_intended')->nullable();
            $table->tinyInteger('agree_terms')->default(0);
            $table->tinyInteger('receive_news')->default(0);
            $table->string('status', 50)->default('pending')->comment('pending
active
inactive');
            $table->decimal('rating_locator_score', 6, 2)->default('0');
            $table->integer('rating_locator_count')->default('0');
            $table->decimal('rating_tenant_score', 6, 2)->default('0');
            $table->integer('rating_tenant_count')->default('0');
            $table->timestamp('loggedin_at')->nullable();

            $table->unique(['email'], 'uid_UNIQUE');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
