<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGatewayCapturesTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'gateway_captures';

    /**
     * Run the migrations.
     * @table gateway_captures
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('order_id');
            $table->unsignedInteger('order_payment_id');
            $table->unsignedInteger('gateway_request_id');
            $table->text('json_response');
            $table->integer('status'); // status da captura // no caso da cielo é um número inteiro

            $table->index(['order_id'], 'orders_id_idx');
            $table->index(['order_payment_id'], 'order_payment_id');
            $table->index(['gateway_request_id'], 'gateway_request_id_idx');

            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
