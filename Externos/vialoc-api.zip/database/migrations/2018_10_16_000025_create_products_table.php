<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductsTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'products';

    /**
     * Run the migrations.
     * @table products
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('uid', 200)->nullable();
            $table->string('external_id', 45)->nullable();
            $table->string('name', 200);
            $table->string('slug', 100)->nullable();
            $table->text('content')->comment('descrição detalhada');
            $table->text('link_video')->nullable();
            // $table->unsignedInteger('city_id');
            $table->unsignedInteger('user_id')->nullable();
            $table->unsignedInteger('address_id')->nullable();
            $table->string('type', 100)->comment('arquivo de config: carreta baú, carreta sider, porta container.');
            $table->unsignedInteger('brand_id')->comment('marca');
            $table->decimal('height', 9, 2)->nullable()->comment('altura');
            $table->decimal('width', 9, 2)->comment('largura');
            $table->decimal('length', 9, 2)->comment('comprimento');
            $table->decimal('weight', 9, 2)->nullable()->comment('peso');
            $table->decimal('cubing', 9, 2)->nullable()->comment('cubagem, capacidade por metros cubicos.');
            $table->string('axes')->nullable()->comment('quantidade de eixos.');
            $table->string('licensing', 7)->nullable()->comment('2018-09 (ano-mês)');
            $table->string('year', 4);
            $table->string('model', 191)->nullable()->comment('Esse é o modelo do fabricante. Não tem nada a ver com
o modelo de carro. Pode ser uma string que não tem nada
a ver com Ano.');
            $table->string('chassis', 50)->nullable();
            $table->string('renavam', 50)->nullable();
            $table->string('antt', 50)->nullable();
            $table->string('owner_name', 200)->nullable();
            $table->string('owner_cpf_cnpj', 14)->nullable();
            $table->string('license_plate', 20)->nullable();
            $table->string('floor', 50)->nullable()->comment('arquivo config: chapa xadrez ou madeirite.');
            $table->tinyInteger('with_tires')->nullable();
            $table->string('suspension', 30)->comment('arquivo de config: pneumática ou mecânica.');
            $table->decimal('rating_score', 6, 2)->default('0');
            $table->integer('rating_count')->default('0');
            $table->integer('enhance_level')->default('0')->comment('Inteiro especificando o grau de destaque do produto nas listagems. Quanto maior o valor, melhor será posição de destaque.');
            // $table->double('latitude', 10, 6)->nullable();
            // $table->double('longitude', 10, 6)->nullable();
            $table->string('status', 50)->default('draft')->comment('draft
active
inactive');

            $table->index(['type'], 'IDX_TYPE');
            $table->index(['slug'], 'IDX_SLUG');
            $table->index(['brand_id'], 'fk_vehicle_brand1_idx');
            $table->index(['user_id'], 'fk_items_users1_idx');
            $table->index(['status'], 'IDX_STATUS');
            $table->index(['enhance_level'], 'IDX_ENHANCELEVEL');
            $table->unique(['external_id'], 'external_id_UNIQUE');
            $table->unique(['uid'], 'uid_UNIQUE');

            $table->softDeletes();
            $table->timestamps();

            $table->foreign('brand_id', 'fk_vehicle_brand1_idx')
                ->references('id')->on('brands')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('user_id', 'fk_items_users1_idx')
                ->references('id')->on('users')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
