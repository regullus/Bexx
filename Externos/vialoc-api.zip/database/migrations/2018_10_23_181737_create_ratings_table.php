<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRatingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ratings', function (Blueprint $table) {
            $table->increments('id');

            $table->unsignedInteger('user_id');
            $table->foreign('user_id', 'fk_rating_user')
                ->references('id')->on('users');

            $table->unsignedInteger('order_id');
            $table->foreign('order_id', 'fk_rating_order')
                ->references('id')->on('orders');

            $table->string('ratingable_type');
            $table->integer('ratingable_id');
            $table->string('subtype')->nullable();
            $table->integer('score')->default(0);
            $table->text('comment')->nullable();
            $table->string('status')->default('pending');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ratings');
    }
}
