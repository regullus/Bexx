<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrdersTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'orders';

    /**
     * Run the migrations.
     * @table orders
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('user_id');
            $table->text('json_user');
            $table->unsignedInteger('address_id')->nullable();
            $table->text('json_address');
            $table->unsignedInteger('product_id');
            $table->text('json_product');
            $table->unsignedInteger('price_id');
            $table->text('json_price');
            $table->text('json_prices_base')->comment('Armazena todos os preços usados como base para a escolha do preço
em price_id e json_price.');
            $table->date('date_start');
            $table->date('date_end');
            $table->integer('days_total');
            $table->decimal('price_total', 20, 2);
            $table->string('status', 50)->default('pending-confirmation')->comment('pending-confirmation
pending-payment
refused
pending-takeout
active
finished
canceled');
            $table->longText('metadata')->nullable();

            $table->index(['product_id'], 'fk_orders_products1_idx');

            $table->index(['price_id'], 'fk_orders_prices1_idx');

            $table->index(['user_id'], 'fk_contract_users1_idx');
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('user_id', 'fk_contract_users1_idx')
                ->references('id')->on('users')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('product_id', 'fk_orders_products1_idx')
                ->references('id')->on('products')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('price_id', 'fk_orders_prices1_idx')
                ->references('id')->on('prices')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
