<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMediablesTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'mediables';

    /**
     * Run the migrations.
     * @table mediables
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->unsignedInteger('media_id');
            $table->string('mediable_type');
            $table->unsignedInteger('mediable_id');
            $table->string('tag');
            $table->unsignedInteger('order')->nullable();

            $table->index(['media_id'], 'fk_mediables_media1_idx');

            $table->unique(['media_id', 'mediable_type', 'mediable_id', 'tag'], 'UQ_MEDIABLES');

            $table->foreign('media_id', 'fk_mediables_media1_idx')
                ->references('id')->on('media')
                ->onDelete('cascade')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
