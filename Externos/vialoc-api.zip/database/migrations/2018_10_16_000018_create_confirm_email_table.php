<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateConfirmEmailTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'confirm_email';

    /**
     * Run the migrations.
     * @table confirm_email
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('user_id');
            $table->string('email', 191);
            $table->string('token', 191);
            $table->timestamp('created_at')->nullable()->default(null);

            $table->index(['email'], 'password_resets_email_index');

            $table->index(['user_id'], 'fk_confirm_email_users1_idx');

            $table->unique(['token'], 'token_UNIQUE');

            $table->foreign('user_id', 'fk_confirm_email_users1_idx')
                ->references('id')->on('users')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
