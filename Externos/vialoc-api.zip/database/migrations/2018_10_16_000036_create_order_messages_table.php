<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrderMessagesTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'order_messages';

    /**
     * Run the migrations.
     * @table order_messages
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('order_id');
            $table->text('content');
            $table->unsignedInteger('user_id');
            $table->timestamp('read_at')->nullable()->comment('destinado para a contraparte da questao - no caso se o criador da questao leu');

            $table->index(['user_id'], 'fk_order_messages_users1_idx');
            $table->index(['order_id'], 'fk_order_messages_orders1_idx');

            $table->softDeletes();
            $table->timestamps();

            $table->foreign('order_id', 'fk_order_messages_orders1_idx')
                ->references('id')->on('orders')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('user_id', 'fk_order_messages_users1_idx')
                ->references('id')->on('users')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
