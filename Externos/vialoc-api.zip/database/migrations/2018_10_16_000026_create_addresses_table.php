<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAddressesTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'addresses';

    /**
     * Run the migrations.
     * @table addresses
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('user_id');
            $table->string('label', 191)->default('Principal');
            $table->string('zipcode', 8)->nullable();
            $table->string('address', 191)->nullable();
            $table->string('address_number')->nullable();
            $table->string('address_complement', 50)->nullable();
            $table->unsignedInteger('city_id')->nullable();
            $table->string('district')->nullable();
            $table->text('notes')->nullable();
            $table->tinyInteger('is_main')->default(0);
            $table->double('latitude', 10, 6)->nullable();
            $table->double('longitude', 10, 6)->nullable();

            $table->index(['user_id'], 'fk_addresses_users1_idx');

            $table->index(['city_id'], 'fk_addresses_cities1_idx');
            $table->softDeletes();
            $table->nullableTimestamps();

            $table->foreign('user_id', 'fk_addresses_users1_idx')
                ->references('id')->on('users')
                ->onDelete('no action')
                ->onUpdate('no action');

            $table->foreign('city_id', 'fk_addresses_cities1_idx')
                ->references('id')->on('cities')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
