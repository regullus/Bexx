<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGatewayRequestsTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'gateway_requests';

    /**
     * Run the migrations.
     * @table gateway_requests
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('order_id');
            $table->unsignedInteger('order_payment_id');
            $table->text('json_gateway_request')->nullable()->comment('Armazena a requisição feita ao Gateway com exceção dos dados não permitidos (full card number, expiration e cvv).');
            $table->text('json_gateway_response')->nullable()->comment('Resposta do Gateway para a requisição realizada.');
            $table->string('status_authorization', 191)->nullable()->comment('Se cartão de crédito
processing
authorized
denied
comunication_error');
            $table->string('status_capture', 191)->nullable()->comment('Se cartão de crédito
pending
captured
not_captured');

            $table->index(['order_id'], 'order_id_idx');
            $table->index(['order_payment_id'], 'order_payment_id_idx');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
