<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCreditCardCompaniesTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'credit_card_companies';

    /**
     * Run the migrations.
     * @table credit_card_companies
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('name', 191);
            $table->string('slug', 191)->nullable();
            $table->integer('max_installments')->default('1')->comment('Serve apenas para as bandeiras de cartão de crédito. Os payment_methods bank_slip e bank_slip_billed não usam esse campo.');
            $table->text('options')->nullable();
            $table->string('status', 191)->default('active');

            $table->index(['slug'], 'payment_company_slug');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
