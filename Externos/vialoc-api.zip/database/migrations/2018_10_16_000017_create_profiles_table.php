<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProfilesTable extends Migration
{
    /**
     * Schema table name to migrate.
     * @var string
     */
    public $set_schema_table = 'profiles';

    /**
     * Run the migrations.
     * @table profiles
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable($this->set_schema_table)) {
            return;
        }
        Schema::create($this->set_schema_table, function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('user_id');
            $table->string('external_id', 191)->nullable()->default(null)->comment('Caso o cliente já possua por exemplo cadastro njo ERP,
este id representa o usuário njo ERP.');
            $table->string('cpf', 11)->nullable();
            $table->date('birthdate')->nullable();
            $table->string('cnpj', 14)->nullable();
            $table->string('company_name', 191)->nullable()->default(null);
            $table->string('trading_name', 191)->nullable()->default(null);
            $table->string('state_tax_number', 20)->nullable()->default(null);
            $table->string('website', 191)->nullable()->default(null);
            $table->string('phones', 191)->nullable();

            $table->index(['user_id'], 'fk_customers_user1_idx');

            $table->unique(['state_tax_number'], 'state_tax_number_UNIQUE');

            $table->unique(['external_id'], 'customers_external_id_unique');

            $table->unique(['company_name'], 'company_name_UNIQUE');

            $table->unique(['user_id'], 'user_id_UNIQUE');
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('user_id', 'fk_customers_user1_idx')
                ->references('id')->on('users')
                ->onDelete('no action')
                ->onUpdate('no action');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->set_schema_table);
    }
}
