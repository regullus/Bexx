<?php

use Illuminate\Support\Str;
use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(App\Models\Address::class, function (Faker $faker) {
    $faker->addProvider(new \JansenFelipe\FakerBR\FakerBR($faker));

    $city_id = $faker->randomElement([5271, 5243, 3659, 4502, 1630, 4175, 2878]);

    $latlon = [
        5271 => [ // São Paulo, SP
            'latitude' => -23.548670,
            'longitude' => -46.638250,
        ],
        5243 => [ // Santo André, SP
            'latitude' => -23.721440,
            'longitude' => -46.405610,
        ],
        3659 => [ // Rio de Janeiro
            'latitude' => -22.597231,
            'longitude' => -43.691730,
        ],
        4502 => [ // Florianópolis
            'latitude' => -27.595267,
            'longitude' => -48.541812,
        ],
        1630 => [ // Belo Horizonte
            'latitude' => -19.924042,
            'longitude' => -43.944892,
        ],
        4175 => [ // Porto Alegre
            'latitude' => -30.032500,
            'longitude' => -51.230377,
        ],
        2878 => [ // Curitiba
            'latitude' => -25.459935,
            'longitude' => -49.280018,
        ],
    ];

    return [
        'zipcode' => $faker->randomNumber(5).'-999',
        'address' => $faker->streetName,
        'address_number' => $faker->buildingNumber,
        'address_complement' => $faker->secondaryAddress,
        'district' => $faker->cityPrefix,
        'city_id' => $city_id,
        'is_main' => 1,
        'latitude' => $latlon[$city_id]['latitude'],
        'longitude' => $latlon[$city_id]['longitude'],
    ];
});
