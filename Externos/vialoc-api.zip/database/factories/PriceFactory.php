<?php

use Illuminate\Support\Str;
use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(App\Models\Price::class, function (Faker $faker) {
    $faker->addProvider(new \JansenFelipe\FakerBR\FakerBR($faker));

    $price_per_day = $faker->numberBetween(90, 100);

    return [
        'more_than' => 1,
        'price_per_day' => $price_per_day,
        'price_period' => $price_per_day,
    ];
});

$factory->state(App\Models\Price::class, 'week', function (Faker $faker) {
    $faker->addProvider(new \JansenFelipe\FakerBR\FakerBR($faker));

    $price_per_day = $faker->numberBetween(80, 89);

    return [
        'more_than' => 7,
        'price_per_day' => $price_per_day,
        'price_period' => ($price_per_day * 7),
    ];
});

$factory->state(App\Models\Price::class, 'month', function (Faker $faker) {
    $faker->addProvider(new \JansenFelipe\FakerBR\FakerBR($faker));

    $price_per_day = $faker->numberBetween(70, 79);

    return [
        'more_than' => 30,
        'price_per_day' => $price_per_day,
        'price_period' => ($price_per_day * 30),
    ];
});
