<?php

use Illuminate\Support\Str;
use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(App\Models\User::class, function (Faker $faker) {
    $faker->addProvider(new \JansenFelipe\FakerBR\FakerBR($faker));

    $gender = $faker->randomElement(['male', 'female']);
    $status = $faker->randomElement(['active', 'active', 'active', 'pending', 'inactive', 'blocked']);
    $type = $faker->randomElement(['tenant', 'locator']);

    return [
        'uid' => (string) Str::uuid(),
        'name' => $faker->firstName($gender),
        'last_name' => $faker->lastName,
        'email' => $faker->unique()->safeEmail,
        'password' => 'jmugf123', // secret
        'type' => $type,
        'remember_token' => Str::random(10),
        'email_confirmed' => 1,
        'agree_terms' => 1,
        'status' => $status,
    ];
});
