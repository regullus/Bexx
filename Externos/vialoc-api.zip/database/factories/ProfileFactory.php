<?php

use Illuminate\Support\Str;
use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(App\Models\Profile::class, function (Faker $faker) {
    $faker->addProvider(new \JansenFelipe\FakerBR\FakerBR($faker));

    $type = $faker->randomElement(['company', 'person']);

    $cpf = null;
    $birthdate = null;
    $cnpj = null;
    $company_name = null;
    $trading_name = null;
    $state_tax_number = null;
    $phones = null;

    if ($type == 'person') {
        $cpf = onlyNumbers($faker->cpf);
        $birthdate = '15/08/1978';
    } else {
        $cnpj = onlyNumbers($faker->cnpj);
    }

    return [
        'cpf' => $cpf,
        'birthdate' => $birthdate,
        'cnpj' => $cnpj,
        'company_name' => $faker->unique()->company,
        'trading_name' => $faker->company.' '.$faker->companySuffix,
        'phones' => ['phone_1' => '(11) 99999-9999'],
    ];
});
