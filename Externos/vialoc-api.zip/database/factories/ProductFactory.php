<?php

use Illuminate\Support\Str;
use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(App\Models\Product::class, function (Faker $faker) {
    $faker->addProvider(new \JansenFelipe\FakerBR\FakerBR($faker));
    // $faker->addProvider(new Bluemmb\Faker\PicsumPhotosProvider($faker));

    $type = $faker->randomElement(['basculante', 'bau', 'bebidas', 'canavieira', 'carroceria', 'florestal', 'gado', 'graneleiro', 'porta-container', 'prancha', 'refrigerada', 'sider', 'tanque']);
    $license_plate = $faker->randomLetter.$faker->randomLetter.$faker->randomLetter.'-'.$faker->randomNumber(4);
    $floor = $faker->randomElement(['maderite', 'chapa-xadrez']);
    $suspension = $faker->randomElement(['pneumatica', 'mecanica']);
    $status = $faker->randomElement(['draft', 'active', 'active', 'active', 'active', 'inactive', 'suspended']);

    $user_id = $faker->numberBetween(1, 2);

    return [
        'name' => ucfirst($faker->words(3, true)),
        'content' => $faker->text(800),
        'address_id' => $user_id,
        'user_id' => $user_id,
        'type' => $type,
        'brand_id' => $faker->numberBetween(1, 3),
        'width' => $faker->numberBetween(2, 4),
        'length' => $faker->numberBetween(4, 10),
        'axes' => $faker->numberBetween(1, 3),
        'licensing' => '09/2018',
        'year' => $faker->numberBetween(2002, 2018),
        'model' => $faker->word.'-'.$faker->numberBetween(2002, 2018),
        'chassis' => \Str::random(17), // são 17 caracteres
        'renavam' => $faker->randomNumber(5) . $faker->randomNumber(5) . '-' . $faker->randomNumber(1), // são 11 caracters, sendo um dígito verificador
        'antt' => $faker->randomNumber(5) . $faker->randomNumber(4),
        'owner_name' => $faker->name,
        'owner_cpf_cnpj' => $faker->cpf,
        'license_plate' => $license_plate,
        'floor' => $floor,
        'with_tires' => $faker->randomElement([0, 1]),
        'suspension' => $suspension,
        'status' => $status,
    ];
});
