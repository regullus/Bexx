<?php

/**
 * Todas as rotas deste arquivo devem ser chamadas com api/ no prefixo da URI, antes mesmo do prefixo especificado
 * manualmente na rota. Esta configuração é definida em
 * App\Providers\RouteServiceProvider.php.
 */

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

////////////////// REFACTOR START

/*********************************************************************************************
 * PUBLIC
 *********************************************************************************************/

Route::namespace('v1')->prefix('v1')->group(function () {
    /*********************************************************************************************
     * ADMIN - apenas para teste
     *********************************************************************************************/
    Route::namespace('Admin')->prefix('admin')->group(function () {
        Route::get('generate-brands-list', 'ConfigurationController@generateBrandsList');
        Route::get('generate-price-range', 'ConfigurationController@generatePriceRange');
        Route::get('generate-year-range', 'ConfigurationController@generateYearRange');
        Route::get('generate-types-list', 'ConfigurationController@generateTypesList');
        Route::get('generate-all', 'ConfigurationController@generateAll');
    });

    /*********************************************************************************************
     * COMMON / UTILS
     *********************************************************************************************/
    Route::namespace('Common')->prefix('common')->group(function () {
        Route::post('auth/login', 'AuthController@login'); // Rota declarada conforme documentação do Laravel.
        Route::post('auth/refresh', 'AuthController@refresh');
        Route::post('auth/forgot-password', 'AuthController@forgotPassword');
        Route::put('auth/redefine-password', 'AuthController@redefinePassword');

        // Social login
        Route::post('login/{provider}/callback', 'AuthController@socialProviderCallback');
        Route::get('login/{provider}', 'AuthController@socialProviderLogin');

        // Contact
        Route::post('contact', 'ContactController@create');

        // Faq
        Route::get('faq', 'FaqController@index');

        // Newsletter
        Route::post('newsletter', 'NewsletterController@create');
        Route::delete('newsletter/{newsletter_uid}', 'NewsletterController@delete');

        // Page
        Route::get('page/{page_slug}', 'PageController@get');
        Route::get('home', 'PageController@home');

        // Products
        Route::get('utils/products-form-data', 'UtilsController@productsFormData'); // Dados de formulários

        Route::get('products/locator/{user_slug}', 'ProductController@listByLocator');
        Route::get('products', 'ProductController@index');
        Route::get('product/{product_slug}', 'ProductController@view');

        // Users
        Route::post('users/create-user', 'UsersController@createUser'); // Insere usuário com profile pessoa física
        Route::post('users/create-user-logged', 'UsersController@createUserLogged'); // Insere usuário com profile pessoa física
        Route::post('users/resend-confirm-email', 'UsersController@resendConfirmEmail');

        Route::get('users/confirm-email/{token}', 'UsersController@confirmEmail');

        Route::get('utils/get-locations/{location_name}', 'UtilsController@getLocations');
        Route::get('utils/cities-by-state/{state}', 'UtilsController@citiesByState');
        Route::get('utils/zipcode/{zipcode}', 'UtilsController@zipcode');
    });

    /*********************************************************************************************
     * TENANT
     *********************************************************************************************/

    Route::namespace('Tenant')->prefix('tenant')->group(function () {
        Route::post('order/{order}/check-payment', 'OrderController@checkPayment');
    });
});

/*********************************************************************************************
 * PRIVATE
 *********************************************************************************************/

Route::namespace('v1')->prefix('v1')->middleware('auth')->group(function () {
    /*********************************************************************************************
     * ADMIN
     *********************************************************************************************/
    Route::namespace('Admin')->prefix('admin')->middleware('role:admin')->group(function () {
        Route::resource('users', 'UsersController');

        Route::post('faq', 'FaqController@create');

        // Media library
        Route::get('media-library', 'MediaLibraryController@index');
        Route::get('media-library/list', 'MediaLibraryController@list');
        Route::delete('media-library/{media?}', 'MediaLibraryController@destroy');
        Route::post('media-library/upload', 'MediaLibraryController@upload');
    });

    /*********************************************************************************************
     * COMMON / UTILS
     *********************************************************************************************/
    Route::namespace('Common')->prefix('common')->group(function () {
        Route::post('auth/logout', 'AuthController@logout'); // Rota declarada conforme documentação do Laravel.

        // Faq
        Route::post('faq/{faq}/rating', 'FaqController@rating');

        // Dashboard
        Route::get('dashboard', 'DashboardController@index');

        // Users
        // Route::put('users/complementation-user', 'UsersController@updateProfile'); # Insere usuário com profile pessoa física
        Route::put('users/complete-registration', 'UsersController@completeRegistration');
        Route::get('users/me', 'UsersController@me');

        // Route::put('users/update-email', 'UsersController@updateEmail');
        Route::put('users/update-password', 'UsersController@updatePassword');

        // Addresses list
        Route::get('users/addresses', 'AddressController@list');

        // Document get
        Route::get('user/{document_type}/{size?}', 'UsersController@document');

        // Ratings list
        Route::get('users/ratings/locator', 'RatingController@locator');
        Route::get('users/ratings/tenant', 'RatingController@tenant');

        // aqui estão as rotas que precisam ter a sessão validada por tempo
        Route::middleware(['loggedintime'])->group(function () {
            Route::post('users/change-avatar', 'UsersController@changeAvatar');
            Route::put('users/update-profile', 'UsersController@updateProfile');

            // User Address
            Route::post('users/address', 'AddressController@create');
            Route::put('users/address/{address}/set-main', 'AddressController@setMainAddress');
            Route::put('users/address/{address}', 'AddressController@update');
        });

        // Notification
        Route::get('notifications', 'NotificationController@index');
        Route::delete('notifications', 'NotificationController@removeNotifications');
        Route::put('notifications/{notification}', 'NotificationController@setRead');

        // Product
        Route::get('order/{order}/{document_type}/{size?}', 'OrderController@document');

        // Product
        Route::get('product/{product_uid}/{document_type}/{size?}', 'ProductController@document');
    });

    /*********************************************************************************************
     * LOCATOR
     *********************************************************************************************/
    Route::namespace('Locator')->prefix('locator')->group(function () {
        Route::get('dashboard', 'DashboardController@index');

        //Order
        Route::put('order/{order}/confirm', 'OrderController@confirm');
        Route::put('order/{order}/refuse', 'OrderController@refuse');
        Route::put('order/{order}/takeout', 'OrderController@takeout');
        Route::put('order/{order}/devolution', 'OrderController@devolution');
        Route::post('order/{order}/rate-tenant', 'OrderController@rateTenant');
        // Route::post('order/{order}/maintenance', 'OrderController@maintenance'); // remover este futuramente

        Route::get('order/list-locator-pending-confirmation', 'OrderController@listLocatorPendingConfirmation');
        Route::get('order/{order}/messages', 'OrderController@messages');
        Route::post('order/{order}/message', 'OrderController@createMessage');
        Route::put('order/{order}/change-address', 'OrderController@changeAddress');
        Route::get('order/{order}', 'OrderController@view');
        Route::get('orders', 'OrderController@index');

        // Product
        Route::put('products/messages/{questionAnswer}/read', 'ProductController@messageRead');
        Route::get('products/messages', 'ProductController@messages');
        Route::get('products', 'ProductController@index');
        Route::get('product/{product_uid}/view', 'ProductController@view');
        Route::put('product/{product_uid}/order-images', 'ProductController@orderImages');

        // aqui estão as rotas que precisam ter a sessão validada por tempo
        Route::middleware(['loggedintime'])->group(function () {
            Route::post('product/create', 'ProductController@create');
            Route::put('product/{product_uid}/update', 'ProductController@update');
            Route::post('product/{product_uid}/question/{questionAnswer}', 'ProductController@answer');

            Route::post('product/{product_uid}/prices', 'ProductController@prices');
            Route::delete('product/{product_uid}/delete-image/{image_id}', 'ProductController@deleteImage');
            Route::delete('product/{product_uid}/delete-documents/{image_id}', 'ProductController@deleteDocuments');
            Route::put('product/{product_uid}/set-status', 'ProductController@setStatus');
        });

        Route::put('product/{product_uid}/set-featured-image', 'ProductController@setFeaturedImage');
        Route::post('product/{product_uid}/upload-documents', 'ProductController@uploadDocuments');
        Route::post('product/{product_uid}/upload-image/{tag?}', 'ProductController@uploadImage');
        Route::get('product/{product_uid}/messages', 'ProductController@messagesByProduct');

        // Rating
        Route::get('ratings/{direction}', 'RatingController@index'); // direction: received || sent
    });

    /*********************************************************************************************
     * TENANT
     *********************************************************************************************/
    Route::namespace('Tenant')->prefix('tenant')->group(function () {
        Route::get('dashboard', 'DashboardController@index');

        Route::post('product/{product_uid}/question', 'ProductController@createQuestion');
        Route::put('products/messages/{questionAnswer}/read', 'ProductController@messageRead');
        Route::get('products/messages', 'ProductController@messages');

        // Favorites
        Route::post('favorites/create', 'FavoriteController@create');
        Route::get('favorites', 'FavoriteController@get');
        Route::delete('favorites/product/{product_uid}', 'FavoriteController@delete');

        // Order
        Route::get('orders/{status?}', 'OrderController@index');
        Route::put('order/{order}/cancel', 'OrderController@cancel');
        Route::put('order/{order}/change-payment', 'OrderController@changePaymentMethod');
        Route::post('order/{order}/payment', 'OrderController@payment');
        Route::put('order/{order}/takeout', 'OrderController@takeout');
        Route::put('order/{order}/devolution', 'OrderController@devolution');
        Route::post('order/{order}/rate-locator', 'OrderController@rateLocator');
        Route::post('order/{order}/rate-product', 'OrderController@rateProduct');
        Route::get('order/{order}', 'OrderController@view');
        Route::post('order', 'OrderController@create'); // Post real

        // Rating
        Route::get('ratings/{direction}', 'RatingController@index'); // direction: received || sent
    });
});

////////////////// REFACTOR END

// testing
Route::any('test', function(){
    $user =  \App\Models\User::findOrFail(2);
    $data =  (object) array(
        'test' => rand(),
    );
    $user->notify(new \App\Notifications\TestBroadcastNotification($data));
    return response()->json($data);
});

/*
 * O comportamento padrão do Laravel para usuário não autenticado é redirecioná-lo para uma
 * página de login porém, por ser uma API, ela deve apenas retornar o código 401 com a mensagem Unauthenticated. Para
 * isto segui as coordenadas da documentação do Laravel Auth e implementei o método unauthenticated() em
 * Exceptions/Handler.php.
 *
 */

/*
 * O prefixo das rotas do Site não possuem o termo "site" declarado, ao contrário do common e do admin. Em outras
 * palavras, no Swagger ou em qq cliente eu devo especificar o recurso com o prefixo apenas quando a requisição for
 * feita a um endpoint de common ou admin. Para as rotas que chamam Controllers no diretorio v1/Site basta eu declarar
 * v1/recurso. No de common v1/common/recurso e admin v1/admin/recurso.
 */

/*********************************************************************************************
 * PUBLIC
 *********************************************************************************************/
Route::namespace('v1\Site')->prefix('v1')->group(function () {
    // prefix() especifica o namespace (subdiretório dentro de Controllers).

    // Product list
    // Route::get('products/owner/{user_slug}', 'ProductController@listByOwner');
    // Route::get('products', 'ProductController@list');
    // Route::get('product/{product_slug}', 'ProductController@details');

    // Route::post('product', 'ProductController@post');
    // Route::get('product', 'ProductController@get');
});

/*********************************************************************************************
 * SITE
 *********************************************************************************************/
Route::namespace('v1\Site')->prefix('v1')->middleware('auth')->group(function () {
    // prefix() especifica o namespace (subdiretório dentro de Controllers).

    // Product resource
    // Route::get('products/owner-list', 'ProductController@ownerList');
    // Route::get('products/owner-messages', 'ProductController@ownerProductsMessages');

    // Route::post('product/{product_uid}/upload-image', 'ProductController@uploadImage');
    // Route::get('product/{product_uid}/owner-details', 'ProductController@ownerDetails');
    // Route::get('product/{product_uid}/owner-product-messages', 'ProductController@ownerProductMessages');
    // Route::get('product/{product_uid}/{document_type}/{size?}', 'ProductController@document');

    // Route::middleware(['loggedintime'])->group(function () { // aqui estão as rotas que precisam ter a sessão validada por tempo
    // Route::post('product/create', 'ProductController@create');
    // Route::post('product/{product_uid}/prices', 'ProductController@prices');
    // Route::put('product/{product_uid}/update', 'ProductController@update');
    // Route::delete('product/{product_uid}/delete-image/{image_id}', 'ProductController@deleteImage');
    // Route::put('product/{product_uid}/order-images', 'ProductController@orderImages');
    // Route::put('product/{product_uid}/set-featured-image', 'ProductController@setFeaturedImage');
    // Route::post('product/{product_uid}/upload-documents', 'ProductController@uploadDocuments');
    // Route::delete('product/{product_uid}/delete-documents/{image_id}', 'ProductController@deleteDocuments');
    // Route::put('product/{product_uid}/set-status', 'ProductController@setStatus');

    // Route::post('product/{product_uid}/question/{question?}', 'ProductController@createQuestionAnswer');
    // });

    // Order
    Route::post('order', 'OrderController@create'); // Post real
    Route::get('orders/{status?}', 'OrderController@list');

    Route::get('order/{order}', 'OrderController@details');
});
