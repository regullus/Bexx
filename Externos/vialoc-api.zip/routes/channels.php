<?php

/*
|--------------------------------------------------------------------------
| Broadcast Channels
|--------------------------------------------------------------------------
|
| Here you may register all of the event broadcasting channels that your
| application supports. The given channel authorization callbacks are
| used to check if an authenticated user can listen to the channel.
|
*/

Broadcast::channel('users.{uid}', function ($user, $uid) {
    \Log::info('Inside broadcast channel');
    \Log::info('users.' . $uid);
    \Log::info($user);
    \Log::info($user->uid === $uid);
    return $user->uid === $uid;
});
