<?php

namespace App\Http\Middleware;

use Closure;
use DateTime;
use Exception;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

/**
 * Quando o usuário não estiver autenticado, o comportamento padrão do Laravel seria redirecioná-lo para uma
 * página de login, porém, por ser uma API ela deve apenas alterar o código de retorno para 401. Para isto
 * segui as coordenadas da documentação do Laravel Auth e implementei o método unauthenticated em
 * Exceptions/Handler.php.
 */
class LoggedInTime
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (Auth::check()) {
            $user = auth()->user();

            $loggedin_at = new DateTime($user->loggedin_at);
            $now = new DateTime('now');

            $diff = $now->diff($loggedin_at);

            if ($diff->h > config('c7.login_expires')) {
                return response()->json(['message' => config('error.login_expired')], 406);
            }
        }

        return $next($request);
    }
}
