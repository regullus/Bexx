<?php

namespace App\Http\Requests\v1\Common\Address;

use Illuminate\Foundation\Http\FormRequest;

class AddressCreateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'label' => 'required|max:191',
            'zipcode' => 'required|max:9',
            'address' => 'required|max:191',
            'address_number' => 'required|integer',
            'address_complement' => 'max:50',
            'city_id' => 'required|integer|exists:cities,id',
            // 'is_main' => 'required|in:0,1'
        ];
    }

    /**
     * Get custom attributes for validator errors.
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'label' => 'Identificador',
        ];
    }
}
