<?php

namespace App\Http\Requests\v1\Common\Address;

use Illuminate\Foundation\Http\FormRequest;

class AddressUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            // 'id' => 'required|exists:addresses',
            'label' => 'filled|max:191',
            'zipcode' => 'filled|max:9',
            'address' => 'filled|max:191',
            'address_number' => 'filled|integer',
            'address_complement' => 'max:50',
            'city_id' => 'filled|integer|exists:cities,id',
            'is_main' => 'filled|in:0,1',
        ];
    }

    /**
     * Get custom attributes for validator errors.
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'label' => 'Identificador',
        ];
    }
}
