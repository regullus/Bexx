<?php

namespace App\Http\Requests\v1\Common\Users;

/*
 * Parent
 */
use Illuminate\Foundation\Http\FormRequest;

class RegisterCompanyRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'id' => 'unique:users|integer',
            'email' => 'required|email|unique:users',
            'password' => 'required|confirmed',
            'profile.cnpj' => 'required|unique:profiles,cnpj',
            'profile.company_name' => 'required|unique:profiles|max:191',
            'profile.trading_name' => 'required|max:191',
            'profile.state_tax_number' => 'unique:profiles,state_tax_number',
        ];
    }
}
