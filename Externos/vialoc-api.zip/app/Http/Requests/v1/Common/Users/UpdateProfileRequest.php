<?php

namespace App\Http\Requests\v1\Common\Users;

use Illuminate\Foundation\Http\FormRequest;
use Waavi\Sanitizer\Laravel\SanitizesInput;

class UpdateProfileRequest extends FormRequest
{
    use SanitizesInput;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $user = auth()->user();

        $rules = [
            'email' => 'email|unique:users,email,'.$user->id,

            //-- Pessoa física ou Pessoa Jurídica
            'profile.type' => 'in:person,company',
                //-- Pessoa física
                'profile.cpf' => 'required_if:profile.type,person|nullable|unique:profiles,cpf,'.$user->profile->id,
                'profile.birthdate' => 'required_if:profile.type,person|nullable|date_format:"d/m/Y"',

                //-- Pessoa jurídica
                'profile.cnpj' => 'required_if:profile.type,company|nullable|unique:profiles,cnpj,'.$user->profile->id,
                'profile.company_name' => 'required_if:profile.type,company|nullable|max:191',
                'profile.trading_name' => 'required_if:profile.type,company|nullable|max:191',
        ];

        return $rules;
    }

    /**
     * Sanitization.
     */
    public function filters()
    {
        return [
            'profile.company_name' => 'strip_tags|escape',
            'profile.trading_name' => 'strip_tags|escape',
        ];
    }
}
