<?php

namespace App\Http\Requests\v1\Common\Users;

use Illuminate\Foundation\Http\FormRequest;
use Waavi\Sanitizer\Laravel\SanitizesInput;

class CompleteRegistrationRequest extends FormRequest
{
    use SanitizesInput;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $user = auth()->user();

        return [
            // 'type' => 'required|in:tenant,locator',
            'email' => 'email|unique:users,email,'.$user->id,
            'password' => 'required|min:3',
            'agree_terms' => 'required|boolean',

            'name' => 'max:200',
            'last_name' => 'max:200',
        ];
    }

    /**
     * Sanitization.
     */
    public function filters()
    {
        return [
            'email' => 'escape|lowercase',
            'name'  => 'strip_tags|escape',
            'last_name' => 'strip_tags|escape',
        ];
    }
}
