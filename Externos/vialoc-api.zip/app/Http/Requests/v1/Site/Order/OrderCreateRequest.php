<?php

namespace App\Http\Requests\v1\Site\Order;

use Illuminate\Foundation\Http\FormRequest;

class OrderCreateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'product_uid' => 'required|exists:products,uid',
            'date_start' => 'required|date|after:yesterday', // a data inicial tem q vir depois de ontem, de hoje pra frente.
            'date_end' => 'required|date|after:date_start', // a data final deve ser maior (after) que a data inicial (date_ini)
        ];
    }
}
