<?php

namespace App\Http\Requests\v1\Site\Order;

use Illuminate\Foundation\Http\FormRequest;

class OrderPaymentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'payment_method' => 'required|in:bank-slip,credit-card,debit-card',
            'payment_method_option' => 'required_if:payment_method,credit-card,debit-card',
            'card.number' => 'required_if:payment_method,credit-card,debit-card',
            'card.expiration.month' => [
                'required_if:payment_method,credit-card,debit-card',
                function ($attribute, $value, $fail) {
                    if (((int) request()->input('card.expiration.year') == (int) date('Y')) && ((int) $value < (int) date('m'))) {
                        $fail('O cartão está expirado, por favor cadastre outro cartão.');
                    }
                }
            ],
            'card.expiration.year' => [
                'required_if:payment_method,credit-card,debit-card',
                function ($attribute, $value, $fail) {
                    if ((int) $value < (int) date('Y')) {
                        $fail('O cartão está expirado, por favor cadastre outro cartão.');
                    }
                }
            ],
            'card.cvv' => 'required_if:payment_method,credit-card',
            'card.holder' => 'required_if:payment_method,credit-card,debit-card',
        ];
    }
}
