<?php

namespace App\Http\Requests\v1\Site\Order;

use Illuminate\Foundation\Http\FormRequest;

class OrderUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'id' => 'required|exists:orders',
            'product_id' => 'filled|exists:products,id',
            'date_start' => 'filled|date',
            'date_end' => 'filled|date',
        ];
    }

    /*
        public function withValidator($validator) {
            $validator->after(function ($validator) {
                if($this->has('user_id')) {
                    $validator->errors()->add('user_id', config('error.user_not_allowed'));
                }
            });
        }
    */
}
