<?php

namespace App\Http\Requests\v1\Site\Product;

use Illuminate\Foundation\Http\FormRequest;
use Waavi\Sanitizer\Laravel\SanitizesInput;

class ProductCreateRequest extends FormRequest
{
    use SanitizesInput;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|max:200',
            'brand_id' => 'required|integer|exists:brands,id',
            'type' => 'required|max:100',
            'year' => 'required|digits:4',
            'model' => 'required',
            'length' => 'required',
            'width' => 'required',
            // 'city_id' => 'required|integer|exists:cities,id',
            'floor' => 'required',
            'suspension' => 'required',
            'address_id' => 'required_if:address_zipcode,null',
            'address.zipcode' => 'required_if:address_id,null',
            'address.address' => 'required_if:address_id,null',
            'address.address_number' => 'required_if:address_id,null',
            'address.district' => 'required_if:address_id,null',
            'address.city_id' => 'required_if:address_id,null',
            'address.state_code' => 'required_if:address_id,null',
            'content' => 'required|min:3',
        ];
    }

    /**
     * Sanitization.
     */
    public function filters()
    {
        return [
            'name' => 'strip_tags',
            'type' => 'strip_tags',
            'model' => 'strip_tags',
            'floor' => 'strip_tags',
            'suspension' => 'strip_tags',
            'address.zipcode' => 'strip_tags',
            'address.address' => 'strip_tags',
            'address.address_number' => 'strip_tags',
            'address.district' => 'strip_tags',
            'address.city_id' => 'strip_tags',
            'address.state_code' => 'strip_tags',
            'content' => 'strip_tags',
        ];
    }
}
