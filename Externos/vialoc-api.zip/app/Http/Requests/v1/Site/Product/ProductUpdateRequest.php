<?php

namespace App\Http\Requests\v1\Site\Product;

use Illuminate\Foundation\Http\FormRequest;
use Waavi\Sanitizer\Laravel\SanitizesInput;

class ProductUpdateRequest extends FormRequest
{
    use SanitizesInput;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            // Step 1
            'name' => 'required_if:step,Step1|max:200',
            'brand_id' => 'required_if:step,Step1|integer|exists:brands,id',
            'type' => 'required_if:step,Step1|max:100',
            'year' => 'required_if:step,Step1|digits:4',
            'model' => 'required_if:step,Step1',
            'length' => 'required_if:step,Step1',
            'width' => 'required_if:step,Step1',
            'floor' => 'required_if:step,Step1|max:30',
            'suspension' => 'required_if:step,Step1',
            'address_id' => [function ($attribute, $value, $fail) {
                if (empty($value) && empty(request()->input('address.zipcode')) && request()->input('step') == 'Step1') {
                    $fail('Você precisa selecionar um endereço existente ou cadastrar um novo');
                }
            }],
            'address.zipcode' => 'required_if:address_id,nullrequired_if:step,Step1',
            'address.address' => 'required_if:address_id,nullrequired_if:step,Step1',
            'address.address_number' => 'required_if:address_id,nullrequired_if:step,Step1',
            'address.district' => 'required_if:address_id,nullrequired_if:step,Step1',
            'address.city_id' => 'required_if:address_id,nullrequired_if:step,Step1',
            'address.state_code' => 'required_if:address_id,nullrequired_if:step,Step1',
            'content' => 'required_if:step,Step1|min:3',

            // Step 2
            // 'chassis' => 'max:50',
            // 'renavam' => 'max:50',
            // 'antt' => 'max:50',
            // 'licensing' => 'max:50',

            // Step 3
            'prices.*.price_period' => 'required_if:step,Step3',
            // 'prices.*.price_per_day' => 'required_if:step,Step3',
            'prices.*.more_than' => 'required_if:step,Step3',
        ];
    }

    /**
     * Sanitization.
     */
    public function filters()
    {
        return [
            'name' => 'strip_tags',
            'type' => 'strip_tags',
            'model' => 'strip_tags',
            'floor' => 'strip_tags',
            'suspension' => 'strip_tags',
            'address.zipcode' => 'strip_tags',
            'address.address' => 'strip_tags',
            'address.address_number' => 'strip_tags',
            'address.district' => 'strip_tags',
            'address.city_id' => 'strip_tags',
            'address.state_code' => 'strip_tags',
            'content' => 'strip_tags',

            // Step 1
            'name' => 'strip_tags',
            'type' => 'strip_tags',
            'model' => 'strip_tags',
            'floor' => 'strip_tags',
            'suspension' => 'strip_tags',
            'address.zipcode' => 'strip_tags',
            'address.address' => 'strip_tags',
            'address.address_number' => 'strip_tags',
            'address.district' => 'strip_tags',
            'address.city_id' => 'strip_tags',
            'address.state_code' => 'strip_tags',
            'content' => 'strip_tags',

            // Step 3
            'prices.*.price_period' => 'strip_tags',
            // 'prices.*.price_per_day' => '',
            'prices.*.more_than' => 'strip_tags',
        ];
    }
}
