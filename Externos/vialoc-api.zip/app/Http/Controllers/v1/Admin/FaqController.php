<?php

namespace App\Http\Controllers\v1\Admin;

/*
 * Parent
 */
use Illuminate\Http\Request;
/*
 * Vendor packages
 */

use App\Services\v1\Admin\FaqService;
/*
 * User resources.
 */
use App\Http\Controllers\Controller;
use App\Transformers\v1\FaqFullTransformer;
use App\Http\Requests\v1\Admin\Faq\FaqCreateRequest;

class FaqController extends Controller
{
    private $service;

    public function __construct(FaqService $service)
    {
        $this->service = $service;
    }

    public function create(FaqCreateRequest $request)
    {
        return fractal()
            ->item($this->service->create(auth()->user(), $request->all()), new FaqFullTransformer())
            ->respond(201);
    }
}
