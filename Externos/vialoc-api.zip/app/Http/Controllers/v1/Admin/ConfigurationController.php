<?php

namespace App\Http\Controllers\v1\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Traits\DefineSearchFiltersTrait;

class ConfigurationController extends Controller
{
    use DefineSearchFiltersTrait;

    public function __construct()
    {
        //
    }

    public function generateBrandsList(Request $request)
    {
        self::cacheBrandsList();

        return response()->json(\Cache::get('brands_list'), 201);
    }

    public function generatePriceRange(Request $request)
    {
        self::cachePriceRange();

        return response()->json([\Cache::get('price_range')], 201);
    }

    public function generateYearRange(Request $request)
    {
        self::cacheYearRange();

        return response()->json([\Cache::get('year_range')], 201);
    }

    public function generateTypesList(Request $request)
    {
        self::cacheTypesList();

        return response()->json([\Cache::get('types_list')], 201);
    }

    public function generateAll(Request $request)
    {
        $all = self::cacheAllFormData();

        return response()->json($all, 201);
    }
}
