<?php

namespace App\Http\Controllers\v1\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\User;
use App\Services\v1\Common\AuthService;
use App\Services\v1\Common\UserService;
use App\Transformers\v1\Admin\UserEditTransformer;
use App\Transformers\v1\Admin\UserItemTransformer;

class UsersController extends Controller
{
    protected $service, $user;

    public function __construct(UserService $service, AuthService $authService)
    {
        $this->service = $service;
        $this->authService = $authService;
        $this->user = \Auth::check() ? \Auth::user() : null;
    }

    public function index()
    {
        $collection = User::paginate(config('c7.rows_per_page'));
        $users_array = $collection->transformWith(new UserItemTransformer())->toArray();

        $pagination = \C7Utils::buildPaginator($users_array, $collection);
        return response()->json($pagination);
    }

    public function create()
    {
        //
    }

    public function store()
    {
        //
    }

    public function show()
    {
        //
    }

    public function edit(Request $request, User $user)
    {
        return fractal($user, new UserEditTransformer())->parseIncludes(['profile']);
    }

    public function update()
    {
        //
    }

    public function destroy()
    {
        //
    }
}
