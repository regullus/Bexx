<?php

namespace App\Http\Controllers\v1\Admin;

use App\Models\Media;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Transformers\v1\MediaTransformer;
use App\Services\v1\Site\MediaLibraryService;
use App\Http\Requests\v1\Site\MediaLibrary\MediaUploaderRequest;

class MediaLibraryController extends Controller
{
    protected $media;

    public function __construct(MediaLibraryService $MediaLibraryService)
    {
        $this->mediaLibraryService = $MediaLibraryService;
    }

    public function index()
    {
        $media = Media::paginate(120);

        // return view('adm.media-library.index', compact('media'));
    }

    public function list(Request $request)
    {
        $media = $this->mediaLibraryService->list($request);

        return fractal()->collection(
            $media,
            new MediaTransformer()
        );
    }

    public function destroy(Media $media)
    {
        if ($media_id = $this->mediaLibraryService->destroy($media)) {
            return $media_id;
        }

        return 'O arquivo de mídia não foi encontrado.';
    }

    public function upload(MediaUploaderRequest $request)
    {
        $file = $request->file('file');

        $file_stored = $this->mediaLibraryService->create($file);

        return fractal()->item(
            $file_stored,
            new MediaTransformer()
        );
    }
}
