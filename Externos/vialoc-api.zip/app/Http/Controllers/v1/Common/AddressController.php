<?php

namespace App\Http\Controllers\v1\Common;

use App\Http\Controllers\Controller;


use App\Models\Address;
use App\Services\v1\Common\AddressService;
use App\Transformers\v1\AddressFullTransformer;
use App\Http\Requests\v1\Common\Address\AddressCreateRequest;
use App\Http\Requests\v1\Common\Address\AddressUpdateRequest;

class AddressController extends Controller
{
    public function __construct()
    {
        $this->service = new AddressService();
    }

    public function create(AddressCreateRequest $request)
    {
        return fractal()
            ->item($this->service->create($request->all()), new AddressFullTransformer())
            // ->parseIncludes(['city.state'])
            ->respond(201);
    }

    public function update(AddressUpdateRequest $request, Address $address)
    {
        return fractal()
            ->item($this->service->update($address, $request->all()), new AddressFullTransformer());
            // ->parseIncludes(['city.state']);
    }

    public function list()
    {
        return fractal()
            ->collection(auth()->user()->addresses, new AddressFullTransformer());
            // ->parseIncludes(['city.state'])
    }

    public function setMainAddress(Address $address)
    {
        $addresses = $this->service->setMainAddress($address);

        return fractal()
            ->collection($addresses, new AddressFullTransformer());
            // ->parseIncludes(['city.state'])
    }
}
