<?php

namespace App\Http\Controllers\v1\Common;

use Carbon\Carbon;
use App\Models\Order;
use App\Http\Controllers\Controller;
use App\Transformers\v1\NotificationTransformer;
use App\Transformers\v1\FavoriteSummaryTransformer;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $response = [];

        $user = auth()->user();

        $response['favorites'] = fractal($user->favorites()->take(5)->get(), new FavoriteSummaryTransformer())->toArray();
        $response['notifications'] = fractal($user->notifications()->orderBy('created_at', 'desc')->take(10)->get(), new NotificationTransformer())->toArray();

        return response()->json($response);
    }
}
