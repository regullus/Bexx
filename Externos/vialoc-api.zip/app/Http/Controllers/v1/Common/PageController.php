<?php

namespace App\Http\Controllers\v1\Common;

use App\Models\Page;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Transformers\v1\PageFullTransformer;
use App\Transformers\v1\ProductSummaryTransformer;

class PageController extends Controller
{
    // protected $service;

    public function __construct()
    {
        // $this->service = $service;
    }

    public function get(Request $request, Page $page_slug)
    {
        return fractal()
            ->item($page_slug, new PageFullTransformer())
            ->respond(200);
    }

    public function home()
    {
        $typesOp = [];
        $types = shuffleAssocArray((new Product)->list_types);
        $types_i = 0;
        // $types = array_slice($types, 0, 6);

        // Pega um de cada categoria
        foreach ($types as $k => $v) {
            if ($types_i >= 6) {
                break;
            }
            $product_get = Product::where('status', 'active')->where('type', $k)->inRandomOrder()->first();
            if (! $product_get) {
                continue;
            }

            $product = fractal()
                ->item($product_get, new ProductSummaryTransformer())
                ->parseIncludes(['address', 'profile'])
                ->toArray();

            $typesOp[$k] = [
                'label' => $v,
                'product' => $product,
            ];

            $types_i++;
        }

        ksort($typesOp);

        return response()->json($typesOp, 200);
    }
}
