<?php

namespace App\Http\Controllers\v1\Common;

use App\Models\Order;
use App\Traits\DocumentTrait;
use App\Http\Controllers\Controller;
use Symfony\Component\Translation\Exception\NotFoundResourceException;

class OrderController extends Controller
{
    use DocumentTrait;

    protected $user;

    public function __construct()
    {
        $this->user = auth()->user();
    }

    public function document(Order $order, $document_type, $size)
    {
        $product = $order->product;

        // verifica se é o proprietário
        if (! $this->user->can('update', $product) && ! $this->user->can('updateAsTenant', $order) && ! $this->user->can('updateAsLocator', $order)) {
            abort(404);
        }

        // verifica se o pedido está em algum status que permita a visualização do documento
        if (! $order->isStatus(['pending-takeout', 'active', 'finished'])) {
            abort(404);
        }

        try {
            $base64 = $this->getDocuments($order, $document_type, $size);
            return response()->json($base64, 200);
        } catch (NotFoundResourceException $e) {
            return response()->json($e->getMessage(), $e->getCode());
        }
    }
}
