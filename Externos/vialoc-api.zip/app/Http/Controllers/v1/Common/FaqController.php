<?php

namespace App\Http\Controllers\v1\Common;

/*
 * Parent
 */
use App\Models\Faq;
/*
 * Vendor packages
 */

use App\Models\FaqRating;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
/*
 * User resources.
 */
use App\Transformers\v1\FaqFullTransformer;
use App\Transformers\v1\FaqRatingFullTransformer;

class FaqController extends Controller
{
    public function index(Request $request)
    {
        return fractal()
            ->collection(Faq::all(), new FaqFullTransformer())
            ->parseIncludes(['rating'])
            ->respond(200);
    }

    public function rating(Request $request, Faq $faq)
    {
        $ratings = $faq->faq_ratings()->where('user_id', auth()->user()->id);
        if ($ratings->count()) {
            return response()->json([], 410);
        }

        $request->merge(['user_id' => auth()->user()->id]);

        return fractal()
            ->item($faq->faq_ratings()->create($request->all()), new FaqRatingFullTransformer())
            ->respond(201);
    }
}
