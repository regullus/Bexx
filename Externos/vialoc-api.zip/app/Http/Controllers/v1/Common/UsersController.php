<?php

namespace App\Http\Controllers\v1\Common;

/*
 * Parent
 */
use Exception;
use Illuminate\Support\Str;
/*
 * Vendor packages
 */

use App\Traits\DocumentTrait;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Services\v1\Common\AuthService;
use App\Services\v1\Common\UserService;
use App\Transformers\v1\UserFullTransformer;
/*
 * User resources.
 */
use Illuminate\Auth\AuthenticationException;
use App\Http\Requests\v1\Common\Users\CreateUserRequest;
use App\Http\Requests\v1\Common\Users\ChangeAvatarRequest;
use App\Http\Requests\v1\Common\Users\UpdateProfileRequest;
use App\Http\Requests\v1\Common\Users\ChangePasswordRequest;
use App\Http\Requests\v1\Common\Users\CompleteRegistrationRequest;
use App\Exceptions\EmailAlreadyExistsException;
use Symfony\Component\Translation\Exception\NotFoundResourceException;

class UsersController extends Controller
{
    protected $service;

    protected $user;

    use DocumentTrait;

    public function __construct(UserService $service, AuthService $authService)
    {
        $this->service = $service;
        $this->authService = $authService;
        $this->user = \Auth::check() ? \Auth::user() : null;
    }

    public function createUser(CreateUserRequest $request)
    {
        return fractal()
            ->item($this->service->createUser($request->all()), new UserFullTransformer())
            ->parseIncludes(['address', 'profile'])
            ->respond(201);
    }

    /**
     * Cria usuário e loga, retornando o usuário criado e seu token.
     *
     * Este endpoint foi criado apenas em função do retorno, por isso o request é o mesmo do createUser(). Ao criar um
     * usuário, o front precisa receber como retorno o usuário e seu token porém, não seria correto fazer o metodo
     * create() retornar qualquer coisa (como o token por exemplo) além do usuário.
     *
     * Sendo assim, este método tem a função de criar e logar um usuário, e retornar as informações de usuário e token.
     *
     * O Transformer será utilizado pontualmente, apenas pra obedecer a lógica de retorno definida porém, não será
     * retornado diretamente como é feito na maioria dos endpoints. Lembrando que o Transformer deve modificar apenas
     * informações de banco e nesse caso eu tenho informações do Request que devem ser consideradas (usuário e senha)
     * para gerar o token.
     *
     */
    public function createUserLogged(CreateUserRequest $request)
    {
        $user = fractal()
            ->item($this->service->createUser($request->all()), new UserFullTransformer())
            ->parseIncludes(['address', 'profile'])
            ->toArray();

        $token = auth()->attempt(request(['email', 'password']));
        $ttl = auth()->factory()->getTTL();
        $authData = $this->authService->buildTokenInformation($token, $ttl);

        return response()
            ->json(['user' => $user, 'auth' => $authData], 200)
            ->cookie('token', $token, config('jwt.ttl'));
    }

    /**
     * Completa o cadastro do usuário que se registrou por meio de uma rede social.
     */
    public function completeRegistration(CompleteRegistrationRequest $request)
    {
        $data = $request->all();
        $data['status'] = 'pending';

        $user = fractal()
            ->item($this->service->updateUser($data), new UserFullTransformer())
            ->parseIncludes(['address', 'profile'])
            ->toArray();

        $token = auth()->attempt(request(['email', 'password']));
        $ttl = auth()->factory()->getTTL();
        $authData = $this->authService->buildTokenInformation($token, $ttl);

        return response()
            ->json(['user' => $user, 'auth' => $authData], 200)
            ->cookie('token', $token, config('jwt.ttl'));
    }

    public function updateProfile(UpdateProfileRequest $request)
    {
        try {
            $user = $this->service->updateProfile($request->all()); // toda a validação fica no request... se chegar até aqui considero que vai inserir.
            return fractal()
                ->item($user, new UserFullTransformer)
                ->parseIncludes(['address', 'profile'])
                ->respond(200); // 200 pois eu altero e retorno a entity
        } catch (EmailAlreadyExistsException $e) {
            \Log::info($e->getFile().' - '.$e->getMessage().' - '.$e->getCode());

            return response()->json($e->getMessage(), $e->getCode());
        }
    }

    public function changeAvatar(ChangeAvatarRequest $request)
    {
        $avatar = $this->service->changeAvatar($request);
        $avatar_url = url($avatar->metadata['thumbnails']['default']['path']).'?nocache='.Str::random(5);

        return response()->json(['avatar' => $avatar_url]);
    }

    /**
     * Rotina acionada através do click no link enviado via email, tanto no cadastro de usuário quanto no complemento de
     * cadastro quando o usuário altera o email.
     *
     * Parameters types: string, number, integer, boolean, array
     * Parameters place in: query, path, body, formData, header
     *
     * Não consegui entender consumes e produces
     *
     */
    public function confirmEmail($token)
    {
        try {
            $this->service->confirmEmail($token);
            return response()->json([], 200);
        } catch (NotFoundResourceException $e) {
            \Log::error($e->getFile().' - '.$e->getMessage().' - '.$e->getCode());

            return response()->json($e->getMessage(), $e->getCode());
        }
    }

    public function me()
    {
        return fractal()
            ->item($this->user, new UserFullTransformer)
            ->parseIncludes(['address', 'profile'])
            ->respond(200); // 200 pois eu altero e retorno a entity
    }

    public function updatePassword(ChangePasswordRequest $request)
    {
        try {
            return fractal()
                ->item($this->service->changePassword($request), new UserFullTransformer)
                ->parseIncludes(['address', 'profile'])
                ->respond(200); // 200 pois eu altero e retorno a entity
        // } catch(AuthenticationException $e) {
        //     return response()->json(['error' => 'Unauthenticated'], 403); #Sem Transformer pois o retorno é muito simples.
        } catch (Exception $e) { // senha incorreta
            return response()->json([
                'errors' => [
                    'generic' => ['A senha atual inserida está incorreta.'],
                ],
            ], 422);
        }
    }

    public function resendConfirmEmail()
    {
        $user = auth()->user();
        $this->service->resendConfirmEmail($user);

        return response()->json(['to_email' => ($user->email_intended ?? $user->email)]);
    }

    public function document($document_type, $size)
    {
        try {
            $base64 = $this->getDocuments(auth()->user(), $document_type, $size);
            return response()->json($base64, 200);
        } catch (NotFoundResourceException $e) {
            return response()->json($e->getMessage(), $e->getCode());
        }
    }
}
