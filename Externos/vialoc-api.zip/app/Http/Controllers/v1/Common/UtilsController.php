<?php

namespace App\Http\Controllers\v1\Common;

use C7WsQuery;
use Exception;
use App\Models\City;
use App\Models\User;
use App\Models\Brand;
use App\Models\State;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Transformers\v1\BrandTransformer;
use App\Transformers\v1\StateTransformer;
use App\Transformers\v1\CityFullTransformer;
use Symfony\Component\Translation\Exception\NotFoundResourceException;

class UtilsController extends Controller
{
    protected $product;

    public function __construct(Product $product, User $user)
    {
        $this->product = $product;
        $this->user = $user;
    }

    public function productsFormData()
    {
        $brands = Brand::where('status', 'active')->orderBy('name', 'asc')->get();

        return response()->json([
            'platform_version' => config('c7.platform_version'),
            'brands' => fractal()->collection($brands, new BrandTransformer()),
            'floors' => $this->product->list_floors,
            'suspensions' => $this->product->list_suspensions,
            'status' => $this->product->publicStatus(),
            'types' => $this->product->list_types,
            'filters' => [
                'price_range' => \Cache::get('price_range'),
                'year_range' => \Cache::get('year_range'),
                'brands_list' => \Cache::get('brands_list'),
                'types_list' => \Cache::get('types_list'),
            ],
        ]);
    }

    public function citiesByState($state_code)
    {
        $cities = City::where('state_code', $state_code)->orderBy('name', 'asc')->get();

        return fractal()->collection($cities, new CityFullTransformer());
    }

    public function zipcode($zipcode)
    {
        try {
            $address = C7WsQuery::zipcode($zipcode);
            if (! $address) {
                return response()->json([
                    'errors' => [
                        'zipcode' => ['CEP não encontrado.'],
                    ],
                ], 422);
            }

            return response()->json($address);
        } catch (NotFoundResourceException $e) {
            return response()->json($e->getMessage(), $e->getCode());
        }
    }

    public function getLocations($location_name)
    {
        if (strlen($location_name) < 3) {
            return response()->json([
                'errors' => [
                    'generic' => ['Digite 3 caracteres ou mais, para efetuar a busca dos locais.'],
                ],
            ], 422);
        }
        $states = State::select('name', 'code')->where('name', 'like', '%'.$location_name.'%')->take(10)->get();
        $cities = City::where('name', 'like', '%'.$location_name.'%')->take(10)->get();

        return response()->json([
            'states' => fractal()->collection($states, new StateTransformer()),
            'cities' => fractal()->collection($cities, new CityFullTransformer()),
        ]);
    }
}
