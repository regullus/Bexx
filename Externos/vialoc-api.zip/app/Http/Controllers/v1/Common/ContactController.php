<?php

namespace App\Http\Controllers\v1\Common;

/*
 * Parent
 */
use Illuminate\Http\Request;
/*
 * Vendor packages
 */

use App\Http\Controllers\Controller;
/*
 * User resources.
 */
use App\Http\Requests\v1\Site\Contact\CreateContactRequest;

class ContactController extends Controller
{
    public function create(CreateContactRequest $request)
    {
        return response()->json([], 200);
    }
}
