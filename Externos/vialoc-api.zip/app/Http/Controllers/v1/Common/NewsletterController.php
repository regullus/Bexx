<?php

namespace App\Http\Controllers\v1\Common;

use Exception;
use App\Models\Newsletter;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\v1\Site\NewsletterService;
use App\Http\Requests\v1\Site\Newsletter\CreateNewsletterRequest;

class NewsletterController extends Controller
{
    protected $service;

    public function __construct(NewsletterService $service)
    {
        $this->service = $service;
    }

    public function create(CreateNewsletterRequest $request)
    {
        $this->service->create($request->all());

        return response()->json([], 201);
    }

    public function delete(Newsletter $uid)
    {
        $newsletter = $uid;
        $newsletter->delete();

        return response()->json([], 200);
    }
}
