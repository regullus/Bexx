<?php

namespace App\Http\Controllers\v1\Common;

use Exception;
use App\Models\User;
use App\Models\Product;
use App\Facades\C7Utils;
use Illuminate\Http\Request;
use Symfony\Component\Translation\Exception\NotFoundResourceException;

use App\Traits\DocumentTrait;
use App\Http\Controllers\Controller;
use App\Transformers\v1\UserSimpleTransformer;
use App\Transformers\v1\ProductViewTransformer;
use App\Transformers\v1\ProductSummaryTransformer;
use App\Http\Requests\v1\Site\Product\ProductListRequest;
use League\Fractal\Pagination\IlluminatePaginatorAdapter;

class ProductController extends Controller
{
    use DocumentTrait;

    protected $user;

    public function __construct()
    {
        $this->user = auth()->user();
    }

    /*********************************************************************************************
     * PUBLIC
     *********************************************************************************************/

    /**
     * Os filtros de Models citados na explicação abaixo (documentação: https://github.com/Tucker-Eric/EloquentFilter)
     * consistem numa maneira prática de realizar buscas complexas no banco de dados. Quando dizemos "maneira prática"
     * referimo-nos à UTILIZAÇÃO dos filtros depois de prontos (às suas chamadas) porém, seu entendimento e
     * desenvolvimento não é simples. Os filtros seguem a mesma ideia dos Transformers que se aproveitam da capacidade
     * que o Eloquent possui de alcançar qualquer Entity através de qualquer ponto de entrada na modelagem. Basicamente
     * eu crio um espelho (filtro) pra cada model e implemento um método para cada campo da tabela. A promessa é que
     * isso cubra 90% das buscas realizadas no banco de dados através do reuso dos filtros.
     *
     * As chaves enviadas nos parâmnetros da URL como query string terão métodos de mesmo nome, seja no filtro inicial,
     * seja nos filtros subsequentes.
     *
     * O fluxo prático é: olhar quais campos são enviados via query string, olhar na controller qual model está sendo
     * utilizada, procurar um filtro de mesmo nome (com sufixo Filter) no diretório ModelsFilter e procurar um método
     * com o mesmo nome (camel cased) de cada chave enviada neste filtro. Se eu não encontrar um método de mesmo nome,
     * procurar no array $relations (do filtro). As chaves em $relations representam os métodos de relacionamento NA
     * MODEL. Abrir a Model desse relacionamento, procurar por seu filtro, procurar pelo método camel cased repetindo o
     * procedimento.
     *
     *
     *
     * ** Não encontrei uma maneira de colocar os parâmetros em uma classe Swagger quando o in="query"
     * ** Por esse motivo a annotation do Swagger ficou tão grande para o método list() abaixo.
     *
     */
    public function index(ProductListRequest $request)
    {
        $request->merge([
            'product_status' => 'active',
        ]);

        if ($request->has('order_date_start') && $request->input('order_date_start')) {
            $request->merge([
                'product_reservation' => [
                    'date_start' => $request->input('order_date_start'),
                    'date_end' => $request->input('order_date_end'),
                ],
            ]);
        }

        $products = Product::with('price_monthly')->where('status', 'active')->filter($request->all());

        $collection = $products->paginate(config('c7.rows_per_page'));

        $arr = fractal()
            ->collection($collection, new ProductSummaryTransformer())
            ->toArray();
        // ->paginateWith(new IlluminatePaginatorAdapter($collection))
        // ->respond(200);

        $arrPaginated = C7Utils::buildPaginator($arr, $collection);

        return response()->json($arrPaginated, 200);
    }

    /**
     * Este método se assemelha ao list, porém vai trazer apenas as carretas pertencentes a um proprietário.
     */
    public function listByLocator(ProductListRequest $request, User $user_slug)
    {
        $user = $user_slug;

        $request->merge([
            'product_user' => $user->id,
            'product_status' => 'active',
        ]);

        if ($request->has('order_date_start') && $request->input('order_date_start')) {
            $request->merge([
                'date_interval' => [
                    'date_start' => $request->input('order_date_start'),
                    'date_end' => $request->input('order_date_end'),
                ],
            ]);
        }

        $collection = Product::filter($request->all())
            ->paginate(config('c7.rows_per_page'));

        $arr = fractal()
            ->collection($collection, new ProductSummaryTransformer())
            ->toArray();

        $arrPaginated = C7Utils::buildPaginator($arr, $collection);

        $arrPaginated['locator'] = fractal()
            ->item($user, new UserSimpleTransformer())
            ->toArray();

        return response()->json($arrPaginated, 200);
    }

    public function view(Request $request, Product $product_slug)
    {
        $product = $product_slug;

        return fractal()
                ->item($product, new ProductViewTransformer())
                ->parseIncludes(['prices', 'images', 'view_images', 'locator', 'questions.answers', 'ratings.user'])
                ->toArray();
    }

    public function document($product_uid, $document_type, $size)
    {
        $product = $product_uid;

        // verifica se é o proprietário
        if (! $this->user->can('update', $product)) {
            abort(404);
        }

        try {
            $base64 = $this->getDocuments($product, $document_type, $size);
            return response()->json($base64, 200);
        } catch (NotFoundResourceException $e) {
            return response()->json($e->getMessage(), $e->getCode());
        }
    }
}
