<?php

namespace App\Http\Controllers\v1\Common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Support\Str;
use Carbon\Carbon;
use JWTAuth;
use Exception;
use Socialite;

use App\Http\Requests\v1\Common\Auth\ForgotPasswordRequest;
use App\Models\User;
use App\Services\v1\Common\AuthService;
use App\Transformers\v1\UserFullTransformer;
// use App\Services\v1\Common\SocialAccountsService;


/**
 * Class AuthController.
 *
 * Esta classe foi copiada integralmente do link http://jwt-auth.readthedocs.io/en/develop/quick-start/
 * Alguns métodos foram alterados principamente em função dos Transformers e as annotations do Swagger foram incluídas.
 * O método me() foi removido para deixar somente em UsersController.php
 */

/**
 * Quando o usuário não estiver autenticado, o comportamento padrão do Laravel seria redirecioná-lo para uma
 * página de login, porém, por ser uma API ela deve apenas alterar o código de retorno para 401. Para isto
 * segui as coordenadas da documentação do Laravel Auth e implementei o método unauthenticated em
 * Exceptions/Handler.php.
 */

class AuthController extends Controller
{
    use ResetsPasswords;

    /**
     * Create a new AuthController instance.
     *
     * @return void
     */
    public function __construct(AuthService $auth)
    {
        $this->service = $auth;
        // $this->middleware('auth:api', ['except' => ['login']]);
    }

    public function login()
    {
        $credentials = request(['email', 'password']);
        if (! $token = auth()->attempt($credentials)) {
            return response()->json(['errors' => ['generic' => ['E-mail e senha não conferem.']]], 403); //Sem Transformer pois o retorno é muito simples.
        }

        $ttl = auth()->factory()->getTTL();
        $authData = $this->service->buildTokenInformation($token, $ttl);

        // atualiza a data de login do usuário
        $user_update = auth()->user()->update(['loggedin_at' => Carbon::now()->toDateTimeString()]);

        return response()->json($authData, 200); //Sem Transformer pois o retorno é padrão do jwt.
    }

    protected function getSessionData()
    {
    }

    public function logout()
    {
        auth()->logout();

        return response()->json(['message' => 'Successfully logged out'])->cookie('token', null); //Sem Transformer pois o retorno é muito simples.
    }

    public function refresh()
    {
        $token = auth()->refresh();

        $ttl = auth()->factory()->getTTL();
        $authData = $this->service->buildTokenInformation($token, $ttl);

        return response()
            ->json(['auth' => $authData], 200)
            ->cookie('token', $token, config('jwt.ttl'));
    }

    public function forgotPassword(ForgotPasswordRequest $request)
    {
        $user = User::where('email', $request->input('email'))->where('status', '!=', 'blocked')->first();
        if (! $user) {
            return response()->json([
                'errors' => [
                    'generic' => ['O cadastro com este e-mail não foi encontrado ou não está ativo.'],
                ],
            ], 422);
        }

        try {
            Password::sendResetLink(['email' => $user->email], function (Message $message) {
                $message->subject('Sua redefinição de senha');
            });
        } catch (\Exception $e) {
            //Return with error
            $error_message = $e->getMessage();

            return response()->json([
                'errors' => [
                    'generic' => [$error_message],
                ],
            ], 422);
        }

        return response()->json([
            'data' => [
                'email_target' => hideEmail($user->email),
            ],
        ]);
    }

    public function redefinePassword(Request $request)
    {
        $this->validate($request, $this->rules(), $this->validationErrorMessages());

        // Here we will attempt to reset the user's password. If it is successful we
        // will update the password on an actual user model and persist it to the
        // database. Otherwise we will parse the error and return the response.
        $response = $this->broker()->reset(
            $this->credentials($request),
            function ($user, $password) {
                $this->resetPassword($user, $password);
            }
        );

        if ($response != Password::PASSWORD_RESET) {
            return response()->json([
                'errors' => [
                    'generic' => ['A sua solicitação de redefinição de senha é inválida ou está expirada.'],
                ],
            ], 422);
        }

        try {
            $token = auth()->attempt(request(['email', 'password']));
            $ttl = auth()->factory()->getTTL();
            $authData = $this->service->buildTokenInformation($token, $ttl);
            $user = fractal()
                ->item(auth()->user(), new UserFullTransformer())
                ->parseIncludes(['address', 'profile'])
                ->toArray();

            // atualiza a data de login do usuário
            $user_update = auth()->user()->update(['loggedin_at' => Carbon::now()->toDateTimeString()]);

            return response()
                ->json(['user' => $user, 'auth' => $authData], 200)
                ->cookie('token', $token, config('jwt.ttl'));
        } catch (Exception $e) {
            \Log::alert($e->getFile().' - '.$e->getMessage().' - '.$e->getCode());

            return response()->json('Internal error', 500);
        }
    }

    /**
     * OVERRIDE - Reset the given user's password.
     *
     * @param  \Illuminate\Contracts\Auth\CanResetPassword  $user
     * @param  string  $password
     * @return void
     */
    protected function resetPassword($user, $password)
    {
        $user->password = $password;
        $user->setRememberToken(Str::random(60));
        $user->save();

        event(new PasswordReset($user));
        $this->guard()->login($user);
    }

    public function socialProviderLogin($provider)
    {
        return Socialite::with($provider)->stateless()->redirect()->getTargetUrl();
    }

    public function socialProviderCallback($provider)
    {
        $providerUser = Socialite::with($provider)->stateless()->user();

        $user = $this->service->socialAccountFindOrCreate($providerUser, $provider);

        // atualiza a data de login do usuário
        $user->update(['loggedin_at' => Carbon::now()->toDateTimeString()]);
        $user->fresh();

        \Log::info($user);

        $responseUser = fractal()
            ->item($user, new UserFullTransformer())
            ->parseIncludes(['address', 'profile'])
            ->toArray();

        $ttl = auth()->factory()->getTTL();
        $token = JWTAuth::fromUser($user);
        $authData = $this->service->buildTokenInformation($token, $ttl);

        return response()
            ->json(['user' => $responseUser, 'auth' => $authData], 200)
            ->cookie('token', $token, config('jwt.ttl'));
    }
}
