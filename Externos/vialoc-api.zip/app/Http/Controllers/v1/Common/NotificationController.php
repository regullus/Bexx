<?php

namespace App\Http\Controllers\v1\Common;

use App\Models\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Transformers\v1\NotificationTransformer;

class NotificationController extends Controller
{
    public function index()
    {
        $notifications = auth()->user()->notifications()->orderBy('created_at', 'desc')->get();

        return fractal()
            ->collection($notifications, new NotificationTransformer())
            ->respond(200);
    }

    public function setRead(Notification $notification)
    {
        $this->authorize('update', $notification);
        $notification->update(['read_at' => now()]);

        return response()->json('', 200);
    }

    public function removeNotifications(Request $request)
    {
        $notifications = Notification::find($request->input('notificationIds'));
        foreach ($notifications as $notification) {
            $this->authorize('update', $notification);
            $notification->delete();
        }

        return response()->json('', 200);
    }
}
