<?php

namespace App\Http\Controllers\v1\Locator;

use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Transformers\v1\NotificationTransformer;
use App\Transformers\v1\OrderSummaryTransformer;

class DashboardController extends Controller
{
    protected $user;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $response = [];

        $user = auth()->user();
        $response['questions_unanswered'] = $user->locatorQuestions()->where('parent_id', 0)->doesntHave('answers')->count();
        $response['orders_messages_unread'] = $user->locatorMessages()->where('order_messages.user_id', '<>', $user->id)->whereNull('read_at')->count();

        $orders_unconfirmed = $user->locatorOrders()->where('orders.status', 'pending-confirmation')->orderBy('date_start', 'asc');
        $response['orders_unconfirmed_count'] = $orders_unconfirmed->count();
        $response['orders_unconfirmed'] = fractal($orders_unconfirmed->take(5)->get(), new OrderSummaryTransformer())->parseIncludes(['product'])->toArray();

        $orders_takeout = $user->locatorOrders()->where('orders.status', 'pending-takeout')->orderBy('date_start', 'asc');
        $response['orders_takeout_count'] = $orders_takeout->count();
        $response['orders_takeout'] = fractal($orders_takeout->take(5)->get(), new OrderSummaryTransformer())->parseIncludes(['product'])->toArray();

        $date_limit = Carbon::now()->addWeek()->format('Y-m-d');
        $orders_finishing = $user->locatorOrders()->where('orders.status', 'active')->whereDate('date_end', '<=', $date_limit)->orderBy('date_end', 'asc');
        $response['orders_finishing_count'] = $orders_finishing->count();
        $response['orders_finishing'] = fractal($orders_finishing->take(5)->get(), new OrderSummaryTransformer())->parseIncludes(['product'])->toArray();

        // $notifications = $user->unreadNotifications()->where('data->profile_recipient', 'locator')->orderBy('created_at', 'desc')->get();
        // $response['notifications'] = fractal($notifications, new NotificationTransformer())->toArray();

        return response()->json($response);
    }
}
