<?php

namespace App\Http\Controllers\v1\Locator;

use Exception;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\QuestionAnswer;
use Symfony\Component\Translation\Exception\NotFoundResourceException;

use App\Http\Controllers\Controller;
use App\Services\v1\Site\PriceService;
use App\Services\v1\Site\ProductService;
use App\Services\v1\Site\QuestionAnswerService;
use App\Transformers\v1\MediaTransformer;
use App\Transformers\v1\PriceFullTransformer;
use App\Transformers\v1\ProductFullTransformer;
use App\Transformers\v1\QuestionFullTransformer;
use App\Transformers\v1\ProductSummaryTransformer;
use App\Http\Requests\v1\Site\Product\ProductCreateRequest;
use App\Http\Requests\v1\Site\Product\ProductUpdateRequest;
use App\Http\Requests\v1\Site\Price\PriceMaintenanceRequest;
use App\Http\Requests\v1\Site\Product\ProductSetStatusRequest;
use App\Http\Requests\v1\Site\Product\ProductOrderImagesRequest;
use App\Http\Requests\v1\Site\Product\ProductUploadImageRequest;
use App\Http\Requests\v1\Site\Product\CreateQuestionAnswerRequest;
use App\Http\Requests\v1\Site\Product\ProductUploadDocumentRequest;
use App\Http\Requests\v1\Site\Product\ProductSetFeaturedImageRequest;

class ProductController extends Controller
{
    protected $service;

    protected $priceService;

    public function __construct(ProductService $service, PriceService $priceService)
    {
        $this->service = $service;
        $this->priceService = $priceService;
    }

    public function index(Request $request)
    {
        $products = auth()->user()->products()->where('status', '!=', 'suspended')->get();

        return fractal()->collection($products, new ProductSummaryTransformer())
                ->parseIncludes(['address'])
                ->toArray();
    }

    public function create(ProductCreateRequest $request)
    {
        $product = $this->service->create($request->all());

        return response()->json(['uid' => $product->uid], 201);
    }

    public function update(ProductUpdateRequest $request, Product $product_uid)
    {
        try {
            $product = $this->service->update($product_uid, $request->all());

            return fractal()->item($product, new ProductFullTransformer())
                // ->parseIncludes(['prices', 'questions.answers'])
                ->parseIncludes(['address', 'prices', 'images', 'featured_image'])
                ->toArray();
        } catch (NotFoundResourceException $e) {
            \Log::info($e->getFile().' - '.$e->getMessage().' - '.$e->getCode());

            return response()->json($e->getMessage(), $e->getCode());
        }
    }

    public function view(Product $product_uid)
    {
        $product = $product_uid;
        $product->load(['address']);

        return fractal()->item($product, new ProductFullTransformer())
                // ->parseIncludes(['prices', 'questions.answers'])
                ->parseIncludes(['address', 'featured_image', 'images', 'view_images', 'prices'])
                ->toArray();
    }

    public function answer(CreateQuestionAnswerRequest $request, Product $product_uid, QuestionAnswer $questionAnswer)
    {
        $data = $request->all();
        $product = $product_uid;
        $questionAnswerService = new QuestionAnswerService;
        $questionAnswer = $questionAnswerService->answer($data, $product, $questionAnswer);

        return fractal()
            ->item($questionAnswer, new QuestionFullTransformer())
            ->respond(201);
    }

    public function messages(Request $request)
    {
        $user = auth()->user();
        $questionAnswer = new QuestionAnswer();
        $collection = $questionAnswer
            ->whereHas('product', function ($query) use ($user) {
                $query->where('user_id', $user->id);
            })
            ->with(['product', 'user'])
            ->where('parent_id', 0)
            ->orderBy('created_at', 'DESC')
            ->get();

        return fractal()->collection($collection, new QuestionFullTransformer())
                ->parseIncludes(['product', 'user', 'answers'])
                ->toArray();
    }

    public function messagesByProduct(Product $product_uid)
    {
        $product = $product_uid;
        $this->authorize('update', $product);

        return fractal()->item($product, new ProductSummaryTransformer())
                // ->parseIncludes(['questions.answers'])
                ->parseIncludes(['questions.answers', 'questions.user'])
                ->toArray();
    }

    public function messageRead(QuestionAnswer $questionAnswer, Request $request)
    {
        $questionAnswerService = new QuestionAnswerService;

        try {
            $questionAnswerService->setRead($questionAnswer);

            return response()->json([], 200);
        } catch (Exception $e) {
            return response()->json(['errors' => ['generic' => $e->getMessage()]], $e->getCode());
        }
    }

    /**
     * Recebe os preços de um produto e faz a manutenção mantendo os que já existem, adicionando os novos e removendo os
     * que foram excluídos.
     */
    public function prices(PriceMaintenanceRequest $request, Product $product_uid)
    {
        $product = $product_uid;

        try {
            return fractal()
                ->collection($this->priceService->maintenance($product, $request->all()), new PriceFullTransformer())
                ->respond(201);
        } catch (NotFoundResourceException $e) {
            \Log::info($e->getFile().' - '.$e->getMessage().' - '.$e->getCode());

            return response()->json($e->getMessage(), $e->getCode());
        }
    }

    public function setStatus(ProductSetStatusRequest $request, Product $product_uid)
    {
        $product = $product_uid;

        try {
            $this->service->setStatus($product, $request['status']);
            if ($request['status'] == 'active') {
                $message = 'Carreta ativada com sucesso.';
            } else {
                $message = 'Carreta desativada com sucesso.';
            }

            return response()->json(['message' => $message]);
        } catch (NotFoundResourceException $e) {
            \Log::info($e->getFile().' - '.$e->getMessage().' - '.$e->getCode());

            return response()->json($e->getMessage(), $e->getCode());
        }
    }

    public function uploadImage(ProductUploadImageRequest $request, Product $product_uid, $tag = null)
    {
        $product = $product_uid;
        $image = $this->service->uploadImage($product, $request, $tag);

        return fractal()
                ->item($image, new MediaTransformer())
                ->respond(201);
    }

    public function deleteImage(Product $product_uid, $image_id)
    {
        $product = $product_uid;
        $this->service->deleteImage($product, $image_id);

        return response()->json(['message' => 'Imagem removida com sucesso!']);
    }

    public function orderImages(ProductOrderImagesRequest $request, Product $product_uid)
    {
        $product = $product_uid;
        $product->syncMedia($request['ids'], 'product-image');

        return response()->json(['message' => 'Ordem de imagens definida com sucesso!']);
    }

    public function setFeaturedImage(ProductSetFeaturedImageRequest $request, Product $product_uid)
    {
        $product = $product_uid;
        $product->syncMedia($request['image_id'], 'product-featured-image');

        return fractal()
            ->item($product->firstMedia('product-featured-image'), new MediaTransformer())
            ->respond(201);
    }

    public function uploadDocuments(ProductUploadDocumentRequest $request, Product $product_uid)
    {
        $product = $product_uid;
        $document = $this->service->uploadDocument($product, $request);

        return getMediaBase64($document);
    }

    public function deleteDocuments(Product $product_uid, $image_id)
    {
        $product = $product_uid;
        $this->service->deleteImage($product, $image_id);

        return response()->json(['message' => 'Documento removido com sucesso!']);
    }
}
