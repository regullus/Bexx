<?php

namespace App\Http\Controllers\v1\Locator;

use Exception;
use App\Models\Order;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\v1\Locator\OrderService;
use App\Transformers\v1\RatingTransformer;
use App\Transformers\v1\OrderFullTransformer;
use App\Transformers\v1\OrderSummaryTransformer;
use App\Http\Requests\v1\Site\Order\OrderRateUserRequest;
use League\Fractal\Pagination\IlluminatePaginatorAdapter;
use App\Http\Requests\v1\Site\Order\OrderMaintenanceRequest;
use App\Http\Requests\v1\Site\Order\OrderMessageCreateRequest;

class OrderController extends Controller
{
    protected $service;

    protected $user;

    public function __construct()
    {
        $this->service = new OrderService();
        $this->user = auth()->user();
    }

    public function index(Request $request, $status = null)
    {
        if ($status) {
            $orders = $this->user->locatorOrders()->where('status', $status)->get();
        } else {
            $orders = $this->user->locatorOrders()->get();
        }

        return fractal()->collection($orders, new OrderSummaryTransformer())
            ->parseIncludes(['product', 'user']);
    }

    /**
     * LOCADOR - Atualiza status do pedido.
     */
    public function confirm(Request $request, Order $order)
    {
        try {
            return fractal()
                ->item($this->service->confirm($order, $this->user), new OrderFullTransformer())
                ->parseIncludes(['logs', 'price', 'product', 'user']);
        } catch (Exception $e) {
            return response()->json(['errors' => ['generic' => $e->getMessage()]], $e->getCode());
        }
    }

    /**
     * LOCADOR - Recusa pedido recebido.
     */
    public function refuse(Request $request, Order $order)
    {
        try {
            return fractal()
                ->item($this->service->refuse($order, $this->user), new OrderFullTransformer())
                ->parseIncludes(['logs', 'price', 'product', 'user']);
        } catch (Exception $e) {
            return response()->json(['errors' => ['generic' => $e->getMessage()]], $e->getCode());
        }
    }

    public function takeout(Request $request, Order $order)
    {
        try {
            $this->service->informTakeout($order, $this->user);

            return response()->json([], 200);
        } catch (Exception $e) {
            return response()->json(['errors' => ['generic' => $e->getMessage()]], $e->getCode());
        }
    }

    public function devolution(Request $request, Order $order)
    {
        try {
            return fractal()
                ->item($this->service->doDevolution($order, $this->user), new OrderFullTransformer())
                ->parseIncludes(['address', 'logs', 'price', 'product', 'user']);
        } catch (Exception $e) {
            return response()->json(['errors' => ['generic' => $e->getMessage()]], $e->getCode());
        }
    }

    public function changeAddress(Request $request, Order $order)
    {
        $data = $request->all();

        try {
            $this->service->changeAddress($order, $this->user, $data['address_id']);

            return response()->json([], 200);
        } catch (Exception $e) {
            return response()->json(['errors' => ['generic' => $e->getMessage()]], $e->getCode());
        }
    }

    /**
     * LOCATÁRIO - Lista pedidos pendentes de confirmação
     */
    public function listLocatorPendingConfirmation(Request $request)
    {
        $arrFilter = $request->all();
        $arrFilter['order_status'] = config('c7.order.status.pending-confirmation');
        $arrFilter['product_user_id'] = $this->user->id;

        $collection = Order::filter($arrFilter)
            ->paginate(config('c7.rows_per_page'));

        return fractal()
            ->collection($collection, new OrderSummaryTransformer())
            ->parseIncludes(['messages.user'])
            ->paginateWith(new IlluminatePaginatorAdapter($collection))
            ->respond(200);
    }

    /**
     * LOCADOR - traz os detalhes do pedido de locacao
     */
    public function view(Order $order)
    {
        if (! $this->user->can('updateAsLocator', $order)) {
            return response()->json(['errors' => ['generic' => config('error.resource_not_allowed')]], 404);
        }

        $transformerIncludes = ['address', 'logs', 'price', 'product', 'user'];
        if ($order->status == 'finished') {
            $transformerIncludes[] = 'ratings';
        }

        $arrOrder = fractal()
            ->item($order, new OrderFullTransformer())
            ->parseIncludes($transformerIncludes)
            ->toArray();

        $collectionOverlappingOrders = $order->searchOverlappingOrders();
        $arrOverlapping = fractal()
            ->collection($collectionOverlappingOrders, new OrderSummaryTransformer())
            ->parseIncludes(['messages.user'])
            ->toArray();

        return response()
            ->json(['order' => $arrOrder, 'overlapping' => $arrOverlapping], 200);
    }

    public function rateTenant(OrderRateUserRequest $request, Order $order)
    {
        $data = $request->all();

        try {
            $rating = $this->service->rateTenant($order, $data);

            return fractal()
                ->item($rating, new RatingTransformer());
        } catch (Exception $e) {
            \Log::info($e);
            return response()->json(['errors' => ['generic' => $e->getMessage()]], $e->getCode());
        }
    }

    /**
     * Confirma 1 pedido (enviado no path) e recusa X pedidos (enviados no body).
     */
    public function maintenance(OrderMaintenanceRequest $request, Order $order)
    {
        try {
            $this->service->maintenance($order, $this->user, $request->all());

            return response()->json([], 200);
        } catch (Exception $e) {
            return response()->json(['errors' => ['generic' => $e->getMessage()]], $e->getCode());
        }
    }

    /**
     * Lista as mensagens.
     */
    public function messages(Request $request, Order $order)
    {
        return fractal()
            ->item($order, new OrderFullTransformer()) // Transformer de pedido
            ->parseIncludes(['product.user', 'messages', 'user'])
            ->respond(201);
    }

    /**
     * Cria a mensagem para o chat.
     */
    public function createMessage(OrderMessageCreateRequest $request, Order $order)
    {
        $data = $request->all();

        try {
            $this->service->createMessage($order, $this->user, $data);

            return response()->json([], 200);
        } catch (Exception $e) {
            return response()->json(['errors' => ['generic' => $e->getMessage()]], $e->getCode());
        }
    }
}
