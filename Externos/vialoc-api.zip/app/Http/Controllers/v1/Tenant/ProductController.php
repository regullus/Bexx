<?php

namespace App\Http\Controllers\v1\Tenant;

use Exception;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\QuestionAnswer;
use App\Http\Controllers\Controller;
use App\Services\v1\Site\QuestionAnswerService;
use App\Transformers\v1\QuestionFullTransformer;
use Intervention\Image\Exception\NotFoundException;
use App\Http\Requests\v1\Site\Product\CreateQuestionAnswerRequest;

class ProductController extends Controller
{
    private $user;

    public function __construct()
    {
        $this->user = auth()->user();
    }

    public function createQuestion(CreateQuestionAnswerRequest $request, Product $product_uid)
    {
        $product = $product_uid;
        $data = $request->all();
        $questionAnswerService = new QuestionAnswerService;

        $questionAnswer = $questionAnswerService->create($data, $product);

        return fractal()
            ->item($questionAnswer, new QuestionFullTransformer()) // Transformer de pedido
            ->parseIncludes(['answers', 'product', 'user'])
            ->respond(201);
    }

    /**
     * Neste endpoint será possível visualizar o documento da carreta
     */
    public function document(Product $product_uid, $document_type, $size)
    {
        try {
            $product = $product_uid;
            $base64 = $this->getDocuments($product, $document_type, $size);

            return response()->json($base64, 200);
        } catch (NotFoundException $e) {
            return response()->json($e->getMessage(), $e->getCode());
        }
    }

    public function messages(Request $request)
    {
        $questionAnswer = new QuestionAnswer();
        $collection = $questionAnswer
            ->where('user_id', $this->user->id)
            ->where('parent_id', 0)
            ->orderBy('created_at', 'DESC')
            ->get();

        /*
         * Colocar o usuário dono da carreta no mesmo núvel de answers
         */
        return fractal()->collection($collection, new QuestionFullTransformer())
                ->parseIncludes(['answers.user', 'product'])
                ->toArray();
    }

    public function messageRead(QuestionAnswer $questionAnswer, Request $request)
    {
        $questionAnswerService = new QuestionAnswerService;

        try {
            $questionAnswerService->setRead($questionAnswer);

            return response()->json([], 200);
        } catch (Exception $e) {
            return response()->json(['errors' => ['generic' => $e->getMessage()]], $e->getCode());
        }
    }
}
