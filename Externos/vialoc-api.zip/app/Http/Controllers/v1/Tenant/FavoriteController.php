<?php

namespace App\Http\Controllers\v1\Tenant;

use App\Models\Product;
use App\Models\Favorite;
use App\Http\Controllers\Controller;
use App\Transformers\v1\FavoriteSummaryTransformer;
use App\Http\Requests\v1\Site\Favorite\CreateFavoriteRequest;

class FavoriteController extends Controller
{
    public function create(CreateFavoriteRequest $request)
    {
        $product = Product::where('uid', $request->input('product_uid'))->first();
        $arr['product_id'] = $product->id;
        auth()->user()->favorites()->create($arr);

        return response()->json([], 200);
    }

    public function get()
    {
        $collection = auth()->user()->favorites()->whereHas('product', function ($query) {
            $query->where('status', 'active');
        });

        return fractal()
            ->collection($collection->get(), new FavoriteSummaryTransformer())
            ->respond(200);
    }

    public function delete(Product $product_uid)
    {
        $product = $product_uid;
        \Log::info($product);
        auth()->user()->favorites()
            ->where('product_id', $product->id)
            ->first()
            ->delete();

        return response()->json([], 200);
    }
}
