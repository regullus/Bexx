<?php

namespace App\Http\Controllers\v1\Tenant;

use Carbon\Carbon;
use App\Facades\C7Utils;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Transformers\v1\RatingTransformer;

class RatingController extends Controller
{
    protected $user;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->user = auth()->user();
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $direction)
    {
        if ($direction == 'received') {
            $ratings = $this->user->ratingsTenantReceived()->where('status', 'approved');
        } else {
            $ratings = $this->user->ratingsTenantSent();
        }

        $collection = $ratings->paginate(config('c7.rows_per_page'));

        $arr = fractal()
            ->collection($collection, new RatingTransformer())
            ->parseIncludes(['user', 'user_rated'])
            ->toArray();

        $arrPaginated = C7Utils::buildPaginator($arr, $collection);

        return response()->json($arrPaginated, 200);
    }
}
