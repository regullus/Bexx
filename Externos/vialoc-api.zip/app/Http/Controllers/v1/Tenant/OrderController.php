<?php

namespace App\Http\Controllers\v1\Tenant;

use Exception;
use App\Models\Order;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\v1\Tenant\OrderService;
use App\Transformers\v1\RatingTransformer;
use App\Transformers\v1\OrderFullTransformer;
use App\Transformers\v1\OrderSummaryTransformer;
use App\Http\Requests\v1\Site\Order\OrderCreateRequest;
use App\Http\Requests\v1\Site\Order\OrderPaymentRequest;
use App\Http\Requests\v1\Site\Order\OrderRateUserRequest;
use App\Http\Requests\v1\Site\Order\OrderRateProductRequest;
use App\Http\Requests\v1\Site\Order\OrderMessageCreateRequest;

class OrderController extends Controller
{
    protected $service;

    protected $user;

    public function __construct()
    {
        $this->service = new OrderService();
        $this->user = auth()->user();
    }

    public function index(Request $request, $status = null)
    {
        if ($status) {
            $orders = auth()->user()->orders()->where('status', $status)->get();
        } else {
            $orders = auth()->user()->orders()->get();
        }

        return fractal()->collection($orders, new OrderSummaryTransformer())
            ->parseIncludes(['locator', 'product']);
    }

    /**
     * LOCATÁRIO - Grava pedido.
     */
    public function create(OrderCreateRequest $request)
    {
        try {
            return fractal()
                ->item($this->service->create($request->toArray(), auth()->user()), new OrderFullTransformer()); // Transformer de pedido
        } catch (Exception $e) {
            \Log::info(json_encode($e));

            return response()->json(['errors' => ['generic' => $e->getMessage()]], 422);
        }
    }

    public function cancel(Order $order)
    {
        $order = $this->service->cancel($order);

        return fractal()
            ->item($order, new OrderFullTransformer())
            ->parseIncludes(['locator', 'product', 'price', 'logs']);
    }

    public function changePaymentMethod(Order $order)
    {
        $order = $this->service->changePaymentMethod($order);

        return fractal()
            ->item($order, new OrderFullTransformer())
            ->parseIncludes(['locator', 'logs', 'payment', 'payment_logs', 'price', 'product']);
    }

    public function payment(OrderPaymentRequest $request, Order $order)
    {
        $data = $request->all();

        try {
            $order = $this->service->payment($order, $data);

            return fractal()
                ->item($order, new OrderFullTransformer())
                ->parseIncludes(['locator', 'logs', 'payment', 'payment_logs', 'price', 'product', 'address',]);
        } catch (Exception $e) {
            \Log::error($e);

            return response()->json(['errors' => ['generic' => $e->getMessage()]], 422);
        }
    }

    public function checkPayment(Request $request, Order $order)
    {
        $data = $request->all();

        try {
            $order = $this->service->checkPayment($order, $data['PaymentId']);
            // direciona para o site, na página de detalhes da locação
            return redirect(config('c7.webapp_url').'/locatario/locacoes/'.$order->id.'?mensagem=pagamento-sucesso');
        } catch (Exception $e) {
            \Log::error($e);

            return redirect(config('c7.webapp_url').'/locatario/locacoes/'.$order->id.'?erro='.urlencode($e->getMessage()));
        }
    }

    public function takeout(Request $request, Order $order)
    {
        $data = $request->all();

        try {
            $order = $this->service->doTakeout($order);

            return fractal()
                ->item($order, new OrderFullTransformer())
                ->parseIncludes(['locator', 'logs', 'payment', 'payment_logs', 'price', 'product', 'address']);
        } catch (Exception $e) {
            \Log::error($e);

            return response()->json(['errors' => ['generic' => $e->getMessage()]], 422);
        }
    }

    public function devolution(Request $request, Order $order)
    {
        $data = $request->all();

        try {
            $this->service->informDevolution($order);

            return response()->json([], 200);
        } catch (Exception $e) {
            \Log::error($e);

            return response()->json(['errors' => ['generic' => $e->getMessage()]], 422);
        }
    }

    public function rateLocator(OrderRateUserRequest $request, Order $order)
    {
        $data = $request->all();

        try {
            $rating = $this->service->rateLocator($order, $data);

            return fractal()
                ->item($rating, new RatingTransformer());
        } catch (Exception $e) {
            return response()->json(['errors' => ['generic' => $e->getMessage()]], $e->getCode());
        }
    }

    public function rateProduct(OrderRateProductRequest $request, Order $order)
    {
        $data = $request->all();

        try {
            $rating = $this->service->rateProduct($order, $data);

            return fractal()
                ->item($rating, new RatingTransformer());
        } catch (Exception $e) {
            return response()->json(['errors' => ['generic' => $e->getMessage()]], $e->getCode());
        }
    }

    /**
     * LOCATÁRIO - traz os detalhes do pedido de locacao
     */
    public function view(Order $order)
    {
        if (! $this->user->can('updateAsTenant', $order)) {
            return response()->json(['errors' => ['generic' => config('error.resource_not_allowed')]], 403);
        }

        $transformerIncludes = ['locator', 'logs', 'payment', 'payment_logs', 'price', 'product'];

        if (in_array($order->status, ['pending-takeout', 'active', 'finished'])) {
            $transformerIncludes[] = 'address';
        }

        if ($order->status == 'finished') {
            $transformerIncludes[] = 'ratings';
        }

        return fractal()
            ->item($order, new OrderFullTransformer())
            ->parseIncludes($transformerIncludes);
    }

    public function createMessage(OrderMessageCreateRequest $request, Order $order)
    {
        $arr = $request->all();
        $arr['user_id'] = auth()->user()->id;
        $order->messages()->create($arr);

        return fractal()
            ->item($order, new OrderFullTransformer()) // Transformer de pedido
            ->parseIncludes(['messages.user'])
            ->respond(201);
    }
}
