<?php

use Illuminate\Support\Facades\File;

/**
 * Return formatted string based on a mask format.
 * @param  string $value   the string to apply a mask
 * @param  string $mask   the mask format like '#####-###'
 * @return null|string          if succeded, returns the formatted string, else null
 */
function mask($value, $mask)
{
    if (empty($value)) {
        return;
    }

    $masked = '';
    $k = 0;
    for ($i = 0; $i <= strlen($mask) - 1; $i++) {
        if ($mask[$i] == '#') {
            if (isset($value[$k])) {
                $masked .= $value[$k++];
            }
        } else {
            if (isset($mask[$i])) {
                $masked .= $mask[$i];
            }
        }
    }

    return $masked;
}

/**
 * Convert a float number to a currency type number.
 * @param  float $price   the float number to convert in a currency
 * @param  array  $options formatting options
 * @return null|string          if succeded, returns the currency number, else null
 */
function floatFormatted($float, $options = [])
{
    $options = array_merge([
        'return_null' => true,
        'decimals' => 2,
        'remove_zero_cents' => false,
    ], $options);
    if (empty($float) && $options['return_null']) {
        return;
    }

    $value = number_format($float, $options['decimals'], ',', '.');
    if ($options['remove_zero_cents']) {
        $value = str_replace(',00', '', $value);
    }

    return $value;
}

function formatted2Float($float)
{
    return floatval(str_replace(['.', ','], ['', '.'], $float));
}

/**
 * Hide partially an email address.
 * @param  string $email   the string with email-address to hide
 * @return null|string          returns the formatted email
 */
function hideEmail($email)
{
    return preg_replace('/(?:^|@).\K|\.[^@]*$(*SKIP)(*F)|.(?=.*?\.)/', '*', $email);
}

/**
 * Hide partially a credit card number.
 * @param  string $creditCardNumber   the string with credit card number to hide
 * @return null|string          returns the formatted creditCard
 */
function hideCreditCard($creditCardNumber)
{
    $charsToObfuscate = strlen($creditCardNumber) - 4;
    $lastDigits = substr($creditCardNumber, -4);

    return str_repeat('*', $charsToObfuscate).$lastDigits;
}

/**
 * Convert new lines to a numerically indexed array.
 * @param  string $content Text with line-breaks
 * @return array          Numerically indexed array
 */
function nl2Array($content)
{
    $content = @explode("\n", trim($content));
    if (! is_array($content)) {
        return [];
    }

    return array_filter($content, 'trim');
}

/**
 * Convert object to array recursively.
 * @param  string $object object to be converted
 * @return array          Numerically indexed array
 */
function object2Array($object)
{
    return json_decode(json_encode($object), true);
}

/**
 * Shuffle array preserving his keys.
 * @param  array $assoc_array Associative array
 * @return array          Associative array shuffled
 */
function shuffleAssocArray($assoc_array)
{
    $new_array = [];
    $keys = array_keys($assoc_array);

    shuffle($keys);

    foreach ($keys as $key) {
        $new_array[$key] = $assoc_array[$key];
    }

    return $new_array;
}

function onlyNumbers($string)
{
    return preg_replace('/\D/', '', $string);
}

function getGravatarHash($email)
{
    return md5(strtolower(trim($email)));
}

function getMediaBase64($media, $size = null)
{
    $file_path = config('filesystems.disks.'.$media->disk.'.root').DIRECTORY_SEPARATOR.$media->getDiskPath();

    if (! empty($size) && $size != 'full') {
        // se o tamanho da thumb for encontrado, traz o novo tamanho, se não traz o tamanho full
        if (! empty($media->metadata['thumbnails'][$size])) {
            $file_path = storage_path($media->metadata['thumbnails'][$size]['path']);
        }
    }

    if (! \File::exists($file_path)) {
        return;
    }

    $file = \File::get($file_path);
    $type = \File::mimeType($file_path);

    return 'data:'.$type.';base64,'.base64_encode($file);
}

function getGeoCoord($address)
{
    $response = \GoogleMaps::load('geocoding')
        ->setParam(['address' => $address])
        ->get();

    return json_decode($response);
}

function getAmountDays($date_start, $date_end)
{
    $date_start = new DateTime($date_start);
    $date_end = new DateTime($date_end);
    $interval = $date_start->diff($date_end);
    $addCurrentDay = 1;

    return $interval->days + $addCurrentDay;
}

// LIST ORDER HELPERS ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

function getLinkOrder($field, $label, $route = null)
{
    $url = getUrlOrder($field, $route);
    $direction = request()->input('order_direction');

    if (request()->input('order') == $field && $direction) {
        $arrow = ($direction == 'asc' ? 'up' : 'down');
    }

    return '<a href="'.$url.'">'.$label.(isset($arrow) ? ' <i class="fa fa-chevron-'.$arrow.'"></i>' : '').'</a>';
}

function getUrlOrder($field, $route = null)
{
    $params = [
        'order' => $field,
        'order_direction' => 'asc',
    ];

    $current_direction = request()->input('order_direction');
    if (request()->input('order') == $field && $current_direction) {
        $params['order_direction'] = ($current_direction == 'asc' ? 'desc' : 'asc');
    }

    return getUrlWithParams($params, $route);
}

function getUrlWithParams($params = [], $route = null)
{
    if (is_null($route)) {
        $route = request()->route()->getName();
    }
    $query_params = request()->query();
    $query_params = array_merge($query_params, $params);

    return route($route, $query_params);
}

// END LIST ORDER HELPERS ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

function getTemplates($directory)
{
    $files = File::allFiles(resource_path('views/'.$directory));
    $list_templates = [];

    foreach ($files as $file) {
        $info = pathinfo($file);
        $filename = str_replace('.blade', '', $info['filename']);
        $file_route = str_replace('/', '.', $directory).'.'.$filename;
        $list_templates[$file_route] = $filename;
    }

    return $list_templates;
}

function getDirectoryTemplates($dir_templates)
{
    $directories = File::directories(resource_path('views/'.$dir_templates));
    $list_templates = [];

    foreach ($directories as $directory) {
        $info = pathinfo($directory);
        $dir_name = $info['basename'];
        $dir_route = str_replace('/', '.', $dir_templates).'.'.$dir_name;
        $list_templates[$dir_route] = $dir_name;
    }

    return $list_templates;
}

function getThumbnails($media)
{
    $thumbs = [];
    $config_thumbs = config('c7.thumbs_sizes');

    foreach ($config_thumbs as $th_name => $th) {
        $thumbs[$th_name] = getThumbnail(['media' => $media, 'thumb_size' => $th_name]);
    }

    return $thumbs;
}

function getThumbnail($opt)
{
    $opt = array_merge([
        'media' => null,
        'thumb_size' => 'default',
        'full_url' => true,
    ], $opt); //$media, $thumb_size, $full_url=true

    $th = config('c7.thumbs_sizes')[$opt['thumb_size']];

    $url = url($opt['media']->disk.'/'.$opt['media']->directory);

    return ($opt['full_url'] ? $url.'/' : '').$opt['media']->filename.'-'.($th['w'] ? $th['w'] : 0).'x'.($th['h'] ? $th['h'] : 0).'.'.$opt['media']->extension;
}

function getSomeParagraphs($content, $options)
{
    $options = array_merge([
        'paragraphsQty' => 1,
        'doAutop' => false,
        'stripTags' => false,
    ], $options);

    if ($options['stripTags']) {
        $content = strip_tags($content);
    }

    $paragraphs = explode("\n", $content, ($options['paragraphsQty'] + 1));
    array_pop($paragraphs);
    $content = implode("\n", $paragraphs);

    if ($options['doAutop']) {
        $content = autop($content);
    }

    return $content;
}

/**
 * Newline preservation help function for wpautop.
 *
 * @since 3.1.0
 *
 * @param array $matches preg_replace_callback matches array
 * @return string
 */
function _autop_newline_preservation_helper($matches)
{
    return str_replace("\n", '<WPPreserveNewline />', $matches[0]);
}

/**
 * Replaces double line-breaks with paragraph elements.
 *
 * A group of regex replaces used to identify text formatted with newlines and
 * replace double line-breaks with HTML paragraph tags. The remaining line-breaks
 * after conversion become <<br />> tags, unless $br is set to '0' or 'false'.
 *
 *
 * @param string $pee The text which has to be formatted.
 * @param bool   $br  Optional. If set, this will convert all remaining line-breaks
 *                    after paragraphing. Default true.
 * @return string Text which has been converted into correct paragraph tags.
 */
function autop($pee, $br = true)
{
    $pre_tags = [];

    if (trim($pee) === '') {
        return '';
    }

    // Just to make things a little easier, pad the end.
    $pee = $pee."\n";

    /*
     * Pre tags shouldn't be touched by autop.
     * Replace pre tags with placeholders and bring them back after autop.
     */
    if (strpos($pee, '<pre') !== false) {
        $pee_parts = explode('</pre>', $pee);
        $last_pee = array_pop($pee_parts);
        $pee = '';
        $i = 0;

        foreach ($pee_parts as $pee_part) {
            $start = strpos($pee_part, '<pre');

            // Malformed html?
            if ($start === false) {
                $pee .= $pee_part;

                continue;
            }

            $name = "<pre wp-pre-tag-$i></pre>";
            $pre_tags[$name] = substr($pee_part, $start).'</pre>';

            $pee .= substr($pee_part, 0, $start).$name;
            $i++;
        }

        $pee .= $last_pee;
    }
    // Change multiple <br>s into two line breaks, which will turn into paragraphs.
    $pee = preg_replace('|<br\s*/?>\s*<br\s*/?>|', "\n\n", $pee);

    $allblocks = '(?:table|thead|tfoot|caption|col|colgroup|tbody|tr|td|th|div|dl|dd|dt|ul|ol|li|pre|form|map|area|blockquote|address|math|style|p|h[1-6]|hr|fieldset|legend|section|article|aside|hgroup|header|footer|nav|figure|figcaption|details|menu|summary)';

    // Add a double line break above block-level opening tags.
    $pee = preg_replace('!(<'.$allblocks.'[\s/>])!', "\n\n$1", $pee);

    // Add a double line break below block-level closing tags.
    $pee = preg_replace('!(</'.$allblocks.'>)!', "$1\n\n", $pee);

    // Standardize newline characters to "\n".
    $pee = str_replace(["\r\n", "\r"], "\n", $pee);

    // Find newlines in all elements and add placeholders.
    $pee = replace_in_html_tags($pee, ["\n" => ' <!-- wpnl --> ']);

    // Collapse line breaks before and after <option> elements so they don't get autop'd.
    if (strpos($pee, '<option') !== false) {
        $pee = preg_replace('|\s*<option|', '<option', $pee);
        $pee = preg_replace('|</option>\s*|', '</option>', $pee);
    }

    /*
     * Collapse line breaks inside <object> elements, before <param> and <embed> elements
     * so they don't get autop'd.
     */
    if (strpos($pee, '</object>') !== false) {
        $pee = preg_replace('|(<object[^>]*>)\s*|', '$1', $pee);
        $pee = preg_replace('|\s*</object>|', '</object>', $pee);
        $pee = preg_replace('%\s*(</?(?:param|embed)[^>]*>)\s*%', '$1', $pee);
    }

    /*
     * Collapse line breaks inside <audio> and <video> elements,
     * before and after <source> and <track> elements.
     */
    if (strpos($pee, '<source') !== false || strpos($pee, '<track') !== false) {
        $pee = preg_replace('%([<\[](?:audio|video)[^>\]]*[>\]])\s*%', '$1', $pee);
        $pee = preg_replace('%\s*([<\[]/(?:audio|video)[>\]])%', '$1', $pee);
        $pee = preg_replace('%\s*(<(?:source|track)[^>]*>)\s*%', '$1', $pee);
    }

    // Collapse line breaks before and after <figcaption> elements.
    if (strpos($pee, '<figcaption') !== false) {
        $pee = preg_replace('|\s*(<figcaption[^>]*>)|', '$1', $pee);
        $pee = preg_replace('|</figcaption>\s*|', '</figcaption>', $pee);
    }

    // Remove more than two contiguous line breaks.
    $pee = preg_replace("/\n\n+/", "\n\n", $pee);

    // Split up the contents into an array of strings, separated by double line breaks.
    $pees = preg_split('/\n\s*\n/', $pee, -1, PREG_SPLIT_NO_EMPTY);

    // Reset $pee prior to rebuilding.
    $pee = '';

    // Rebuild the content as a string, wrapping every bit with a <p>.
    foreach ($pees as $tinkle) {
        $pee .= '<p>'.trim($tinkle, "\n")."</p>\n";
    }

    // Under certain strange conditions it could create a P of entirely whitespace.
    $pee = preg_replace('|<p>\s*</p>|', '', $pee);

    // Add a closing <p> inside <div>, <address>, or <form> tag if missing.
    $pee = preg_replace('!<p>([^<]+)</(div|address|form)>!', '<p>$1</p></$2>', $pee);

    // If an opening or closing block element tag is wrapped in a <p>, unwrap it.
    $pee = preg_replace('!<p>\s*(</?'.$allblocks.'[^>]*>)\s*</p>!', '$1', $pee);

    // In some cases <li> may get wrapped in <p>, fix them.
    $pee = preg_replace('|<p>(<li.+?)</p>|', '$1', $pee);

    // If a <blockquote> is wrapped with a <p>, move it inside the <blockquote>.
    $pee = preg_replace('|<p><blockquote([^>]*)>|i', '<blockquote$1><p>', $pee);
    $pee = str_replace('</blockquote></p>', '</p></blockquote>', $pee);

    // If an opening or closing block element tag is preceded by an opening <p> tag, remove it.
    $pee = preg_replace('!<p>\s*(</?'.$allblocks.'[^>]*>)!', '$1', $pee);

    // If an opening or closing block element tag is followed by a closing <p> tag, remove it.
    $pee = preg_replace('!(</?'.$allblocks.'[^>]*>)\s*</p>!', '$1', $pee);

    // Optionally insert line breaks.
    if ($br) {
        // Replace newlines that shouldn't be touched with a placeholder.
        $pee = preg_replace_callback('/<(script|style).*?<\/\\1>/s', '_autop_newline_preservation_helper', $pee);

        // Normalize <br>
        $pee = str_replace(['<br>', '<br/>'], '<br />', $pee);

        // Replace any new line characters that aren't preceded by a <br /> with a <br />.
        $pee = preg_replace('|(?<!<br />)\s*\n|', "<br />\n", $pee);

        // Replace newline placeholders with newlines.
        $pee = str_replace('<WPPreserveNewline />', "\n", $pee);
    }

    // If a <br /> tag is after an opening or closing block tag, remove it.
    $pee = preg_replace('!(</?'.$allblocks.'[^>]*>)\s*<br />!', '$1', $pee);

    // If a <br /> tag is before a subset of opening or closing block tags, remove it.
    $pee = preg_replace('!<br />(\s*</?(?:p|li|div|dl|dd|dt|th|pre|td|ul|ol)[^>]*>)!', '$1', $pee);
    $pee = preg_replace("|\n</p>$|", '</p>', $pee);

    // Replace placeholder <pre> tags with their original content.
    if (! empty($pre_tags)) {
        $pee = str_replace(array_keys($pre_tags), array_values($pre_tags), $pee);
    }

    // Restore newlines in all elements.
    if (false !== strpos($pee, '<!-- wpnl -->')) {
        $pee = str_replace([' <!-- wpnl --> ', '<!-- wpnl -->'], "\n", $pee);
    }

    return $pee;
}

/**
 * Replace characters or phrases within HTML elements only.
 *
 * @since 4.2.3
 *
 * @param string $haystack The text which has to be formatted.
 * @param array $replace_pairs In the form array('from' => 'to', ...).
 * @return string The formatted text.
 */
function replace_in_html_tags($haystack, $replace_pairs)
{
    // Find all elements.
    $textarr = html_split($haystack);
    $changed = false;

    // Optimize when searching for one item.
    if (1 === count($replace_pairs)) {
        // Extract $needle and $replace.
        foreach ($replace_pairs as $needle => $replace) {
        }

        // Loop through delimiters (elements) only.
        for ($i = 1, $c = count($textarr); $i < $c; $i += 2) {
            if (false !== strpos($textarr[$i], $needle)) {
                $textarr[$i] = str_replace($needle, $replace, $textarr[$i]);
                $changed = true;
            }
        }
    } else {
        // Extract all $needles.
        $needles = array_keys($replace_pairs);

        // Loop through delimiters (elements) only.
        for ($i = 1, $c = count($textarr); $i < $c; $i += 2) {
            foreach ($needles as $needle) {
                if (false !== strpos($textarr[$i], $needle)) {
                    $textarr[$i] = strtr($textarr[$i], $replace_pairs);
                    $changed = true;
                    // After one strtr() break out of the foreach loop and look at next element.
                    break;
                }
            }
        }
    }

    if ($changed) {
        $haystack = implode($textarr);
    }

    return $haystack;
}

/**
 * Separate HTML elements and comments from the text.
 *
 * @param string $input The text which has to be formatted.
 * @return array The formatted text.
 */
function html_split($input)
{
    return preg_split(get_html_split_regex(), $input, -1, PREG_SPLIT_DELIM_CAPTURE);
}

/**
 * Retrieve the regular expression for an HTML element.
 *
 * @return string The regular expression
 */
function get_html_split_regex()
{
    static $regex;

    if (! isset($regex)) {
        $comments =
              '!'           // Start of comment, after the <.
            .'(?:'         // Unroll the loop: Consume everything until --> is found.
            .'-(?!->)' // Dash not followed by end of comment.
            .'[^\-]*+' // Consume non-dashes.
            .')*+'         // Loop possessively.
            .'(?:-->)?';   // End of comment. If not found, match all input.

        $cdata =
              '!\[CDATA\['  // Start of comment, after the <.
            .'[^\]]*+'     // Consume non-].
            .'(?:'         // Unroll the loop: Consume everything until ]]> is found.
            .'](?!]>)' // One ] not followed by end of comment.
            .'[^\]]*+' // Consume non-].
            .')*+'         // Loop possessively.
            .'(?:]]>)?';   // End of comment. If not found, match all input.

        $escaped =
              '(?='           // Is the element escaped?
            .'!--'
            .'|'
            .'!\[CDATA\['
            .')'
            .'(?(?=!-)'      // If yes, which type?
            .$comments
            .'|'
            .$cdata
            .')';

        $regex =
              '/('              // Capture the entire match.
            .'<'           // Find start of element.
            .'(?'          // Conditional expression follows.
            .$escaped  // Find end of escaped element.
            .'|'           // ... else ...
            .'[^>]*>?' // Find end of normal element.
            .')'
            .')/';
    }

    return $regex;
}
