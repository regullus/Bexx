<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 30/05/18
 * Time: 19:31.
 */

namespace App\Models\Observers;

use App\Models\Address;

class AddressObserver
{
    public function saved(Address $address)
    {
        if ($address->is_main == 1) {
            Address::where('user_id', $address->user_id)
                ->where('id', '<>', $address->id)
                ->update(['is_main' => 0]);
        }
    }
}
