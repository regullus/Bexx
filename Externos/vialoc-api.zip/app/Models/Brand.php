<?php

namespace App\Models;

use EloquentFilter\Filterable;
use App\ModelFilters\BrandFilter;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * User resources.
 */
class Brand extends Model
{
    use Filterable, SoftDeletes, Sluggable;

    protected $fillable = [
        'name',
        'slug',
        'status',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function products()
    {
        return $this->hasMany(Product::class);
    }

    /*********************************************************************************************
     * FILTERS
     *********************************************************************************************/

    public function modelFilter()
    {
        return $this->provideFilter(BrandFilter::class);
    }

    /*********************************************************************************************
     * PLUGINS
     *********************************************************************************************/

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'name',
                'onUpdate' => true,
            ],
        ];
    }
}
