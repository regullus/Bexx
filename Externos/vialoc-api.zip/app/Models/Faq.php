<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Faq extends Model
{
    protected $table = 'faq';

    protected $fillable = [
        'question',
        'answer',
        'target',
    ];

    public $list_targets = [
        'locator' => 'Locador',
        'tenant' => 'Locatário',
        'both' => 'Ambos',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function faq_ratings()
    {
        return $this->hasMany(FaqRating::class);
    }
}
