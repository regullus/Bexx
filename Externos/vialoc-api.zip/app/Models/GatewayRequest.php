<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GatewayRequest extends Model
{
    protected $casts = [
        'order_id' => 'int',
        'order_payment_id' => 'int',
        'json_gateway_request' => 'array',
        'json_gateway_response' => 'array',
    ];

    protected $fillable = [
        'order_id',
        'order_payment_id',
        'json_gateway_request',
        'json_gateway_response',
        'status_authorization',
        'status_capture',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function orderPayment()
    {
        return $this->belongsTo(OrderPayment::class);
    }

    public function gatewayCaptures()
    {
        return $this->hasMany(GatewayCapture::class);
    }
}
