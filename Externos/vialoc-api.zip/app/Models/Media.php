<?php

namespace App\Models;

use Illuminate\Support\Arr;
use App\Traits\ScopeOrderedTrait;
use Plank\Mediable\Media as PlankMedia;
use App\Traits\ScopeFilterMetadataTrait;

class Media extends PlankMedia
{
    use ScopeFilterMetadataTrait, ScopeOrderedTrait;

    protected $casts = [
        'metadata' => 'array',
    ];

    protected $guarded = ['id', 'user_id', 'disk', 'directory', 'filename', 'extension', 'size', 'mime_type', 'aggregate_type', 'metadata'];

    protected $fillable = ['id', 'user_id', 'disk', 'directory', 'filename', 'extension', 'size', 'mime_type', 'aggregate_type', 'metadata'];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->user_id = Arr::random([1, 2, 3]); // somente para o faker

            if (auth()->check()) {
                $model->user_id = auth()->user()->id;
            }
        });
    }

    /*********************************************************************************************
     * METHODS
     *********************************************************************************************/

    public function getThumb($thumb = 'default', $type = 'url')
    {
        $thumb_op = null;
        if (isset($this->metadata['thumbnails'][$thumb])) {
            if ($type == 'url') {
                $thumb_op = asset($this->metadata['thumbnails'][$thumb]['path']);
            } elseif ($type == 'path') {
                $thumb_op = public_path().DIRECTORY_SEPARATOR.$this->metadata['thumbnails'][$thumb]['path'];
            }
        }

        return $thumb_op;
    }

    /*********************************************************************************************
     * SCOPES
     *********************************************************************************************/

    public function scopeFilterSearch($query, $search)
    {
        if (! $search) { // se não, desconsidera este filtro
            return $query;
        }

        return $query
                    ->where('filename', 'like', '%'.$search.'%')
                    ->orWhere('directory', 'like', '%'.$search.'%')
                    ->orWhere('aggregate_type', 'like', '%'.$search.'%')
                    ->orWhere('mime_type', 'like', '%'.$search.'%');
    }
}
