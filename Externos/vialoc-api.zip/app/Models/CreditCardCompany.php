<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CreditCardCompany extends Model
{
    protected $casts = [
        'max_installments' => 'int',
    ];

    protected $fillable = [
        'name',
        'slug',
        'max_installments',
        'options',
        'status',
    ];
}
