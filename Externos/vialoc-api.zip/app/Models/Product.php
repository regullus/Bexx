<?php

namespace App\Models;

use Illuminate\Support\Str;
use Plank\Mediable\Mediable;
use EloquentFilter\Filterable;
use App\ModelFilters\ProductFilter;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model implements Auditable
{
    use Filterable, Mediable, SoftDeletes, Sluggable;
    use \OwenIt\Auditing\Auditable;

    protected $casts = [
        'city_id' => 'int',
        'user_id' => 'int',
        'brand_id' => 'int',
        'height' => 'float',
        'width' => 'float',
        'length' => 'float',
        'weight' => 'float',
        'cubing' => 'float',
        'axes' => 'int',
        'rating_score' => 'float',
        'rating_count' => 'int',
    ];

    protected $fillable = [
        'external_id',
        'name',
        'slug',
        'content',
        'link_video',
        // 'city_id',
        'address_id',
        'user_id',
        'type',
        'brand_id',
        'height',
        'width',
        'length',
        'weight',
        'cubing',
        'axes',
        'licensing',
        'year',
        'model',
        'chassis',
        'renavam',
        'antt',
        'owner_name',
        'owner_cpf_cnpj',
        'license_plate',
        'floor',
        'with_tires',
        'suspension',
        'rating_score',
        'rating_count',
        // 'latitude',
        // 'longitude',
        'status',
    ];

    public $list_types = [
        'basculante' => 'Basculante',
        'bau' => 'Baú',
        'bebidas' => 'Bebidas',
        'canavieira' => 'Canavieira',
        'carroceria' => 'Carroceria',
        'florestal' => 'Florestal',
        'gado' => 'Gado',
        'graneleiro' => 'Graneleiro',
        'porta-container' => 'Porta-container',
        'prancha' => 'Prancha',
        'refrigerada' => 'Refrigerada',
        'sider' => 'Sider',
        'tanque' => 'Tanque',
    ];

    public $list_floors = [
        'chapa-xadrez' => 'Chapa Xadrez',
        'maderite' => 'Maderite',
    ];

    public $list_suspensions = [
        'pneumatica' => 'Pneumática',
        'mecanica' => 'Mecânica',
    ];

    public $list_status = [
        'draft' => 'Rascunho',
        'active' => 'Ativo',
        'inactive' => 'Inativo',
        'suspended' => 'Suspenso',
    ];

    public $list_image_views = [
        'left' => 'Vista lateral esquerda',
        'right' => 'Vista lateral direita',
        'front' => 'Vista frontal',
        'back' => 'Vista traseira',
        'interior' => 'Vista interior',
        'axes' => 'Eixos',
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uid = (string) Str::uuid();
        });
    }

    /*********************************************************************************************
     * MUTATORS
     *********************************************************************************************/

    public function setWidthAttribute($value)
    {
        if ($value == '0,00') {
            return $this->attributes['width'] = null;
        }

        return $this->attributes['width'] = formatted2Float($value);
    }

    public function setHeightAttribute($value)
    {
        if ($value == '0,00') {
            return $this->attributes['height'] = null;
        }

        return $this->attributes['height'] = formatted2Float($value);
    }

    public function setLengthAttribute($value)
    {
        if ($value == '0,00') {
            return $this->attributes['length'] = null;
        }

        return $this->attributes['length'] = formatted2Float($value);
    }

    public function setWeightAttribute($value)
    {
        if ($value == '0,00') {
            return $this->attributes['weight'] = null;
        }

        return $this->attributes['weight'] = formatted2Float($value);
    }

    public function setCubingAttribute($value)
    {
        if ($value == '0,00') {
            return $this->attributes['cubing'] = null;
        }

        return $this->attributes['cubing'] = formatted2Float($value);
    }

    public function setLicensingAttribute($value)
    {
        if ($value) {
            return $this->attributes['licensing'] = implode('-', array_reverse(explode('/', $value)));
        }
    }

    public function setLicensePlateAttribute($value)
    {
        return $this->attributes['license_plate'] = strtoupper($value);
    }

    public function setOwnerCpfCnpjAttribute($value)
    {
        return $this->attributes['owner_cpf_cnpj'] = onlyNumbers($value);
    }

    public function getWidthFormattedAttribute()
    {
        if ($this->width) {
            return floatFormatted($this->width);
        }
    }

    public function getHeightFormattedAttribute()
    {
        if ($this->height) {
            return floatFormatted($this->height);
        }
    }

    public function getLengthFormattedAttribute()
    {
        if ($this->length) {
            return floatFormatted($this->length);
        }
    }

    public function getWeightFormattedAttribute()
    {
        if ($this->weight) {
            return floatFormatted($this->weight);
        }
    }

    public function getCubingFormattedAttribute()
    {
        if ($this->cubing) {
            return floatFormatted($this->cubing);
        }
    }

    public function getLicensingFormattedAttribute()
    {
        if ($this->licensing) {
            return implode('/', array_reverse(explode('-', $this->licensing)));
        }
    }

    public function getOwnerCpfCnpjFormattedAttribute()
    {
        $mask = '###.###.###-##';
        if (strlen($this->owner_cpf_cnpj) > 11) {
            $mask = '##.###.###/####-##';
        }

        return mask($this->owner_cpf_cnpj, $mask);
    }

    public function getTypeFormattedAttribute()
    {
        if ($this->type) {
            return $this->list_types[$this->type];
        }
    }

    public function getFloorFormattedAttribute()
    {
        if ($this->floor) {
            return $this->list_floors[$this->floor];
        }
    }

    public function getSuspensionFormattedAttribute()
    {
        if ($this->suspension) {
            return $this->list_suspensions[$this->suspension];
        }
    }

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function address()
    {
        return $this->belongsTo(Address::class);
    }

    public function availability_alerts()
    {
        return $this->hasMany(AvailabilityAlert::class);
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class);
    }

    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function favorites()
    {
        return $this->hasMany(Favorite::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    public function prices()
    {
        return $this->hasMany(Price::class);
    }

    public function price_monthly()
    {
        return $this->hasOne(Price::class)->where('more_than', 30);
    }

    public function price_logs()
    {
        return $this->hasMany(PriceLog::class);
    }

    public function questions()
    {
        return $this->hasMany(QuestionAnswer::class)->where('parent_id', 0);
    }

    public function questionAnswers()
    {
        return $this->hasMany(QuestionAnswer::class);
    }

    public function ratings()
    {
        return $this->morphMany(Rating::class, 'ratingable');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /*********************************************************************************************
     * FILTERS
     *********************************************************************************************/

    /**
     * Define o filtro padrão ou seja, se na controller ou no serviço eu não definir um filtro como segundo parâmetro (
     * dinamicamente), então a classe filtro retornada nesse método será assumida.
     *
     *
     * @return string
     */
    public function modelFilter()
    {
        return $this->provideFilter(ProductFilter::class);
    }

    /*********************************************************************************************
     * PLUGINS
     *********************************************************************************************/

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable()
    {
        return [
            'slug' => [
                'source' => ['id', 'name'],
                'onUpdate' => true,
            ],
        ];
    }

    /*********************************************************************************************
     * METHODS
     *********************************************************************************************/

    /**
     * Verifica se a carreta está completa para ser ativada, considerando que precise ter o cadastro básico (primeira parte) e ao menos um preço.
     */
    public function isComplete()
    {
        return (bool)
            $this->name &&
            $this->brand_id &&
            $this->type &&
            $this->year &&
            $this->model &&
            ($this->axes !== null) &&
            $this->length &&
            $this->width &&
            $this->floor &&
            $this->suspension &&
            $this->content &&
            ($this->prices()->count() == 3) &&
            (! empty($mediaViews = $this->getMedia(['left', 'right', 'front', 'back', 'interior', 'axes'])) && $mediaViews->count() == 6) &&
            $this->owner_name &&
            $this->owner_cpf_cnpj &&
            $this->license_plate &&
            $this->chassis &&
            $this->renavam &&
            $this->antt &&
            $this->licensing &&
            $this->hasMedia('doc_crlv');
    }

    /**
     * Verifica se a status da carreta.
     */
    public function isStatus($status)
    {
        if (is_array($status)) {
            return (bool) in_array($this->status, $status);
        }

        return (bool) $this->status == $status;
    }

    /**
     * A criação de um pedido (soliictação) por parte do locatário só pode entrar no sistema caso a carreta esteja
     * disponível. Estar disponível significa que minha carreta não possui nenhum agendamento para o pedíodo solicitado.
     * Os status colocados na query representam situações que não possibilitam a locação da carreta.
     */
    public function availableToRent($dateStart, $dateEnd)
    {
        return ! (bool)
            $this->orders()
                ->where(function ($query) use ($dateStart, $dateEnd) {
                    $query->where('date_end', '>=', $dateStart)
                        ->where('date_start', '<=', $dateEnd);
                })
                ->whereIn('status', [
                    'pending-payment',
                    'pending-takeout',
                    'active',
                ])
                ->orderBy('created_at', 'asc')
                ->count();
    }

    /**
     * Gera um array de datas dos periodos que uma carreta estará alugada.
     */
    public function getRentedIntervals()
    {
        $op = [];
        $orders = $this->orders()
            ->whereIn('status', [
                'pending-payment',
                'pending-takeout',
                'active',
            ])
            ->where('date_end', '>=', now())
            ->orderBy('created_at', 'asc')
            ->get();

        if (! count($orders)) {
            return $op;
        }

        foreach ($orders as $order) {
            $op[] = ['start' => strtotime($order->date_start->format('Y-m-d').' 00:00:00'), 'end' => strtotime($order->date_end->format('Y-m-d').' 23:59:59')];
        }

        return $op;
    }

    /**
     * Filtra a lista de status para apresentar apenas os status que podem ser disponibilizados publicamente.
     */
    public function publicStatus()
    {
        $statuses = $this->list_status;
        unset($statuses['draft']);

        return $statuses;
    }
}
