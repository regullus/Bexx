<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BankSlip extends Model
{
    protected $casts = [
        'order_id' => 'int',
        'order_payment_id' => 'int',
    ];

    protected $fillable = [
        'order_id',
        'order_payment_id',
        'barcode_number',
        'digitable_line',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function orderPayment()
    {
        return $this->belongsTo(OrderPayment::class);
    }
}
