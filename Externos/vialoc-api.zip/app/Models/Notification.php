<?php

namespace App\Models;

use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    public $incrementing = false;

    protected $casts = [
        'notifiable_id' => 'int',
        'user_id' => 'int',
        'data' => 'array',
    ];

    protected $dates = [
        'read_at',
    ];

    protected $fillable = [
        'type',
        'notifiable_type',
        'notifiable_id',
        'data',
        'user_id',
        'read_at',
    ];

    // public $list_profile_types = [
    // 	'locator' => 'Locador',
    // 	'tenant' => 'Locatário',
    // ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->id = (string) Str::uuid();
        });
    }

    public function notifiable()
    {
        return $this->morphTo();
    }
}
