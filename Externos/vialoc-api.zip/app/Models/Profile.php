<?php

namespace App\Models;

use Carbon\Carbon;
use EloquentFilter\Filterable;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;
use Illuminate\Database\Eloquent\SoftDeletes;

class Profile extends Model implements Auditable
{
    use Filterable, SoftDeletes;
    use \OwenIt\Auditing\Auditable;

    protected $casts = [
        'phones' => 'array',
        'user_id' => 'int',
    ];

    protected $dates = [
        'birthdate',
    ];

    protected $fillable = [
        'user_id',
        'cpf',
        'birthdate',
        'cnpj',
        'company_name',
        'trading_name',
        'state_tax_number',
        'external_id',
        'website',
        'phones',
    ];

    /*********************************************************************************************
     * MUTATORS
     *********************************************************************************************/

    public function setBirthdateAttribute($value)
    {
        if ($value) {
            $this->attributes['birthdate'] = Carbon::createFromFormat('d/m/Y', $value);
        }
    }

    public function setCpfAttribute($value)
    {
        return $this->attributes['cpf'] = onlyNumbers($value);
    }

    public function setCnpjAttribute($value)
    {
        return $this->attributes['cnpj'] = onlyNumbers($value);
    }

    public function getCpfFormattedAttribute()
    {
        return mask($this->cpf, '###.###.###-##');
    }

    public function getCnpjFormattedAttribute()
    {
        return mask($this->cnpj, '##.###.###/####-##');
    }

    public function getShortTradingNameAttribute()
    {
        if (! $this->trading_name) {
            return;
        }

        $parts = explode(' ', $this->trading_name, 2);

        return $parts[0].' '.substr($parts[1], 0, 1).'.';
    }

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /*********************************************************************************************
    * FILTERS
    *********************************************************************************************/

    public function modelFilter()
    {
        return $this->provideFilter(\App\ModelFilters\ProfileFilter::class);
    }

    /*********************************************************************************************
     * METHODS
     *********************************************************************************************/

    public function isComplete()
    {
        return (bool)
            ($this->cnpj && $this->company_name && $this->trading_name && $this->state_tax_number) ||
            ($this->cpf && $this->birthdate);
    }
}
