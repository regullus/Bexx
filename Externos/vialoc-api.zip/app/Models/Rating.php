<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Rating extends Model
{
    protected $casts = [
        'evaluable_id' => 'int',
    ];

    protected $fillable = [
        'user_id',
        'order_id',
        'ratingable_type',
        'ratingable_id',
        'subtype',
        'score',
        'comment',
        'status',
    ];

    public static function boot()
    {
        parent::boot();

        // atualiza o produto/usuario com o rating "compilado", se o comentário for aprovado
        self::saved(function ($model) {
            // comentado o trecho abaixo, pois a nota é contabilizada independente do comentário ser aprovado ou não
            // if ($model->status != 'approved') {
            //     return;
            // }

            $subtype = $model->subtype;
            if ($subtype == 'product') { // produto
                $product = $model->ratingable;
                $sumScore = $product->ratings()->where('status', 'approved')->sum('score');
                $count = $product->ratings()->where('status', 'approved')->count();
                $product->rating_score = ($sumScore && $count ?  ($sumScore / $count) : 0);
                $product->rating_count = $count;
                \Log::info($product);
                $product->save();
            } else { // se for usuário ($subtype = 'locator' || 'tenant')
                $user = $model->ratingable;

                if ($subtype == 'locator') {
                    $sumScore = $user->ratingsLocatorReceived()->where('status', 'approved')->sum('score');
                    $count = $user->ratingsLocatorReceived()->where('status', 'approved')->count();
                } else { // tenant
                    $sumScore = $user->ratingsTenantReceived()->where('status', 'approved')->sum('score');
                    $count = $user->ratingsTenantReceived()->where('status', 'approved')->count();
                }

                $user['rating_'.$subtype.'_score'] = ($sumScore && $count ?  ($sumScore / $count) : 0);
                $user['rating_'.$subtype.'_count'] = $count;
                $user->save();
            }
        });
    }

    public $list_status = [
        'pending' => 'Sob revisão', // Avaliação está sob revisão
        'approved' => 'Aprovado', // Avaliação está aprovada
    ];

    /*********************************************************************************************
     * MUTATORS
     *********************************************************************************************/

    public function getStatusFormattedAttribute()
    {
        if ($this->type) {
            return $this->list_status[$this->status];
        }
    }

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function ratingable()
    {
        return $this->morphTo();
    }

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
