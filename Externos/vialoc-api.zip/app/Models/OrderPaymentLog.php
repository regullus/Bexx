<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderPaymentLog extends Model
{
    public $timestamps = false;

    protected $casts = [
        'order_payment_id' => 'int',
        'order_id' => 'int',
        'user_id' => 'int',
        'json_data' => 'array',
    ];

    protected $fillable = [
        'order_payment_id',
        'order_id',
        'user_id', // id do usuário que fez a alteração
        'payment_status',
        'request_ip', // IP de origem do request
        'json_data', // Snapshot da alteração que foi feita no order_payment
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function order_payment()
    {
        return $this->belongsTo(OrderPayment::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
