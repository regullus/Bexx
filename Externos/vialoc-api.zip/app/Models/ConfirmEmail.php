<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ConfirmEmail extends Model
{
    protected $table = 'confirm_email';

    public $timestamps = false;

    protected $hidden = [
        'token',
    ];

    protected $casts = [
        'user_id' => 'int',
    ];

    protected $fillable = [
        'user_id',
        'email',
        'token',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
