<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;

class QuestionAnswer extends Model
{
    use Notifiable, SoftDeletes;

    protected $casts = [
        'parent_id' => 'int',
        'user_id' => 'int',
        'product_id' => 'int',
    ];

    protected $dates = [
        'read_at',
    ];

    protected $fillable = [
        'parent_id',
        'user_id',
        'product_id',
        'content',
        'status',
        'read_at', // destinado para a contraparte da questao - no caso se o criador da questao leu
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function answers()
    {
        return $this->hasMany(self::class, 'parent_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function question()
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
