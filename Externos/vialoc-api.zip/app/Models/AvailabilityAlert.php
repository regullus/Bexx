<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AvailabilityAlert extends Model
{
    public $timestamps = false;

    protected $casts = [
        'product_id' => 'int',
        'user_id' => 'int',
    ];

    protected $fillable = [
        'product_id',
        'user_id',
        'email',
        'status',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
