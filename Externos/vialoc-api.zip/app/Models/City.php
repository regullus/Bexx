<?php

namespace App\Models;

use EloquentFilter\Filterable;
use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    use Filterable;

    protected $casts = [
        'is_capital' => 'int',
    ];

    protected $fillable = [
        'id',
        'name',
        'ibge_code',
        'state_code',
        'is_capital',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function state()
    {
        return $this->belongsTo(State::class, 'state_code');
    }

    public function addresses()
    {
        return $this->hasMany(Address::class);
    }

    public function products()
    {
        return $this->hasMany(Product::class);
    }

    /*********************************************************************************************
     * FILTERS
     *********************************************************************************************/

    public function modelFilter()
    {
        return $this->provideFilter(\App\ModelFilters\CityFilter::class);
    }
}
