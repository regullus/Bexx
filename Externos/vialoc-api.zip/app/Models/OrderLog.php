<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderLog extends Model
{
    public $timestamps = false;

    protected $dates = ['created_at'];

    protected $casts = [
        'user_id' => 'int',
        'order_id' => 'int',
        'json_order' => 'object',
    ];

    protected $fillable = [
        'user_id',
        'order_id',
        'json_order',
        'status',
    ];

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_at = $model->freshTimestamp();
        });
    }

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function order()
    {
        return $this->belongsTo(Order::class);
    }
}
