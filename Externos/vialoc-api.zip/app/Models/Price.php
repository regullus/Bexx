<?php

namespace App\Models;

use EloquentFilter\Filterable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Price extends Model
{
    use Filterable, SoftDeletes;

    protected $casts = [
        'product_id' => 'int',
        'more_than' => 'int',
        'price_period' => 'float',
        'price_per_day' => 'float',
    ];

    protected $fillable = [
        'id',
        'product_id',
        'more_than',
        'price_per_day',
        'price_period',
        'status',
    ];

    /*********************************************************************************************
     * MUTATORS
     *********************************************************************************************/

    public function getPricePeriodFormattedAttribute()
    {
        if ($this->price_period) {
            return floatFormatted($this->price_period);
        }
    }

    public function getPricePerDayFormattedAttribute()
    {
        if ($this->price_per_day) {
            return floatFormatted($this->price_per_day);
        }
    }

    public function setPricePeriodAttribute($value)
    {
        return $this->attributes['price_period'] = formatted2Float($value);
    }

    public function setPricePerDayAttribute($value)
    {
        return $this->attributes['price_per_day'] = formatted2Float($value);
    }

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    /*********************************************************************************************
     * FILTERS
     *********************************************************************************************/

    public function modelFilter()
    {
        return $this->provideFilter(\App\ModelFilters\PriceFilter::class);
    }
}
