<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class OrderMessage extends Model
{
    use SoftDeletes;

    protected $casts = [
        'order_id' => 'int',
        'user_id' => 'int',
    ];

    protected $dates = [
        'read_at',
    ];

    protected $fillable = [
        'order_id',
        'content',
        'user_id',
        'read_at', // destinado para a contraparte da questao - no caso se o criador da questao leu
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
