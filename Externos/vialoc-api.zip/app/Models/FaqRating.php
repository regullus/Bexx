<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FaqRating extends Model
{
    protected $casts = [
        'faq_id' => 'int',
        'user_id' => 'int',
        'rating' => 'int',
    ];

    protected $fillable = [
        'faq_id',
        'user_id',
        'rating',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function faq()
    {
        return $this->belongsTo(Faq::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
