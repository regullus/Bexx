<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    protected $casts = [
        'users_id' => 'int',
    ];

    protected $dates = [
        'published_at',
    ];

    protected $fillable = [
        'users_id',
        'title',
        'slug',
        'except',
        'content',
        'type',
        'status',
        'published_at',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function user()
    {
        return $this->belongsTo(User::class, 'users_id');
    }
}
