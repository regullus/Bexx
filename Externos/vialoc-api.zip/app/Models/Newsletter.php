<?php

namespace App\Models;

use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;

class Newsletter extends Model
{
    protected $fillable = [
        'user_id',
        'name',
        'last_name',
        'email',
        'status',
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uid = (string) Str::uuid();
        });
    }

    /**
     * Quando o Model Bind for executado ou seja, quando eu enviar um UID no path da rota newsletter para o método
     * delete, a busca pelo UID no banco será realizada através do campo "uid" da tabela e não "id" que seria o campo
     * padrão de busca do Model Bind. Abaixo eu alterei o campo de busca para uid.
     *
     * https://laravel.com/docs/5.7/routing#route-model-binding
     */
    public function getRouteKeyName()
    {
        return 'uid';
    }
}
