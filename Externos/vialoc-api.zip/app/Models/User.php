<?php

namespace App\Models;

/*
 * Vendor packages
 */
use Illuminate\Support\Str;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Spatie\Permission\Traits\HasRoles;
use Plank\Mediable\Mediable;
use EloquentFilter\Filterable;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Notifications\Notifiable;
use OwenIt\Auditing\Contracts\Auditable;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Notifications\UserResetPasswordNotification;

class User extends Authenticatable implements JWTSubject, Auditable
{
    use Filterable, Mediable, Notifiable, Sluggable, SoftDeletes, HasRoles;
    use \OwenIt\Auditing\Auditable;
    use \Staudenmeir\EloquentHasManyDeep\HasRelationships;

    protected $casts = [
        'email_confirmed' => 'int',
        'agree_terms' => 'int',
        'receive_news' => 'int',
        'rating_locator_score' => 'float',
        'rating_locator_count' => 'int',
        'rating_tenant_score' => 'float',
        'rating_tenant_count' => 'int',
    ];

    protected $fillable = [
        'id',
        'uid',
        'name',
        'last_name',
        'email',
        'password',
        'type',
        'email_confirmed',
        'remember_token',
        'email_intended',
        'agree_terms',
        'receive_news',
        'status',
        'rating_locator_score',
        'rating_locator_count',
        'rating_tenant_score',
        'rating_tenant_count',
        'loggedin_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    protected $dates = [
        'loggedin_at', 'created_at', 'updated_at',
    ];

    public $list_status = [
        'to-complete' => 'to-complete', // Usuário foi cadastrado por uma rede social, porém precisa completar o cadastro.
        'active' => 'Ativo', // Usuário está ativo
        'inactive' => 'Inativo', // Usuário foi inativado pelo administrador e não pode acessar
        'blocked' => 'Bloqueado', // Usuário foi bloqueado pelo administrador/sistema e não pode acessar
        'pending' => 'Pendente', // Usuário foi recem registrado e não pode executar algumas ações até confirmar o cadastro
    ];

    public $list_type = [
        'tenant' => 'Locatário',
        'locator' => 'Locador',
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uid = (string) Str::uuid();
        });

        self::created(function ($model) {
            $model->profile()->create();
        });
    }

    /**
     * The channels the user receives notification broadcasts on.
     *
     * @return string
     */
    public function receivesBroadcastNotificationsOn()
    {
        return 'users.'.$this->uid;
    }

    /*********************************************************************************************
     * MUTATORS
     *********************************************************************************************/

    public function getFullNameAttribute()
    {
        return $this->name.' '.$this->last_name;
    }

    public function getShortNameAttribute()
    {
        return $this->name.' '.substr($this->last_name, 0, 1).'.';
    }

    public function getStatusFormattedAttribute()
    {
        return $this->list_status[$this->status];
    }

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    // endereço principal
    public function address()
    {
        return $this->hasOne(Address::class)->where('is_main', 1);
    }

    public function addresses()
    {
        return $this->hasMany(Address::class);
    }

    public function availability_alerts()
    {
        return $this->hasMany(AvailabilityAlert::class);
    }

    public function confirm_emails()
    {
        return $this->hasMany(ConfirmEmail::class);
    }

    public function faq_ratings()
    {
        return $this->hasMany(FaqRating::class);
    }

    public function favorites()
    {
        return $this->hasMany(Favorite::class);
    }

    public function linkedSocialAccounts()
    {
        return $this->hasMany(LinkedSocialAccount::class);
    }

    public function locatorQuestions()
    {
        return $this->hasManyThrough(QuestionAnswer::class, Product::class);
    }

    public function locatorMessages()
    {
        return $this->hasManyDeep(OrderMessage::class, [Product::class, Order::class]);
    }

    public function locatorMessagesCounterpart()
    {
        return $this->hasManyDeep(OrderMessage::class, [Product::class, Order::class])->where('user_id', '!=', auth()->user()->id);
    }

    public function locatorOrders()
    {
        return $this->hasManyThrough(Order::class, Product::class);
    }

    public function newsletter()
    {
        return $this->hasOne(Newsletter::class);
    }

    public function notifications()
    {
        return $this->morphMany(Notification::class, 'notifiable');
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    public function orderMessages()
    {
        return $this->hasMany(OrderMessage::class);
    }

    public function orderMessagesCounterpart()
    {
        return $this->hasManyDeep(OrderMessage::class, [Order::class])->where('order_messages.user_id', '!=', auth()->user()->id);
    }

    public function pages()
    {
        return $this->hasMany(Page::class, 'users_id');
    }

    public function products()
    {
        return $this->hasMany(Product::class);
    }

    public function profile()
    {
        return $this->hasOne(Profile::class);
    }

    public function questions()
    {
        return $this->hasMany(QuestionAnswer::class)->where('parent_id', 0);
    }

    public function questionAnswers()
    {
        return $this->hasMany(QuestionAnswer::class)->where('parent_id', '!=', 0);
    }

    public function ratings()
    {
        return $this->morphMany(Rating::class, 'ratingable');
    }

    public function ratingsLocatorReceived()
    {
        return $this->morphMany(Rating::class, 'ratingable')->where('subtype', 'locator');
    }

    public function ratingsLocatorSent()
    {
        return $this->hasMany(Rating::class)->where('subtype', 'tenant');
    }

    public function ratingsTenantReceived()
    {
        return $this->morphMany(Rating::class, 'ratingable')->where('subtype', 'tenant');
    }

    public function ratingsTenantSent()
    {
        return $this->hasMany(Rating::class)->where('subtype', 'locator');
    }

    /*********************************************************************************************
     * PLUGINS
     *********************************************************************************************/

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable()
    {
        return [
            'slug' => [
                'source' => ['id', 'name'],
                'onUpdate' => true,
            ],
        ];
    }

    // Rest omitted for brevity

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = bcrypt($value);
    }

    /*********************************************************************************************
     * FILTERS
     *********************************************************************************************/

    public function modelFilter()
    {
        return $this->provideFilter(\App\ModelFilters\UserFilter::class);
    }

    /*********************************************************************************************
     * METHODS
     *********************************************************************************************/

    public function isComplete()
    {
        return (bool)
            ($this->address && $this->address->isComplete()) &&
            ($this->profile && $this->profile->isComplete());
    }

    /*********************************************************************************************
     * NOTIFICATIONS
     *********************************************************************************************/

    /**
     * OVERRIDE - Send the password reset notification.
     *
     * @param  string  $token
     * @return void
     */
    public function sendPasswordResetNotification($token)
    {
        $this->notify(new UserResetPasswordNotification($token));
    }
}
