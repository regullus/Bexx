<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class GatewayCapture extends Model
{
    use SoftDeletes;

    protected $casts = [
        'order_id' => 'int',
        'order_payment_id' => 'int',
        'gateway_request_id' => 'int',
        'json_response' => 'array',
        'status' => 'int',
    ];

    protected $fillable = [
        'order_id',
        'order_payment_id',
        'gateway_request_id',
        'json_response',
        'status',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function gatewayRequest()
    {
        return $this->belongsTo(GatewayRequest::class);
    }

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function orderPayment()
    {
        return $this->belongsTo(OrderPayment::class);
    }
}
