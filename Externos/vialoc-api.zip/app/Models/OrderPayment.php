<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderPayment extends Model
{
    protected $casts = [
        'order_id' => 'int',
    ];

    protected $fillable = [
        'order_id',
        'payment_method_slug',
        'payment_method_option', // num primeiro momento será utilizado para armazenar qual a bandeira de cartão foi feito o pagamento
        'gateway_payment_id',
        'gateway_transaction_id',
        'status', // status geral do pagamento
        'status_authorization', // apenas cartão de crédito - status da autorização
        'status_capture', // apenas cartão de crédito - status da captura
    ];

    public $list_credit_card_brands = [
        'visa' => 'Visa',
        'mastercard' => 'Mastercard',
        'american-express' => 'American Express',
        'elo' => 'Elo',
        'aura' => 'Aura',
        'jcb' => 'JCB',
        'diners-club' => 'Diners',
        'discover' => 'Discover',
        'hipercard' => 'Hipercard',
    ];

    public $list_payment_methods = [
        'bank-slip' => 'Boleto Bancário',
        'credit-card' => 'Cartão de Crédito',
        'debit-card' => 'Cartão de Débito',
    ];

    public $list_status = [
        'pending' => 'Pendente', // pendente de envio
        'processing' => 'Processando', // aguardando baixa ou retorno
        'finished' => 'Finalizado', // Pagamento foi realizado com sucesso
        'canceled' => 'Cancelado', // Cancelado por solicitação no fluxo ou manual
    ];

    public $list_status_authorization = [ // só se aplica se o pagamento for cartão de crédito
        'processing' => 'Em processamento',
        'authorized' => 'Autorizado',
        'finished' => 'Finalizado',
        'voided' => 'Cancelado',
        'refunded' => 'Cancelado',
        'pending' => 'Pendente',
        'aborted' => 'Cancelado',
        'scheduled' => 'Agendado',
        'denied' => 'Não autorizado',
        'comunication_error' => 'Erro de comunicação',
    ];

    public $list_status_capture = [ // só se aplica se o pagamento for cartão de crédito
        'pending' => 'Pendente',
        'processing' => 'Em processamento',
        'finished' => 'Finalizado',
        'denied' => 'Não autorizado',
        'comunication_error' => 'Erro de comunicação',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function bankSlip()
    {
        return $this->hasOne(BankSlip::class);
    }

    public function gatewayRequest()
    {
        return $this->hasOne(GatewayRequest::class)->latest();
    }

    public function gatewayRequests()
    {
        return $this->hasMany(GatewayRequest::class);
    }

    public function gatewayCapture()
    {
        return $this->hasOne(GatewayCapture::class)->latest();
    }

    public function gatewayCaptures()
    {
        return $this->hasMany(GatewayCapture::class);
    }

    public function logs()
    {
        return $this->hasMany(OrderPaymentLog::class);
    }

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function paymentMethod()
    {
        return $this->belongsTo(PaymentMethod::class, 'payment_method_slug', 'slug');
    }
}
