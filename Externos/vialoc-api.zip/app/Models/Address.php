<?php

namespace App\Models;

use App\Traits\ScopeInsideRadiusTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Address extends Model
{
    use SoftDeletes, ScopeInsideRadiusTrait;

    protected $casts = [
        'user_id' => 'int',
        'city_id' => 'int',
        'is_main' => 'int',
    ];

    protected $fillable = [
        'user_id',
        'label',
        'zipcode',
        'address',
        'address_number',
        'address_complement',
        'district',
        'city_id',
        'notes',
        'is_main',
        'latitude',
        'longitude',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function products()
    {
        return $this->hasMany(Product::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /*********************************************************************************************
     * METHODS
     *********************************************************************************************/

    public function setZipcodeAttribute($value)
    {
        return $this->attributes['zipcode'] = onlyNumbers($value);
    }

    public function getZipcodeFormattedAttribute()
    {
        return mask($this->zipcode, '#####-###');
    }

    public function isComplete()
    {
        return (bool)
            $this->zipcode &&
            $this->address &&
            $this->address_number &&
            $this->district &&
            $this->city_id;
    }
}
