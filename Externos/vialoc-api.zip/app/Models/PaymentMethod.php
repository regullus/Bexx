<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentMethod extends Model
{
    protected $casts = [
        'options' => 'array',
    ];

    protected $fillable = [
        'name',
        'slug',
        'options',
        'status',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function orderPayments()
    {
        return $this->hasMany(OrderPayment::class, 'slug', 'payment_method_slug');
    }
}
