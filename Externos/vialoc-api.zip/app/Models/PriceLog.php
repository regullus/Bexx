<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PriceLog extends Model
{
    /**
     * Disable updated_at column.
     *
     * @var string
     */
    const UPDATED_AT = null;

    protected $casts = [
        'product_id' => 'int',
        'json_prices' => 'obj',
    ];

    protected $fillable = [
        'price_id',
        'json_prices',
    ];

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function product()
    {
        return $this->belongsTo(Product::class);
    }
}
