<?php

namespace App\Models;

use EloquentFilter\Filterable;
use App\ModelFilters\OrderFilter;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use Filterable;

    protected $casts = [
        'address_id' => 'int',
        'days_total' => 'int',
        'json_address' => 'object',
        'json_price' => 'object',
        'json_prices_base' => 'object',
        'json_product' => 'object',
        'json_user' => 'object',
        'price_id' => 'int',
        'price_total' => 'float',
        'product_id' => 'int',
        'user_id' => 'int',
        'metadata' => 'array',
    ];

    protected $dates = [
        'date_start',
        'date_end',
    ];

    protected $fillable = [
        'user_id',
        'json_user',
        'address_id',
        'json_address',
        'product_id',
        'json_product',
        'price_id',
        'json_price',
        'json_prices_base',
        'date_start',
        'date_end',
        'days_total',
        'price_total',
        'status',
        'metadata',
    ];

    public $list_status = [
        'pending-confirmation' => 'Aguardando confirmação do locador',
        'pending-payment' => 'Aguardando pagamento',
        'refused' => 'Recusado pelo locador',
        'pending-takeout' => 'Aguardando retirada',
        'active' => 'Locação em andamento',
        'finished' => 'Locação finalizada',
        'canceled' => 'Locação cancelada pelo usuário',
    ];

    /*********************************************************************************************
     * MUTATORS
     *********************************************************************************************/

    public function getPriceTotalFormattedAttribute()
    {
        return floatFormatted($this->price_total);
    }

    public function getStatusFormattedAttribute()
    {
        return $this->list_status[$this->status];
    }

    public function getJsonProductViewAttribute()
    {
        return (object) [
            'uid' => $this->json_product->uid,
            'type' => $this->json_product->type,
            'name' => $this->json_product->name,
            'slug' => $this->json_product->slug,
            'model' => $this->json_product->model,
            'year' => $this->json_product->year,
            'axes' => $this->json_product->axes,
            'width' => $this->json_product->width,
            'height' => $this->json_product->height,
            'length' => $this->json_product->length,
            'weight' => $this->json_product->weight,
            'cubing' => $this->json_product->cubing,
            'floor' => $this->json_product->floor,
            'suspension' => $this->json_product->suspension,
            'with_tires' => $this->json_product->with_tires,
            'brand' => $this->json_product->brand->name,
            'city' => $this->json_product->address->city->name,
            'state_code' => $this->json_product->address->city->state_code,
        ];
    }

    /*********************************************************************************************
     * RELATIONSHIPS
     *********************************************************************************************/

    public function address()
    {
        return $this->belongsTo(Address::class);
    }

    public function bankSlip()
    {
        return $this->hasOne(BankSlip::class)->latest();
    }

    public function bankSlips()
    {
        return $this->hasMany(BankSlip::class);
    }

    public function logs()
    {
        return $this->hasMany(OrderLog::class);
    }

    public function messages()
    {
        return $this->hasMany(OrderMessage::class);
    }

    public function messagesCounterpart()
    {
        return $this->hasMany(OrderMessage::class)->where('user_id', '!=', auth()->user()->id);
    }

    public function payment()
    {
        return $this->hasOne(OrderPayment::class)->latest();
    }

    public function payments()
    {
        return $this->hasMany(OrderPayment::class);
    }

    public function price()
    {
        return $this->belongsTo(Price::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function ratings()
    {
        return $this->hasMany(Rating::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /*********************************************************************************************
     * FILTERS
     *********************************************************************************************/

    public function modelFilter()
    {
        return $this->provideFilter(OrderFilter::class);
    }

    /*********************************************************************************************
     * METHODS
     *********************************************************************************************/

    public function isStatus($status)
    {
        if (is_array($status)) {
            return in_array($this->status, $status);
        }

        return $this->status == $status;
    }

    public function searchOverlappingOrders()
    {
        return
            $this->product->orders()
                ->where('id', '!=', $this->id)
                ->overlapPeriod($this)
                ->whereIn('status', [
                    'pending-confirmation',
                    // na teoria os status abaixo nunca vão ocorrer na etapa de confirmação pois no momento da criação da
                    // criação (solicitação feita pelo locatário), é feita uma busca na tabela de pedidos verificando se
                    // existe algum com um desses status dentro do período em questão. Caso exista retorna erro.
                    'pending-payment',
                    'pending-takeout',
                    'active',
                ])
                ->orderBy('created_at', 'asc')
                ->get();
    }

    public function scopeOverlapPeriod($query, $order)
    {
        return $query->where(function ($query) use ($order) {
            $query->where('date_end', '>=', $order->date_start)
                ->where('date_start', '<=', $order->date_end);
        });
    }
}
