<?php

namespace App\Tools;

use App\Models\City;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\ServerException;
use GuzzleHttp\Exception\ConnectException;

class C7WsQuery
{
    protected $client;

    public function __construct()
    {
        $this->client = new Client([
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ],
        ]);
    }

    public function zipcode($zipcode)
    {
        $zipcode = onlyNumbers($zipcode);

        $address = self::viacep($zipcode);

        if (! $address) {
            $address = self::republicavirtual($zipcode);
        }

        if (! $address) {
            return false;
        }

        return $address;
    }

    protected function viacep($zipcode)
    {
        try {
            $response = $this->client->get("https://viacep.com.br/ws/{$zipcode}/json/unicode/");
        } catch (ClientException | ConnectException | ServerException $e) {
            return false;
        }

        $address = json_decode($response->getBody()->getContents());

        if (empty(! $address->uf) && ! empty($address->erro)) {
            return false;
        }

        return [
            'zipcode' => mask($zipcode, '#####-###'),
            'address' => $address->logradouro,
            'district' => $address->bairro,
            'city' => $address->localidade,
            'state_code' => $address->uf,
            'city_id' => self::getCityId($address->uf, $address->localidade),
        ];
    }

    protected function republicavirtual($zipcode)
    {
        try {
            $response = $this->client->get("http://cep.republicavirtual.com.br/web_cep.php?cep={$zipcode}&formato=json");
        } catch (ClientException | ConnectException | ServerException $e) {
            return false;
        }

        $address = json_decode($response->getBody()->getContents());

        if ($address->resultado == '0') {
            return false;
        }

        return [
            'zipcode' => mask($zipcode, '#####-###'),
            'address' => $address->tipo_logradouro.' '.$address->logradouro,
            'district' => $address->bairro,
            'city' => $address->cidade,
            'state_code' => $address->uf,
            'city_id' => self::getCityId($address->uf, $address->cidade),
        ];
    }

    public function getCityId($state, $city)
    {
        $city = City::where('state_code', $state)->where('name', 'like', $city)->first();

        if (! $city) {
            return;
        }

        return $city->id;
    }
}
