<?php

namespace App\Tools;

use Illuminate\Support\Arr;
use Illuminate\Support\Str;

class C7Upload
{
    public static function avatar($file, $user_uid)
    {
        $path = 'users'.DIRECTORY_SEPARATOR.$user_uid;
        $full_path = public_path().DIRECTORY_SEPARATOR.'media'.DIRECTORY_SEPARATOR.$path;
        if (! \File::exists($full_path)) {
            \File::makeDirectory($full_path, 0755, true);
        }

        $filename = 'avatar';

        $file_stored = \MediaUploader::fromSource($file)
                ->useFilename($filename)
                ->toDirectory($path)
                ->onDuplicateReplace()
                ->upload();

        self::generateThumbnails($file_stored, ['sizes_only' => ['default']]);

        return $file_stored;
    }

    public static function productImage($file, $product, $filename_suffix = null)
    {
        $path = 'products'.DIRECTORY_SEPARATOR.$product->created_at->format('Y'.DIRECTORY_SEPARATOR.'m').DIRECTORY_SEPARATOR.$product->uid;
        // $full_path = public_path() . DIRECTORY_SEPARATOR . 'media' . DIRECTORY_SEPARATOR . $path;
        // if (!\File::exists($full_path)) {
        //     \File::makeDirectory($full_path, 0755, true);
        // }

        if (empty($filename_suffix)) {
            $filename_suffix = Str::random(10);
        }

        $filename = 'carreta-'.$product->type.'-'.Str::slug(substr($product->name, 0, 20)).'-'.$filename_suffix;

        $file_stored = \MediaUploader::fromSource($file)
                ->useFilename($filename)
                ->toDirectory($path)
                ->onDuplicateIncrement()
                ->upload();

        self::generateThumbnails($file_stored, ['sizes_only' => ['default', 'retangle-small', 'retangle-medium']]);

        return $file_stored;
    }

    public static function productDocument($file, $document_type, $product)
    {
        $path = 'products'.DIRECTORY_SEPARATOR.$product->created_at->format('Y'.DIRECTORY_SEPARATOR.'m').DIRECTORY_SEPARATOR.$product->uid;

        $filename = $document_type;

        $file_stored = \MediaUploader::fromSource($file)
                ->useFilename($filename)
                ->toDisk('documents')
                ->toDirectory($path)
                ->onDuplicateReplace()
                ->upload();

        self::generateThumbnails($file_stored, ['sizes_only' => ['default']]);

        return $file_stored;
    }

    protected static function generateThumbnails($file, $attributes = [])
    {
        $attributes = array_merge([
            'sizes_only' => null, // only these thumbnail sizes
            'sizes_exclude' => null, // exclude these thumbnail sizes
            'sizes_include' => null, // include these thumbail sizes
        ], $attributes);

        $config_thumbs = config('c7.thumbs_sizes');

        if ($attributes['sizes_only']) {
            $config_thumbs = Arr::only($config_thumbs, $attributes['sizes_only']);
        }

        if ($attributes['sizes_exclude']) {
            $config_thumbs = Arr::except($config_thumbs, $attributes['sizes_exclude']);
        }

        $thumbnails = [];
        $metadata = [];

        $path = $file->disk.DIRECTORY_SEPARATOR.$file->directory;
        $full_path = config('filesystems.disks.'.$file->disk.'.root').DIRECTORY_SEPARATOR.$file->directory;
        $file_original = $file->filename.'.'.$file->extension;
        $file_path = $full_path.DIRECTORY_SEPARATOR.$file_original;

        $file_info = \Image::make($file_path);
        $metadata = [
                    'width' => $file_info->width(),
                    'height' => $file_info->height(),
                ];

        // generate Thumbs
        foreach ($config_thumbs as $th_name => $th) {
            if (! $th['auto'] && ($attributes['sizes_include'] && ! in_array($th_name, $attributes['sizes_include']))) {
                continue;
            }

            $get_thumb = \Image::make($file_path);

            if ($th['crop']) {
                $get_thumb->fit($th['w'], $th['h']);
            } else {
                $get_thumb->resize($th['w'], $th['h'], function ($constraint) {
                    $constraint->aspectRatio();
                });
            }

            $file_target = $file->filename.'-'.($th['w'] ? $th['w'] : 0).'x'.($th['h'] ? $th['h'] : 0).'.'.$file->extension;

            $get_thumb->save($full_path.DIRECTORY_SEPARATOR.$file_target);

            $thumbnails[$th_name] = [
                'path' => $path.DIRECTORY_SEPARATOR.$file_target,
            ];
        }

        $metadata['thumbnails'] = $thumbnails;

        if (is_array($file->metadata)) {
            $metadata = array_merge($file->metadata, $metadata);
        }

        $file->metadata = $metadata;
        $file->save();
    }
}
