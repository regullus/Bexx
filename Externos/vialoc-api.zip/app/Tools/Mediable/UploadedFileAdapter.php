<?php

namespace App\Tools\Mediable;

use Plank\Mediable\SourceAdapters\UploadedFileAdapter as PlankUploadedFileAdapter;

/**
 * Uploaded File Adapter.
 *
 * Adapts the UploadedFile class from Symfony Components.
 *
 * @author Sean Fraser <sean@plankdesign.com>
 */
class UploadedFileAdapter extends PlankUploadedFileAdapter
{
    /**
     * {@inheritdoc}
     */
    public function extension(): string
    {
        $extension = (string) strtolower($this->source->getClientOriginalExtension());

        if ($extension) {
            return $extension;
        }

        return (string) strtolower($this->source->guessExtension());
    }
}
