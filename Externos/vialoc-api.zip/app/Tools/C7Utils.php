<?php

namespace App\Tools;

class C7Utils
{
    public static function buildPaginator($arr, $collection)
    {
        $arr['pagination']['currentPage'] = $collection->currentPage();
        $arr['pagination']['perPage'] = $collection->perPage();
        $arr['pagination']['total'] = $collection->total();
        $arr['pagination']['lastPage'] = $collection->lastPage();

        return $arr;
    }
}
