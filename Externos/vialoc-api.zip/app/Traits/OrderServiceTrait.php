<?php

namespace App\Traits;

use App\Models\Order;

trait OrderServiceTrait
{
    // REVISAR
    public function createMessage(Order $order, User $user, $data)
    {
        // Valida se a carreta pertence ao usuário logado
        if (! $this->user->can('updateAsLocator', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        // verifica se a carreta está ativa
        if ($order->product->status != 'active') {
            throw new ProductUnavailableException(config('error.product_unavailable'), 404);
        }

        // Verifica se o pedido que vai ser confirmado possui status pending-confirmation
        if ($order->isStatus(['pending-confirmation', 'pending-payment', 'refused', 'canceled', 'finished'])) {
            throw new OrderActionNotAllowedException(config('error.order_status_not_allowed'), 422);
        }

        $data['user_id'] = $user->id;

        return $order->messages()->create($data);
    }

    protected function log(Order $order)
    {
        // Grava o log do pedido
        return $order->logs()->create([
            'user_id' => $this->user ? $this->user->id : null,
            'order_id' => $order->id,
            'json_order' => $order,
            'status' => $order->status,
        ]);
    }

    protected function doRating(Order $order, $rating, $subtype)
    {
        $ratingData = [
            'user_id' => $this->user->id,
            'order_id' => $order->id,
            'subtype' => $subtype,
            'score' => $rating['score'],
            'comment' => ! empty($rating['comment']) ? $rating['comment'] : null,
            'status' => empty($rating['comment']) ? 'approved' : 'pending', // se não houver comentário, o rating é aprovado automaticamente
        ];

        if ($subtype == 'product') {
            $rating = $order->product->ratings()->create($ratingData);
        } elseif ($subtype == 'locator') {
            $rating = $order->product->user->ratings()->create($ratingData);
        } else { // tenant
            $rating = $order->user->ratings()->create($ratingData);
        }

        return $rating;
    }
}
