<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 05/11/18
 * Time: 14:13.
 */

namespace App\Traits;

use Intervention\Image\Exception\NotFoundException;

trait DocumentTrait
{
    /**
     * Pela URL será especificado o documento que vai ser baixado. O locador poderá ver o documento somente durante a
     * edição do produto. O locatário vai poder ver o documento após a contratação. Hoje existe apenas um documento
     * chamado CRLV porém, no futuro vão existir outros.
     *
     * O locador pode ver o documento quando ele cadastra a carreta, e no caso do locatário vai poder ver depois que ele
     * pagar o pedido.
     *
     * Este método vai ser chamado (no caso do CRLV), na tela de produto, quando o usuário subir o documento na aba
     * "Informações adicionais" no final do formulário.
     *
     * Não é um documento público, por este motivo o documento fica dentro do storage.
     */
    public function getDocuments($item, $document_type, $size)
    {
        //$item = $model->where('uid', $key)->first();
        if (empty($item)) {
            return;
        }

        $document = $item->firstMedia($document_type);
        if (empty($document)) {
            return;
        }

        if (empty($document_base64 = getMediaBase64($document, $size))) {
            return;
        }

        return $document_base64;
    }
}
