<?php

namespace App\Traits;

trait ScopeOrderedTrait
{
    public function scopeOrdered($query, $order_field = null, $order_direction = null)
    {
        if (! $order_field) {
            $order_field = 'created_at';
        }

        if (! $order_direction) {
            $order_direction = 'desc';
        }

        return $query->orderBy($order_field, $order_direction);
    }
}
