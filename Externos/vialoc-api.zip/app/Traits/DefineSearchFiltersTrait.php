<?php

namespace App\Traits;

use App\Models\Brand;
use App\Models\Price;
use App\Models\Product;
use Illuminate\Support\Arr;
use App\Transformers\v1\BrandTransformer;

trait DefineSearchFiltersTrait
{
    protected function cacheBrandsList()
    {
        $brands = Brand::whereHas('products', function ($query) {
            $query->where('status', 'active');
        })->get();

        \Cache::forever('brands_list', fractal($brands, new BrandTransformer)->toArray());

        return \Cache::get('brands_list');
    }

    protected function cachePriceRange()
    {
        $chunk = 250;

        $prices = Price::where('more_than', 30)->whereHas('product', function ($query) {
            $query->where('status', 'active');
        });

        $price_min = (integer) floor(($prices->min('price_period') - $chunk) / $chunk);
        $price_min = ($price_min < 1 ? 1 : $price_min) * $chunk;

        $price_max = (integer) ((ceil($prices->max('price_period') + $chunk) / $chunk) * $chunk);

        if ($price_min == $price_max) {
            $price_max += 1000;
        }

        \Cache::forever('price_range', [$price_min, $price_max]);

        return \Cache::get('price_range');
    }

    protected function cacheYearRange()
    {
        $year_min = (int) Product::where('status', 'active')->min('year');
        $year_max = (int) Product::where('status', 'active')->max('year');

        \Cache::forever('year_range', [$year_min, $year_max]);

        return \Cache::get('year_range');
    }

    protected function cacheTypesList()
    {
        $get_types = Product::select('type')->where('status', 'active')->distinct()->get()->pluck('type')->toArray();
        $types = Arr::only((new Product)->list_types, $get_types);

        \Cache::forever('types_list', $types);

        return \Cache::get('types_list');
    }

    protected function cacheAllFormData()
    {
        self::cacheBrandsList();
        self::cachePriceRange();
        self::cacheYearRange();
        self::cacheTypesList();

        return [
            'price_range' => \Cache::get('price_range'),
            'year_range' => \Cache::get('year_range'),
            'brands_list' => \Cache::get('brands_list'),
            'types_list' => \Cache::get('types_list'),
        ];
    }
}
