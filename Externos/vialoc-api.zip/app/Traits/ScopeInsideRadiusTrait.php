<?php

namespace App\Traits;

trait ScopeInsideRadiusTrait
{
    /**
     * Filtra por elementos cuja latitude e longitude estejam dentro de um raio pré-determinado.
     * @param  object  $query    Objeto do Eloquent
     * @param  string  $key      Chave da entrada na metadata
     * @param  string  $value    Valor da entrada na metadata
     * @param  bool $only_all Se true, performa a busca somente se key e value estiverem preenchidos
     * @return object            Retorna o objeto do eloquent
     */
    public function scopeInsideRadius($query, $coordinates, $radius = 1000)
    {

        // 6371 para kilometros e 3959 para milhas
        $haversine = '(6371 * acos(cos(radians('.$coordinates['latitude'].')) 
                        * cos(radians(`latitude`)) 
                        * cos(radians(`longitude`) 
                        - radians('.$coordinates['longitude'].')) 
                        + sin(radians('.$coordinates['latitude'].')) 
                        * sin(radians(`latitude`))))';

        // return $query->select('id, label, zipcode, address, address_number, address_complement, district, city_id, is_main, latitude, longitude')
        return $query->select('*')
                     ->selectRaw("{$haversine} AS distance")
                     ->whereRaw("{$haversine} < ?", [$radius]);
    }
}
