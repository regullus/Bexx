<?php

namespace App\Traits;

use Carbon\Carbon;
use App\Models\User;

trait NotificationToBroadcastTrait
{
    protected function setBroadcastData($data)
    {
        $timestamp = Carbon::now()->addSecond()->toDateTimeString();

        switch ($data['tag']) {
            default:
                $message = str_replace(['%user%', '%context%'], [$data['user']['short_name'], $data['product']['name']], config('c7.notifications.'.$data['tag']));
        }

        return array_merge([
            'message' => $message,
            'is_unread' => 1,
            'created_at' => $timestamp,
        ], $data);
    }
}
