<?php

namespace App\Traits;

trait ScopeFilterMetadataTrait
{
    /**
     * Filtra por entrada na metadata.
     * @param  object  $query    Objeto do Eloquent
     * @param  string  $key      Chave da entrada na metadata
     * @param  string  $value    Valor da entrada na metadata
     * @param  bool $only_all Se true, performa a busca somente se key e value estiverem preenchidos
     * @return object            Retorna o objeto do eloquent
     */
    public function scopeFilterMetadata($query, $key, $value, $only_all = false)
    {
        if (! $key || ($only_all && ! $value)) { // se não, desconsidera este filtro
            return $query;
        }

        if (! $value) {
            return $query->where('metadata', 'like', '"'.$key.'"');
        }

        $query_term = '%"'.$key.'":"'.$value.'"%';

        if (is_numeric($value)) {
            $query_term = '%"'.$key.'":'.$value.'%';
        }

        return $query->where('metadata', 'like', $query_term);
    }
}
