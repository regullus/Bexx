<?php

namespace App\Exceptions;

use Exception;
use App\Models\User;
use Namshi\JOSE\JWS;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Validation\ValidationException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;

/**
 * Quando o usuário não estiver autenticado, o comportamento padrão do Laravel seria redirecioná-lo para uma
 * página de login, porém, por ser uma API ela deve apenas alterar o código de retorno para 401. Para isto
 * segui as coordenadas da documentação do Laravel Auth e implementei o método unauthenticated em
 * Exceptions/Handler.php.
 */
class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * @param  \Exception  $exception
     * @return void
     */
    public function report(Exception $exception)
    {
        // if (app()->bound('sentry') && $this->shouldReport($exception)) {
        //     app('sentry')->captureException($exception);
        // }

        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Exception  $exception
     * @return \Illuminate\Http\Response
     */
    public function render($request, Exception $exception)
    {
        if ($exception instanceof ValidationException) {
            return response()->json(['message' => 'As informações são inválidas.', 'errors' => $exception->validator->getMessageBag()], 422); //type your error code.
        }

        return parent::render($request, $exception);
    }

    protected function unauthenticated($request, AuthenticationException $exception)
    {
        /*
                try {
                    $strJson = Cookie::get('token');
                    if(!$strJson)
                        return response()->json(['message' => $exception->getMessage()], 401);
                    $objNamshi = JWS::load($strJson);
                    $user = User::find($objNamshi->getPayload()['sub']);
                    if(!$user)
                        return response()->json(['message' => $exception->getMessage()], 401);
                    auth()->login($user);
                } catch(Exception $e) {
                }
                */
        return response()->json(['message' => $exception->getMessage()], 401);
    }
}
