<?php

namespace App\Exceptions;

use Exception;
use Illuminate\Database\Eloquent\Collection;

class ConflictOrderException extends Exception
{
    private $collection;

    public $code = 422;

    public function setOrdersRefused(Collection $collection)
    {
        $this->collection = $collection;
    }

    public function getOrdersRefused()
    {
        return $this->collection;
    }
}
