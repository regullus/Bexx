<?php

namespace App\Exceptions;

use Exception;

class OrderNotFound extends Exception
{
    //
}
