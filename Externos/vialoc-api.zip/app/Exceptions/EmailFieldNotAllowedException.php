<?php

namespace App\Exceptions;

use Exception;

class EmailFieldNotAllowedException extends Exception
{
    //
}
