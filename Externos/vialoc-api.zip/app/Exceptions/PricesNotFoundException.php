<?php

namespace App\Exceptions;

use Exception;

class PricesNotFoundException extends Exception
{
    //
}
