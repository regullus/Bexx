<?php

namespace App\Exceptions;

use Exception;

class OrderRatingAlreadyDoneException extends Exception
{
    //
}
