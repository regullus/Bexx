<?php

namespace App\Exceptions;

use Exception;

class ProductUnavailableException extends Exception
{
    //
}
