<?php

namespace App\Exceptions;

use Exception;

class NotAllowRefuseException extends Exception
{
    //
}
