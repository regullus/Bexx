<?php

namespace App\Exceptions;

use Exception;

class OrderActionNotAllowedException extends Exception
{
    //
}
