<?php

namespace App\Notifications;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class UserConfirmationNotification extends Notification implements ShouldQueue
{
    use Queueable;

    protected $token;

    protected $user;

    /**
     * Create a notification instance.
     *
     * @param  string  $token
     * @return void
     */
    public function __construct($token)
    {
        $this->token = $token;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        // Caso o e-mail pretendido esteja definido, é alterado o email de destino
        if (! empty($notifiable->email_pretended)) {
            $notifiable->email = $notifiable->email_pretended;
        }

        return (new MailMessage)
            ->subject('Confirme o seu cadastro na Vialoc')
            ->greeting('Olá '.$notifiable->name)
            ->line('Para confirmar este e-mail no seu perfil da Vialoc, basta clicar no botão abaixo:')
            ->action('Confirmar o meu e-mail', config('c7.webapp_url').'/?ativar-conta='.$this->token)
            ->line('Obrigado por fazer parte da Vialoc!');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
