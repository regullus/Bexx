<?php

namespace App\Notifications;

use App\Models\User;
use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Traits\NotificationToBroadcastTrait;
use App\Transformers\v1\UserSimpleTransformer;
use App\Transformers\v1\ProductSummaryTransformer;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Messages\BroadcastMessage;

class OrderRefusedNotification extends Notification implements ShouldQueue
{
    use Queueable, NotificationToBroadcastTrait;

    private $order;

    public $notificationData;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(Order $order)
    {
        $this->order = $order;

        $this->notificationData = [
            'tag' => 'order-refused',
            'profile_recipient' => 'tenant',
            'order_id' => $this->order->id,
            'user' => fractal()->item($this->order->product->user, new UserSimpleTransformer())->toArray(),
            'product' => fractal()->item($this->order->product, new ProductSummaryTransformer())->toArray(),
        ];
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database', 'mail', 'broadcast'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('Seu pedido de locação #'.$this->order->id.' foi recusado pelo locador.')
            ->greeting('Olá '.$notifiable->name)
            ->line('Infelizmente, '.$this->order->product->user->short_name.' recusou o seu pedido de locação:')
            ->line('Carreta: <strong>'.$this->order->product->name.'</strong>')
            ->line('Período: de <strong>'.$this->order->date_start->format('d/m/Y').'</strong> a <strong>'.$this->order->date_end->format('d/m/Y').'</strong>')
            ->line('Valor: R$ '.floatFormatted($this->order->price_total))
            ->line('Escolha outra carreta na Vialoc que atenda aos seus requisitos. Clique no botão abaixo para prosseguir.')
            ->action('Ver carretas', config('c7.webapp_url').'/carretas');
    }

    public function toDatabase(User $notifiable)
    {
        return $this->notificationData;
    }

    /**
     * Get the broadcastable representation of the notification.
     * @param  mixed  $notifiable
     * @return BroadcastMessage
     */
    public function toBroadcast(User $notifiable)
    {
        \Log::info('OrderRefusedNotificaton toBroadcast');
        $this->notificationData['id'] = $this->id;
        $message = self::setBroadcastData($this->notificationData);

        return new BroadcastMessage($message);
    }
}
