<?php

namespace App\Notifications;

use App\Models\User;
use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Traits\NotificationToBroadcastTrait;
use App\Transformers\v1\UserSimpleTransformer;
use App\Transformers\v1\ProductSummaryTransformer;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Messages\BroadcastMessage;

class OrderInformDevolutionNotification extends Notification implements ShouldQueue
{
    use Queueable, NotificationToBroadcastTrait;

    private $order;

    public $notificationData;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(Order $order)
    {
        $this->order = $order;

        $this->notificationData = [
            'tag' => 'order-inform-devolution',
            'profile_recipient' => 'locator',
            'order_id' => $this->order->id,
            'user' => fractal()->item($this->order->user, new UserSimpleTransformer())->toArray(),
            'product' => fractal()->item($this->order->product, new ProductSummaryTransformer())->toArray(),
        ];
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database', 'mail', 'broadcast'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('Por favor, confirme a devolução da carreta, referente à locação #'.$this->order->id)
            ->greeting('Olá '.$notifiable->name)
            ->line($this->order->user->short_name.' informou que você recebeu a devolução da carreta abaixo:')
            ->line('Carreta: <strong>'.$this->order->product->name.'</strong>')
            ->line('Período: de <strong>'.$this->order->date_start->format('d/m/Y').'</strong> a <strong>'.$this->order->date_end->format('d/m/Y').'</strong>')
            ->line('Valor: R$ '.floatFormatted($this->order->price_total))
            ->line('Agora você precisará confirmar que recebeu a devolução a carreta, para que possamos finalizar o pedido de locação. Clique no botão abaixo para prosseguir.')
            ->action('Confirmar a devolução da carreta', config('c7.webapp_url').'/locador/locacoes/'.$this->order->id);
    }

    public function toDatabase(User $notifiable)
    {
        return $this->notificationData;
    }

    /**
     * Get the broadcastable representation of the notification.
     * @param  mixed  $notifiable
     * @return BroadcastMessage
     */
    public function toBroadcast(User $notifiable)
    {
        \Log::info('OrderInformTakeoutNotificaton toBroadcast');
        $this->notificationData['id'] = $this->id;
        $message = self::setBroadcastData($this->notificationData);

        \Log::info($this->id);

        return new BroadcastMessage($message);
    }
}
