<?php

namespace App\Notifications;

use Carbon\Carbon;
use App\Models\User;
use Illuminate\Bus\Queueable;
use App\Models\QuestionAnswer;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Traits\NotificationToBroadcastTrait;
use App\Transformers\v1\UserSimpleTransformer;
use App\Transformers\v1\ProductSummaryTransformer;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Messages\BroadcastMessage;

class QuestionNotification extends Notification implements ShouldQueue
{
    use Queueable, NotificationToBroadcastTrait;

    private $questionAnswer;

    public $notificationData;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(QuestionAnswer $questionAnswer)
    {
        $this->questionAnswer = $questionAnswer;

        $this->notificationData = [
            'tag' => 'product-question',
            'profile_recipient' => 'locator',
            'question_id' => $this->questionAnswer->id,
            'question_parent_id' => $this->questionAnswer->parent_id,
            'user' => fractal()->item($this->questionAnswer->user, new UserSimpleTransformer())->toArray(),
            'product' => fractal()->item($this->questionAnswer->product, new ProductSummaryTransformer())->toArray(),
        ];
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database', 'mail', 'broadcast'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail(User $notifiable)
    {
        $product_featured_image = $this->questionAnswer->product->firstMedia('product-featured-image');
        $product_featured_image = $product_featured_image ? asset($product_featured_image->metadata['thumbnails']['retangle-small']['path']) : asset(config('c7.image-unavailable.small'));

        return (new MailMessage)
            ->subject('Você recebeu uma pergunta')
            ->greeting('Olá '.$notifiable->name)
            ->line($this->questionAnswer->user->name.' enviou a seguinte pergunta:')
            ->line('<em>'.$this->questionAnswer->content.'</em>')
            ->action('Visualizar a pergunta', config('c7.webapp_url').'/locador/carretas/'.$this->questionAnswer->product->uid.'/mensagens#pergunta-'.$this->questionAnswer->id)
            ->line('Referente à carreta:')
            ->line('<strong>'.$this->questionAnswer->product->name.'</strong>');
    }

    public function toDatabase(User $notifiable)
    {
        return $this->notificationData;
    }

    /**
     * Get the broadcastable representation of the notification.
     * @param  mixed  $notifiable
     * @return BroadcastMessage
     */
    public function toBroadcast(User $notifiable)
    {
        \Log::info('tá broadcasting sim');
        $this->notificationData['id'] = $this->id;
        $message = self::setBroadcastData($this->notificationData);

        return new BroadcastMessage($message);
    }
}
