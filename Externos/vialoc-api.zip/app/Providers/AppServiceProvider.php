<?php

namespace App\Providers;

use App\Models\Address;
use Illuminate\Support\ServiceProvider;
use App\Models\Observers\AddressObserver;
use Illuminate\Queue\Events\JobFailed;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Address::observe(AddressObserver::class);

        \Queue::failing(function (JobFailed $event) {
            \Log::info('Queue failing');
            \Log::info($event->connectionName);
            \Log::info($event->job);
            \Log::info($event->exception);
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
