<?php

namespace App\Providers;

use App\Tools\C7Utils;
use App\Tools\C7Upload;
use App\Tools\C7WsQuery;
use Illuminate\Support\ServiceProvider;

class ToolsServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind('C7Upload', function () {
            return new C7Upload;
        });

        $this->app->bind('C7Utils', function () {
            return new C7Utils;
        });

        $this->app->bind('C7WsQuery', function () {
            return new C7WsQuery;
        });
    }
}
