<?php

namespace App\Providers;

use App\Models\Page;
use App\Models\User;
use App\Models\Product;
use App\Models\Newsletter;
use App\Models\QuestionAnswer;
use Illuminate\Support\Facades\Route;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * This namespace is applied to your controller routes.
     *
     * In addition, it is set as the URL generator's root namespace.
     *
     * @var string
     */
    protected $namespace = 'App\Http\Controllers';

    /**
     * Define your route model bindings, pattern filters, etc.
     *
     * @return void
     */
    public function boot()
    {
        //

        parent::boot();

        Route::bind('answer', function ($value) {
            $answer = QuestionAnswer::where([
                ['id', '=', $value],
                ['parent_id', '>', 0],
            ])->first();
            if (! $answer) {
                abort(404);
            }

            return $answer;
        });

        Route::bind('newsletter_uid', function ($value) {
            $newsletter = Newsletter::where(['uid' => $value])->first();
            if (! $newsletter) {
                abort(404);
            }

            return $newsletter;
        });

        Route::bind('page_slug', function ($value) {
            $page = Page::where(['slug' => $value])->first();
            if (! $page) {
                abort(404);
            }

            return $page;
        });

        Route::bind('product_slug', function ($value) {
            $product = Product::where(['slug' => $value])->where('status', 'active')->first();
            if (! $product) {
                abort(404);
            }

            return $product;
        });

        Route::bind('product_uid', function ($value) {
            $product = Product::where(['uid' => $value])->first();
            if (! $product) {
                abort(404);
            }

            return $product;
        });

        Route::bind('user_slug', function ($value) {
            $user = User::where(['slug' => $value, 'status' => 'active'])->first();
            if (! $user) {
                abort(404);
            }

            return $user;
        });
    }

    /**
     * Define the routes for the application.
     *
     * @return void
     */
    public function map()
    {
        $this->mapApiRoutes();

        $this->mapWebRoutes();

        //
    }

    /**
     * Define the "web" routes for the application.
     *
     * These routes all receive session state, CSRF protection, etc.
     *
     * @return void
     */
    protected function mapWebRoutes()
    {
        Route::middleware('web')
             ->namespace($this->namespace)
             ->group(base_path('routes/web.php'));
    }

    /**
     * Define the "api" routes for the application.
     *
     * These routes are typically stateless.
     *
     * @return void
     */
    protected function mapApiRoutes()
    {
        Route::prefix('api')
             ->middleware('api')
             ->namespace($this->namespace)
             ->group(base_path('routes/api.php'));
    }
}
