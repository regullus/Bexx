<?php

namespace App\Providers;

use App\Models\Order;
use App\Models\Address;
use App\Models\Product;
use App\Models\Notification;
use App\Policies\OrderPolicy;
use App\Models\QuestionAnswer;
use App\Policies\AddressPolicy;
use App\Policies\ProductPolicy;
use App\Policies\NotificationPolicy;
use Illuminate\Support\Facades\Gate;
use App\Policies\QuestionAnswerPolicy;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        // 'App\Model' => 'App\Policies',
        Address::class => AddressPolicy::class,
        Notification::class => NotificationPolicy::class,
        Product::class => ProductPolicy::class,
        QuestionAnswer::class => QuestionAnswerPolicy::class,
        Order::class => OrderPolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        //
    }
}
