<?php

namespace App\Services\v1\Common;

use App\Models\Order;
use Cielo\API30\Merchant;
use App\Models\OrderPayment;
use Cielo\API30\Ecommerce\Sale;
use Cielo\API30\Ecommerce\Payment;
use Cielo\API30\Ecommerce\CreditCard;
use Cielo\API30\Ecommerce\Environment;
use Cielo\API30\Ecommerce\CieloEcommerce;
use Cielo\API30\Ecommerce\Request\CieloRequestException;

class CieloService
{
    private $order;

    private $paymentData;

    private $orderPriceTotalCents;

    private $environment;

    private $merchant;

    private $cielo;

    private $sale;

    private $salePayment;

    private $paymentStatus;

    private $payment;

    private $saleCapture;

    private $saleRequest;

    public function __construct()
    {
        $this->order = null;
        $this->paymentData = null;

        $this->orderPriceTotalCents = null;

        $this->environment = config('services.cielo.environment') == 'sandbox' ? Environment::sandbox() : Environment::production();
        $this->merchant = new Merchant(config('services.cielo.merchant_id'), config('services.cielo.merchant_key'));
        $this->cielo = new CieloEcommerce($this->merchant, $this->environment);

        $this->sale = null;
        $this->saleCapture = null;
        $this->saleRequest = null;
        $this->paymentStatus = null;

        $this->salePayment = null;
    }

    public function setup(Order $order, $paymentData)
    {
        $this->order = $order;
        $this->paymentData = $paymentData;

        // Valor do preço total em centavos
        $this->orderPriceTotalCents = intval($order->price_total * 100);

        // apesar de definir o Payment ao Sale, o pagamento ainda não foi enviado à Cielo
        $this->salePayment = $this->setSale();

        return $this;
    }

    public function createPayment()
    {
        // complements o $this->payment com as infos de pagamento
        $this->setPayment();

        try {
            \Log::info('createSale');
            \Log::info(json_encode($this->saleRequest));
            // Criar a venda na Cielo
            $this->sale = $this->cielo->createSale($this->saleRequest);

            \Log::info('createSale end');
            // Com a venda criada na Cielo, já temos o ID do pagamento, TID e demais dados retornados pela Cielo
            $payment = $this->sale->getPayment();

            \Log::info(json_encode($payment));
            \Log::info('getPayment end');

            // define o payment status
            $this->paymentStatus = $this->getPaymentStatus($payment->getStatus());

            $orderPayment = $this->createOrderPayment($payment);

            // grava o request feito para a Cielo
            $gatewayRequest = $this->createGatewayRequest($orderPayment);

            // grava o log do payment
            $this->createOrderPaymentLog($orderPayment);

            // se o pagamento está autorizado...
            if ($this->paymentData['payment_method'] == 'credit-card' && $payment->getStatus() == 1) {
                // faz a captura
                $this->saleCapture = $this->cielo->captureSale($payment->getPaymentId(), $this->orderPriceTotalCents);

                // grava a captura
                $gatewayCapture = $this->createGatewayCapture($orderPayment, $gatewayRequest);

                // se o pagamento foi confirmado e finalizado
                if ($this->saleCapture->getStatus() == 2) {
                    // atualiza o orderPayment
                    $saleCaptureSatus = $this->getPaymentStatus($this->saleCapture->getStatus());
                    $orderPayment->update(['status' => 'finished', 'status_authorization' => $this->paymentStatus, 'status_capture' => $saleCaptureSatus]);

                    // grava o log do payment
                    $this->createOrderPaymentLog($orderPayment);

                    // atualiza o gatewayRequest
                    $gatewayCapture->gatewayRequest()->update(['status_authorization' => 'authorized', 'status_capture' => 'finished']);
                }
            }

            // se boleto
            if ($this->paymentData['payment_method'] == 'bank-slip' && $payment->getStatus() == 1) {
                // atualiza o boleto
                $this->order->bankSlip->update([
                    'order_payment_id' => $orderPayment->id,
                    'barcode_number' => $gatewayRequest->json_gateway_response['payment']['barCodeNumber'],
                    'digitable_line' => $gatewayRequest->json_gateway_response['payment']['digitableLine'],
                ]);
            }

            return $orderPayment;
        } catch (CieloRequestException $e) {
            // Em caso de erros de integração, podemos tratar o erro aqui.
            // os códigos de erro estão todos disponíveis no manual de integração.
            \Log::error(json_encode($e));
            $error = $e->getCieloError();
            \Log::error(json_encode($error));
        }
    }

    private function setSale()
    {
        $this->saleRequest = new Sale($this->order->id);
        // Crie uma instância de Customer informando o nome do cliente
        $this->setSaleCustomer();
        // Retorna a instância de Payment informando o valor do pagamento
        return $this->saleRequest->payment($this->orderPriceTotalCents);
    }

    private function setSaleCustomer()
    {
        if (in_array($this->paymentData['payment_method'], ['credit-card', 'debit-card'])) {
            $this->saleRequest->customer($this->order->user->full_name);
        } else { // se boleto
            $this->saleRequest->customer(substr($this->order->user->full_name, 0, 34))
                ->setIdentity($this->order->user->profile->cpf ? $this->order->user->profile->cpf : $this->order->user->profile->cnpj)
                ->setIdentityType($this->order->user->profile->cpf ? 'CPF' : 'CNPJ')
                ->address()->setZipCode($this->order->user->address->zipcode)
                    ->setCountry('BRA') // sempre será BRA
                    ->setState($this->order->user->address->city->state_code)
                    ->setCity($this->order->user->address->city->name)
                    ->setDistrict(substr($this->order->user->address->district, 0, 50))
                    ->setStreet($this->order->user->address->address)
                    ->setNumber($this->order->user->address->address_number);
        }
    }

    private function setPayment()
    {
        switch ($this->paymentData['payment_method']) {
            case 'credit-card':
                $this->payWithCreditCard();

                break;
            case 'debit-card':
                $this->payWithDebitCard();

                break;
            case 'bank-slip':
                $this->payWithBankSlip();

                break;
        }
    }

    private function getPaymentStatus($paymentStatus)
    {
        return config('c7.payment-status.cielo.transactional.code-'.$paymentStatus.'.slug');
    }

    private function payWithBankSlip()
    {
        $bankSlip = $this->order->bankSlips()->create([]);
        $this->salePayment->setType(Payment::PAYMENTTYPE_BOLETO)
            ->setAddress('BR 365 - KM 622 - Zona Rural - Uberlândia - MG') // Endereço Vialoc
            ->setBoletoNumber($bankSlip->id)
            ->setAssignor('Vialoc')
            ->setDemonstrative('Pagamento referente à locação #'.$this->order->id)
            ->setExpirationDate(date('d/m/Y', strtotime('+1 day')))
            ->setIdentification('08277509000198')
            ->setInstructions('Não receber após o vencimento.');

        \Log::info('payWithBankSlip end');
    }

    private function payWithCreditCard()
    {
        $creditCardBrand = $this->getCreditCardBrand($this->paymentData['payment_method_option']);

        $this->salePayment->setType(Payment::PAYMENTTYPE_CREDITCARD)
            ->creditCard($this->paymentData['card']['cvv'], $creditCardBrand)
            ->setExpirationDate($this->paymentData['card']['expiration']['month'].'/'.$this->paymentData['card']['expiration']['year'])
            ->setCardNumber(onlyNumbers($this->paymentData['card']['number']))
            ->setHolder($this->paymentData['card']['holder']);
    }

    private function payWithDebitCard()
    {
        $creditCardBrand = $this->getCreditCardBrand($this->paymentData['payment_method_option']);

        $this->salePayment->setType(Payment::PAYMENTTYPE_DEBITCARD)
            ->setAuthenticate(true)
            ->setReturnUrl(config('app.url').'/api/v1/tenant/order/'.$this->order->id.'/check-payment')
            ->debitCard($this->order->id, $creditCardBrand)
            ->setExpirationDate($this->paymentData['card']['expiration']['month'].'/'.$this->paymentData['card']['expiration']['year'])
            ->setCardNumber(onlyNumbers($this->paymentData['card']['number']))
            ->setHolder($this->paymentData['card']['holder']);
    }

    private function getCreditCardBrand()
    {
        switch ($this->paymentData['payment_method_option']) {
            case 'visa':
                return CreditCard::VISA;
            case 'mastercard':
            case 'maestro':
                return CreditCard::MASTERCARD;
            case 'american-express':
                return CreditCard::AMEX;
            case 'elo':
                return CreditCard::ELO;
            case 'aura':
                return CreditCard::AURA;
            case 'jcb':
                return CreditCard::JCB;
            case 'diners-club':
                return CreditCard::DINERS;
            case 'discover':
                return CreditCard::DISCOVER;
            case 'hipercard':
                return CreditCard::HIPERCARD;
        }
    }

    private function createOrderPayment($payment)
    {
        $status = 'processing';
        // se o pagamento foi negado já cancela a o pagamento do pedido
        if (in_array($this->paymentStatus, ['denied', 'voided', 'refused', 'aborted'])) {
            $status = 'canceled';
        }

        return $this->order->payments()->create([
            'payment_method_slug' => $this->paymentData['payment_method'],
            'payment_method_option' => $this->paymentData['payment_method_option'],
            'gateway_payment_id' => $payment->getPaymentId(),
            'gateway_transaction_id' => $payment->getTid(),
            'status' => $status,
            'status_authorization' => $this->paymentData['payment_method'] == 'credit-card' ? $this->paymentStatus : null,
            'status_capture' =>  $this->paymentData['payment_method'] == 'credit-card' ? 'pending' : null,
        ]);
    }

    private function createGatewayRequest($orderPayment, $request = null)
    {
        if (! $request) {
            // pega só os dados de pagamento do $this->, não precisamos dos demais dados
            $saleRequestPayment = object2Array($this->saleRequest->getPayment());
            if ($orderPayment->payment_method_slug == 'credit-card' && ! empty($saleRequestPayment['creditCard'])) {
                $saleRequestPayment['creditCard']['cardNumber'] = hideCreditCard($saleRequestPayment['creditCard']['cardNumber']);
            }
            if ($orderPayment->payment_method_slug == 'debit-card' && ! empty($saleRequestPayment['debitCard'])) {
                $saleRequestPayment['debitCard']['cardNumber'] = hideCreditCard($saleRequestPayment['debitCard']['cardNumber']);
            }
        } else {
            $saleRequestPayment = $request;
        }

        return $orderPayment->gatewayRequests()->create([
            'order_id' => $this->order->id,
            'json_gateway_request' => $saleRequestPayment,
            'json_gateway_response' => object2Array($this->sale),
            'status_authorization' => $this->paymentData['payment_method'] == 'credit-card' ? $this->paymentStatus : null,
            'status_capture' =>  $this->paymentData['payment_method'] == 'credit-card' ? 'pending' : null,
        ]);
    }

    private function createGatewayCapture($orderPayment, $gatewayRequest)
    {
        return $orderPayment->gatewayCaptures()->create([
            'order_id' => $this->order->id,
            'gateway_request_id' => $gatewayRequest->id,
            'json_response' => object2Array($this->saleCapture),
            'status' => $this->saleCapture->getStatus(),
        ]);
    }

    private function createOrderPaymentLog($orderPayment)
    {
        // atualiza a model
        $orderPayment->fresh();

        return $orderPayment->logs()->create([
            'order_id' => $this->order->id,
            'user_id' => auth()->user()->id ?? null,
            'request_ip' => request()->ip(),
            'payment_status' => $orderPayment->status,
            'json_data' => $orderPayment->toArray(),
        ]);
    }

    /**
     * Verifica os pagamentos feitos nos métodos cartão de débito / boleto bancário.
     */
    public function checkPayment(OrderPayment $orderPayment)
    {
        $this->order = $orderPayment->order;
        $this->sale = $this->cielo->getSale($orderPayment->gateway_payment_id);

        $paymentStatus = $this->getPaymentStatus($this->sale->getPayment()->getStatus());

        // grava o request feito para a Cielo
        $gatewayRequest = $this->createGatewayRequest($orderPayment, ['paymentId' => $orderPayment->gateway_payment_id]);

        // atualiza a orderPayment
        $orderPayment->update(['status' => $paymentStatus]);

        $this->createOrderPaymentLog($orderPayment);

        return $orderPayment;
    }
}
