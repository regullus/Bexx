<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 02/08/18
 * Time: 09:46.
 */

namespace App\Services\v1\Common;

use App\Models\User;
/*
 * User resources.
 */
use App\Models\Address;
use Symfony\Component\Translation\Exception\InvalidArgumentException;

class AddressService
{
    private $model;

    private $user;

    public function __construct()
    {
        $this->model = new Address();
        $this->user = \Auth::user();
    }

    public function create($arrData)
    {
        $this->model->user_id = $this->user->id;
        $this->model->fill($arrData)->save();

        return $this->model;
    }

    public function update(Address $address, $arrData)
    {
        if (! $this->user->can('update', $address)) {
            throw new InvalidArgumentException(config('error.resource_not_allowed'), 403);
        }

        $address->update($arrData);

        return $address->fresh();
    }

    public function setMainAddress(Address $address)
    {
        if (! $this->user->can('update', $address)) {
            throw new InvalidArgumentException(config('error.resource_not_allowed'), 403);
        }

        $address_main = Address::where('is_main', 1)->update(['is_main' => 0]);
        $address->update(['is_main' => 1]);

        $this->user->load(['addresses']);

        return $this->user->addresses;
    }
}
