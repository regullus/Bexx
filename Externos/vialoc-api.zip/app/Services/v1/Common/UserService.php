<?php

namespace App\Services\v1\Common;

/*
 * Vendor packages
 */
use App\Models\User;
use Illuminate\Support\Str;
use App\Models\ConfirmEmail;
use Illuminate\Support\Facades\DB;
use App\Services\v1\Site\NewsletterService;
use Illuminate\Auth\AuthenticationException;
use App\Notifications\UserConfirmationNotification;
use Symfony\Component\Translation\Exception\NotFoundResourceException;

/**
 * Class UserService.
 */
class UserService
{
    protected $user;

    public function __construct()
    {
        $this->user = \Auth::check() ? \Auth::user() : null;
    }

    /**
     * Cria um usuário.
     *
     * @return User
     */
    public function createUser($arrData, $sendConfirmEmail = true)
    {
        DB::beginTransaction();

        // Cria usuário.
        $user = new User();
        $user->fill($arrData);
        $user->save();

        // Cria perfil.
        // $user->profile()->create($arrData['profile']);

        // Cria o endereço (em branco)
        $user->addresses()->create(['is_main' => 1]);

        DB::commit();

        if (isset($arrData['receive_news']) && $arrData['receive_news']) {
            self::addToNewsletter($arrData, $user);
        }

        if ($sendConfirmEmail) {
            self::createConfirmEmail($user);
        }

        return $user;
    }

    protected static function createConfirmEmail($user)
    {
        $confirmEmail = new ConfirmEmail();
        $confirmEmail->user_id = $user->id;
        $confirmEmail->email = $user->email_intended ?? $user->email;
        $confirmEmail->token = Str::random(60);
        $confirmEmail->save();

        $user->notify(new UserConfirmationNotification($confirmEmail->token));
    }

    public function resendConfirmEmail($user)
    {
        self::createConfirmEmail($user);

        return $user;
    }

    protected static function addToNewsletter($arrData, $user)
    {
        $newsletterService = new NewsletterService();
        $arr['email'] = $arrData['email'];
        $arrExtra['name'] = $arrData['name'];
        $arrExtra['last_name'] = $arrData['last_name'];
        $arrExtra['user_id'] = $user->id;

        return $newsletterService->create($arr, $arrExtra);
    }

    /**
     * Atualiza um usuário criado a partir de uma rede social.
     *
     * @return User
     */
    public function updateUser($arrData)
    {
        DB::beginTransaction();

        // altera o status do usuário para pendente
        $arrData['status'] = 'pending';

        $user = \Auth::user();
        $user->fill($arrData);
        $user->save();

        DB::commit();

        if (isset($arrData['receive_news']) && $arrData['receive_news']) {
            self::addToNewsletter($arrData, $user);
        }

        self::createConfirmEmail($user);

        return $user;
    }

    /**
     * O complemento de usuário é sempre alteração pois a criação de usuário insere Nome e Sobrenomne que está na tabela
     * profiles. Este endpoint atende a tela de complemento de cadastro e compoe uma das duas condições para que o
     * usuário seja ativado no sistema. As duas condições para que o usuário seja ativado são o click no link e o
     * complemento de cadastro. Ser ativado no sistema significa que o usuário pode fazer ações chave, que são a criação
     * de pedido por parte do locatário e a confirmação por parte do locador.
     *
     *
     *
     * @param $arrData
     * @return mixed
     */
    public function updateProfile($arrData)
    {
        $user = \Auth::user();
        $user->load(['address']);
        // DB::beginTransaction();

        // Altera os dados do usuário.
        if ($user->email != $arrData['email']) { // Se for uma alteração de email.
            $user->email_intended = $arrData['email'];
            unset($arrData['email']);
        }

        // Mesmo que o email tenha sido alterado (entrando na condição acima) ele ativa o usuário atual, afinal de contas ele acaba de preencher os dados complementares.
        if ($user->email_confirmed) {
            $arrData['status'] = 'active';
        }

        unset($arrData['password']);
        $user->update($arrData);

        // Altera os dados do perfil.
        $user->profile->update($arrData['profile']);

        $arrData['address']['is_main'] = 1;

        if (empty($arrData['address']['city_id'])) {
            $arrData['address']['city_id'] = \C7WsQuery::getCityId($arrData['address']['state_code'], $arrData['address']['city']);
        }

        if (empty($arrData['address']['latitude'])) {
            $address = $arrData['address']['address'].', '.$arrData['address']['address_number'].', '.$arrData['address']['city'].', '.$arrData['address']['state_code'].', BR';
            $geo_data = getGeoCoord($address);
            $geo_coords = null;

            if (! empty($geo_data->results)) {
                $geo_coords = array_shift($geo_data->results)->geometry->location;
            }

            if ($geo_coords && ! empty($geo_coords->lat)) {
                $arrData['address']['latitude'] = $geo_coords->lat;
                $arrData['address']['longitude'] = $geo_coords->lng;
            }
        }

        $user->address->update($arrData['address']);

        // se o usuário possui produtos, atualiza os dados de endereço
        if ($products = $user->products()->where('address_id', $user->address->id)->get()) {
            foreach ($products as $product) {
                $product->update(['city_id' => $arrData['address']['city_id'], 'latitude' => $arrData['address']['latitude'], 'longitude' => $arrData['address']['longitude']]);
            }
        }

        if (isset($arrData['receive_news']) && $arrData['receive_news']) {
            $newsletterService = new NewsletterService();
            $newsletterService->create(['email' => $user->email], ['user_id' => $user->id, 'name' => $user->name, 'last_name' => $user->last_name]);
        } else {
            optional($user->newsletter())->delete();
        }

        if (! $user->email_confirmed || ! empty($user->email_intended)) {
            self::createConfirmEmail($user);
        }

        // DB::commit();

        return $user;
    }

    /**
     * Atende ao click no link enviado no Cadastrto de usuário e no Complemento de cadastro.
     *
     * O registro gravado na tabela confirm_email serve para que este endpoint consiga identificar em primeiro lugar
     * o email a ser confirmado. Lembrando que a confirmação de email é uma das condições para que o usuário seja
     * ativado. Este email pode ser o email cadastrado na primeira etapa, de usuário, ou na segunda
     * etapa, como alteração de email. Assim que o click é feito, este script recebe o token único que identifica
     * esse email. Ao buscar o registro no banco, então o email é confrontado com o email pretendido (email intended)
     * que trata alteração no complemento de cadastro, ou com o email do próprio usuário, preenchido na primeira etapa.
     * Caso não coincida com nenhum dos dois, pode ser que o usuário tenha alterado seu email duas vezes. Nesse caso o
     * campo email_intended e sobreposto com o email informado na segunda alteração.
     *
     * @param $token
     */
    public function confirmEmail($token)
    {
        // Recupera o email pedido via token e o usuário que realizou o pedido.
        $confirmEmail = ConfirmEmail::where('token', $token)->first(); // busca registro via token.
        if (! $confirmEmail) {
            throw new NotFoundResourceException(config('error.not_found_resource'), 404);
        }
        $user = $confirmEmail->user; // recupera usuário do confirm_email

        if ($confirmEmail->email == $user->email_intended) {
            $user->email = $confirmEmail->email;
            $user->email_intended = '';
        } elseif ($confirmEmail->email != $user->email) { // se não é um email pretendido e nem o e-mail atual, retorna o erro
            throw new NotFoundResourceException(config('error.not_found_resource'), 404); // fazer um exception so pra link não encontrado.
        }

        // Confirma o click enviado no "Cadastro de usuário" ou no "Complemento do cadastro".
        $user->email_confirmed = 1;

        // Verifica se o complemento de cadastro (uma das duas condições) foi feito. Se sim então ativa a conta, afinal
        // o click (outra condição) foi feito.
        if ($user->isComplete()) {
            $user->status = 'active';
        }

        // Verifica se o usuário possui registro na tabela newsletter e atualiza o email

        return $user->save();
    }

    /*
        public function changeEmail(ChangeEmailRequest $request) {
            $this->user->update([
                'email' => $request->input('email'),
            ]);

            return $this->user;
        }
    */
    public function changePassword($arrData)
    {
        $credentials = [
            'email' => $this->user->email,
            'password' => $arrData['password_current'],
        ];

        if (! $token = auth()->attempt($credentials)) {
            throw new AuthenticationException(config('error.authentication_exception'));
        }

        $this->user->update([
            'password' => $arrData['password'],
        ]);

        return $this->user;
    }

    public function changeAvatar($arrData)
    {
        $avatar = \C7Upload::avatar($arrData->file('avatar'), $this->user->uid);
        $this->user->syncMedia($avatar, 'avatar');

        return $avatar;
    }

    // public function updateProfile(UpdateProfileRequest $request) {
    //     DB::beginTransaction();
    //     $this->user->fill($request->all())->save();
    //     $this->user->profile->fill($request->all())->save();
    //     DB::commit();

    //     return $this->user;
    // }
}
