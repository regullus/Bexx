<?php

namespace App\Services\v1\Common;

use App\Models\User;
use App\Models\LinkedSocialAccount;
use App\Services\v1\Common\UserService;
use Laravel\Socialite\Two\User as ProviderUser;

class AuthService
{
    protected $userService;

    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
    }

    public function buildTokenInformation($token, $ttl)
    {
        return [
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => $ttl * 60,
        ];
    }

    /**
     * Find or create user instance by provider user instance and provider name.
     *
     * @param ProviderUser $providerUser
     * @param string $provider
     *
     * @return User
     */
    public function socialAccountFindOrCreate(ProviderUser $providerUser, string $provider): User
    {
        $linkedSocialAccount = LinkedSocialAccount::where('provider_name', $provider)
            ->where('provider_id', $providerUser->getId())
            ->first();

        if ($linkedSocialAccount) {
            return $linkedSocialAccount->user;
        } else {
            $user = null;

            if ($email = $providerUser->getEmail()) {
                $user = User::where('email', $email)->first();
            }

            if (! $user) {
                $providerName = explode(' ', $providerUser->getName(), 2);
                $user = $this->userService->createUser([
                    'name' => $providerName[0],
                    'last_name' => $providerName[1],
                    'email' => $providerUser->getEmail(),
                    'status' => 'to-complete',
                ], false);

                if ($providerAvatar = $providerUser->getAvatar()) {
                    $avatar = \C7Upload::avatar($providerAvatar, $user->uid);
                    $user->syncMedia($avatar, 'avatar');
                }
            }

            $user->linkedSocialAccounts()->create([
                'provider_id' => $providerUser->getId(),
                'provider_name' => $provider,
            ]);

            return $user;
        }
    }
}
