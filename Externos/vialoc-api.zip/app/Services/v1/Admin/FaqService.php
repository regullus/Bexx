<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 02/08/18
 * Time: 09:46.
 */

namespace App\Services\v1\Admin;

/*
 * Vendor packages
 */

/*
 * User resources.
 */
use App\Models\Faq;
use App\Models\User;

class FaqService
{
    private $model;

    public function __construct(Faq $model)
    {
        $this->model = $model;
    }

    public function create(User $user, $arrFaq)
    {
        $this->model->fill($arrFaq)->save();

        return $this->model;
    }
}
