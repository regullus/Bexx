<?php

namespace App\Services\v1\Tenant;

use App\Models\Order;
use App\Models\Product;
use App\Traits\OrderServiceTrait;
use App\Exceptions\PaymentException;
use App\Services\v1\Common\CieloService;
use App\Notifications\OrderCreatedNotification;
use App\Transformers\v1\AddressFullTransformer;
use App\Notifications\OrderCanceledNotification;
use Illuminate\Validation\UnauthorizedException;
use App\Exceptions\OrderActionNotAllowedException;
use App\Exceptions\OrderRatingAlreadyDoneException;
use App\Notifications\OrderConfirmTakeoutNotification;
use App\Notifications\OrderInformDevolutionNotification;

class OrderService
{
    use OrderServiceTrait;

    private $order;

    private $user;

    public function __construct()
    {
        $this->order = new Order();
        $this->user = auth()->user();
    }

    public function create($arrData)
    {
        // TODO criar uma validação que verifica se o horário atual é maior que o horário especificado no config... se for maior então retorna uma exception impedindo a solicitação.

        $product = Product::where('uid', $arrData['product_uid'])->where('status', config('c7.product.status.active'))->first();

        if (! $product) {
            throw new OrderActionNotAllowedException(config('error.product_not_found'), 422);
        }

        if (! $product->availableToRent($arrData['date_start'], $arrData['date_end'])) {
            throw new OrderActionNotAllowedException(config('error.product_unavailable_to_rent'), 422);
        }

        // carrega os relacionamentos
        $product->load(['address.city', 'brand']);

        // Calcula a quantidade de dias com base na data inicial e final
        // $priceService = new PriceService();
        $days = getAmountDays($arrData['date_start'], $arrData['date_end']);

        // Recupera o preço do produto com base na quantidade de dias pretendida pelo locatário.
        $prices = $product->prices()->orderBy('more_than', 'asc')->get();
        $price = null;
        foreach ($prices as $priceObj) {
            if ($days < $priceObj->more_than) {
                break;
            }
            $price = $priceObj;
        }

        // Grava pedido.
        $this->order->user_id = $this->user->id;
        $this->order->json_user = $this->user;

        $this->order->address_id = $product->address->id;
        $this->order->json_address = fractal($product->address, new AddressFullTransformer());

        $this->order->product_id = $product->id;
        $this->order->json_product = $product;

        $this->order->price_id = $price->id;
        $this->order->json_price = $price;
        $this->order->json_prices_base = $prices;

        $this->order->days_total = $days;
        $this->order->price_total = $days * $price->price_per_day;
        $this->order->metadata = [];
        $this->order->fill($arrData)->save();

        // atualiza os dados da model
        $this->order = $this->order->fresh();

        // Grava o log do pedido
        $this->log($this->order);

        // notifica o locador
        $this->order->product->user->notify(new OrderCreatedNotification($this->order));

        return $this->order;
    }

    public function cancel(Order $order)
    {
        if (! $this->user->can('updateAsTenant', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        if (! $order->isStatus('pending-confirmation')) {
            throw new OrderActionNotAllowedException(config('error.order_already_confirmed'), 422);
        }

        // Cancela pedido
        $order->status = 'canceled';
        $order->save();

        // Grava o log do pedido
        $this->log($order);

        // Notifica o locador
        $order->product->user->notify(new OrderCanceledNotification($order));

        return $order;
    }

    public function changePaymentMethod(Order $order)
    {
        if (! $this->user->can('updateAsTenant', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        if (! $order->isStatus('pending-payment')) {
            throw new OrderActionNotAllowedException(config('error.order_not_available_to_payment'), 422);
        }

        // Cancela pedido
        $order->payment->update(['status' => 'canceled']);

        $order->payment->logs()->create([
            'order_id' => $order->id,
            'user_id' => auth()->user()->id,
            'request_ip' => request()->ip(),
            'payment_status' => $order->payment->status,
            'json_data' => $order->payment->toArray(),
        ]);

        return $order;
    }

    public function payment(Order $order, $paymentData)
    {
        if (! $this->user->can('updateAsTenant', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        if (! $order->isStatus('pending-payment')) {
            throw new OrderActionNotAllowedException(config('error.order_not_available_to_payment'), 422);
        }

        $orderPayment = (new CieloService)->setup($order, $paymentData)->createPayment();

        if ($orderPayment->payment_method_slug == 'credit-card') { // Cartão de crédito
            if (in_array($orderPayment->status_authorization, ['denied', 'voided', 'refused', 'aborted'])) {
                throw new PaymentException(config('error.payment_'.$orderPayment->status_authorization), 422);
            }

            // se o pagamento foi finalizado. faz a troca de status
            if ($orderPayment->status_authorization == 'authorized' && $orderPayment->status_capture == 'finished') {
                $order = $this->setOrderPaid($order);
            }
        }

        return $order;
    }

    /**
     * Verifica os pagamentos feitos nos métodos cartão de débito / boleto bancário.
     */
    public function checkPayment(Order $order, $paymentId)
    {
        if (! $order->isStatus('pending-payment')) {
            throw new OrderActionNotAllowedException(config('error.order_not_available_to_payment'), 422);
        }

        $orderPayment = $order->payments()->where('gateway_payment_id', $paymentId)->first();

        if ($orderPayment->status == 'processing') {
            $orderPayment = (new CieloService)->checkPayment($orderPayment);

            if ($orderPayment->status == 'finished') {
                $order = $this->setOrderPaid($order);
            }
        }

        return $order;
    }

    /**
     * Locatário CONFIRMA que retirou a carreta.
     */
    public function doTakeout(Order $order)
    {
        if (! $this->user->can('updateAsTenant', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        if (! $order->isStatus('pending-takeout')) {
            throw new OrderActionNotAllowedException(config('error.order_status_not_allowed'), 422);
        }

        // Ativa o pedido
        $order->status = 'active';
        $order->save();

        // Grava o log do pedido
        $this->log($order);

        // Notifica o proprietário
        $order->product->user->notify(new OrderConfirmTakeoutNotification($order));

        return $order;
    }

    /**
     * Locatário INFORMA que devolveu a carreta ao locador.
     */
    public function informDevolution(Order $order)
    {
        if (! $this->user->can('updateAsTenant', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        if (! $order->isStatus('active')) {
            throw new OrderActionNotAllowedException(config('error.order_status_not_allowed'), 422);
        }

        // Informa que a carreta foi devolvida ao locador
        $order->metadata = array_merge($order->metadata ?? [], [
            'tenant_devolution_informed' => true,
            'tenant_devolution_informed_date' => date('Y-m-d H:i:s'),
        ]);
        $order->save();

        // Notifica o locador
        $order->product->user->notify(new OrderInformDevolutionNotification($order));

        return $order;
    }

    /**
     * Locatário AVALIA locador.
     */
    public function rateLocator(Order $order, $rating)
    {
        // verifica se o usuário é o locatário do pedido
        if (! $this->user->can('updateAsTenant', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        // Verifica se o pedido que vai ser confirmado possui status finished
        if (! $order->isStatus('finished')) {
            throw new OrderActionNotAllowedException(config('error.order_status_not_allowed'), 422);
        }

        // Verifica se já existe um rating para o usuário
        if ($order->ratings()->where('subtype', 'locator')->count()) {
            throw new OrderRatingAlreadyDoneException(config('error.order_rating_user_already_done'), 422);
        }

        return self::doRating($order, $rating, 'locator');
    }

    /**
     * Locatário AVALIA carreta.
     */
    public function rateProduct(Order $order, $rating)
    {
        // verifica se o usuário é o locatário do pedido
        if (! $this->user->can('updateAsTenant', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        // Verifica se o pedido que vai ser confirmado possui status finished
        if (! $order->isStatus('finished')) {
            throw new OrderActionNotAllowedException(config('error.order_status_not_allowed'), 422);
        }

        // Verifica se já existe um rating para a carreta
        if ($order->ratings()->where('subtype', 'product')->count()) {
            throw new OrderRatingAlreadyDoneException(config('error.order_rating_product_already_done'), 422);
        }

        return self::doRating($order, $rating, 'product');
    }

    protected function setOrderPaid(Order $order)
    {
        $order->status = 'pending-takeout';
        $order->save();

        $this->log($order);

        return $order;
    }
}
