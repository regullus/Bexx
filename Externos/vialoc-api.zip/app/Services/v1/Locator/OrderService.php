<?php

namespace App\Services\v1\Locator;

use App\Models\User;
use App\Models\Order;
use App\Traits\OrderServiceTrait;
use App\Exceptions\ConflictOrderException;
use App\Exceptions\ProductUnavailableException;
use App\Notifications\OrderRefusedNotification;
use Illuminate\Validation\UnauthorizedException;
use App\Notifications\OrderConfirmedNotification;
use App\Exceptions\OrderActionNotAllowedException;
use App\Exceptions\OrderRatingAlreadyDoneException;
use App\Notifications\OrderInformTakeoutNotification;
use App\Notifications\OrderConfirmDevolutionNotification;

class OrderService
{
    use OrderServiceTrait;

    private $order;

    private $user;

    public function __construct()
    {
        $this->order = new Order();
        $this->user = auth()->user();
    }

    public function confirm(Order $order)
    {
        // Valida se a carreta pertence ao usuário logado
        if (! $this->user->can('updateAsLocator', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        // verifica se a carreta está ativa
        if ($order->product->status != 'active') {
            throw new ProductUnavailableException(config('error.product_unavailable'), 404);
        }

        // Verifica se o pedido que vai ser confirmado possui status pending-confirmation
        if (! $order->isStatus('pending-confirmation')) {
            throw new OrderActionNotAllowedException(config('error.order_status_not_allowed'), 422);
        }

        // Retorna todos os pedidos de mesmo período e com status concorrente, que impedem de eu confirmar este pedido.
        // $ordersOverlapping = $order->searchOverlappingOrders();
        // if ($ordersOverlapping->count()) {
        //     $exception = new ConflictOrderException();
        //     $exception->setOrdersRefused($ordersOverlapping);
        //     throw $exception;
        // }

        // Confirma pedido
        $order->status = 'pending-payment';
        $order->save();

        // Grava o log do pedido
        $this->log($order);

        // Notifica o locatário
        $order->user->notify(new OrderConfirmedNotification($order));

        return $order;
    }

    public function refuse(Order $order, User $user)
    {
        // Valida se a carreta pertence ao usuário logado
        if (! $this->user->can('updateAsLocator', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        // Verifica se o pedido que vai ser confirmado possui status pending-confirmation
        if (! $order->isStatus('pending-confirmation')) {
            throw new OrderActionNotAllowedException(config('error.order_status_not_allowed'), 422);
        }

        // Recusa o pedido
        $order = $this->doRefuse($order, $user);

        // Grava o log do pedido
        $this->log($order);

        return $order;
    }

    public function doRefuse(Order $order, User $user)
    {
        // Valida se a carreta pertence ao usuário logado
        if (! $this->user->can('updateAsLocator', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        // Verifica se o pedido que vai ser confirmado possui status pending-confirmation
        if (! $order->isStatus('pending-confirmation')) {
            throw new OrderActionNotAllowedException(config('error.order_status_not_allowed'), 422);
        }

        // Muda o status recusando o pedido
        $order->status = 'refused';
        $order->save();

        // Notifica o locatário
        $order->user->notify(new OrderRefusedNotification($order));

        return $order;
    }

    /**
     * Locador INFORMA que o locatário fez a retirada.
     */
    public function informTakeout(Order $order, User $user)
    {
        // Valida se a carreta pertence ao usuário logado
        if (! $this->user->can('updateAsLocator', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        // Verifica se o pedido que vai ser confirmado possui status pending-confirmation
        if (! $order->isStatus('pending-takeout')) {
            throw new OrderActionNotAllowedException(config('error.order_status_not_allowed'), 422);
        }

        // Informa que o locatário retirou a carreta
        $order->metadata = array_merge($order->metadata ?? [], [
            'locator_takeout_informed' => true,
            'locator_takeout_informed_date' => date('Y-m-d H:i:s'),
        ]);
        $order->save();

        // Notifica o locatário
        $order->user->notify(new OrderInformTakeoutNotification($order));

        return $order;
    }

    /**
     * Locador CONFIRMA que o locatário fez a devolução.
     */
    public function doDevolution(Order $order)
    {
        // Valida se a carreta pertence ao usuário logado
        if (! $this->user->can('updateAsLocator', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        // Verifica se o pedido que vai ser confirmado possui status pending-confirmation
        if (! $order->isStatus('active')) {
            throw new OrderActionNotAllowedException(config('error.order_status_not_allowed'), 422);
        }

        // Ativa o pedido
        $order->status = 'finished';
        $order->save();

        // Grava o log do pedido
        $this->log($order);

        // Notifica o locatário
        $order->user->notify(new OrderConfirmDevolutionNotification($order));

        return $order;
    }

    /**
     * Locador AVALIA locatário.
     */
    public function rateTenant(Order $order, $rating)
    {
        // Valida se a carreta pertence ao usuário logado
        if (! $this->user->can('updateAsLocator', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        // Verifica se o pedido que vai ser confirmado possui status finished
        if (! $order->isStatus('finished')) {
            throw new OrderActionNotAllowedException(config('error.order_status_not_allowed'), 422);
        }

        // Verifica se já existe um rating para o usuário
        if ($order->ratings()->where('subtype', 'tenant')->count()) {
            throw new OrderRatingAlreadyDoneException(config('error.order_rating_user_already_done'), 422);
        }

        return self::doRating($order, $rating, 'tenant');
    }

    public function changeAddress(Order $order, User $user, $address_id)
    {
        // Valida se a carreta pertence ao usuário logado
        if (! $this->user->can('updateAsLocator', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        // Altera o endereço
        $order->address_id = $address_id;

        return $order->save();
    }

    public function maintenance($order, User $user, $arrIDs)
    {
        // Valida se a carreta pertence ao usuário logado
        if (! $this->user->can('updateAsLocator', $order)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        foreach ($arrIDs as $id) {
            $orderRefused = Order::find($id);
            $this->doRefuse($orderRefused, $user);
        }
        $this->confirm($order, $user);
    }
}
