<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 02/08/18
 * Time: 09:46.
 */

namespace App\Services\v1\Site;

/*
 * Vendor packages
 */
use DateTime;
use App\Models\User;
use App\Models\Price;
use App\Models\Product;
use Illuminate\Support\Arr;
/*
 * User resources.
 */
use App\Models\PricesHistory;
use Illuminate\Support\Facades\DB;
use App\Exceptions\PricesNotFoundException;
use Symfony\Component\Translation\Exception\NotFoundResourceException;

class PriceService
{
    private $model;

    public function __construct()
    {
        $this->model = new Price();
    }

    /**
     * Os preços que já existentes (que já estão no banco de dados e estão sendo exibidos) são recebidos com ID (o front
     * deve enviar com ID). Os preços adicionados (novos) são recebidos sem ID e os preços removidos, não serão
     * recebidos.
     *
     * Baseado nessa premissa, a primeira ação do código é separar os preços (enviados em um array de arrays, ou, um
     * array de preços) que possuem ID (preços que já estão no banco de dados) dos preços que não possuem ID (novos
     * preços). Em seguida busca TODOS os preços DO PRODUTO com exceção daqueles que foram enviados com ID ou seja,
     * busca todos os preços que devem ser excluídos e excluí do banco (deleteMass). Em seguida cria os preços enviados
     * sem ID.
     */
    public function maintenance(Product $product, $arrPrice)
    {
        foreach ($arrPrice as $price) {
            $price['price_period'] = $price['price_per_day'] * $price['more_than'];

            if (! isset($price['id'])) {
                $createPrice[] = $price;
            } else {
                $safePriceIds[] = $price['id'];
                $updatePrice[] = $price;
            }
        }

        if (! empty($safePriceIds)) {
            $pricesToExclude = $product->prices()->whereNotIn('id', $safePriceIds)->get();
            foreach ($pricesToExclude as $price) {
                $excludePriceIds[] = $price->id;
            }
        }

        DB::beginTransaction();

        // Salva um snapshot do estado atual (anterior à modificação) dos preços antes de alterar.
        $product->price_logs()->create(['json_prices' => $product->prices]);

        if (! empty($createPrice)) {
            $this->createMass($product, $createPrice, false);
        }
        if (! empty($updatePrice)) {
            $this->updateMass($updatePrice, false);
        }
        if (! empty($excludePriceIds)) {
            $this->deleteMass($excludePriceIds, false);
        }
        DB::commit();

        return $product->prices()->orderBy('more_than', 'asc')->get();
    }

    public function create(Product $product, $arrPrice)
    {
        // Grava preço.
        $arrPrice['product_id'] = $product->id;

        return $this->model->create($arrPrice);
    }

    public function createMass(Product $product, $arrPrices, $boolTransaction = true)
    {
        $collection = collect([]);

        $boolTransaction && DB::beginTransaction();
        foreach ($arrPrices as $price) {
            $collection->push($this->create($product, $price));
        }
        $boolTransaction && DB::commit();

        return $collection;
    }

    public function update($arrPrice)
    {
        // Grava preço.
        // return $this->model->where('id', $arrPrice['id'])->update(Arr::only($arrPrice, ['more_than', 'price_per_day']));
        $price = $this->model->find($arrPrice['id']);
        $price->fill($arrPrice);

        return $price->save();
    }

    public function updateMass($arrPrices, $boolTransaction = true)
    {
        $collection = collect([]);

        $boolTransaction && DB::beginTransaction();
        foreach ($arrPrices as $price) {
            $collection->push($this->update($price));
        }
        $boolTransaction && DB::commit();

        return $collection;
    }

    public function delete($id)
    {
        $price = $this->model->destroy($id);
    }

    /**
     * Recebe um array indexado com os IDs de preços que devem ser excluídos.
     */
    public function deleteMass($arrIds, $boolTransaction = true)
    {
        $boolTransaction && DB::beginTransaction();
        // foreach($arrIds as $id) {
        //     $this->delete($id);
        // }
        $this->model->destroy($arrIds);
        $boolTransaction && DB::commit();
    }
}
