<?php

namespace App\Services\v1\Site;

use App\Models\Product;
use App\Models\QuestionAnswer;
use App\Policies\ProductPolicy;
use App\Policies\QuestionAnswerPolicy;
use App\Notifications\AnswerNotification;
use App\Notifications\QuestionNotification;
use App\Exceptions\ProductUnavailableException;
use App\Exceptions\ResourceUnavailableException;
use Illuminate\Validation\UnauthorizedException;

class QuestionAnswerService
{
    private $model;

    private $user;

    public function __construct()
    {
        $this->model = new QuestionAnswer();
        $this->user = auth()->user();
    }

    public function answer($data, Product $product, QuestionAnswer $question)
    {
        // se o usuário não for proprietário do produto, não poderá publicar a resposta
        if (! $this->user->can('update', $product)) {
            throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
        }

        if (! $product->isStatus('active')) {
            throw new ProductUnavailableException(config('error.product_unavailable'), 422);
        }

        $data['user_id'] = $this->user->id;
        $answer = $product->questionAnswers()->updateOrCreate(['parent_id' => $question->id], $data);

        // notifica o usuário criador da pergunta
        $question->user->notify(new AnswerNotification($answer));

        return $answer;
    }

    public function create($data, Product $product)
    {
        // se o usuário for proprietário do produto, não poderá publicar a questão
        if ($this->user->can('update', $product)) {
            throw new UnauthorizedException(config('error.message_cannot_be_owner'), 403);
        }

        if (! $product->isStatus('active')) {
            throw new ProductUnavailableException(config('error.product_unavailable'), 422);
        }

        // notifica o do no da carreta
        $userToNotify = $product->user;

        $data['user_id'] = $this->user->id;
        $questionAnswer = $product->questionAnswers()->create($data);

        $userToNotify->notify(new QuestionNotification($questionAnswer));

        return $questionAnswer;
    }

    public function setRead(QuestionAnswer $questionAnswer)
    {
        if ($questionAnswer->parent_id > 0) { // se for uma resposta quem le é o locatário
            if (! $this->user->can('isQuestionOwner', $questionAnswer)) {
                throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
            }
        } else { // se for uma pergunta quem lê é o locador
            $questionAnswer->load(['product']);
            if (! $this->user->can('update', $questionAnswer->product)) {
                throw new UnauthorizedException(config('error.resource_not_allowed'), 403);
            }
        }

        if (! empty($questionAnswer->read_at)) {
            throw new ResourceUnavailableException(config('error.message_already_read'), 422);
        }

        $questionAnswer->read_at = now();

        return $questionAnswer->save();
    }
}
