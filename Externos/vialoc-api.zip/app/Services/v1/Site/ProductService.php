<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 02/08/18
 * Time: 09:46.
 */

namespace App\Services\v1\Site;

/**{
        $this->model = new Price();

 * Vendor packages
 */

/*
 * User resources.
 */
use App\Models\User;
use App\Models\Media;
use App\Models\Product;
use App\Policies\ProductPolicy;
use Illuminate\Support\Facades\DB;
use App\Traits\DefineSearchFiltersTrait;
use App\Http\Requests\v1\Site\ProductDisableRequest;

class ProductService
{
    use DefineSearchFiltersTrait;

    private $model;

    private $user;

    public function __construct()
    {
        $this->model = new Product();
        $this->user = auth()->user();
    }

    public function create($arrData)
    {
        $this->model->user_id = $this->user->id;
        $this->model->fill($arrData)->save();

        if (empty($this->model->address_id)) {
            $address_string = $arrData['address']['address'].', '.$arrData['address']['address_number'].', '.$arrData['address']['city'].', '.$arrData['address']['state'].', BR';
            $geo_data = getGeoCoord($address_string);
            $geo_coords = null;

            if (! empty($geo_data->results)) {
                $geo_coords = array_shift($geo_data->results)->geometry->location;
            }

            if ($geo_coords && ! empty($geo_coords->lat)) {
                $arrData['address']['latitude'] = $geo_coords->lat;
                $arrData['address']['longitude'] = $geo_coords->lng;
            }

            $address = $this->user->addresses()->create($arrData['address']);
            $this->model->update(['address_id' => $address->id]);
        }

        return $this->model;
    }

    public function update(Product $product, $arrData)
    {
        if (! $this->user->can('update', $product)) {
            abort(404);
        }

        // remove o status do array
        unset($arrData['status']);

        /*
         * Atualiza com os novos dados e retorna o objeto inteiro.
         */
        $product->fill($arrData)->save();

        if (empty($product->address_id)) {
            $address_string = $arrData['address']['address'].', '.$arrData['address']['address_number'].', '.$arrData['address']['city'].', '.$arrData['address']['state'].', BR';
            $geo_data = getGeoCoord($address_string);
            $geo_coords = null;

            if (! empty($geo_data->results)) {
                $geo_coords = array_shift($geo_data->results)->geometry->location;
            }

            if ($geo_coords && ! empty($geo_coords->lat)) {
                $arrData['address']['latitude'] = $geo_coords->lat;
                $arrData['address']['longitude'] = $geo_coords->lng;
            }

            $address = $this->user->addresses()->create($arrData['address']);
            $product->update(['address_id' => $address->id]);
        }

        // Provavelmente não possa ficar aqui, talvez seja necessario jogar em um cronjob
        if ($product->status == 'active') {
            self::cacheAllFormData();
        }

        return $product;
    }

    public function setStatus(Product $product, $status)
    {
        if (! $this->user->can('update', $product)) {
            abort(404);
        }

        if ($status == 'active' && ! $product->isComplete()) {
            abort(422);
        }

        $product->fill(['status' => $status])->save();

        return $product;
    }

    // public function disable(Product $product) {
    //     if(!$this->user->can('update', $product)) {
    //         abort(404);
    //     }

    //     $product->status = config('c7.product.status.inactive');
    //     return $product->save();
    // }

    public function uploadImage(Product $product, $arrData, $tag = null)
    {
        if (! $this->user->can('update', $product)) {
            abort(404);
        }

        if (empty($tag)) {
            $image = \C7Upload::productImage($arrData->file('image'), $product);
            $product->attachMedia($image, 'product-image');

            // se o produto não tem nenhuma imagem de destaque, é definida a primeira imagem como destaque
            if (! $product->hasMedia('product-featured-image')) {
                $product->attachMedia($image, 'product-featured-image');
            }
        } else {
            $image = \C7Upload::productImage($arrData->file('image'), $product, $tag);
            $product->syncMedia($image, $tag); // é utilizado o syncMedia pois só haverá uma imagem por posição
        }

        return $image;
    }

    public function deleteImage(Product $product, $image_id)
    {
        if (! $this->user->can('update', $product)) {
            abort(404);
        }

        $product->media()->find($image_id)->delete();
    }

    public function uploadDocument(Product $product, $arrData)
    {
        if (! $this->user->can('update', $product)) {
            abort(404);
        }

        $document = \C7Upload::productDocument($arrData->file('image'), $arrData->input('document_type'), $product);
        $product->attachMedia($document, $arrData->input('document_type'));

        return $document;
    }
}
