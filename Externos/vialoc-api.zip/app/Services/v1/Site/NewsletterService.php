<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 09/10/18
 * Time: 09:46.
 */

namespace App\Services\v1\Site;

use App\Models\Newsletter;

class NewsletterService
{
    protected $model;

    public function __construct()
    {
        $this->model = new Newsletter();
    }

    public function create($arr, $arrExtra = [])
    {
        $this->model->updateOrCreate($arr, $arrExtra);
    }
}
