<?php

namespace App\Services\v1\Site;

use App\Models\Media;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use App\Http\Controllers\Controller;

class MediaLibraryService
{
    public function list($request)
    {
        return Media::filterSearch($request->input('s'))
                        ->filterMetadata('width', $request->input('width'), true)
                        ->filterMetadata('height', $request->input('height'), true)
                        ->ordered()
                        ->paginate(40);
    }

    public function destroy($media)
    {
        if ($media) {
            $media_id = $media->id;

            // remove os thumbs se houver
            $all_files = \Storage::disk($media->disk)->files($media->directory);
            // filter the ones that match the filename.*
            $media_thumbs = Arr::where($all_files, function ($value, $key) use ($media) {
                return strpos($value, $media->directory.DIRECTORY_SEPARATOR.$media->filename.'__') === 0;
            });

            // iterate through files and echo their content
            if (! empty($media_thumbs)) {
                foreach ($media_thumbs as $media_thumb) {
                    \Storage::disk($media->disk)->delete($media_thumb);
                }
            }

            $media->delete();

            return $media_id;
        }

        return 'O arquivo de mídia não foi encontrado.';
    }

    public function create($file, $options = [])
    {
        $opt = array_merge([
            'path' => date('Y'.DIRECTORY_SEPARATOR.'m'),
            'filename' => null,
            'thumbnails' => [
                'sizes_only' => null,
                'sizes_exclude' => null,
            ],
        ], $options);

        // os diretórios serão por ano e mês
        // $path = date('Y'. DIRECTORY_SEPARATOR .'m');

        if (empty($opt['filename'])) {
            $filename_original = $file;
            if (is_object($file)) {
                $filename_original = $file->getClientOriginalName();
            }
            $opt['filename'] = Str::slug(pathinfo($filename_original, PATHINFO_FILENAME));
        }

        $file_stored = \MediaUploader::fromSource($file)
                ->useFilename($opt['filename'])
                ->toDirectory($opt['path'])
                ->onDuplicateReplace()
                ->upload();

        // gera um thumbnail
        if ($file_stored->aggregate_type == 'image') {
            self::generateExtras($file_stored, $opt['thumbnails']);
        }

        return $file_stored;
    }

    protected function generateExtras(Media $file, $attributes = [])
    {
        $attributes = array_merge([
            'sizes_only' => null, // only these thumbnail sizes
            'sizes_exclude' => null, // exclude these thumbnail sizes
        ], $attributes);

        $config_thumbs = config('c7.thumbs_sizes');

        if ($attributes['sizes_only']) {
            $config_thumbs = Arr::only($config_thumbs, $attributes['sizes_only']);
        }

        if ($attributes['sizes_exclude']) {
            $config_thumbs = Arr::except($config_thumbs, $attributes['sizes_exclude']);
        }

        $thumbnails = [];
        $metadata = [];

        $path = $file->disk.DIRECTORY_SEPARATOR.$file->directory;
        $fullpath = public_path($path);
        $file_original = $file->filename.'.'.$file->extension;
        $file_path = $fullpath.DIRECTORY_SEPARATOR.$file_original;

        // generate infos if image
        if ($file->aggregate_type == 'image') {
            $file_info = \Image::make($file_path);
            $metadata = [
                        'width' => $file_info->width(),
                        'height' => $file_info->height(),
                    ];

            // generate Thumbs
            foreach ($config_thumbs as $th_name => $th) {
                $get_thumb = \Image::make($file_path);

                if ($th['crop']) {
                    $get_thumb->fit($th['w'], $th['h']);
                } else {
                    $get_thumb->resize($th['w'], $th['h'], function ($constraint) {
                        $constraint->aspectRatio();
                    });
                }

                $file_target = $file->filename.'__'.($th['w'] ? $th['w'] : 0).'x'.($th['h'] ? $th['h'] : 0).'.'.$file->extension;

                $get_thumb->save($fullpath.DIRECTORY_SEPARATOR.$file_target);

                $thumbnails[$th_name] = [
                    'path' => $path.DIRECTORY_SEPARATOR.$file_target,
                ];
            }

            $metadata['thumbnails'] = $thumbnails;
        }

        if (is_array($file->metadata)) {
            $metadata = array_merge($file->metadata, $metadata);
        }

        $file->metadata = $metadata;
        $file->save();
    }
}
