<?php

namespace App\ModelFilters;

/*
 * Parent
 */
use EloquentFilter\ModelFilter;
use App\Http\Requests\v1\Site\Product\ProductListRequest;

class ProductFilter extends ModelFilter
{
    /**
     * Related Models that have ModelFilters as well as the method on the ModelFilter
     * As [relationMethod => [input_key1, input_key2]].
     *
     * @var array
     */
    public $relations = [
        'address' => ['latitude', 'longitude'],
        'city' => ['city_id', 'city_name', 'city_state_code'],
        'user' => ['user_email', 'profile_name'],
        'prices' => ['price', 'price_min', 'price_max'],
        'brand' => ['brand_name'],
        'orders' => ['date_interval'],
    ];

    public function productAxes($value)
    {
        $this->where('axes', $value);
    }

    public function productBrand($value)
    {
        $this->where('brand_id', $value);
    }

    public function productContent($value)
    {
        $this->whereLike('content', $value);
    }

    public function productCubing($value)
    {
        $this->where('cubing', $value);
    }

    public function productFloor($value)
    {
        $this->where('floor', $value);
    }

    public function productHeight($value)
    {
        $this->where('height', $value);
    }

    public function productLength($value)
    {
        $this->where('length', $value);
    }

    public function productLicensing($value)
    {
        $this->where('licensing', $value);
    }

    public function productName($value)
    {
        $this->whereLike('name', $value);
    }

    public function productOrderBy($value)
    {
        $coordinates = request()->input('address_radius');

        switch ($value) {
            case 'price':
                $this->select('products.*', 'prices.price_period')
                    ->leftJoin('prices', 'prices.product_id', '=', 'products.id')->where('prices.more_than', 30)->orderBy('prices.price_period');

                break;
            case 'distance':
                if (empty($coordinates) || empty($coordinates['latitude']) || empty($coordinates['longitude'])) {
                    break;
                }
                $this->orderBy('distance');

                break;
        }
    }

    public function productPriceRange($priceRange)
    {
        $this->with('price_monthly')->whereHas('price_monthly', function ($query) use ($priceRange) {
            $query->whereBetween('prices.price_period', $priceRange);
        });
    }

    /**
     * Método invocado quando há a necessidade de puxar carretas disponíveis para locação.
     */
    public function productReservation($dates)
    {
        $this->whereDoesntHave('orders', function ($query) use ($dates) {
            $query->where(function ($query) use ($dates) {
                $query->whereBetween('date_start', [$dates['date_start'], $dates['date_end']])
                    ->orWhereBetween('date_end', [$dates['date_start'], $dates['date_end']]);
            })->whereIn('status', ['pending-payment', 'pending-takeout', 'active']);
        });
    }

    public function productStatus($value)
    {
        if ($value) {
            $this->where('status', $value);
        }
    }

    public function productSuspension($value)
    {
        $this->where('suspension', $value);
    }

    public function productType($value)
    {
        if (is_array($value)) {
            $this->whereIn('type', $value);
        } else {
            $this->where('type', $value);
        }
    }

    public function productUid($value)
    {
        $this->where('uid', $value);
    }

    // Esse método é chamado quando o campo product_user_id é solicitado. O eloquentfilter remove o _id e chama o método
    // de mesmo nome.
    public function productUser($value)
    {
        $this->where('user_id', $value);
    }

    public function productWeight($value)
    {
        $this->where('weight', $value);
    }

    public function productWidth($value)
    {
        $this->where('width', $value);
    }

    public function productYear($value)
    {
        $this->where('year', $value);
    }

    public function productYearRange($yearRange)
    {
        $this->whereBetween('year', $yearRange);
    }

    // $value = [latitude => value, longitude => value]
    public function addressRadius($coordinates)
    {
        if (empty($coordinates) || empty($coordinates['latitude']) || empty($coordinates['longitude'])) {
            return;
        }
        // $this->whereHas('address', function ($q) use ($value) {
        //     $q->insideRadius($value);
        // });

        // $this->with(['address' => function ($q) use ($value) {
        //     $q->insideRadius($value);
        // }]);

        if (empty($coordinates['radius'])) {
            $coordinates['radius'] = 1000;
        }

        // 6371 para kilometros e 3959 para milhas
        // $haversine = "(6371 * acos(cos(radians(" . $coordinates['latitude'] . "))
        //                 * cos(radians(addresses.latitude))
        //                 * cos(radians(addresses.longitude)
        //                 - radians(" . $coordinates['longitude'] . "))
        //                 + sin(radians(" . $coordinates['latitude'] . "))
        //                 * sin(radians(addresses.latitude))))";

        // $this->join('addresses', function ($join) use ($haversine, $coordinates) {
        //     $join->on('products.address_id', '=', 'addresses.id')
        //          ->selectRaw("{$haversine} AS distance")
        //          ->whereRaw("{$haversine} < ?", [$coordinates['radius']])
        //          ->orderBy('distance', 'asc');
        // });

        // 6371 para kilometros e 3959 para milhas
        $haversine = '(6371 * acos(cos(radians('.$coordinates['latitude'].'))
                        * cos(radians(latitude))
                        * cos(radians(longitude)
                        - radians('.$coordinates['longitude'].'))
                        + sin(radians('.$coordinates['latitude'].'))
                        * sin(radians(latitude))))';

        $this->join('addresses', 'products.address_id', '=', 'addresses.id')
             ->select('products.*')
             ->selectRaw("{$haversine} AS distance")
             ->whereRaw("{$haversine} < ?", [$coordinates['radius']]);
        //  ->orderBy('distance', 'asc');
    }

    /*
     * Quando o relacionamento com o endereço é invocado, o escopo abaixo é solicitado
     */
    // public function addressSetup($query)
    // {
    //     \Log::info(json_encode($query));
    //     $query->insideRadius();
    // }

    /*
     * Existem duas maneiras de implementar relacionamento entre filtros segundo a documentação do pacote
     * Tucker-Eric/EloquentFilter. Uma delas é a forma descrita abaixo. Não pretendo utilizar essa forma porém, deixamos
     * comentada.
     *
     * Chamada do filtro considerando o metodo explicado aqui:
     * $productCollection = Product::filter($request->all())->with('city')->toSql(); #Depois tira o use da model Product que fiz aqui...
     *
     */
    /*
    public function city($id) {
        return $this->related('city', 'city_id', '=', $id);
    }
    */
}
