<?php

namespace App\ModelFilters;

use EloquentFilter\ModelFilter;

class CityFilter extends ModelFilter
{
    /**
     * Related Models that have ModelFilters as well as the method on the ModelFilter
     * As [relationMethod => [input_key1, input_key2]].
     *
     * @var array
     */
    public $relations = [];

    public function city($value)
    {
        if ($value) {
            $this->where('id', $value);
        }
    }

    public function cityName($value)
    {
        $this->whereLike('name', $value);
    }

    public function cityIbgeCode($value)
    {
        $this->where('ibge_code', $value);
    }

    public function cityStateCode($value)
    {
        if ($value) {
            $this->where('state_code', $value);
        }
    }
}
