<?php

namespace App\ModelFilters;

use EloquentFilter\ModelFilter;

class PriceFilter extends ModelFilter
{
    /**
     * Related Models that have ModelFilters as well as the method on the ModelFilter
     * As [relationMethod => [input_key1, input_key2]].
     *
     * @var array
     */
    public $relations = [];

    public function priceMin($value)
    {
        $this->where('price_per_day', '>=', $value);
    }

    public function priceMax($value)
    {
        $this->where('price_per_day', '<=', $value);
    }
}
