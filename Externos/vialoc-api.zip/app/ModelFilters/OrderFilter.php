<?php

namespace App\ModelFilters;

use EloquentFilter\ModelFilter;

class OrderFilter extends ModelFilter
{
    /**
     * Related Models that have ModelFilters as well as the method on the ModelFilter
     * As [relationMethod => [input_key1, input_key2]].
     *
     * @var array
     */
    public $relations = [
        'product' => ['product_user_id', 'product_uid'],
    ];

    public function orderStatus($value)
    {
        $this->where('status', $value);
    }

    // CHECAR: O FILTRO NÃO ESTÁ BOM

    /**
     * A ideia é realizar uma busca por carretas excluindo as que possuem pedidos agendados para o intervalo de data
     * solicitado. Também é possível enviar apenas a data inicial mas não a data final apenas.
     */
    public function dateInterval($arr)
    {
        if (! isset($arr['date_start']) || $arr['date_start']) {
            return;
        }
        $dateStart = $arr['date_start'];
        $dateEnd = $arr['date_end'];
        if (! $dateEnd) {
            $dateEnd = $dateStart;
        }

        // O usuário pode ou não fornecer
        $this->where(function ($query) use ($dateStart, $dateEnd) {
            $query->where('date_end', '<', $dateStart)
                ->orWhere('date_start', '>', $dateEnd);
        })
        ->whereIn('status', ['pending-payment', 'pending-takeout', 'active']);
    }
}
