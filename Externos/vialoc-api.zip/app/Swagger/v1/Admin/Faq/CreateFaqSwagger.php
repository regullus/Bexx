<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 07/05/18
 * Time: 15:30.
 */

namespace App\Swagger\v1\Admin\Faq;

/**
 * @SWG\Definition(required={}, type="object")
 */
class CreateFaqSwagger
{
    /**
     * @var string
     * @SWG\Property(example="Posso me cadastrar como locatário e como locador ao mesmo tempo?")
     */
    public $question;

    /**
     * @var string
     * @SWG\Property(example="Sim. A pergunta feita no cadastro serve apenas para que possamos identificar sua intenção porém, posteriormente você poderá cadastrar uma carreta e alugar carretas sem probelmas.")
     */
    public $answer;

    /**
     * @var int
     * @SWG\Property(example=3)
     */
    public $target;
}
