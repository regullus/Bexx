<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 07/05/18
 * Time: 15:30.
 */

namespace App\Swagger\v1\Site\Price;

/**
 * @SWG\Definition(required={}, type="object")
 */
class CreatePriceSwagger
{
    /**
     * @var int
     * @SWG\Property(example="3")
     */
    public $more_than;

    /**
     * @var string
     * @SWG\Property(example="100")
     */
    public $price_per_day;
}
