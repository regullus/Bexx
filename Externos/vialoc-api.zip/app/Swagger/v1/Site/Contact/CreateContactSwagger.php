<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 07/05/18
 * Time: 15:30.
 */

namespace App\Swagger\v1\Site\Contact;

/**
 * @SWG\Definition(required={}, type="object")
 */
class CreateContactSwagger
{
    /**
     * @var string
     * @SWG\Property(example="Alexandre Martins Vargas")
     */
    public $name;

    /**
     * @var string
     * @SWG\Property(example="alexnadremv@gmail.com")
     */
    public $email;

    /**
     * @var string
     * @SWG\Property(example="Solicitação para tal coisa.")
     */
    public $subject;

    /**
     * @var string
     * @SWG\Property(example="Tenho uma dúvida em relação a tal coisa...")
     */
    public $message;
}
