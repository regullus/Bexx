<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 19/10/18
 * Time: 09:39.
 */

namespace App\Swagger\v1\Site\Rating;

/**
 * @SWG\Definition(type="object")
 */
class CreateRatingProductSwagger
{
    /**
     * var integer.
     * @SWG\Property(example="")
     */
    public $subtype;

    /**
     * var integer.
     * @SWG\Property(example="4")
     */
    public $rating;

    /**
     * @var var string
     * @SWG\Property(example="Comentário qq")
     */
    public $comment;
}
