<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 07/05/18
 * Time: 15:30.
 */

namespace App\Swagger\v1\Site\Newsletter;

/**
 * @SWG\Definition(required={}, type="object")
 */
class CreateNewsletterSwagger
{
    /**
     * @var string
     * @SWG\Property(example="alexandremv@gmail.com")
     */
    public $email;
}
