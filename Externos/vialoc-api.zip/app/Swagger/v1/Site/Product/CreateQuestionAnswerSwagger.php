<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 01/08/18
 * Time: 17:11.
 */

namespace App\Swagger\v1\Site\Product;

/**
 * @SWG\Definition(type="object")
 */
class CreateQuestionAnswerSwagger
{
    /**
     * @var string
     * @SWG\Property(example="Pergunta ou resposta.")
     */
    public $content;
}
