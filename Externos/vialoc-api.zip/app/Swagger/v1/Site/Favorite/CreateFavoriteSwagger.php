<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 19/10/18
 * Time: 09:39.
 */

namespace App\Swagger\v1\Site\Favorite;

/**
 * @SWG\Definition(type="object")
 */
class CreateFavoriteSwagger
{
    /**
     * var integer.
     * @SWG\Property(example="1")
     */
    public $product_id;
}
