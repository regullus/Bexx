<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 01/08/18
 * Time: 17:11.
 */

namespace App\Swagger\v1\Site\Order;

/**
 * @SWG\Definition(type="object")
 */
class OrderCreateSwagger
{
    /**
     * @var int
     * @SWG\Property(example="2557f48d-c193-4036-b088-a731b05bac59")
     */
    public $product_uid;

    /**
     * @var string
     * @SWG\Property(example="2018-11-22")
     */
    public $date_start;

    /**
     * @var string
     * @SWG\Property(example="2018-11-29")
     */
    public $date_end;
}
