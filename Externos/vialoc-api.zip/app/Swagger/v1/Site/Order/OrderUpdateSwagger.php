<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 01/08/18
 * Time: 17:11.
 */

namespace App\Swagger\v1\Site\Order;

/**
 * @SWG\Definition(type="object")
 */
class OrderUpdateSwagger
{
    /**
     * @var string
     * @SWG\Property(example="Carreta fazendinha profissional pequena")
     */
    public $name;

    /**
     * @var int
     * @SWG\Property(example="1")
     */
    public $city_id;

    /**
     * @var string
     * @SWG\Property(example="Descrição completa da carreta.")
     */
    public $content;

    /**
     * @var string
     * @SWG\Property(example="Carreta baú.")
     */
    public $type;

    /**
     * @var int
     * @SWG\Property(example="1")
     */
    public $brand_id;

    /**
     * Altura em metros.
     *
     * @var number
     * @SWG\Property(example="4.00")
     */
    public $height;

    /**
     * Largura em metros.
     *
     * @var number
     * @SWG\Property(example="2.00")
     */
    public $width;

    /**
     * Comprimento em metros.
     *
     * @var number
     * @SWG\Property(example="10.00")
     */
    public $length;

    /**
     * Peso.
     *
     * @var number
     * @SWG\Property(example="1000.00")
     */
    public $weight;

    /**
     * Cubagem.
     *
     * @var number
     * @SWG\Property(example="1000.00")
     */
    public $cubing;

    /**
     * Quantidade de eixos.
     *
     * @var int
     * @SWG\Property(example="3")
     */
    public $axes;

    /**
     * @var string
     * @SWG\Property(example="06/2018")
     */
    public $licensing;

    /**
     * @var string
     * @SWG\Property(example="2017")
     */
    public $year;

    /**
     * @var string
     * @SWG\Property(example="2018")
     */
    public $model;

    /**
     * @var string
     * @SWG\Property(example="X5Z7895D78A965")
     */
    public $chassis;

    /**
     * @var string
     * @SWG\Property(example="001487515985")
     */
    public $renavam;

    /**
     * @var string
     * @SWG\Property(example="7777777777")
     */
    public $antt;

    /**
     * @var string
     * @SWG\Property(example="madeirite")
     */
    public $floor;

    /**
     * @var string
     * @SWG\Property(example="pneumatica")
     */
    public $suspension;
}
