<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 01/08/18
 * Time: 17:11.
 */

namespace App\Swagger\v1\Site\Order;

/**
 * @SWG\Definition(type="object")
 */
class OrderCreateQuestionAnswerSwagger
{
    /**
     * @var string
     * @SWG\Property(example="Posso retirar a carreta em tal lugar?")
     */
    public $content;
}
