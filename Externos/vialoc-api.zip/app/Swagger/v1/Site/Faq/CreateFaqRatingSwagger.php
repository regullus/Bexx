<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 07/05/18
 * Time: 15:30.
 */

namespace App\Swagger\v1\Site\Faq;

/**
 * @SWG\Definition(required={}, type="object")
 */
class CreateFaqRatingSwagger
{
    /**
     * @var string
     * @SWG\Property(example="1")
     */
    public $rating;
}
