<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 08/05/18
 * Time: 10:35.
 */

namespace App\Swagger\v1\Common\User;

use App\Swagger\v1\Common\Address\AddressCreateSwagger;
use App\Swagger\v1\Common\Address\AddressUpdateSwagger;

/**
 * @SWG\Definition(required={}, type="object")
 */
class UpdateProfileSwagger
{
    /**
     * @var string
     * @SWG\Property(example="30487276809")
     */
    public $cpf;

    /**
     * @var string
     * @SWG\Property(example="14/09/1981")
     */
    public $birthdate;

    /**
     * @var string
     * @SWG\Property(example="60583853000125")
     */
    public $cnpj;

    /**
     * @var string
     * @SWG\Property(example="Industria Mecânica Faia Ltda")
     */
    public $company_name;

    /**
     * @var string
     * @SWG\Property(example="Faia")
     */
    public $trading_name;
}
