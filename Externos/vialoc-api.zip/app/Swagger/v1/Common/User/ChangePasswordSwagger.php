<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 08/05/18
 * Time: 09:31.
 */

namespace App\Swagger\v1\Common\User;

/**
 * @SWG\Definition(required={}, type="object")
 */
class ChangePasswordSwagger
{
    /**
     * @var string
     * @SWG\Property(example="alexandre123")
     */
    public $password_current;

    /**
     * @var string
     * @SWG\Property(example="alexandre123")
     */
    public $password;

    /**
     * @var string
     * @SWG\Property(example="alexandre123")
     */
    public $password_confirmation;
}
