<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 07/05/18
 * Time: 15:30.
 */

namespace App\Swagger\v1\Common\User;

/**
 * @SWG\Definition(required={}, type="object")
 */
class RegisterCompanySwagger
{
    /**
     * @var string
     * @SWG\Property(example="alexandremv@gmail.com")
     */
    public $email;

    /**
     * @var string
     * @SWG\Property(example="alexandre123")
     */
    public $password;

    /**
     * @var string
     * @SWG\Property(example="alexandre123")
     */
    public $password_confirmation;

    /**
     * @var string
     * @SWG\Property(example="60583853000125")
     */
    public $cnpj;

    /**
     * @var string
     * @SWG\Property(example="Industria Mecânica Faia Ltda")
     */
    public $company_name;

    /**
     * @var string
     * @SWG\Property(example="Faia")
     */
    public $trading_name;
}
