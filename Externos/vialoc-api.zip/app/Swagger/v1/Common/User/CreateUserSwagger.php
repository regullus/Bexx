<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 07/05/18
 * Time: 15:30.
 */

namespace App\Swagger\v1\Common\User;

use App\Swagger\v1\Common\Address\AddressCreateSwagger;

/**
 * @SWG\Definition(required={}, type="object")
 */
class CreateUserSwagger
{
    /**
     * @var string
     * @SWG\Property(example="tenant")
     */
    public $type;

    /**
     * @var string
     * @SWG\Property(example="Alexandre")
     */
    public $name;

    /**
     * @var string
     * @SWG\Property(example="Vargas")
     */
    public $last_name;

    /**
     * @var string
     * @SWG\Property(example="alexandremv@gmail.com")
     */
    public $email;

    /**
     * @var string
     * @SWG\Property(example="alexandre123")
     */
    public $password;

    /**
     * @var string
     * @SWG\Property(example="1")
     */
    public $agree_terms;

    /**
     * @var string
     * @SWG\Property(example="1")
     */
    public $receive_news;

    /**
     * @var UpdateProfileSwagger
     * @SWG\Property()
     */
    public $profile;

    /**
     * @var AddressCreateSwagger
     * @SWG\Property()
     */
    public $address;
}
