<?php
/**
 * Created by PhpStorm.
 * User: alexandre
 * Date: 01/08/18
 * Time: 17:11.
 */

namespace App\Swagger\v1\Common\Address;

/**
 * @SWG\Definition(type="object")
 */
class AddressUpdateSwagger
{
    /**
     * @var string
     * @SWG\Property(example="Principal")
     */
    public $label;

    /**
     * @var string
     * @SWG\Property(example="03370010")
     */
    public $zipcode;

    /**
     * @var string
     * @SWG\Property(example="Avenida Luca")
     */
    public $address;

    /**
     * @var int
     * @SWG\Property(example="485")
     */
    public $address_number;

    /**
     * @var string
     * @SWG\Property(example="")
     */
    public $address_complement;

    /**
     * @var int
     * @SWG\Property(example="12")
     */
    public $city_id;

    /**
     * @var string
     * @SWG\Property(example="observações relacionadas ao endereço")
     */
    public $notes;

    /**
     * @var int
     * @SWG\Property(example="1")
     */
    public $is_main;
}
