<?php

namespace App\Swagger\v1\Common\Auth;

/**
 * @SWG\Definition(required={}, type="object")
 */
class Login
{
    /**
     * @var string
     * @SWG\Property(example="alexandremv@gmail.com")
     */
    public $email;

    /**
     * @var string
     * @SWG\Property(example="alexandre123")
     */
    public $password;
}
