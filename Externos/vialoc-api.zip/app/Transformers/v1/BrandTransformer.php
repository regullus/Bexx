<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Brand;

class BrandTransformer extends Fractal\TransformerAbstract
{
    public function transform(Brand $brand)
    {
        return [
            'id' => $brand->id,
            'name' => $brand->name,
            'slug' => $brand->slug,
            'status' => $brand->status,
        ];
    }
}
