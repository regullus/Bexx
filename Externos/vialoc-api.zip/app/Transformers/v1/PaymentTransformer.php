<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\OrderPayment;

class PaymentTransformer extends Fractal\TransformerAbstract
{
    public function transform(OrderPayment $orderPayment)
    {
        $op = [
            'id' => $orderPayment->id,
            'payment_method_slug' => $orderPayment->payment_method_slug,
            'payment_method_formatted' => $orderPayment->paymentMethod->name,
            'payment_method_option' => $orderPayment->payment_method_option,
            'gateway_payment_id' => $orderPayment->gateway_payment_id,
            'gateway_transaction_id' => $orderPayment->gateway_transaction_id,
            'status' => $orderPayment->status,
            'status_formatted' => $orderPayment->list_status[$orderPayment->status],
            // 'created_at' => $orderPayment->created_at->format('Y-m-d H:i:s'),
            'created_at_formatted' => $orderPayment->created_at->format('d/m/Y H:i'),
        ];

        if ($orderPayment->payment_method_slug == 'credit-card') {
            $op['credit_card_number'] = $orderPayment->gatewayRequest->json_gateway_request['creditCard']['cardNumber'];
            $op['status_authorization_message'] = config('error.payment_'.$orderPayment->status_authorization);
            $op['status_capture_formatted'] = $orderPayment->list_status_capture[$orderPayment->status_capture];
            $op['payment_method_option_formatted'] = $orderPayment->paymentMethod->options[$orderPayment->payment_method_option]['name'];
        }

        if ($orderPayment->payment_method_slug == 'bank-slip') {
            $op['url'] = $orderPayment->gatewayRequest->json_gateway_response['payment']['url'];
            $op['expiration_date'] = date('d/m/Y', strtotime($orderPayment->gatewayRequest->json_gateway_response['payment']['expirationDate']));
            $op['is_expired'] = time() > strtotime($orderPayment->gatewayRequest->json_gateway_response['payment']['expirationDate']);
        }

        if ($orderPayment->payment_method_slug == 'debit-card') {
            $op['url'] = $orderPayment->gatewayRequest->json_gateway_response['payment']['authenticationUrl'];
        }

        return $op;
    }
}
