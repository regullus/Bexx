<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Product;

class ProductFullTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'prices',
        'address',
        'featured_image',
        'view_images',
        'images',
        'questions',
    ];

    public function transform(Product $product)
    {
        $product->load(['price_monthly']);
        $featured_image = $product->firstMedia('product-featured-image');

        return [
            'uid' => $product->uid,
            'external_id' => $product->external_id,
            'name' => $product->name,
            'slug' => $product->slug,
            'content' => $product->content,
            'link_video' => $product->link_video,
            'address_id' => $product->address_id,
            'city' => ($product->address && $product->address->city ? $product->address->city->name : ''),
            'state_code' => ($product->address && $product->address->city ? $product->address->city->state_code : ''),
            'user_id' => $product->user_id,
            'type' => $product->type,
            'type_formatted' => $product->type_formatted,
            'brand_id' => $product->brand_id,
            'brand' => $product->brand->name,
            'height' => $product->height,
            'width' => $product->width_formatted,
            'length' => $product->length_formatted,
            'weight' => $product->weight_formatted,
            'cubing' => $product->cubing_formatted,
            'axes' => $product->axes,
            'licensing' => $product->licensing_formatted,
            'year' => $product->year,
            'model' => $product->model,
            'chassis' => $product->chassis,
            'renavam' => $product->renavam,
            'antt' => $product->antt,
            'owner_name' => $product->owner_name,
            'owner_cpf_cnpj' => $product->owner_cpf_cnpj,
            'license_plate' => $product->license_plate,
            'floor' => $product->floor,
            'with_tires' => (bool) $product->with_tires,
            'suspension' => $product->suspension,
            'status' => $product->status,
            'price_from' => $product->price_monthly ? $product->price_monthly->price_period : 0,
            'featured_image_path' => $featured_image ? $featured_image->metadata['thumbnails']['retangle-small']['path'] : null,
            'rating_score' => $product->rating_score,
            'rating_count' => $product->rating_count,
            'is_complete' => $product->isComplete(),
        ];
    }

    public function includeAddress(Product $product)
    {
        if (empty($product->address)) {
            return;
        }

        return $this->item($product->address, new AddressFullTransformer());
    }

    public function includeFeaturedImage(Product $product)
    {
        $featured_image = $product->firstMedia('product-featured-image');

        if (! $featured_image) {
            return;
        }

        return $this->item($featured_image, new MediaTransformer());
    }

    public function includeViewImages(Product $product)
    {
        return $this->collection($product->getMedia(['left', 'right', 'front', 'back', 'interior', 'axes']), new MediaTransformer());
    }

    public function includeImages(Product $product)
    {
        return $this->collection($product->getMedia(['product-image']), new MediaTransformer());
    }

    public function includePrices(Product $product)
    {
        return $this->collection($product->prices()->orderBy('prices.more_than', 'asc')->get(), new PriceFullTransformer());
    }

    public function includeQuestions(Product $product)
    {
        return $this->collection($product->questions()->orderBy('created_at', 'desc')->get(), new QuestionFullTransformer());
    }
}
