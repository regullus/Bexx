<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\City;

class CityFullTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'state',
    ];

    public function transform(City $city)
    {
        return [
            'id' => $city->id,
            'name' => $city->name,
            'state_code' => $city->state_code,
            'state' => $city->state->name,
            'ibge_code' => $city->ibge_code,
        ];
    }

    public function includeState(City $city)
    {
        return $this->item($city->state, new StateTransformer());
    }
}
