<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Product;

class ProductSummaryTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'address',
        'prices',
        'questions',
    ];

    public function transform(Product $product)
    {
        $product->load(['price_monthly']);
        $featured_image = $product->firstMedia('product-featured-image');

        // \Log::info($product->id);
        // \Log::info($product);
        // \Log::info($product->price_monthly);

        $op = [
            'uid' => $product->uid,
            'slug' => $product->slug,
            'name' => $product->name,
            'type' => $product->type,
            'type_formatted' => $product->type_formatted,
            'brand_id' => $product->brand_id,
            'brand' => $product->brand->name,
            'year' => $product->year,
            'city_id' => $product->address->city_id,
            'city' => $product->address->city->name,
            'state_code' => $product->address->city->state_code,
            'price_from' => $product->price_monthly ? $product->price_monthly->price_period : 0,
            'featured_image_path' => $featured_image ? $featured_image->metadata['thumbnails']['retangle-small']['path'] : null,
            'rating_score' => $product->rating_score,
            'rating_count' => $product->rating_count,
            'status' => $product->status,
            'type' => $product->type,
        ];

        if (! empty($product->distance)) {
            $op['distance'] = $product->distance;
        }

        return $op;
    }

    public function includeAddress(Product $product)
    {
        return $this->item($product->address, new AddressFullTransformer());
    }

    public function includePrices(Product $product)
    {
        return $this->collection($product->prices, new PriceFullTransformer());
    }

    public function includeQuestions(Product $product)
    {
        return $this->collection($product->questions()->orderBy('created_at', 'desc')->get(), new QuestionFullTransformer());
    }
}
