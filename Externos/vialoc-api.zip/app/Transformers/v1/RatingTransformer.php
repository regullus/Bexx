<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Rating;

class RatingTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = ['product', 'user', 'user_rated'];

    public function transform(Rating $rating)
    {
        return [
            'subtype' => $rating->subtype,
            'score' => $rating->score,
            'comment' => $rating->comment,
            'status' => $rating->status,
            'status_formatted' => $rating->status_formatted,
            'created_at' => $rating->created_at->format('Y-m-d H:i:s'),
        ];
    }

    public function includeProduct(Rating $rating)
    {
        return $this->item($rating->ratingable, new ProductViewTransformer());
    }

    // Avaliador
    public function includeUser(Rating $rating)
    {
        return $this->item($rating->user, new UserSimpleTransformer());
    }

    // Avaliado
    public function includeUserRated(Rating $rating)
    {
        return $this->item($rating->ratingable, new UserSimpleTransformer());
    }
}
