<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\QuestionAnswer;

class QuestionFullTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'answers',
        'user',
        'product',
    ];

    public function transform(QuestionAnswer $question)
    {
        $op = [
            'id' => $question->id,
            'parent_id' => $question->parent_id,
            'content' => $question->content,
            'created_at' => $question->created_at->format('d/m/Y H:i'),
        ];

        if (($user = auth()->user()) && is_null($question->read_at)) {
            $question->load(['product']);
            if ($question->product->user_id == $user->id) { // se for questão, verifica se o produto pai é do usuário
                $op['is_unread'] = true;
            }
        }

        return $op;
    }

    public function includeAnswers(QuestionAnswer $question)
    {
        $answers = $question->answers();
        if ($answers->count()) {
            return $this->item($answers->first(), new AnswerFullTransformer());
        }
    }

    public function includeUser(QuestionAnswer $questionAnswer)
    {
        return $this->item($questionAnswer->user()->first(), new UserSimpleTransformer());
    }

    public function includeProduct(QuestionAnswer $questionAnswer)
    {
        return $this->item($questionAnswer->product()->first(), new ProductSummaryTransformer());
    }
}
