<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Profile;

class ProfileCompanyTransformer extends Fractal\TransformerAbstract
{
    public function transform(Profile $profile)
    {
        return [
            'cnpj' => $profile->cnpj,
            'company_name' => $profile->company_name,
            'trading_name' => $profile->trading_name,
        ];
    }
}
