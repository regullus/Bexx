<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\User;

class UserFullTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'address',
        'profile',
        'notifications',
        'profilePerson',
        'profileCompany',
    ];

    public function transform(User $user)
    {
        $avatar = $user->firstMedia('avatar');

        return [
            'id' => $user->id,
            'uid' => $user->uid,
            'avatar' => $avatar ? url($avatar->metadata['thumbnails']['default']['path']) . '?nocache=' . \Str::random(5) : null,
            'name' => $user->name,
            'last_name' => $user->last_name,
            'email' => $user->email,
            // 'type' => $user->type,
            'status' => $user->status,
            'is_complete' => $user->isComplete(),
            'email_confirmed' => $user->email_confirmed,
            'email_intended' => $user->email_intended,
            'rating_locator_score' => $user->rating_locator_score,
            'rating_locator_count' => $user->rating_locator_count,
            'rating_tenant_score' => $user->rating_tenant_score,
            'rating_tenant_count' => $user->rating_tenant_count,
            'receive_news' => $user->receive_news,
            'created_at' => $user->created_at->format('Y-m-d H:i:s'),
            'loggedin_at' => $user->loggedin_at ? $user->loggedin_at->timestamp : null,
        ];
    }

    public function includeAddress(User $user)
    {
        $user->load('address');
        if (empty($user->address)) {
            return $this->null();
        }

        return $this->item($user->address, new AddressFullTransformer());
    }

    public function includeProfile(User $user)
    {
        $user->load('profile');
        if (empty($user->profile)) {
            return $this->null();
        }

        return $this->item($user->profile, new ProfileTransformer());
    }

    public function includeNotifications(User $user)
    {
        $collection = $user->notifications()->whereNull('read_at')->orderBy('created_at', 'desc')->get();
        if ($collection->count() < config('c7.notifications_count')) {
            $collection = $user->notifications()
                ->orderBy('created_at', 'desc')
                ->limit(config('c7.notifications_count'))
                ->get();
        }

        return $this->collection($collection, new NotificationTransformer());
    }

    public function includeProfilePerson(User $user)
    {
        $user->load('profile');

        return $this->item($user->profile, new ProfilePersonTransformer());
    }

    public function includeProfileCompany(User $user)
    {
        $user->load('profile');

        return $this->item($user->profile, new ProfileCompanyTransformer());
    }
}
