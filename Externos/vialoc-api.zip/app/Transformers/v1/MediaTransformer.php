<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Media;

class MediaTransformer extends Fractal\TransformerAbstract
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Media $media)
    {
        return [
            'id' => $media->id,
            'aggregate_type' => $media->aggregate_type,
            'directory' => $media->directory,
            'disk' => $media->disk,
            'name' => $media->basename,
            'url' => config('filesystems.disks.'.$media->disk.'.url').'/'.$media->directory.'/'.$media->basename,
            'extension' => $media->extension,
            'filename' => $media->filename,
            'mime_type' => $media->mime_type,
            'size' => $media->size,
            'metadata' => $media->metadata,
            'tag' => ! empty($media->pivot) ? $media->pivot->tag : null,
        ];
    }
}
