<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Profile;

/**
 * User resources.
 */
class ProfilePersonTransformer extends Fractal\TransformerAbstract
{
    public function transform(Profile $profile)
    {
        return [
            'cpf' => $profile->cpf,
            'name' => $profile->name,
            'birthdate' => $profile->birthdate,
        ];
    }
}
