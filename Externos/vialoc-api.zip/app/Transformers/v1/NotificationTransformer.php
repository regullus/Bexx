<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Notification;

class NotificationTransformer extends Fractal\TransformerAbstract
{
    public function transform(Notification $notification)
    {
        $data = $notification['data'];
        $data['message'] = str_replace(['%user%', '%context%'], [$data['user']['short_name'], $data['product']['name']], config('c7.notifications.'.$data['tag']));
        $data['id'] = $notification['id'];
        $data['is_unread'] = is_null($notification['read_at']) ? 1 : 0;
        $data['created_at'] = $notification['created_at']->format('Y-m-d H:i:s');

        return $data;
    }
}
