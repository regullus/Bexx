<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Order;

class OrderSummaryTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'locator',
        'messages',
        'price',
        'product',
        'user',
    ];

    public function transform(Order $order)
    {
        return [
            'id' => $order->id,
            'price_id' => $order->price_id,
            'date_start' => $order->date_start->format('d/m/Y'),
            'date_end' => $order->date_end->format('d/m/Y'),
            'days_total' => $order->days_total,
            'order_date' => $order->created_at->format('d/m/Y'),
            'price_total' => $order->price_total,
            'price_total_formatted' => $order->price_total_formatted,
            'status' => $order->status,
            'status_formatted' => $order->status_formatted,
        ];
    }

    public function includeLocator(Order $order)
    {
        if (in_array($order->status, ['pending-takeout', 'active', 'finished'])) {
            return $this->item($order->product->user, new UserExtraTransformer());
        }

        return $this->item($order->product->user, new UserSimpleTransformer());
    }

    public function includeMessages(Order $order)
    {
        return $this->collection($order->messages()->get(), new OrderMessageFullTransformer());
    }

    public function includePrice(Order $order)
    {
        return $this->item($order->price, new PriceFullTransformer());
    }

    public function includeProduct(Order $order)
    {
        return $this->item($order->product, new ProductSummaryTransformer());
    }

    public function includeUser(Order $order)
    {
        if ($order->isStatus(['pending-confirmation', 'pending-payment', 'refused', 'canceled'])) {
            return $this->item($order->user, new UserSimpleTransformer());
        }

        return $this->item($order->user, new UserDetailedTransformer());
    }
}
