<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\QuestionAnswer;

class AnswerFullTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'question',
        'user',
    ];

    public function transform(QuestionAnswer $question)
    {
        $op = [
            'id' => $question->id,
            'content' => $question->content,
            'created_at' => $question->created_at->format('d/m/Y H:i'),
        ];

        if (($user = auth()->user()) && is_null($question->read_at)) {
            $question->load(['question']);
            if (! empty($question->question) && $question->question->user_id == $user->id) { // caso contrarío verifica se a pergunta pai é do usuário
                $op['is_unread'] = true;
            }
        }

        return $op;
    }

    public function includeUser(QuestionAnswer $questionAnswer)
    {
        return $this->item($questionAnswer->user()->first(), new UserSimpleTransformer());
    }

    public function includeQuestion(QuestionAnswer $answer)
    {
        $question = $answer->answers();

        return $this->item($question->first(), new QuestionFullTransformer());
    }
}
