<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\User;

class UserSimpleTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'products',
    ];

    public function transform(User $user)
    {
        $avatar = $user->firstMedia('avatar');

        $profile_type = null;
        if ($user->profile->cpf) {
            $profile_type = 'person';
        }
        if ($user->profile->cnpj) {
            $profile_type = 'company';
        }

        return [
            'uid' => $user->uid,
            'avatar' => $avatar ? url($avatar->metadata['thumbnails']['default']['path']) : null,
            'slug' => $user->slug,
            'type' => $profile_type,
            'short_name' => $user->short_name,
            'short_trading_name' => $user->profile->short_trading_name,
            'rating_locator_score' => $user->rating_locator_score,
            'rating_locator_count' => $user->rating_locator_count,
            'rating_tenant_score' => $user->rating_tenant_score,
            'rating_tenant_count' => $user->rating_tenant_count,
        ];
    }

    public function includeProducts(User $user)
    {
        return $this->collection($user->products(), new ProductSummaryTransformer());
    }
}
