<?php

namespace App\Transformers\v1;


use League\Fractal;

use App\Models\Profile;

class ProfileTransformer extends Fractal\TransformerAbstract
{
    public function transform(Profile $profile)
    {
        $profile_type = null;
        if ($profile->cpf) {
            $profile_type = 'person';
        }
        if ($profile->cnpj) {
            $profile_type = 'company';
        }

        return [
            'type' => $profile_type,
            'cpf' => $profile->cpf_formatted,
            'birthdate' => $profile->birthdate ? $profile->birthdate->format('d/m/Y') : null,
            'cnpj' => $profile->cnpj_formatted,
            'company_name' => $profile->company_name,
            'trading_name' => $profile->trading_name,
            'state_tax_number' => $profile->state_tax_number,
            'phones' => $profile->phones,
            'website' => $profile->website,
        ];
    }
}
