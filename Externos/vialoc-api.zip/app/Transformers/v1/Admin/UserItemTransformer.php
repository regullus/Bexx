<?php

namespace App\Transformers\v1\Admin;

use League\Fractal;

use App\Models\User;

class UserItemTransformer extends Fractal\TransformerAbstract
{
    public function transform(User $user)
    {
        $avatar = $user->firstMedia('avatar');

        $profile_type = null;
        if ($user->profile->cpf) {
            $profile_type = 'person';
        }
        if ($user->profile->cnpj) {
            $profile_type = 'company';
        }

        return [
            'id' => $user->id,
            'uid' => $user->uid,
            'avatar' => $avatar ? url($avatar->metadata['thumbnails']['default']['path']) : null,
            'slug' => $user->slug,
            'type' => $profile_type,
            'full_name' => $user->full_name,
            'email' => $user->email,
            'trading_name' => $user->profile->trading_name,
            'status' => $user->status,
            'status_formatted' => $user->status_formatted,
        ];
    }
}
