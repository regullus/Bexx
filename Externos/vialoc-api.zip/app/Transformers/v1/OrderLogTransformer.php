<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\OrderLog;

class OrderLogTransformer extends Fractal\TransformerAbstract
{
    public function transform(OrderLog $orderLog)
    {
        return [
            'status' => $orderLog->status,
            'status_formatted' => $orderLog->order->list_status[$orderLog->status],
            'created_at' => $orderLog->created_at->format('d/m/Y H:i'),
        ];
    }
}
