<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Price;

class PriceFullTransformer extends Fractal\TransformerAbstract
{
    public function transform(Price $price)
    {
        return [
            'id'            => $price->id,
            'more_than'     => $price->more_than,
            'price_per_day' => $price->price_per_day,
            'price_per_day_formatted' => $price->price_per_day_formatted,
            'price_period' => $price->price_period,
            'price_period_formatted' => $price->price_period_formatted,
        ];
    }
}
