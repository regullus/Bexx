<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Product;

class ProductViewTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'address',
        'featured_image',
        'images',
        'locator',
        'prices',
        'questions',
        'ratings',
        'view_images',
    ];

    public function transform(Product $product)
    {
        $product->load(['price_monthly']);
        $featured_image = $product->firstMedia('product-featured-image');
        $is_favorite = (bool) (auth()->check() ? $product->favorites()->where('user_id', auth()->user()->id)->count() : false);

        return [
            'uid' => $product->uid,
            'name' => $product->name,
            'content' => autop($product->content),
            'link_video' => $product->link_video,
            'city_id' => $product->address->city_id,
            'city' => $product->address->city->name,
            'state_code' => $product->address->city->state_code,
            'type' => $product->type,
            'type_formatted' => $product->type_formatted,
            'brand' => $product->brand->name,
            'height' => $product->height,
            'width' => $product->width,
            'length' => $product->length,
            'weight' => $product->weight,
            'cubing' => $product->cubing,
            'axes' => $product->axes,
            'licensing' => $product->licensing,
            'year' => $product->year,
            'model' => $product->model,
            'floor_formatted' => $product->floor_formatted,
            'suspension_formatted' => $product->suspension_formatted,
            'status' => $product->status,
            'rented_intervals' => $product->getRentedIntervals(),
            'price_from' => $product->price_monthly ? $product->price_monthly->price_period : 0,
            'price_from_formatted' => ! empty($product->price_monthly) ? floatFormatted($product->price_monthly->price_period, ['remove_zero_cents' => true]) : 0,
            'featured_image_path' => $featured_image ? $featured_image->metadata['thumbnails']['retangle-small']['path'] : null,
            'rating_score' => $product->rating_score,
            'rating_count' => $product->rating_count,
            'is_favorite' => $is_favorite,
        ];
    }

    public function includeAddress(Product $product)
    {
        return $this->item($product->address, new AddressFullTransformer());
    }

    public function includeFeaturedImage(Product $product)
    {
        $featured_image = $product->firstMedia('product-featured-image');

        if (! $featured_image) {
            return;
        }

        return $this->item($featured_image, new MediaTransformer());
    }

    public function includeImages(Product $product)
    {
        return $this->collection($product->getMedia(['product-image']), new MediaTransformer());
    }

    public function includeViewImages(Product $product)
    {
        return $this->collection($product->getMedia(['left', 'right', 'front', 'back', 'interior', 'axes']), new MediaTransformer());
    }

    public function includeLocator(Product $product)
    {
        return $this->item($product->user, new UserSimpleTransformer());
    }

    public function includePrices(Product $product)
    {
        return $this->collection($product->prices()->orderBy('prices.more_than', 'asc')->get(), new PriceFullTransformer());
    }

    public function includeQuestions(Product $product)
    {
        return $this->collection($product->questions()->orderBy('created_at', 'desc')->get(), new QuestionFullTransformer());
    }

    public function includeRatings(Product $product)
    {
        return $this->collection($product->ratings()->where('status', 'approved')->orderBy('created_at', 'desc')->get(), new RatingTransformer());
    }
}
