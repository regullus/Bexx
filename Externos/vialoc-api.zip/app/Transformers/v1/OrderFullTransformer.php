<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Order;

class OrderFullTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = ['address', 'locator', 'logs', 'messages', 'payment', 'payment_logs', 'price', 'product', 'ratings', 'user'];

    public function transform(Order $order)
    {
        $op = [
            'id' => $order->id,
            'user_id' => $order->user_id,
            // 'json_user' => $order->json_user,
            'product_id' => $order->product_id,
            'json_product' => $order->json_product_view,
            'price_id' => $order->price_id,
            'json_price' => $order->json_price,
            'json_prices_base' => $order->json_prices_base,
            'date_start' => $order->date_start->format('d/m/Y'),
            'date_end' => $order->date_end->format('d/m/Y'),
            'days_total' => $order->days_total,
            'order_date' => $order->created_at->format('d/m/Y'),
            'price_total' => $order->price_total,
            'price_total_formatted' => $order->price_total_formatted,
            'status' => $order->status,
            'status_formatted' => $order->status_formatted,
        ];

        if ($order->isStatus('pending-takeout')) {
            $op['locator_takeout_informed'] = ! empty($order->metadata['locator_takeout_informed']) && $order->metadata['locator_takeout_informed'];
        }

        if ($order->isStatus('active')) {
            $op['tenant_devolution_informed'] = ! empty($order->metadata['tenant_devolution_informed']) && $order->metadata['tenant_devolution_informed'];
        }

        return $op;
    }

    public function includeAddress(Order $order)
    {
        return $this->item($order->address, new AddressFullTransformer());
    }

    public function includeLocator(Order $order)
    {
        if ($order->isStatus(['pending-takeout', 'active', 'finished'])) {
            return $this->item($order->product->user, new UserExtraTransformer());
        }

        return $this->item($order->product->user, new UserSimpleTransformer());
    }

    public function includeLogs(Order $order)
    {
        return $this->collection($order->logs()->orderBy('created_at', 'asc')->get(), new OrderLogTransformer());
    }

    public function includeMessages(Order $order)
    {
        return $this->collection($order->messages()->get(), new OrderMessageFullTransformer());
    }

    public function includePayment(Order $order)
    {
        if (! $payment = $order->payment) {
            return;
        }

        return $this->item($payment, new PaymentTransformer());
    }

    public function includePaymentLogs(Order $order)
    {
        return $this->collection($order->payments, new PaymentTransformer());
    }

    public function includePrice(Order $order)
    {
        return $this->item($order->price, new PriceFullTransformer());
    }

    public function includeProduct(Order $order)
    {
        if ($order->isStatus(['pending-takeout', 'active', 'finished'])) {
            return $this->item($order->product, new ProductExtraTransformer());
        }

        return $this->item($order->product, new ProductViewTransformer());
    }

    public function includeRatings(Order $order)
    {
        return $this->collection($order->ratings, new RatingTransformer());
    }

    public function includeUser(Order $order)
    {
        if ($order->isStatus(['pending-confirmation', 'pending-payment', 'refused', 'canceled'])) {
            return $this->item($order->user, new UserSimpleTransformer());
        }

        return $this->item($order->user, new UserDetailedTransformer());
    }
}
