<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\State;

class StateTransformer extends Fractal\TransformerAbstract
{
    public function transform(State $state)
    {
        return [
            'code' => $state->code,
            'name' => $state->name,
        ];
    }
}
