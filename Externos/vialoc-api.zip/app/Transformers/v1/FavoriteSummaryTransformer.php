<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Favorite;

class FavoriteSummaryTransformer extends Fractal\TransformerAbstract
{
    public function transform(Favorite $favorite)
    {
        $product = $favorite->product;
        $price_from = $product->prices()->orderBy('price_per_day', 'asc')->first();
        $featured_image = $product->firstMedia('product-featured-image');

        $op = [
            'uid' => $product->uid,
            'slug' => $product->slug,
            'name' => $product->name,
            'type' => $product->type,
            'type_formatted' => $product->type_formatted,
            'brand_id' => $product->brand_id,
            'brand' => $product->brand->name,
            'year' => $product->year,
            'city_id' => $product->address->city_id,
            'city' => $product->address->city->name,
            'state_code' => $product->address->city->state_code,
            'price_from' => $price_from ? ($price_from->price_per_day * 30) : null,
            'featured_image_path' => $featured_image ? $featured_image->metadata['thumbnails']['retangle-small']['path'] : null,
            'status' => $product->status,
            'type' => $product->type,
        ];

        if (! empty($product->distance)) {
            $op['distance'] = $product->distance;
        }

        return $op;
    }
}
