<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Address;

class AddressFullTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'city',
    ];

    public function transform(Address $address)
    {
        $op = [
            'id' => $address->id,
            'label' => $address->label,
            'zipcode' => $address->zipcode_formatted,
            'address' => $address->address,
            'address_number' => $address->address_number,
            'address_complement' => $address->address_complement,
            'district' => $address->district,
            'city_id' => $address->city_id,
            'city' => $address->city ? $address->city->name : '',
            'state_code' => $address->city ? $address->city->state_code : '',
            'notes' => $address->notes,
            'latitude' => $address->latitude,
            'longitude' => $address->longitude,
            'is_main' => $address->is_main,
        ];

        if (! empty($address->distance)) {
            $op['distance'] = $address->distance;
        }

        return $op;
    }

    public function includeCity(Address $address)
    {
        return $this->item($address->city, new CityFullTransformer());
    }
}
