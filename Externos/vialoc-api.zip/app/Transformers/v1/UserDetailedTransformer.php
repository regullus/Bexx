<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\User;

class UserDetailedTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'products',
    ];

    public function transform(User $user)
    {
        $avatar = $user->firstMedia('avatar');

        $profile_type = null;
        if ($user->profile->cpf) {
            $profile_type = 'person';
        }
        if ($user->profile->cnpj) {
            $profile_type = 'company';
        }

        return [
            'uid' => $user->uid,
            'avatar' => $avatar ? url($avatar->metadata['thumbnails']['default']['path']) : null,
            'slug' => $user->slug,
            'type' => $profile_type,
            'name' => $user->name,
            'full_name' => $user->full_name,
            'trading_name' => $user->profile->trading_name,
            'phones' => array_values($user->profile->phones),
        ];
    }

    public function includeProducts(User $user)
    {
        return $this->collection($user->products(), new ProductSummaryTransformer());
    }
}
