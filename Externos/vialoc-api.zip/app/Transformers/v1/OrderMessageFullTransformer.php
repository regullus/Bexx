<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\OrderMessage;

class OrderMessageFullTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'user',
    ];

    public function transform(OrderMessage $orderMessage)
    {
        return [
            'id' => $orderMessage->id,
            'user_id' => $orderMessage->user_id,
            'user_name' => $orderMessage->user->name,
            'content' => $orderMessage->content,
            'is_read' => (! empty($orderMessage->read_at)),
            'created_at' => $orderMessage->created_at->format('Y-m-d H:i:s'),
        ];
    }

    public function includeUser(OrderMessage $orderMessage)
    {
        return $this->item($orderMessage->user()->first(), new UserSimpleTransformer());
    }
}
