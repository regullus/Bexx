<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\FaqRating;

class FaqRatingFullTransformer extends Fractal\TransformerAbstract
{
    public function transform(FaqRating $faqRating)
    {
        return [
            'faq_id' => $faqRating->faq_id,
            'rating' => $faqRating->rating,
        ];
    }
}
