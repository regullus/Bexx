<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Faq;

class FaqFullTransformer extends Fractal\TransformerAbstract
{
    protected $availableIncludes = [
        'rating',
    ];

    public function transform(Faq $faq)
    {
        return [
            'id'        => $faq->id,
            'question'  => $faq->question,
            'answer'    => $faq->answer,
            'target'    => $faq->target,
        ];
    }

    public function includeRating(Faq $faq)
    {
        if (! \Auth::check()) {
            return;
        }

        $row = $faq->faq_ratings()->where('user_id', auth()->user()->id)->first();
        if (! $row) {
            return;
        }

        return $this->item($row, new FaqRatingFullTransformer());
    }
}
