<?php

namespace App\Transformers\v1;

use League\Fractal;

use App\Models\Page;

class PageFullTransformer extends Fractal\TransformerAbstract
{
    public function transform(Page $page)
    {
        return [
            'id' => $page->id,
            'title' => $page->title,
            'slug' => $page->slug,
            'except' => $page->except,
            'content' => $page->content,
            'type' => $page->type,
            'status' => $page->status,
        ];
    }
}
