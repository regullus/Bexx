<?php

namespace App\Facades;

use Illuminate\Support\Facades\Facade;

class C7Upload extends Facade
{
    protected static function getFacadeAccessor()
    {
        return 'C7Upload';
    }
}
