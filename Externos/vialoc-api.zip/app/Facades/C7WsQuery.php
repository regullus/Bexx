<?php

namespace App\Facades;

use Illuminate\Support\Facades\Facade;

class C7WsQuery extends Facade
{
    protected static function getFacadeAccessor()
    {
        return 'C7WsQuery';
    }
}
