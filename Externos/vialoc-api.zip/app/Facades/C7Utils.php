<?php

namespace App\Facades;

use Illuminate\Support\Facades\Facade;

class C7Utils extends Facade
{
    protected static function getFacadeAccessor()
    {
        return 'C7Utils';
    }
}
