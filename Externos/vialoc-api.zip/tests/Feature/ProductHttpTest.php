<?php

namespace Tests\Feature;

/*
 * Parent
 */
use Tests\TestCase;
/*
 * User resources.
 */
use App\Models\Product;

class ProductHttpTest extends TestCase
{
    private $dataUser = [
        'email' => 'alexandremv@gmail.com',
        'password' => 'alexandre123', ];

    private $data = [
        'id' => '7',
        'uid' => 'd5addba7-c066-444b-b1c1-a67d62cb2788',
        'external_id' => '12',
        'name'=> 'Carreta fazendinha profissional pequena',
        'content' => 'Descrição completa da carreta.',
        'city_id' => '1',
        'user_id' => '1',
        'type' => 'Carreta baú.',
        'brand_id' => '1',
        'height' => '4.00',
        'width' => '2.00',
        'length' => '10.00',
        'weight' => '1000.00',
        'cubing' => '1000.00',
        'axes' => '3',
        'licensing' => '06/2018',
        'year' => '2017',
        'model' => '2018',
        'chassis' => 'X5Z7895D78A965',
        'renavam' => '001487515985',
        'antt' => '7777777777',
        'floor' => 'madeirite',
        'suspension' => 'pneumatica',
    ];

    private function deleteProduct()
    {
        $product = new Product();
        $product = $product->find($this->data['id']);
        if ($product) {
            $product->forceDelete(); // forceDelete() pois deve deletar fisicamente e não usando soft delete.
        }
    }

    private function token()
    {
        $credentials['email'] = $this->dataUser['email'];
        $credentials['password'] = $this->dataUser['password'];

        return auth()->attempt($credentials);
    }

    public function testCreate()
    {
        $this->deleteProduct();
        $response = $this->withHeaders(['Authorization' => 'Bearer '.$this->token()])
            ->json('POST', '/api/v1/product/create', $this->data);

        $response->assertStatus(201);
    }

    /*
     * Tenta criar um produto com o uid repetido.
     */
/*
    public function testCreateFieldsExists() {
        $this->deleteProduct();
        $response = $this->json('POST', '/api/common/v1/product/create', $this->data); # envio o $this->data cheio mas o end-point vai aproveitar apenas os dados úteis pra ele.
        $response->assertStatus(422);

        $content = json_decode($response->getContent());
        $this->assertTrue(property_exists($content->errors, 'email')); # caso $content->errors possua a property 'email', significa que o endpoint retornou um erro referente ao email, provavelmente email já existente, validando o teste.
        $this->assertTrue(property_exists($content->errors, 'cpf')); # caso $content->errors possua a property 'cpf', significa que o endpoint retornou um erro referente ao cpf, provavelmente cpf já existente, validando o teste.
    }
*/

/*
    public function testUpdate() {
        $this->deleteProduct();

        $product = new Product();
        $product->create($this->data);

        $response = $this->withHeaders(['Authorization' => 'Bearer ' . $this->token()])
            ->json('PUT', '/api/v1/product/update', $this->data);

        $response->assertStatus(200);
    }
*/
/*
    public function testDisableProduct() {
        $this->deleteProduct();

        $product = new Product();
        $product->create($this->data);
echo "1";
die;

        $response = $this->withHeaders(['Authorization' => 'Bearer ' . $this->token()])
            ->json('PUT', '/api/v1/product/disable', $this->data);
print_r($response->getContent());
die;

        $response->assertStatus(200);
    }
*/
}
