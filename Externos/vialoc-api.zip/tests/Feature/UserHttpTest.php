<?php

namespace Tests\Feature;

/*
 * Parent
 */
use Tests\TestCase;
/*
 * User resources.
 */
use App\Models\User;

class UserHttpTest extends TestCase
{
    /**
     * Dados base para todos os testes que serão realizados, alguns utilizando os dados na íntegra, outros usando
     * partes dos dados.
     */
    private $data = [
        'id' => 1,
        'email' => 'alexandremv@gmail.com',
        'password' => 'alexandre123',
        'password_confirmation' => 'alexandre123',
        'cpf' => '30487276809',
        'name' => 'Alexandre Vargas',
        'birthdate' => '1900-01-01',
        'cnpj' => '60583853000125',
        'company_name' => 'Industria Mecânica Faia Ltda',
        'trading_name' => 'Faia', ];

    private function deleteUser()
    {
        $user = new User();
        $user = $user->find($this->data['id']);
        if ($user) {
            if ($profile = $user->profile) {
                $profile->forceDelete(); // forceDelete() pois deve deletar fisicamente e não usando soft delete.
            }
            if ($products = $user->products()->get()) {
                foreach ($products as $product) {
                    $product->forceDelete();
                }
            }
            $user->forceDelete(); // forceDelete() pois deve deletar fisicamente e não usando soft delete.
        }
    }

    private function token()
    {
        $credentials['email'] = $this->data['email'];
        $credentials['password'] = $this->data['password'];

        return auth()->attempt($credentials);
    }

    public function testRegisterPersonSuccess()
    {
        $this->deleteUser();
        $response = $this->json('POST', '/api/common/v1/users/create-person', $this->data); // envio o $this->data cheio mas o end-point vai aproveitar apenas os dados úteis pra ele.
        $response->assertStatus(201);
    }

    public function testRegisterPersonEmailCpfExists()
    {
        $response = $this->json('POST', '/api/common/v1/users/create-person', $this->data); // envio o $this->data cheio mas o end-point vai aproveitar apenas os dados úteis pra ele.
        $response->assertStatus(422);

        $content = json_decode($response->getContent());
        $this->assertTrue(property_exists($content->errors, 'email')); // caso $content->errors possua a property 'email', significa que o endpoint retornou um erro referente ao email, provavelmente email já existente, validando o teste.
        $this->assertTrue(property_exists($content->errors, 'cpf')); // caso $content->errors possua a property 'cpf', significa que o endpoint retornou um erro referente ao cpf, provavelmente cpf já existente, validando o teste.
    }

    public function testRegisterPersonFieldsEmpty()
    {
        $data = ['email' => null,
            'password' => null,
            'cpf' => null,
            'name' => null, ];
        $response = $this->json('POST', '/api/common/v1/users/create-person', $data); // envio o $this->data cheio mas o end-point vai aproveitar apenas os dados úteis pra ele.
        $response->assertStatus(422);

        $content = json_decode($response->getContent());
        $this->assertTrue(property_exists($content->errors, 'email')); // caso $content->errors possua a property 'email', significa que o endpoint retornou um erro referente ao email, provavelmente email vazio não permitido, validando o teste.
        $this->assertTrue(property_exists($content->errors, 'password')); // caso $content->errors possua a property 'password', significa que o endpoint retornou um erro referente ao password, provavelmente password vazio não permitido, validando o teste.
        $this->assertTrue(property_exists($content->errors, 'cpf')); // caso $content->errors possua a property 'cpf', significa que o endpoint retornou um erro referente ao cpf, provavelmente cpf vazio não permitido, validando o teste.
        $this->assertTrue(property_exists($content->errors, 'name')); // caso $content->errors possua a property 'name', significa que o endpoint retornou um erro referente ao name, provavelmente name vazio não permitido, validando o teste.
    }

    public function testRegisterPersonEmailInvalid()
    {
        $this->data['email'] = 'alexandremvgmail.com'; // Email sem @
        $response = $this->json('POST', '/api/common/v1/users/create-person', $this->data); // envio o $this->data cheio mas o end-point vai aproveitar apenas os dados úteis pra ele.
        $response->assertStatus(422);

        $content = json_decode($response->getContent());
        $this->assertTrue(property_exists($content->errors, 'email')); // caso $content->errors possua a property 'email', significa que o endpoint retornou um erro referente ao email, provavelmente email inválido, validando o teste.
    }

    public function testRegisterCompanySuccess()
    {
        $this->deleteUser();
        $response = $this->json('POST', '/api/common/v1/users/create-company', $this->data); // envio o $this->data cheio mas o end-point vai aproveitar apenas os dados úteis pra ele.
        $response->assertStatus(201);
    }

    public function testGetMe()
    {
        $response = $this->withHeaders(['Authorization' => 'Bearer '.$this->token()])
            ->json('GET', '/api/common/v1/users/me');

        $response->assertStatus(200);
    }

    public function testPutEmail()
    {
        $data['email'] = $this->data['email'];
        $data['email_confirmation'] = $this->data['email'];
        $response = $this->withHeaders(['Authorization' => 'Bearer '.$this->token()])
            ->json('PUT', '/api/common/v1/users/update-email', $data);

        $response->assertStatus(200);
    }

    /*
     * Apesar de ser uma dependência do primeiro metodo dessa classe, o phpunit segue a ordem dos métodos acima das
     * dependências declaradas. Em outras palavras, escrevi o metodo abaixo como dependente do primeiro
     * (testRegisterPersonSuccess) porém, o phpunit executou na ordem:
     * testRegisterPersonSuccess
     * testRegisterPersonExisting
     * testDeletePerson

     * @depends testRegisterPersonSuccess
     public function testDeletePerson($id) {
         print $id;
         die;

         $response = $this->json('POST', '/api/common/v1/users/create-person', $this->data);

         $response->assertStatus(422);
     }

     *
     */
}
