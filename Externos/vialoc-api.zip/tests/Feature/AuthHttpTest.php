<?php

namespace Tests\Feature;

/*
 * Parent
 */
use Tests\TestCase;
/*
 * User resources.
 */
use App\Models\User;

class AuthHttpTest extends TestCase
{
    private $data = [
        'id' => 1,
        'email' => 'alexandremv@gmail.com',
        'password' => 'alexandre123',
        'password_confirmation' => 'alexandre123',
        'cpf' => '30487276809',
        'name' => 'Alexandre Vargas',
        'birthdate' => '1900-01-01',
        'cnpj' => '60583853000125',
        'company_name' => 'Industria Mecânica Faia Ltda',
        'trading_name' => 'Faia', ];

    private function deleteUser()
    {
        $user = new User();
        $user = $user->find($this->data['id']);
        if ($user) {
            if ($profile = $user->profile) {
                $profile->forceDelete();
            }
            if ($products = $user->products()->get()) {
                foreach ($products as $product) {
                    $product->forceDelete();
                }
            }
            $user->forceDelete();
        }
    }

    private function token()
    {
        $credentials['email'] = $this->data['email'];
        $credentials['password'] = $this->data['password'];

        return auth()->attempt($credentials);
    }

    public function testLogin()
    {
        // Deleta usuário
        $this->deleteUser();

        // Cria usuário
        // $credentials['email'] = $this->data['email'];
        // $credentials['password'] = $this->data['password'];
        $userModel = new User();
        $userModel->create($this->data); // para inserir o usuário eu não preciso da confirmação de password. Esta confirmação serve só pra validação.

        // Loga usuário criado.
        $response = $this->json('POST', '/api/common/v1/auth/login', $this->data); // envio o $this->data cheio mas o end-point vai aproveitar apenas os dados úteis pra ele.

        // Testo login.
        $response->assertStatus(200); // Valida HTTP status code.
        $response->assertCookie('token');
        $response->assertCookieNotExpired('token');

        $content = json_decode($response->getContent());
        $this->assertTrue(property_exists($content, 'access_token'));
        if (property_exists($content, 'access_token')) { // caso $content->errors possua a property 'email', significa que o endpoint retornou um erro referente ao email, provavelmente email já existente, validando o teste.
            $this->assertNotEmpty($content->access_token);
        }
    }

    public function testLogout()
    {
        // Deleta usuário
        $this->deleteUser();

        // Cria usuário
        // $credentials['email'] = $this->data['email'];
        // $credentials['password'] = $this->data['password'];
        $userModel = new User();
        $userModel->create($this->data); // para inserir o usuário eu não preciso da confirmação de password. Esta confirmação serve só pra validação.

        // Loga usuário criado.
        $response = $this->json('POST', '/api/common/v1/auth/login', $this->data); // envio o $this->data cheio mas o end-point vai aproveitar apenas os dados úteis pra ele.

        // Loga usuário criado.
        $response = $this->json('POST', '/api/common/v1/auth/logout');
        $response->assertCookieExpired('token');
    }

    public function testRefresh()
    {
        // Adicionando comentário.
        $this->assertTrue(true);
    }
}
