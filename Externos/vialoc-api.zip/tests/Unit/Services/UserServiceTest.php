<?php

namespace Tests\Unit\Services;

/*
 * Parent
 */
use Tests\TestCase;
/*
 * Vendor packages
 */
use App\Models\User;
/*
 * User resources.
 */
use App\Services\v1\Common\UserService;
use Illuminate\Auth\AuthenticationException;
use App\Http\Requests\v1\Common\Users\ChangeEmailRequest;
use App\Http\Requests\v1\Common\Users\UpdateProfileRequest;
use App\Http\Requests\v1\Common\Users\ChangePasswordRequest;
use App\Http\Requests\v1\Common\Users\RegisterCompanyRequest;
use App\Http\Requests\v1\Common\Users\RegisterComplementationDataRequest;

class UserServiceTest extends TestCase
{
    private $data = [
        'id' => 1,
        'email' => 'alexandremv@gmail.com',
        'password' => 'alexandre123',
        'password_confirmation' => 'alexandre123',
        'cpf' => '30487276809',
        'name' => 'Alexandre Vargas',
        'birthdate' => '1900-01-01',
        'cnpj' => '60583853000125',
        'company_name' => 'Industria Mecânica Faia Ltda',
        'trading_name' => 'Faia', ];

    private function deleteUser()
    {
        $user = new User();
        $user = $user->find($this->data['id']);
        if ($user) {
            if ($profile = $user->profile) {
                $profile->forceDelete();
            }
            if ($products = $user->products()->get()) {
                foreach ($products as $product) {
                    $product->forceDelete();
                }
            }
            $user->forceDelete();
        }
    }

    private function token()
    {
        $credentials['email'] = $this->data['email'];
        $credentials['password'] = $this->data['password'];

        return auth()->attempt($credentials);
    }

    public function testRegisterPerson()
    {
        $this->deleteUser();

        $request = new RegisterComplementationDataRequest();
        $request->replace($this->data);

        $userService = new UserService();
        $user = $userService->registerPerson($request);

        $this->assertInstanceOf(User::class, $user);
    }

    public function testRegisterCompany()
    {
        $this->deleteUser();

        $request = new RegisterCompanyRequest();
        $request->replace($this->data);

        $userService = new UserService();
        $user = $userService->registerCompany($request);

        $this->assertInstanceOf(User::class, $user);
    }

    public function testChangeEmail()
    {
        $request = new ChangeEmailRequest();
        $data['email'] = 'alexandremv@gmail.com';
        $request->replace($data);

        $this->token();

        $userService = new UserService();
        $user = $userService->changeEmail($request);
        $this->assertInstanceOf(User::class, $user);
    }

    public function testChangePassword()
    {
        $this->token();

        $request = new ChangePasswordRequest();
        $data['password_current'] = $this->data['password'];
        $data['password'] = 'alexandre123';
        $request->merge($data);

        $userService = new UserService();
        $user = $userService->changePassword($request);
        $this->assertInstanceOf(User::class, $user);
    }

    public function testChangePasswordException()
    {
        $this->token();

        $request = new ChangePasswordRequest();
        $data['password_current'] = 'senhaincorreta';
        $data['password'] = 'alexandre123';
        $request->merge($data);

        $userService = new UserService();
        $this->expectException(AuthenticationException::class); // declaro primeiro a exceção que eu espero e logo abaixo chamo o metodo que causa a exception.
        $userService->changePassword($request);
    }

    public function testUpdateProfile()
    {
        $this->token();

        $request = new UpdateProfileRequest();
        $request->merge($this->data);

        $userService = new UserService();
        $user = $userService->updateProfile($request);
        $this->assertInstanceOf(User::class, $user);
    }
}
