<?php

namespace Tests\Unit\Models;

/*
 * Parent
 */
use Tests\TestCase;
/*
 * User resources.
 */
use App\Models\User;

class UserModelTest extends TestCase
{
    /**
     * Não vou desenvolver testes unitários para os metodos de relacionamento declarados abaixo pois eu não possuo os
     * registros desses relacionamentos cadastrados no banco de dados. Também não vou implementar o cadastro desses
     * registros em cada model em função dos testes pois alguns do endpoints possuem uma regra muito profunda (orders
     * por exemplo). Sendo assim, a princípio estes metodos ficarão sem testes. Vou desenvolver os testes conforme cada
     * create() for implementado (o desafio é lembrar).
     */
    private $data = [
        'id' => 1,
        'email' => 'alexandremv@gmail.com',
        'password' => 'alexandre123',
        'password_confirmation' => 'alexandre123',
        'cpf' => '30487276809',
        'name' => 'Alexandre Vargas',
        'birthdate' => '1900-01-01',
        'cnpj' => '60583853000125',
        'company_name' => 'Industria Mecânica Faia Ltda',
        'trading_name' => 'Faia', ];

    private function deleteUser()
    {
        $user = new User();
        $user = $user->find($this->data['id']);
        if ($user) {
            if ($profile = $user->profile) {
                $profile->forceDelete();
            }
            if ($products = $user->products()->get()) {
                foreach ($products as $product) {
                    $product->forceDelete();
                }
            }
            $user->forceDelete();
        }
    }

    public function testCreateUser()
    {
        // Deleta usuário
        $this->deleteUser();

        // Cria usuário
        // $credentials['email'] = $this->data['email'];
        // $credentials['password'] = $this->data['password'];
        $userModel = new User();
        $user = $userModel->create($this->data); // para inserir o usuário eu não preciso da confirmação de password. Esta confirmação serve só pra validação.

        // Testa criação de usuário.
        $this->assertInstanceOf(User::class, $user);
    }
}
