import documentImageMixin from './documentImage'
import errorsMixin from './errors'
import faqMixin from './faq'
import favoritesMixin from './favorites'
import formSearchMixin from './formSearch'
import hashScrollMixin from './hashScroll'
import inputDateMixin from './inputDate'
import socialLoginMixin from './socialLogin'

export {
    documentImageMixin,
    errorsMixin,
    faqMixin,
    favoritesMixin,
    formSearchMixin,
    hashScrollMixin,
    inputDateMixin,
    socialLoginMixin,
}