import Vue from 'vue'
import _ from 'lodash'

export default {
  methods: {
    favoriteDelete (product) {
      console.log('favorite delete triggered', product)
      let index = _.findIndex(this.products, p => p.uid === product.uid)
      Vue.delete(this.products, index)
    }
  }
}