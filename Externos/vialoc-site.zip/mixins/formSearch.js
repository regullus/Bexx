import { mapGetters } from 'vuex'
import _ from 'lodash'

export default {
  data () {
    return {
      // locationLabel: '',
      // getLocationTimeout: null,
      locationsOptions: [],
      form: null,
    }
  },

  computed: {
    ...mapGetters({
      filterBaseData: 'base/filterBaseData',
      searchFilters: 'base/searchFilters',
    }),

    // form: {
    //   get: function () { return _.cloneDeep(this.$store.getters['base/searchFilters']) },
    //   set: function (value) { this.$store.commit('base/setSearchFilters', value) }
    // },

    // types () {
    //   return  { ...{ all: 'Todos os tipos' }, ...this.filterBaseData.types_list }
    // },

    locationLabel: {
      get: function () { return this.$store.getters['base/locationLabel'] },
      set: function (value) { this.$store.commit('base/setLocationLabel', value) }
    },
  },

  created () {
    // get only the fields of the current search form
    let searchFilters = _.cloneDeep(this.searchFilters)
    this.form = _.pickBy(searchFilters, (v, k) => {
      return ['product_type', 'order_date_start', 'order_date_end', ].indexOf(k) > -1
    })

    this.types = { ...{ all: 'Todos os tipos' }, ...this.filterBaseData.types_list }
  },

  methods: {
    selectLocation (place) {
      let location = {
        address_radius: {
          latitude: place.geometry.location.lat(),
          longitude: place.geometry.location.lng(),
        }
      }
      this.locationLabel = place.formatted_address
      this.form = { ...this.form, ...location, product_order_by: 'distance' }
    },

    setSearchFilters () {
      this.$store.dispatch('base/setSearchFilters', this.form)
    },

    onSubmit () {
      this.setSearchFilters()
      this.$emit('do-search', this.form)
    },
  }
}