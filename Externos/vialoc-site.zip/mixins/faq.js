import Vue from 'vue'
import _ from 'lodash'

export default {
  data () {
    return {
      faqList: [],
    }
  },

  asyncData(context) {
    return context.app.$axios.$get('common/faq')
      .then(data => {
        return {
          faqList: data
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  methods: {
    updateQuestion (data) {
      let index = _.findIndex(this.faqList, f => f.id === data.faq_id)
      let question = this.faqList[index]
      console.log(data.id, index, question, { ...question, rating: data })
      Vue.set(this.faqList, index, { ...question, rating: data })
    }
  }
}