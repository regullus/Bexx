import VueScrollTo from 'vue-scrollto'

export default {
  data () {
    return {
      //
    }
  },

  watch: {
    '$route.hash': function() {
      if (this.$route.hash) {
        this.scrollToAnchor(this.$route.hash)
      }
    }
  },

  mounted() {
    if (this.$route.hash) {
      if (this.$route.hash.indexOf('=') === -1) {
        this.scrollToAnchor(this.$route.hash)
      }
    }
  },

  methods: {
    scrollToAnchor(anchor) {
      VueScrollTo.scrollTo(anchor)
    }
  }
}