export default {
  methods: {
    doSocialLogin (provider) {
      this.$axios.$get(`common/login/${provider}`)
        .then(providerUrl => {
          window.location.href = providerUrl
        })
        .catch(e => console.log('encontradas.vue -> onDoSearch', e))
    },

    doSocialLoginCallback (provider) {
      this.$axios.$post(`common/login/${provider}/callback`, this.$route.query)
        .then(
          response => {
            this.$store.dispatch('base/doLoginOnly', response).then(
              () => {
                if (response.user.status === 'to-complete') {
                  this.$router.push('/complete-seu-cadastro')
                } else {
                  this.$router.push('/minha-conta')
                }
              },
              error => {
                this.errorsAlert(error)
              }
            )
          },
          error => {
            this.errorsAlert(error)
          }
        ).catch(e => console.log('encontradas.vue -> onDoSearch', e))
    }
  }
}