export default {
  methods: {
    getDocumentImage (model_type, uid, document_type, size) {
      console.log('getDocumentImage', model_type, uid, document_type, size)
      this.$axios.$get(`common/${model_type}/${uid}/${document_type}/${size}`)
        .then(
          response => {
            this[document_type] = response
          },
          error => {
            console.log('helpers -> getDocumentImage', error)
            this[document_type] = null
          }
        )
    }
  }
}