export default {
  methods: {
    errorsParser (error) {
      let errorDescription = ''

      if (typeof error !== 'undefined' && error.response) {
        if (error.response.data.message) {
          errorDescription = error.response.data.message || ''
        }

        if (error.response.data.errors) {
          if (errorDescription) {
            errorDescription += '<br>'
          }
          _.each(error.response.data.errors, (value, key) => {
            if (_.isArray(value)) {
              errorDescription += _.join(value, '<br>')
            } else {
              errorDescription += value + '<br>'
            }
          })
        }

        if (!errorDescription) {
          return null
        }

        return errorDescription
      }
    },

    errorsAlert (error, alertInfo) {
      let alertDefault = {
        ref: 'formAlert',
        id: 'alert-errors-found',
        type: 'error',
        title: 'Erros encontrados',
        cleanOtherAlerts: true,
      }

      alertInfo = alertInfo || {}

      let alert = { ...alertDefault, ...alertInfo }

      let errorDescription = this.errorsParser(error)

      console.log({ ...alert, description: errorDescription })

      if (errorDescription) {
        this.$refs[alert.ref].showAlert({ ...alert, description: errorDescription })
      }
    },

    errorsModal (error, modalInfo) {
      let modalDefault = {
        id: 'generic',
        title: 'Erros encontrados',
      }

      if (typeof modalInfo === 'undefined') {
        modalInfo = {}
      }

      let modal = { ...modalDefault, ...modalInfo }

      let errorDescription = this.errorsParser(error)
      if (errorDescription) {
        this.$store.dispatch('events/setModal', { ...modal, message: errorDescription })
      }
    }
  }
}
