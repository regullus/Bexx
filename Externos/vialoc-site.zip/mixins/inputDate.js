import { addDays, differenceInDays, format } from 'date-fns'

export default {
  data () {
    return {
      isOverlappingRentedInterval: false,
    }
  },

  computed: {
    dateIniOptions () {
      let self = this
      return {
        disabledDate (time) {
          let pickerTime = time.getTime()
          let timeNow = Date.now()

          if (pickerTime > timeNow && self.product && self.product.rented_intervals.length && self.isInRentedInterval(pickerTime)) {
            return true
          }

          return pickerTime < timeNow
        }
      }
    },

    dateEndOptions () {
      let self = this
      return {
        disabledDate (time) {
          let pickerTime = time.getTime()
          let timeNow = Date.now()

          if (pickerTime > timeNow && self.product && self.product.rented_intervals.length && self.isInRentedInterval(pickerTime)) {
            return true
          }

          if (!self.form.order_date_start) {
            return pickerTime < timeNow
          }
          return pickerTime <= parseInt(format(self.form.order_date_start, 'x'))
        }
      }
    },

    dateEndDefault () {
      return this.form.order_date_start || null
    },

    totalDays () {
      if (!this.form.order_date_start || !this.form.order_date_end) {
        return null
      }

      // adiciona mais um para contar o dia inicial
      return (differenceInDays(this.form.order_date_end, this.form.order_date_start) + 1)
    },
  },

  methods: {
    checkDateEnd () {
      if (!this.form.order_date_start) {
        this.form.order_date_end = ''
        return null
      }

      if (!this.form.order_date_end) {
        return null
      }

      // let moment_date_start = moment(this.form.order_date_start)
      let date_start = parseInt(format(this.form.order_date_start, 'x'))
      let date_end = parseInt(format(this.form.order_date_end, 'x'))

      if (date_start >= date_end) {
        this.form.order_date_end = format(addDays(this.form.order_date_start, 1), 'YYYY-MM-DD')
      }

      if (this.product) {
        this.checkOverlappingRentedInterval()
      }
    },

    isInRentedInterval (pickerTime) {
      pickerTime = pickerTime/1000
      // console.log(pickerTime)
      let isInInterval = false
      this.product.rented_intervals.every((interval) => {
        if (pickerTime >= interval.start && pickerTime <= interval.end) {
          isInInterval = true
          return
        }
      })

      return isInInterval
    },

    checkOverlappingRentedInterval () {
      let self = this

      if (!self.form.order_date_start || !self.form.order_date_end) {
        return
      }

      let date_start = parseInt(format(self.form.order_date_start, 'x')) / 1000
      let date_end = parseInt(format(self.form.order_date_end, 'x')) / 1000

      this.product.rented_intervals.every((interval) => {

        if ((date_start >= interval.start && date_start <= interval.end) && (date_end >= interval.end || date_end < interval.end)) {
          self.isOverlappingRentedInterval = true
          return
        } else if ((date_start >= interval.start || date_start < interval.start) && (date_end >= interval.start && date_end <= interval.end)) {
          self.isOverlappingRentedInterval = true
          return
        } else if (date_start <= interval.start && date_end >= interval.end) {
          self.isOverlappingRentedInterval = true
          return
        }

        // if (date_start <= interval.end && date_end >= interval.start) {
        //   self.isOverlappingRentedInterval = true
        //   return
        // }
      })
    }
  }
}