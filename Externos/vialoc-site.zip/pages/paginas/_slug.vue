<template>
  <div class="inner-wrapper">
    <div class="container -column">
      <article class="inner-article">
        <header class="inner-header">
          <h2 class="inner-title">{{page.title}}</h2>
          <img v-if="slug == 'sobre'" src="~assets/images/quem-somos-vialoc.png"/>
        </header>
        <div class="inner-content">
          <div class="box-txt">
            <p>{{page.content}}</p>
          </div>
        </div>
      </article>
    </div>

  </div>
</template>

<script>
  export default {
    layout: 'inner',

    asyncData(context) {
        return context.app.$axios.$get(`page/${context.params.slug}`)
          .then(data => {
            return {
              page: data,
              slug: context.params.slug
            }
          })
          .catch((e) => { context.error({ statusCode: 404, message: 'Post not found' }) })
      },



  }
</script>
