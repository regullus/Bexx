<template>
  <div class="inner-wrapper page-list">
    <div class="container">
      <div class="inner-left">
        <div class="qtd">Exibindo de {{ products.length }} em {{ pagination.total }} carretas disponíveis</div>
        <app-profile :user="locator" profile="locator" />
      </div>
      <div class="inner-right">
        <div class="list-card">
          <h1 class="title">Carretas de {{ locator.short_name }}</h1>
          <div class="row">
            <div class="item" v-for="product in products" :key="`product-${product.slug}`">
              <app-card :product="product" />
            </div>
          </div>
          <el-button type="primary" v-if="pagination && pagination.currentPage < pagination.lastPage" @click="loadMoreProducts">Carregar mais</el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'
import { params2Querystring } from '@/utils/helpers'

import AppCard from '@/components/AppCard'
import AppProfile from '@/components/AppProfile'

export default {
  layout: 'inner',

  components: {
    AppCard,
    AppProfile,
  },

  data () {
    return {
      pagination: null,
      products: [],
    }
  },

  asyncData (context) {
    return context.app.$axios.$get(`common/products/locator/${context.params.user_slug}`)
      .then(data => {
        return {
          locator: data.locator,
          pagination: data.pagination,
          products: _.reject(data, (v, k) => { return ['locator', 'pagination'].indexOf(k) !== -1 }),
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  methods: {
    loadMoreProducts () {
      let qs = params2Querystring.convert(this.$route.params, ['user_slug'])
      qs += `&page=${this.pagination.currentPage + 1}`
      this.$axios.$get(`common/products/locator/${this.$route.params.user_slug}?${qs}`)
      .then(data => {
        Vue.set(this, 'pagination', data.pagination)
        _.reject(data, (v, k) => { return k === 'pagination' }).forEach((p) =>{
          this.products.push(p)
        })
      })
      .catch(e => context.error(e.response.data.message))
    },
  }
}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }

    .qtd {
      min-height: 3rem;
      margin-bottom: 1rem;
      font-size: 1.2rem;
    }
  }
  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }
  .inner-wrapper {
    margin-top: 0;
  }

  .row {
    lost-flex-container: row;
  }
  .item {
    width: 100%;
    @media (min-width: $screen-md) {
      lost-column: 1/2;
    }
    margin-bottom: 3rem;
  }
  .title {
    font-size: 1.9rem;
    margin-bottom: 2rem;
  }
  .link {
    font-size: 1.3rem;
    color: #4A90E2;

    &:hover {
      text-decoration: underline;
    }
  }
</style>