<template>
  <div class="inner-wrapper">
    <div class="container -column">
      <h2 class="inner-sub">Reserva #12345 - 5 de setembro</h2>

      <app-timeline/>

      <div class="message">
        <div>
          <p class="intro">Pague R$ 2.300,00 com Boleto.</p>
          <p>Você tem 3 dias para pagar. O pagamento é aprovado em 1 ou 2 dias úteis.</p>
        </div>
        <div>
          <el-button type="primary" class="el-button--block">Ver boleto</el-button>
          <small class="obs">Usar outro meio de pagamento</small>
        </div>
      </div>


    </div>
    <div class="container">
      <div class="inner-left">

        <!-- <app-card-details/> -->

      </div>
      <div class="inner-right">
        <div class="inner-sidebar">
          <div class="sidebar-item">
            <app-card-checkout/>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }
  .item {
    margin-bottom: 3rem;
  }

  .message {
    margin-bottom: 3.5rem;
    background-color: #FFF3E2;
    border: 1px solid #F5A623;
    padding: 2.6rem 2.6rem 1.8rem 2.6rem;
    display: flex;
    justify-content: space-between;
    font-size: 1.6rem;

    .intro {
      font-weight: bold;
      font-size: 1.8rem;
    }
    .el-button {
      margin-bottom: 2rem;
    }
    .obs {
      font-size: 1.2rem;
      color: $secondary-color;
    }
  }
</style>

<script>

import AppCardCheckout from '@/components/AppCardCheckout'
import AppTimeline from '@/components/AppTimeline'

export default {
  layout: 'inner',

  components: {
    AppCardCheckout,
    AppTimeline
  },

  meta: {
    breadcrumb: [
      {name: 'Cadastro carreta', path: '/alterar-senha'},
    ]
  },

  data() {
    return {
    }
  }
}

</script>

