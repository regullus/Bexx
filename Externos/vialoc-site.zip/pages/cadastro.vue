<template>
  <div class="inner-wrapper">
    <div class="container -column">
      <div class="inner-form">
        <h2 class="title">Bem-vindo à Vialoc</h2>
        <el-form :model="user" :rules="userRules" ref="formUser" class="el-form--label-top">
          <app-alert ref="formAlert"/>
          <el-row :gutter="10">
            <el-col :span="12">
              <el-form-item label="Nome" prop="name">
                <el-input v-model="user.name"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="Sobrenome" prop="last_name">
                <el-input v-model="user.last_name"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="12">
              <el-form-item label="E-mail" prop="email">
                <el-input v-model="user.email"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="Senha" prop="password">
                <el-input :type="formEl.passwordField" v-model="user.password"></el-input>
                <i class="show-password el-icon-view" :class="{ '-active': formEl.passwordView }" @click="onPasswordView"></i>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <small class="form-obs"><span>*</span> Itens obrigatórios.</small>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item class="check" prop="agree_terms">
                <el-checkbox v-model="user.agree_terms" true-label="1" false-label="">Eu concordo com os <a href="#" class="step-link">termos de serviço</a> e <a href="#" class="step-link">política de privacidade</a>.</el-checkbox>
                <el-checkbox v-model="user.receive_news" true-label="1" false-label="0">Quero receber novidades.</el-checkbox>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item>
                <el-button type="primary" @click="onSubmit" class="submit">Cadastrar</el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div class="bottom">
          <p>Ou cadastre-se pelo <a href="#" class="step-link" @click="doSocialLogin('facebook')">Facebook</a> ou <a href="#" class="step-link" @click="doSocialLogin('google')">Google</a>.</p>
          <p>Já tem uma conta? <el-button  @click="openModalLogin">Faça o login</el-button></p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import _ from 'lodash'
import AppAlert from '@/components/AppAlert'
import { errorsMixin, socialLoginMixin } from '@/mixins'

export default {
  layout: 'inner',

  mixins: [ errorsMixin, socialLoginMixin ],

  components: {
    AppAlert
  },

  meta: {
    breadcrumb: [
      {name: 'Cadastro', path: '/cadastro'},
    ]
  },

  data() {
    return {
      formEl: {
        passwordView: false,
        passwordField: 'password',
      },
      user: {
        // type: '',
        name: '',
        last_name: '',
        email: '',
        password: '',
        agree_terms: '',
        receive_news: '0',
      },
      userRules: {
        // type: [
        //   { type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur' }
        // ],
        'name': [
          { type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur' }
        ],
        'last_name': [
          { type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur' }
        ],
        email: [
          { type: 'email', required: true, message: 'Insira um e-mail válido', trigger: 'blur' }
        ],
        password: [
          { type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur' }
        ],
        agree_terms: [
          { required: true, message: 'Você precisa concordar com os termos', trigger: 'blur' }
        ],
      }
    }
  },
  methods: {
    onSubmit() {
      this.$refs['formUser'].validate((valid) => {
        if (!valid) {
          this.$refs['formAlert'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
          return false;
        }

        // Envia os dados ao endpoint
        this.$store.dispatch('base/registerUser', this.user)
        .then(
          response => {
            this.$router.push("/minha-conta/cadastro")
          },
          error => {
            this.errorsAlert(error)
          }
        )
      })
    },

    onPasswordView(){
      if (!this.formEl.passwordView) {
        this.formEl.passwordView = true
        this.formEl.passwordField = 'text'
      } else {
        this.formEl.passwordView = false
        this.formEl.passwordField = 'password'
      }
    },

    openModalLogin() {
      this.$store.dispatch('events/setModal', { id: 'login', redirect: '/minha-conta' })
    }
  }
}
</script>

<style lang="scss" scoped>
  .step {
    margin: 5rem 0;
    width: 100%;
  }
  .title {
    font-size: 2rem;
    text-align: center;
    margin-bottom: 2.6rem;
  }
  .container {
    max-width: 480px;
  }
  .radio {
    text-align: center;
  }
  .check {
    .el-checkbox {
      display: block;
      margin-left: 0;
      line-height: 25px;
    }
  }
  .bottom {
    font-size: 1.4rem;
    text-align: center;

    p {
      margin-bottom: 1rem;
    }
  }
  .submit {
    display: block;
    width: 100%;
  }
  .step-link {
    color: $secondary-color;
  }

  .show-password {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 2rem;
    cursor: pointer;

    &.-active {
      color: $primary-color;
    }
  }
</style>