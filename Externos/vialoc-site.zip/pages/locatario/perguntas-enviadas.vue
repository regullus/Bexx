<template>
  <div>
    <h2 class="profile-title -tenant">Perguntas enviadas</h2>
    <div class="inner-panel">
      <app-questions-item v-for="(question, index) in questions" :question="question" :productUid="question.product.uid"  type="view-tenant" :key="`question-${index}`" @update-question="onUpdateQuestion" />
      <el-alert v-if="!questions.length" type="info" title="Você ainda não fez nenhuma pergunta a respeito de alguma carreta." show-icon :closable="false"></el-alert>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'
import AppQuestionsItem from '@/components/AppQuestionsItem'

export default {
  layout: 'panel',
  head: {
    bodyAttrs: {
      class: '-tenant',
    }
  },

  components: {
    AppQuestionsItem,
  },

  async asyncData (context) {
    return context.app.$axios.$get(`tenant/products/messages`)
      .then(data => {
        return {
          questions: data,
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  methods: {
    onUpdateQuestion(question) {
      let index = _.findIndex(this.questions, q => q.id === question.id)
      Vue.set(this.questions, index, question)
    }
  }

}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }
</style>
