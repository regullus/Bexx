<template>
  <div>
    <div class="inner-form">
      <div class="header">
        <h2 class="profile-title -tenant">Avaliações</h2>
      </div>

      <el-tabs type="card" v-model="tabActive">
        <el-tab-pane label="Recebidas" name="received">
          <app-rate-user v-for="(rating, k) in ratingsReceived" :key="`rating-${k}`" :user="rating.user" profile="locator" :is-rateable="false" :rating="rating" viewType="listing" />
          <el-card class="box-card" v-if="!ratingsReceived.length">Você ainda não recebeu nenhuma avaliação.</el-card>
          <el-button type="primary" v-if="paginationReceived && paginationReceived.currentPage < paginationReceived.lastPage" @click="loadMoreRatings">Carregar mais</el-button>
        </el-tab-pane>
        <el-tab-pane label="Enviadas" name="sent">
          <app-rate-user v-for="(rating, k) in ratingsSent" :key="`rating-${k}`" :user="rating.user" profile="locator" :is-rateable="false" :rating="rating" viewType="listing" />
          <el-card class="box-card" v-if="!ratingsSent.length">Você ainda não enviou nenhuma avaliação.</el-card>
          <el-button type="primary" v-if="paginationSent && paginationSent.currentPage < paginationSent.lastPage" @click="loadMoreRatings">Carregar mais</el-button>
        </el-tab-pane>
      </el-tabs>

    </div>
  </div>
</template>

<script>
import _ from 'lodash'
import AppRateUser from '@/components/AppRateUser'

export default {
  layout: 'panel',
  middleware: ['auth', 'check-auth'],

  components: {
    AppRateUser
  },

  meta: {
    breadcrumb: [
      { name: 'Avaliações', path: '/locatario/avaliacoes' },
    ]
  },

  data () {
    return {
      tabActive: 'received',
      paginationSent: null,
      ratingsSent: [],
    }
  },

  asyncData (context) {
    return context.app.$axios.$get(`tenant/ratings/received`)
      .then(data => {
        return {
          paginationReceived: data.pagination,
          ratingsReceived: _.reject(data, (v, k) => { return k === 'pagination' }),
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  mounted () {
    this.loadRatingsSent()
  },

  methods: {
    loadMoreRatings () {
      let pagination = 'paginationReceived'
      let ratings = 'ratingsReceived'
      if (this.tabActive == 'sent') {
        let pagination = 'paginationReceived'
        let ratings = 'ratingsReceived'
      }
      let qs = params2Querystring.convert(this.$route.params)
      qs += `&page=${this[pagination].currentPage + 1}`
      this.$axios.$get(`tenant/ratings/${this.tabActive}?${qs}`)
      .then(data => {
        Vue.set(this, pagination, data.pagination)
        _.reject(data, (v, k) => { return k === 'pagination' }).forEach((p) =>{
          this[ratings].push(p)
        })
      })
      .catch(e => context.error(e.response.data.message))
    },

    loadRatingsSent () {
      return this.$axios.$get(`tenant/ratings/sent`)
        .then(data => {
          this.paginationSent = data.pagination
          this.ratingsSent = _.reject(data, (v, k) => { return k === 'pagination' })
        })
        .catch(e => context.error(e.response.data.message))
    }
  }
}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }
</style>
