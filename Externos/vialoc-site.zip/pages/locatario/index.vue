<template>
  <div class="dash -tenant">
    <el-menu :default-active="activeIndex" class="dash-menu" mode="horizontal">
      <el-menu-item index="locator"><nuxt-link to="/locador">Painel Locador</nuxt-link></el-menu-item>
      <el-menu-item index="tenant">Painel Locatário</el-menu-item>
    </el-menu>
    <div class="dash-wrp">
      <div class="dash-ctn">
        <div class="dash-row -inline">
          <app-dash-questions profile="tenant" :counter="questions_answered" />
          <app-dash-messages profile="tenant" :counter="orders_messages_unread"/>
        </div>
        <div class="dash-row">
          <app-dash-orders profile="tenant" subject="unconfirmed" :orders="orders_unconfirmed" :counter="orders_unconfirmed_count"/>
        </div>
        <div class="dash-row">
          <app-dash-orders profile="tenant" subject="takeout" :orders="orders_takeout" :counter="orders_takeout_count"/>
        </div>
        <div class="dash-row">
          <app-dash-orders profile="tenant" subject="finishing" :orders="orders_finishing" :counter="orders_finishing_count"/>
        </div>
      </div>
      <div class="dash-sidebar">
        <div class="dash-item">
          <h2 class="title">
            <svg-alert class="icon dash-color" width="18" height="18"/>
            Notificações
          </h2>
          <app-notes placement="panel" profile="tenant" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import _ from 'lodash'
import AppDashMessages from '@/components/AppDashMessages'
import AppDashOrders from '@/components/AppDashOrders'
import AppDashQuestions from '@/components/AppDashQuestions'
import AppNotes from '@/components/AppNotes'
import SvgAlert from '@/assets/svg/alert.svg?inline'

export default {
  layout: 'panel',
  middleware: ['auth', 'check-auth'],

  components: {
    AppDashMessages,
    AppDashOrders,
    AppDashQuestions,
    AppNotes,
    SvgAlert,
  },

  meta: {
    breadcrumb: [
      { name: 'Minha conta', path: '/minha-conta' },
      { name: 'Painel do locatário', path: '/locatario' },
    ]
  },

  data() {
    return {
      activeIndex: 'tenant',
    };
  },

  async asyncData (context) {
    return context.app.$axios.$get(`tenant/dashboard`)
      .then(data => {
        return {
          orders_messages_unread: data.orders_messages_unread,
          orders_unconfirmed: data.orders_unconfirmed,
          orders_unconfirmed_count: data.orders_unconfirmed_count,
          orders_takeout: data.orders_takeout,
          orders_takeout_count: data.orders_takeout_count,
          orders_finishing: data.orders_finishing,
          orders_finishing_count: data.orders_finishing_count,
          questions_answered: data.questions_answered,
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  methods: {
    handleClick(tab, event) {
      console.log(tab, event)
    }
  }
}

</script>

