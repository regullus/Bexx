<template>
  <div class="inner-wrapper">
    <div class="container -column">
      <h2 class="profile-title -tenant">Pedido de locação #{{ order.id }} - {{ order.order_date }}</h2>

      <app-timeline :logs="order.logs" :order-status="order.status"/>

      <app-order-message ref="appOrderMessage" :order="order" profile="tenant" @do-action="doAction" />
    </div>
    <div class="container">
      <div class="inner-left">
        <app-alert ref="formAlert" />

        <app-card-details
          :order="order"
          profile="tenant"
          @change-status="changeStatus"
          @set-rating="setRating"
          @do-action="doAction"
          />
      </div>

      <div class="inner-right">
        <div class="inner-sidebar">
          <div class="sidebar-item">
            <app-card-checkout
              :order="order"
              :show-header="false"
              @do-action="doAction"
              />
          </div>
          <div class="sidebar-item">
            <app-profile :user="order.locator" profile="locator"/>
          </div>
        </div>
      </div>
    </div>

    <el-dialog :visible.sync="confirm.show" :title="confirm.title" :close-on-click-modal="confirm.easyClose" :close-on-press-escape="confirm.easyClose" width="726px" class="c7-modal-generic" :class="confirm.class">
      <!-- Efetuar o pagamento -->
      <template v-if="confirm.action === 'payment'">
        <el-row>
          <p>Agora faltam poucos passos para concluir o seu pedido de locação. Escolha a forma de pagamento e siga as instruções:</p>
        </el-row>

        <app-alert ref="formAlertPayment" />

        <el-tabs v-model="paymentMethod.payment_method" type="card">

          <!-- Boleto bancário -->
          <el-tab-pane name="bank-slip">
            <div slot="label" class="el-tabs__icon"><span class="icon"><svg-payment-ticket width="31" height="25" /></span> Boleto bancário</div>
            <div class="box-txt">
              <p>Lembre-se que o vencimento do boleto é de <strong>1 dia útil</strong>. Você tem duas opções:</p>
              <ol>
                <li>Imprimir e pagar no banco.</li>
                <li>Pagar pela internet utilizando o código de barras.</li>
              </ol>

              <div class="alert">ATENÇÃO: só emitimos boletos do banco <strong>Bradesco</strong>. Confira os dados antes de pagá-lo.</div>

              <div class="total">Total: <strong>R$ {{ order.price_total_formatted }}</strong></div>

              <el-row>
                <el-button type="primary" @click="doPaymentBankSlip" class="c7-btn-do-payment" :loading="confirm.loading">Pagar com boleto bancário</el-button>
                <el-button type="text info" @click="confirm.show = false"> Cancelar </el-button>
              </el-row>

              <div class="obs">
                <h2 class="title">Importante!</h2>
                <ul>
                  <li>Caso o seu computador tenha um programa anti pop-up, será preciso desativá-lo antes de finalizar o pagamento e imprimir o boleto ou pagar pelo Internet Banking.</li>
                  <li>Não faça depósito ou transferência entre contas. O boleto não é enviado pelos Correios. Imprima-o e pague-o no banco ou pela internet.</li>
                  <li>Se o boleto não for pago até a data de vencimento, o pedido será automaticamente cancelado.</li>
                  <li>O prazo de retirada do equipamento é definido pelo locador e locatário após três dias do pagamento do boleto, tempo necessário para que a instituição bancária confirme o recebimento.</li>
                </ul>
              </div>
            </div>
          </el-tab-pane>

          <!-- Cartão de crédito -->
          <el-tab-pane name="credit-card">
            <div slot="label" class="el-tabs__icon"><span class="icon"><svg-payment-credit width="31" height="25" /></span> Cartão de crédito</div>
            <p>A Vialoc aceita várias bandeiras de cartão de crédito. Escolha a opção conforme sua necessidade.</p>
            <el-form :model="paymentMethod" :rules="creditCardRules" ref="formCreditCard" class="el-form--label-top">
              <el-row>
                <el-col>
                  <el-form-item>
                    <ul class="payment-card-list" :class="{ '-identified' : (cardBrand && cardBrand.niceType) }"><!-- ADICIONAR A CLASS -identified QUANDO IDENTIFICADO O CARTAO -->
                      <!-- ADICIONAR A CLASS -active AO ELEMENTO LI DO CARTAO SELECIONADO -->
                      <li data-card="visa" :class="{ '-active' : (cardBrand && cardBrand.type === 'visa') }">
                        <img src="~assets/svg/payment-visa-card.svg" alt="payment-visa-card" />
                      </li>
                      <li data-card="mastercard" :class="{ '-active' : (cardBrand && cardBrand.type === 'mastercard') }">
                        <img src="~assets/svg/payment-master-card.svg" alt="payment-master-card" />
                      </li>
                      <li data-card="amex" :class="{ '-active' : (cardBrand && cardBrand.type === 'american-express') }">
                        <img src="~assets/svg/payment-amex.svg" alt="payment-amex" />
                      </li>
                      <li data-card="hipercard" :class="{ '-active' : (cardBrand && cardBrand.type === 'hipercard') }">
                        <img src="~assets/svg/payment-hipercard.svg" alt="payment-hipercard" />
                      </li>
                      <li data-card="diners" :class="{ '-active' : (cardBrand && cardBrand.type === 'diners-club') }">
                        <img src="~assets/svg/payment-diners.svg" alt="payment-diners" />
                      </li>
                      <li data-card="elo" :class="{ '-active' : (cardBrand && cardBrand.type === 'elo') }">
                        <img src="~assets/svg/payment-elo.svg" alt="payment-elo" />
                      </li>
                      <li data-card="jcb" :class="{ '-active' : (cardBrand && cardBrand.type === 'jcb') }">
                        <img src="~assets/svg/payment-jcb.svg" alt="payment-jcb" />
                      </li>
                      <li data-card="discover" :class="{ '-active' : (cardBrand && cardBrand.type === 'discover') }">
                        <img src="~assets/svg/payment-discover.svg" alt="payment-discover" />
                      </li>
                    </ul>
                  </el-form-item>
                </el-col>
              </el-row>
              <div class="wrp">
                <el-row :gutter="10">
                  <el-col>
                    <el-form-item label="Número do cartão" prop="card.number">
                      <el-input type="tel" v-model="paymentMethod.card.number" v-mask="cardMask" :maxlength="cardNumberMaxLength"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="10">
                  <el-col :md="8">
                    <el-form-item label="Validade: Mês" prop="card.expiration.month">
                      <el-select v-model="paymentMethod.card.expiration.month" placeholder="Mês">
                        <el-option v-for="month in 12" :key="'month-' + month" :label="month < 10 ? '0' + month : month" :value="month < 10 ? '0' + month : month.toString()"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :md="8">
                    <el-form-item label="Ano" prop="card.expiration.year">
                      <el-select v-model="paymentMethod.card.expiration.year" placeholder="Ano">
                        <el-option v-for="year in years" :key="'year-' + year" :label="year" :value="year.toString()"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :md="8">
                    <el-form-item prop="card.cvv">
                      <span slot="label" class="el-form-tooltip">Cód. de segurança <span class="el-form-tooltip__item" :data-balloon="`Código com ${cardCvvMaxLength} dígitos impresso no verso do cartão.`" data-balloon-pos="up">?</span></span>
                      <el-input type="tel" v-model="paymentMethod.card.cvv" :maxlength="cardCvvMaxLength"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col>
                    <el-form-item label="Nome impresso no cartão" prop="card.holder">
                      <el-input v-model="paymentMethod.card.holder"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <!--
                <el-row :gutter="10">
                  <el-col>
                    <el-form-item label="Parcelar em 3, 6, 9 ou 12 vezes:" prop="">
                      <el-row :gutter="10">
                        <el-col :md="8">
                          <el-select placeholder="">
                            <el-option></el-option>
                          </el-select>
                        </el-col>
                        <el-col :md="16">
                          <div class="el-form__obs">OBSERVAÇÃO: informe apenas<br/> o número de parcelas desejado.</div>
                        </el-col>
                      </el-row>
                    </el-form-item>
                  </el-col>
                </el-row>
                -->
                <el-row>
                  <div class="total">Total: <strong>R$ {{ order.price_total_formatted }}</strong></div>
                </el-row>
              </div>

              <el-row>
                <el-button type="primary" @click="doPaymentCreditCard" class="c7-btn-do-payment" :loading="confirm.loading">Pagar com cartão de crédito</el-button>
                <el-button type="text info" @click="confirm.show = false"> Cancelar </el-button>
              </el-row>
            </el-form>
          </el-tab-pane>

          <!-- Cartão de débito -->
          <el-tab-pane name="debit-card">
            <div slot="label" class="el-tabs__icon"><span class="icon"><svg-payment-debit width="31" height="25" /></span> Cartão de débito</div>
            <p>Digite os dados do seu cartão de débito e clique em “Pagar com débito online”. Em seguida, você será encaminhado para a página do banco, onde deverá efetuar o pagamento.</p>
            <div class="input-method">
              <label class="input-method__label">
                <input type="radio" :checked="cardBrand && cardBrand.type === 'visa'" name="debit-card-method">
                <div class="input-method__name">
                  <img width="60" height="40" src="~assets/svg/payment-visa-card.svg" alt="payment-visa-card" /> &nbsp;
                  Visa Electron
                </div>
              </label>
              <label class="input-method__label">
                <input type="radio" :checked="cardBrand && ['mastercard', 'maestro'].indexOf(cardBrand.type) !== -1" name="debit-card-method">
                <div class="input-method__name">
                  <img width="60" height="40" src="~assets/svg/payment-master-card.svg" alt="payment-master-card"/> &nbsp;
                  Mastercard Maestro
                </div>
              </label>
            </div>

            <div class="box-txt">
              <p>Confira as bandeiras válidas para os cartões emitidos pelos bancos:</p>
              <p v-if="!cardBrand || (cardBrand && cardBrand.type === 'visa')"><strong>Visa Electron:</strong> Banco do Brasil, Bradesco, Citibank, Itaú e Santander.</p>
              <p v-if="!cardBrand || (cardBrand && ['mastercard', 'maestro'].indexOf(cardBrand.type) !== -1)"><strong>Mastercard Maestro:</strong> Banco do Brasil, BancooB, Bradesco, BRB, Caixa, Citibank, Itaú e Santander.</p>
            </div>

            <el-form :model="paymentMethod" :rules="debitCardRules" ref="formDebitCard" class="el-form--label-top" style="margin-bottom: 30px;">
              <div class="wrp">
                <el-row :gutter="10">
                  <el-col>
                    <el-form-item label="Número do cartão" prop="card.number">
                      <el-input type="tel" v-model="paymentMethod.card.number" v-mask="cardMask" :maxlength="cardNumberMaxLength"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="10">
                  <el-col :md="8">
                    <el-form-item label="Validade: Mês" prop="card.expiration.month">
                      <el-select v-model="paymentMethod.card.expiration.month" placeholder="Mês">
                        <el-option v-for="month in 12" :key="'month-' + month" :label="month < 10 ? '0' + month : month" :value="month < 10 ? '0' + month : month.toString()"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :md="8">
                    <el-form-item label="Ano" prop="card.expiration.year">
                      <el-select v-model="paymentMethod.card.expiration.year" placeholder="Ano">
                        <el-option v-for="year in years" :key="'year-' + year" :label="year" :value="year.toString()"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col>
                    <el-form-item label="Nome impresso no cartão" prop="card.holder">
                      <el-input v-model="paymentMethod.card.holder"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
              </div>

              <div class="total">Total: <strong>R$ {{ order.price_total_formatted }}</strong></div>
              <el-row>
                <el-button type="primary" @click="doPaymentDebitCard" class="c7-btn-do-payment" :loading="confirm.loading">Pagar com débito online</el-button>
                <el-button type="text info" @click="confirm.show = false"> Cancelar </el-button>
              </el-row>
            </el-form>

            <p>Após a aprovação do pagamento realizado no ambiente do seu banco (que será aberto em uma nova janela), você será direcionado novamente para a plataforma Vialoc para seguir com o agendamento de retirada do equipamento.</p>
            <div class="alert">
              <strong>ATENÇÃO:</strong> para locações acima de R$ 1.999,00, por gentileza, entrar em contato com o banco emissor do seu cartão e solicitar a liberação do limite.
            </div>

          </el-tab-pane>
        </el-tabs>
      </template>

      <!-- Cancelar reserva -->
      <template v-else-if="confirm.action === 'cancel'">
        <el-row>
          <p>Ao cancelar a reserva, o Locador será notificado. <strong>Atenção:</strong> esta ação não poderá ser revertida.</p>
        </el-row>
        <el-row>
          <app-card :product="order.product" extra-class="-flat" process="only-view" />
        </el-row>
        <el-row>
          <el-table :data="orderTableData" :show-header="false" style="width: 100%">
            <el-table-column prop="attribute_a" width="180"> </el-table-column>
            <el-table-column prop="value_a" class-name="c7-table-value"> </el-table-column>
            <el-table-column prop="attribute_b" width="180"> </el-table-column>
            <el-table-column prop="value_b" class-name="c7-table-value"> </el-table-column>
          </el-table>
        </el-row>
        <el-row>
          <el-button type="danger" @click="doCancelation" :loading="confirm.loading"> Confirmar cancelamento da reserva </el-button>
          <el-button type="text info" @click="confirm.show = false"> Desistir do cancelamento </el-button>
        </el-row>
      </template>

      <!-- Alterar o pagamento -->
      <template v-else-if="confirm.action === 'change-payment'">
        <el-row>
          <p><strong>Atenção:</strong> Para modificar a forma de pagamento deste pedido, a tentativa de pagamento anterior <strong>será cancelada</strong>. Portanto, antes de prosseguir, certifique-se que não foi feito nenhum pagamento ou débito através da forma de pagamento anterior.</p>
          <h5>Forma de pagamento a ser cancelada:</h5>
        </el-row>
        <el-row>
          <el-card>
            <strong>{{ order.payment.payment_method_formatted }}</strong><br>
            Status: {{ order.payment.status_formatted }}
              <small v-if="order.payment.payment_method_slug === 'bank-slip'">(Aguardando a compensação do pagamento)</small>
              <small v-if="order.payment.payment_method_slug === 'debit-card'">(Aguardando a autenticação do pagamento no banco)</small>
              <br>
            <span v-if="order.payment.expiration_date">Data de vencimento: {{ order.payment.expiration_date }}</span>
          </el-card>
        </el-row>
        <el-row>
          <el-button type="danger" @click="doChangePayment" :loading="confirm.loading"> Trocar forma de pagamento </el-button>
          <el-button type="text info" @click="confirm.show = false"> Cancelar </el-button>
        </el-row>
      </template>

      <!-- Confirmar retirada -->
      <template v-else-if="confirm.action === 'takeout'">
        <el-row>
          <p>Ao confirmar a retirada da carreta, o Locador será notificado e receberá o pagamento da locação. <strong>Atenção:</strong> esta ação não poderá ser revertida.</p>
        </el-row>
        <el-row>
          <app-card :product="order.product" extra-class="-flat" process="only-view" />
        </el-row>
        <el-row>
          <el-table :data="orderTableData" :show-header="false" style="width: 100%">
            <el-table-column prop="attribute_a" width="180"> </el-table-column>
            <el-table-column prop="value_a" class-name="c7-table-value"> </el-table-column>
            <el-table-column prop="attribute_b" width="180"> </el-table-column>
            <el-table-column prop="value_b" class-name="c7-table-value"> </el-table-column>
          </el-table>
        </el-row>
        <el-row>
          <el-button type="primary" @click="doTakeout" :loading="confirm.loading"> Confirmar retirada da carreta </el-button>
          <el-button type="text info" @click="confirm.show = false"> Não cancelar </el-button>
        </el-row>
      </template>

      <!-- Informar devolução -->
      <template v-else-if="confirm.action === 'inform-devolution'">
        <el-row>
          <p>Ao informar a devolução da carreta ao locador, será enviada uma mensagem a este solicitando a confirmação da entrega. Assim que o locador confirmar, você receberá uma notificação para avaliar a carreta e o locador. <strong>Atenção:</strong> esta ação não poderá ser revertida.</p>
        </el-row>
        <el-row>
          <app-card :product="order.product" extra-class="-flat" process="only-view" />
        </el-row>
        <el-row>
          <el-table :data="orderTableData" :show-header="false" style="width: 100%">
            <el-table-column prop="attribute_a" width="180"> </el-table-column>
            <el-table-column prop="value_a" class-name="c7-table-value"> </el-table-column>
            <el-table-column prop="attribute_b" width="180"> </el-table-column>
            <el-table-column prop="value_b" class-name="c7-table-value"> </el-table-column>
          </el-table>
        </el-row>
        <el-row>
          <el-button type="primary" @click="doInformDevolution" :loading="confirm.loading"> Informar devolução da carreta </el-button>
          <el-button type="text info" @click="confirm.show = false"> Cancelar </el-button>
        </el-row>
      </template>

      <!-- Confirmar envio de avaliação de usuário -->
      <template v-else-if="confirm.action === 'rating'">
        <el-row>
          <p>Por favor, confirme o envio da seguinte avaliação. <strong>Atenção:</strong> esta ação não poderá ser revertida.</p>
        </el-row>
        <el-row>
          <app-rate-user v-if="rating && rating.subtype === 'locator'" :user="order.locator" profile="locator" :is-rateable="false" :rating="rating" view-type="full-preview" />
          <app-rate-product v-else-if="rating && rating.subtype === 'product'" :product="order.product" :is-rateable="false" :rating="rating" view-type="full-preview" />
        </el-row>
        <el-row>
          <el-button type="primary" @click="doRating" :loading="confirm.loading"> Enviar avaliação {{ rating.subtype === 'locator' ? 'do locador' : 'da carreta' }} </el-button>
          <el-button type="text info" @click="confirm.show = false"> Cancelar </el-button>
        </el-row>
      </template>

    </el-dialog>
  </div>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'
import { mask } from 'vue-the-mask'
import { documentImageMixin, errorsMixin } from '@/mixins'
import { floatFormatted } from '@/utils/helpers'
import creditCardType, { getTypeInfo, types as CardType } from 'credit-card-type';
import { setTimeout } from 'timers';

import AppAlert from '@/components/AppAlert'
import AppCard from '@/components/AppCard'
import AppCardCheckout from '@/components/AppCardCheckout'
import AppCardDetails from '@/components/AppCardDetails'
import AppOrderMessage from '@/components/AppOrderMessage'
import AppProfile from '@/components/AppProfile'
import AppRateUser from '@/components/AppRateUser'
import AppRateProduct from '@/components/AppRateProduct'
import AppTimeline from '@/components/AppTimeline'
import SvgPaymentCredit from '@/assets/svg/payment-credit.svg?inline'
import SvgPaymentTicket from '@/assets/svg/payment-ticket.svg?inline'
import SvgPaymentDebit from '@/assets/svg/payment-debit.svg?inline'


const defaultPaymentMethod = {
  payment_method: 'bank-slip',
  payment_method_option: null,
  card: {
    holder: null,
    number: null,
    cvv: null,
    expiration: {
      month: null,
      year: null
    },
  },
}

const defaultConfirm = {
  show: false, // mostra o modal de confirmação
  title: '', // título do modal de confirmação
  action: '', // ação que determinará o conteúdo do modal a ser apresentado
  easyClose: true, // se true permitirá que o usuário feche o modal clicando fora dele
  loading: false, // se true, mostrará um looper no botão
  class: '', // classes extras no modal
}

export default {
  layout: 'inner',
  head: {
    bodyAttrs: {
      class: '-tenant',
    }
  },

  directives: { mask },

  mixins: [ documentImageMixin, errorsMixin ],

  components: {
    AppAlert,
    AppCard,
    AppCardCheckout,
    AppCardDetails,
    AppOrderMessage,
    AppProfile,
    AppRateUser,
    AppRateProduct,
    AppTimeline,
    SvgPaymentCredit,
    SvgPaymentTicket,
    SvgPaymentDebit,
  },

  meta: {
    breadcrumb: [
      {name: 'Minhas Locações', path: '/locatario/locacoes'},
    ]
  },

  data () {
    return {
      confirm: Object.assign({}, defaultConfirm),
      currentAction: null,
      paymentMethod: Object.assign({}, defaultPaymentMethod),
      rating: null,
      doc_crlv: null
    }
  },

  asyncData (context) {
    return context.app.$axios.$get(`tenant/order/${context.params.order_id}`)
      .then(data => {
        return {
          order: data,
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  mounted () {
    // // Adiciona regra para o cartao Aura
    // creditCardType.addCard({
    //   niceType: 'Aura',
    //   type: 'aura',
    //   patterns: [
    //     50
    //   ],
    //   gaps: [4, 8, 12, 16],
    //   lengths: [19],
    //   code: {
    //     name: 'CVV',
    //     size: 3
    //   }
    // })

    // // remove o cartao Maestro
    // if (creditCardType.getTypeInfo(creditCardType.types.MAESTRO)) {
    //   creditCardType.removeCard(creditCardType.types.MAESTRO)
    // }

    // Adiciona pattern 000  apenas para testes
    creditCardType.updateCard(creditCardType.types.VISA, {
      patterns: [
        4,
        0,
      ]
    });

    // pega o documento
    if (['pending-takeout', 'active', 'finished'].indexOf(this.order.status) !== -1) {
      this.getDocumentImage('order', this.order.id, 'doc_crlv', 'default')
    }

    // mostra a mensagem quando o usuário voltar do ambiente do banco
    if (this.$route.query['mensagem']) {
      switch (this.$route.query['mensagem']) {
        case 'pagamento-sucesso':
          this.$refs.formAlert.showAlert({ type: 'success', title: 'Pagamento realizado com sucesso', description: 'Agora você já poderá combinar com o locador os detalhes para a retirada da carreta.' })
          break;
      }
    }
  },

  computed: {
    priceTotalFormatted () {
      return floatFormatted(this.order.price_total)
    },

    creditCardRules () {
      return {
        'card.holder': [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'card.number': [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'card.cvv': [
          {type: 'string', required: true, message: 'Campo obrigatório', trigger: 'blur'}
        ],
        'card.expiration.month': [
          {type: 'string', required: true, message: 'Campo obrigatório', trigger: 'blur'}
        ],
        'card.expiration.year': [
          {type: 'string', required: true, message: 'Campo obrigatório', trigger: 'blur'}
        ],
      }
    },

    debitCardRules () {
      return {
        'card.holder': [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'card.number': [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'card.expiration.month': [
          {type: 'string', required: true, message: 'Campo obrigatório', trigger: 'blur'}
        ],
        'card.expiration.year': [
          {type: 'string', required: true, message: 'Campo obrigatório', trigger: 'blur'}
        ],
      }
    },

    orderTableData () {
      return [
        {
          attribute_a: 'Data de retirada', value_a: this.order.date_start,
          attribute_b: 'Data de entrega', value_b: this.order.date_end,
        },
        {
          attribute_a: 'Total de dias', value_a: `${this.order.days_total} dias`,
          attribute_b: 'Valor total da locação', value_b: `R$ ${this.priceTotalFormatted}`,
        },
      ]
    },

    years () {
      let year = (new Date()).getFullYear()
      return Array.from({length: 10}, (value, index) => year + index)
    },

    cardBrand () {
      if (!this.paymentMethod.card.number || this.paymentMethod.card.number.length < 3) {
        return null
      }

      let brand = creditCardType(this.paymentMethod.card.number)
      if (brand.length !== 1) {
        return null
      }

      return brand[0]
      // return brand
    },

    cardMask () {
      let cardNumberMask = '#'.repeat(16)

      if (!this.cardBrand) {
        return cardNumberMask
      }

      let cardNumber = this.paymentMethod.card.number

      // number length
      for (var i = 0; this.cardBrand.lengths[i] < cardNumber.length; i++) {
        cardNumberMask = '#'.repeat(this.cardBrand.lengths[i])
      }

      let offsets = [].concat(0, this.cardBrand.gaps, cardNumberMask.length)
      let components = []

      for (var i = 0; offsets[i] < cardNumberMask.length; i++) {
        let start = offsets[i]
        let end = Math.min(offsets[i + 1], cardNumberMask.length)
        components.push(cardNumberMask.substring(start, end))
      }

      return components.join(' ')
    },

    cardNumberMaxLength () {
      let cardNumberMaxLength = 20
      if (!this.cardBrand) {
        return cardNumberMaxLength
      }

      for (var i = 0; this.cardBrand.lengths[i] < this.paymentMethod.card.number.length; i++) {
        cardNumberMaxLength = this.cardBrand.lengths[i] + this.cardBrand.gaps.length
      }

      return cardNumberMaxLength
    },

    cardCvvMaxLength () {
      if (!this.cardBrand) {
        return 4
      }

      return this.cardBrand.code.size
    },

    currentPayment () {
      if (!this.order.payment) {
        return null
      }
      let payments = []
      payments.push(this.order.payment)
      return payments
    }
  },

  methods: {
    changeStatus(status) {
      this.order.status = status
    },

    doAction(action) {
      this.currentAction = action

      switch (action) {
        case 'primary': // Ação primária emitida pelo app-order-message
          this.actionPrimary()
          break
        case 'secondary': // Ação secundária emitida pelo app-order-message
          this.actionSecondary()
          break
        case 'cancel':
          this.askCancelation()
          break
        case 'change-payment':
          this.askChangePayment()
          break
        case 'inform-devolution':
          this.confirmInformDevolution()
          break
      }
    },

    actionPrimary() {
      switch(this.order.status) {
        case 'pending-payment':
          this.setConfirm({ show: true, title: 'Escolha o método de pagamento e siga as instruções', action: 'payment', easyClose: false, class: 'c7-modal-payment'})
          break
        case 'pending-takeout':
          this.setConfirm({ show: true, title: 'Confirme a retirada da carreta', action: 'takeout'})
          break
        case 'active':
          this.confirmInformDevolution()
          break
      }
    },

    actionSecondary() {
      switch(this.order.status) {
        case 'pending-payment':
          break
      }
    },

    // AVALIAÇÃO LOCADOR / CARRETA
    setRating(rating) {
      this.rating = rating
      this.askRating()
    },

    askRating () {
      this.setConfirm({ show: true, title: 'Confirme a avaliação ' + (this.rating.subtype === 'locator' ?  'do Locador' : 'da Carreta'), action: 'rating'})
    },

    doRating () {
      this.confirm.loading = true
      this.$axios.$post(`tenant/order/${this.order.id}/rate-${this.rating.subtype}`, this.rating)
        .then(
          response => {
            this.order.ratings.push(response)
            this.$refs.formAlert.showAlert({ type: 'success', title: 'Avaliação enviada com sucesso', description: 'O locador será informado do envio da sua avaliação, assim que esta for aprovada.' })
          },
          error => {
            this.errorsAlert(error)
          }
        )

      this.setConfirm({ show: false, loading: false })
    },

    // CANCELAMENTO DE RESERVA
    askCancelation() {
      this.setConfirm({ show: true, title: 'Confirme cancelamento da reserva!', action: 'cancel' })
    },

    doCancelation() {
      this.confirm.loading = true
      this.$axios.$put(`tenant/order/${this.order.id}/cancel`)
        .then(
          response => {
            this.order = response
            this.$refs.formAlert.showAlert({ type: 'success', title: 'Pedido de locação cancelado com sucesso', description: 'O locador foi informado deste cancelamento.' })
          },
          error => {
            this.errorsAlert(error)
          }
        )

      this.setConfirm({ show: false, loading: false })
    },

    // PAGAMENTO
    askChangePayment() {
      this.setConfirm({ show: true, title: 'Confirme a troca da forma de pagamento!', action: 'change-payment' })
    },

    doChangePayment() {
      this.confirm.loading = true
      this.$axios.$put(`tenant/order/${this.order.id}/change-payment`)
        .then(
          response => {
            this.order = response
            this.$refs.formAlert.showAlert({ type: 'success', title: 'Pedido de locação alterado com sucesso', description: 'Agora você poderá escolher uma nova forma de pagamento para este pedido de locação.' })
            this.updateOrderMessages()
            this.setConfirm({ show: false, loading: false })
          },
          error => {
            //
          })
      this.confirm.loading = true
      this.confirm.show = false
    },

    doPaymentCreditCard() {
      this.confirm.loading = true
      this.$refs['formCreditCard'].validate((valid) => {
        if (!valid) {
          this.$refs['formAlertPayment'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
          this.confirm.loading = false
          return false
        }

        let payload = Object.assign({}, this.paymentMethod)
        payload.payment_method_option = this.cardBrand.type
        payload.card.number = payload.card.number.replace( /^\D+/g, '')

        this.$axios.$post(`tenant/order/${this.order.id}/payment`, payload)
          .then(
            response => {
              this.order = response
              this.paymentMethod = Object.assign({}, defaultPaymentMethod)
              this.confirm.show = false
              this.confirm.loading = false
              this.$refs.formAlert.showAlert({ type: 'success', title: 'Pagamento realizado com sucesso', description: 'Agora você poderá combinar com o locador os detalhes para a retirada da Carreta.' })
            },
            error => {
              this.confirm.loading = false
              this.errorsAlert(error, { ref: 'formAlertPayment' })
            }
          )
      })
    },

    doPaymentBankSlip() {
      this.confirm.loading = true
      this.clearPaymentMethodData('bank-slip')
      let payload = Object.assign({}, this.paymentMethod)

      this.$axios.$post(`tenant/order/${this.order.id}/payment`, payload)
        .then(
          response => {
            this.order = response
            this.paymentMethod = Object.assign({}, defaultPaymentMethod)
            this.setConfirm({ show: false, loading: false })
            this.updateOrderMessages()
            window.open(this.order.payment.url, '_blank')
            this.$refs.formAlert.showAlert({ type: 'success', title: 'Boleto gerado com sucesso', description: 'O boleto foi gerado em outra janela. Caso não tenha aberto, para visualizar o seu boleto: ', clickUrl: this.order.payment.url, timer: 0 })
          },
          error => {
            this.confirm.loading = false
            this.errorsAlert(error, { ref: 'formAlertPayment' })
          }
        )
    },

    doPaymentDebitCard() {
      this.confirm.loading = true
      this.$refs['formDebitCard'].validate((valid) => {
        if (!valid) {
          this.$refs['formAlertPayment'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
          this.confirm.loading = false
          return false
        }

        let payload = Object.assign({}, this.paymentMethod)
        payload.payment_method_option = this.cardBrand.type
        payload.card.number = payload.card.number.replace( /^\D+/g, '')

        this.$axios.$post(`tenant/order/${this.order.id}/payment`, payload)
          .then(
            response => {
              this.order = response
              this.paymentMethod = Object.assign({}, defaultPaymentMethod)
              window.open(this.order.payment.url, '_blank')
              this.setConfirm({ show: false, loading: false })
              this.updateOrderMessages()
              this.$refs.formAlert.showAlert({ type: 'warning', title: 'Prossiga com o pagamento', description: 'O ambiente de autenticação do seu banco foi aberto em outra janela. Caso não tenha aberto, para acessar o ambiente:', clickUrl: this.order.payment.url, timer: 0 })
            },
            error => {
              this.confirm.loading = false
              this.errorsAlert(error, { ref: 'formAlertPayment' })
            }
          )
      })
    },

    // RETIRADA
    doTakeout() {
      this.confirm.loading = true
      this.$axios.$put(`tenant/order/${this.order.id}/takeout`)
        .then(
          response => {
            this.order = response
            this.$refs.formAlert.showAlert({ type: 'success', title: 'Retirada da carreta confirmada', description: 'O locador foi informado sobre este confirmação de retirada.' })
            this.updateOrderMessages()
          },
          error => {
            this.errorsAlert(error)
          }
        )

      this.confirm.loading = false
      this.confirm.show = false
    },

    // DEVOLUÇÃO
    confirmInformDevolution() {
      this.setConfirm({ show: true, title: 'Informar devolução da carreta', action: 'inform-devolution'})
    },
    doInformDevolution() {
      this.confirm.loading = true
      this.$axios.$put(`tenant/order/${this.order.id}/devolution`)
        .then(
          response => {
            Vue.set(this.order, 'tenant_devolution_informed', true)
            this.$refs.formAlert.showAlert({ type: 'success', title: 'Sucesso', description: 'Foi solicitada uma confirmação da devolução da carreta ao Locador. Informaremos a você quando houver a confirmação.' })
            this.updateOrderMessages()
          },
          error => {
            this.errorsAlert(error)
          }
        )
      this.setConfirm({ show: false, loading: false })
    },

    updateOrderMessages() {
      setTimeout(() => {
        this.$refs.appOrderMessage.setMessages()
      }, 50)
    },

    // para limpar os dados inseridos, caso o pagamento não seja via cartão de crédito
    clearPaymentMethodData(paymentMethodSlug, paymentMethodOption) {
      paymentMethodOption = paymentMethodOption || null
      this.paymentMethod = { ...defaultPaymentMethod, payment_method: paymentMethodSlug, payment_method_option: paymentMethodOption }
    },

    setConfirm (params) {
      this.confirm = {...defaultConfirm, ...params}
    },
  },
}
</script>

<style lang="scss">
  .el-table .c7-table-value {
    font-weight: bold;
  }

  .inner-left .item {
    margin-bottom: 3rem;
  }

  .c7-modal-payment {

    .el-tabs {
      .el-tabs__icon {
        svg {
          fill: #424242;
        }
      }
      &__header {
        .el-tabs__item {
          &.is-active, &:hover {
            background-color: #518FE0;

             svg {
              fill: #fff;
            }
          }
        }
      }
    }
  }
</style>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }
  .item {
    margin-bottom: 3rem;
  }

  .message {
    margin-bottom: 7rem;
    background-color: #FFF3E2;
    border: 1px solid #F5A623;
    padding: 2.6rem 2.6rem 1.8rem 2.6rem;
    display: flex;
    justify-content: space-between;
    font-size: 1.6rem;

    .intro {
      font-weight: bold;
      font-size: 1.8rem;
    }
    .el-button {
      margin-bottom: 2rem;
    }
    .obs {
      font-size: 1.2rem;
      color: $secondary-color;
    }
  }

  .c7-modal-payment {
    .alert {
      border: 1px solid $primary-color;
      background-color: #fff;
      padding: 12px 16px;
      display: inline-block;
      margin-bottom: 3rem;
    }
    .total {
      margin-top: 2rem;
      margin-bottom: 2rem;
      font-size: 1.8rem;

      strong {
        color: #468EE5;
      }
    }
    .obs {
      line-height: 1.6;
      border-top: 1px solid #9D9D9D;
      padding-top: 3rem;
      margin-top: 3rem;

      .title {
        font-size: 18px;
      }
    }
    .el-form {
      padding-left: 30px;

      .wrp {
        width: 360px;
      }
    }
    .c7-btn-do-payment {
      text-transform: uppercase;
      padding-left: 40px;
      padding-right: 40px;
    }
    .input-method {
      margin: 2rem 0;
    }
  }
  .payment-card-list {
    display: flex;
    flex-direction: row;

    li {
      width: 45px;
      height: 30px;
      margin-right: 10px;
      opacity: 1;
      transition: 300ms all;
      svg {
        display: block;
      }
    }

    &.-identified {
      li {
        &:not(.-active) {
          opacity: .3;
        }
      }
    }
  }
</style>
