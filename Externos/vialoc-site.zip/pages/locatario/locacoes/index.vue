<template>
  <div>
    <h2 class="profile-title -tenant">Minhas locações</h2>

    <el-menu :default-active="tabIndex" class="inner-nav el-menu-desc" mode="horizontal" @select="tabHandler">
      <el-menu-item v-for="(status, status_slug) in statuses" :index="status_slug" :key="`tab-${status_slug}`">{{ status.label }} <span v-if="ordersCount[status_slug]">({{ ordersCount[status_slug] }})</span>
        <div class="desc">{{ status.description }}</div>
      </el-menu-item>
    </el-menu>

    <div class="inner-content">
      <app-search-inner-carts/>
      <app-order v-for="order in ordersFiltered" :order="order" profile="tenant" :key="`order-${order.id}`" />
      <el-card class="box-card" v-if="!ordersFiltered.length">
        Não há pedidos registrados nesta etapa.
      </el-card>
    </div>
  </div>
</template>

<script>

import _ from 'lodash'
import AppOrder from '@/components/AppOrder'
import AppSearchInnerCarts from '@/components/AppSearchInnerCarts'

export default {
  layout: 'panel',
  middleware: ['auth', 'check-auth'],

  head: {
    bodyAttrs: {
      class: '-tenant',
    }
  },

  meta: {
    breadcrumb: [
      { name: 'Locatário', path: '/locatario' },
      { name: 'Minhas locações', path: '/locatario/locacoes' },
    ]
  },

  components: {
    AppOrder,
    AppSearchInnerCarts,
  },

  data() {
    return {
      tabIndex: 'pending-confirmation',
      statuses: {
        'pending-confirmation': { label: 'Em confirmação', description: 'Pedidos de locação aguardando a confirmação do proprietário.', },
        'pending-payment': { label: 'Em pagamento', description: 'Pedidos de locação aguardando o pagamento.', },
        // 'refused': { label: 'Recusado pelo proprietário', description: '', },
        'pending-takeout': { label: 'A retirar', description: 'Carretas aguardando a retirada.', },
        'active': { label: 'Ativas', description: 'Locações em andamento.', },
        'finished': { label: 'Finalizadas', description: 'Locações finalizadas.', },
        // 'canceled': { label: 'Locações canceladas', description: '', },
        'all': { label: 'Todos', description: 'Todas as locações.', },
      },
      statusFilter: 'pending-confirmation',
      orders: [],
      formSearch: {
        search: '',
      },
    }
  },

  asyncData (context) {
    return context.app.$axios.$get('tenant/orders')
      .then(data => {
        return {
          orders: data
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  computed: {
    ordersFiltered () {
      console.log(this.statusFilter)
      if (!this.statusFilter || this.statusFilter === 'all') {
        return this.orders
      }
      return _.filter(this.orders, { status: this.statusFilter })
    },

    ordersCount () {
      let counters = {}
      let self = this
      _.forEach(this.statuses, function (status, key) {
        counters[key] = (key !== 'all' ? _.filter(self.orders, { status: key }).length : self.orders.length)
      })

      return counters
    },
  },

  methods: {
    tabHandler (key, keyPath) {
      this.statusFilter = key
    },
  }

}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }
  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }
  .inner-content {
    padding-top: 4rem;
  }
  .el-menu {
    background-color: transparent;
  }
  .el-menu-item {
    font-size: 12px;
  }
  .el-menu--horizontal {
    border-color: #979797;

    > .el-menu-item {
      border: none;
      height: 32px;
      line-height: 32px;
      border: 1px solid #979797;
      border-bottom: none;
      color: #4A4A4A;

      &:not(:last-child) {
        margin-right: 10px;
        // @media (min-width: $screen-md) {
        //   margin-right: 40px;
        // }
      }

      &:hover, &:focus, &.is-active {
        background-color: #4AB5E2;
        color: #fff;
        border-color: #4AB5E2;
      }
    }
  }
</style>