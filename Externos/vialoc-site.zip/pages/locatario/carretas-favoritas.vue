<template>
  <div>
    <h2 class="profile-title -tenant">Carretas favoritas</h2>

    <div class="inner-content">
      <app-search-inner-carts/>
      <app-card v-for="product in productsFiltered" extra-class="-flat" process="favorite" :product="product" :key="`product-${product.uid}`" @favorite-delete="favoriteDelete" />
      <el-card class="box-card" v-if="!productsFiltered.length">
        Você não marcou nenhuma carreta como favorita.
      </el-card>
    </div>
  </div>
</template>

<script>

import _ from 'lodash'
import AppCard from '@/components/AppCard'
import AppSearchInnerCarts from '@/components/AppSearchInnerCarts'
import { favoritesMixin } from '@/mixins'

export default {
  layout: 'panel',
  middleware: ['auth', 'check-auth'],

  mixins: [favoritesMixin],

  components: {
    AppCard,
    AppSearchInnerCarts,
  },

  meta: {
    breadcrumb: [
      { name: 'Minhas carretas', path: '/minhas-carretas' },
    ]
  },

  data() {
    return {
      formSearch: {
        search: '',
      },
    }
  },

  asyncData (context) {
    return context.app.$axios.$get('tenant/favorites')
      .then(data => {
        return {
          products: data
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  computed: {
    productsFiltered () {
      if (!this.statusFilter) {
        return this.products
      }
      return _.filter(this.products, { status: this.statusFilter })
    },
  },

  methods: {
    //
  }

}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }
  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }

  .el-menu {
    background-color: transparent;
  }
  .el-menu-item {
    font-size: 12px;
  }
  .el-menu--horizontal {
    border-color: #979797;

    > .el-menu-item {
      border: none;
      height: 32px;
      line-height: 32px;
      border: 1px solid #979797;
      border-bottom: none;
      color: #4A4A4A;

      &:not(:last-child) {
        margin-right: 10px;
        @media (min-width: $screen-md) {
          margin-right: 40px;
        }
      }

      &:hover, &:focus, &.is-active {
        background-color: #4AB5E2;
        color: #fff;
        border-color: #4AB5E2;
      }
    }
  }
</style>