<template>
  <app-modal/>
</template>

<script>
import AppModal from '@/components/AppModal'

export default {
  components: {
    AppModal,
  },
}

</script>
