<template>
    <div>
      <app-header/>
      <header class="home-header">
        <div class="text">Conectamos quem tem carreta com quem precisa de uma.</div>
        <app-search @do-search="onDoSearch"/>
      </header>

			<section class="steps">
				<h2 class="title">Encontre a carreta ideal para seu serviço</h2>
					<div class="container">
						<div class="item">
							<span class="number">1</span>
							Encontre a carreta<br/> que você precisa
						</div>
						<div class="item">
							<span class="number">2</span>
							Defina o período de uso<br/> e a forma de pagamento
						</div>
						<div class="item">
							<span class="number">3</span>
							Combine com o proprietário<br/> onde retirar e entregar a carreta
						</div>
				</div>
			</section>

      <div class="list-categ">
        <div class="container">
          <div class="item" v-for="(category, category_slug) in categories" :key="`category-${category_slug}`">
            <div class="title">
              {{ category.label }} <nuxt-link :to="`/carretas/${category_slug}`" class="link"> - Ver Lista completa</nuxt-link>
            </div>
            <app-card :product="category.product" />
          </div>
        </div>
      </div>

      <section class="reg">
        <h2 class="title">Possui uma carreta?</h2>
        <p class="txt">A sua carreta pode ser compartilhada e se tornar uma fonte de renda extra.</p>
        <nuxt-link to="/locador/carretas/nova-carreta" class="btn">Cadastre sua carreta aqui</nuxt-link>
      </section>
    </div>
</template>

<script>
import AppCard from '@/components/AppCard'
import AppHeader from '@/components/partials/AppHeader'
import AppSearch from '@/components/AppSearch'

export default {
  components: {
    AppCard,
    AppHeader,
    AppSearch,
  },

  data () {
    return {
      categories: []
    }
  },

  asyncData (context) {
    return context.app.$axios.$get('home')
      .then(data => {
        return {
          categories: data
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  mounted () {
    if (this.$route.query['redefinir-senha']) {
      this.$store.dispatch('events/setModalLogin', 'redefine-password')
    }
    if (this.$route.query['ativar-conta']) {
      this.$axios.$get('/common/users/confirm-email/' + this.$route.query['ativar-conta'])
      .then(
        response => {
          if (this.$auth.user.is_complete) {
            this.$store.dispatch('events/addAlertMaster', { id: 'confirm-email-success', type: 'success', title: 'Confirmação efetuada com sucesso!', description: 'O seu e-mail foi confirmado com sucesso para utilizar na Vialoc.' })
          } else {
            this.$store.dispatch('events/addAlertMaster', { id: 'confirm-email-success', type: 'warning', title: 'Confirmação efetuada com sucesso!', description: 'Agora só falta você completar o seu cadastro para utilizar todas as funcionalidades disponíveis da Vialoc.' })
          }
          this.$auth.user.email_confirmed = 1
          this.$auth.fetchUser()
        },
        error => {
          this.$store.dispatch('events/addAlertMaster', { id: 'confirm-email-success', type: 'error', title: 'Erro na confirmação', description: error.response })
        }
      )
    }
  },

  methods: {
    onDoSearch (searchFilters) {
      this.$router.push(`/carretas/encontradas`)
    }
  }
}
</script>

<style lang="scss" scoped>
  .home-header {
    background: #000 url('~assets/images/bg-home.png') no-repeat;
    background-size: cover;
    padding-top: 10rem;
    padding-bottom: 2rem;

    @media (min-width: $screen-md) {
      height: 540px;
      padding-top: 18rem;
    }
  }
  .text {
    color: #fff;
    text-align: center;
    margin-bottom: 4rem;
    font-size: 2rem;

    @media (min-width: $screen-md) {
      font-size: 3.6rem;
      margin-bottom: 8rem;
    }
  }

  .list {
    background-color: #F2F2F2;
    padding: 5rem 0;
  }

  .reg {
    background-color: #fff;
    text-align: center;
    padding: 4rem 0;

    .title {
      font-size: 2.2rem;
      margin-bottom: 2rem;
    }

    .txt {
      margin-bottom: 3rem;
    }
  }

	.steps {
    padding: 4rem 0;

    .title {
      font-size: 2.2rem;
      text-align: center;
      text-transform: none;
      margin-bottom: 2.6rem;
    }
    .number {
      color: $primary-color;
      font-size: 6rem;
      display: block;
      line-height: 1;
      margin-bottom: 1rem;
      font-weight: bold;
    }
    .item {
      border: 1px solid #CDD1D5;
      background-color: #fff;;
      text-align: center;
      line-height: 1.3;
      padding: .6rem 0 2rem 0;
      margin-bottom: 1.6rem;
      position: relative;

      @media (min-width: $screen-md) {
        lost-column: 1/3;

        &:not(:last-child) {
          &:after {
            content: '';
            width: 42px;
            height: 10px;
            display: block;
            position: absolute;
            z-index: -1;
            right: -30px;
            top: 50%;
            transform: translateY(-50%);
            background: url('data:image/svg+xml;utf8,<svg width="44px" height="10px" viewBox="0 0 44 10" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> <defs></defs><g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="square"><g id="home-vialoc-aluga" transform="translate(-539.000000, -698.000000)" stroke="#4A90E2" stroke-width="3"><path d="M541,703 L577,703" id="Line"></path><path id="Line-decoration-1" d="M577,703 L566.2,700 L566.2,706 L577,703 Z"></path></g></g></svg>') no-repeat;
          }
        }
      }
    }
  }

  .list-categ {
    .item {
      margin-bottom: 3rem;

      @media (min-width: $screen-md) {
        lost-column: 1/3;
      }
    }
    .title {
      font-size: 1.9rem;
      margin-bottom: 2rem;
    }
    .link {
      font-size: 1.3rem;
      color: #4A90E2;

      &:hover {
        text-decoration: underline;
      }
    }
  }
</style>

