<template>
  <div>
    <div class="inner-wrapper list-view">

      <div class="container">
        <a href="" @click.prevent="toPrevious" class="inner-more"><i class="el-icon-arrow-left"></i> Voltar para lista</a>
      </div>

      <div class="container" v-if="product">
        <div class="inner-left">

          <div class="content">
            <div class="view-slider" v-if="viewMainImage">
              <div class="image">
                <img :src="viewMainImage" :alt="product.name" @click="showZoomImage = true">
                <div class="caption" v-if="viewMainImageCaption">{{ viewMainImageCaption }}</div>
              </div>
              <div class="thumbs" v-if="product.images.length || product.view_images.length">
                <carousel :per-page="4" :navigationEnabled="true">
                  <!-- Imagens da carreta -->
                  <slide v-for="(image, index) in product.images" :key="`slide-${index}`" @slide-click="setViewMainImage" :data-image="`${mediaBaseUrl}/${image.metadata.thumbnails['retangle-small'].path}`" :data-zoom="image.url">
                    <img :src="`${mediaBaseUrl}/${image.metadata.thumbnails['retangle-small'].path}`" :alt="product.name" :key="`slide-image-${index}`">
                    <!-- <div class="caption">Aqui vai um texto para a imagem</div> -->
                  </slide>
                  <!-- Imagens das vistas -->
                  <slide v-for="(image, index) in product.view_images" :key="`slide-view-${index}`" @slide-click="setViewMainImage" :data-image="`${mediaBaseUrl}/${image.metadata.thumbnails['retangle-small'].path}`" :data-zoom="image.url" :data-tag="image.tag">
                    <img :src="`${mediaBaseUrl}/${image.metadata.thumbnails['retangle-small'].path}`" :alt="product.name" :key="`slide-view-image-${index}`">
                    <div class="caption">{{ getViewImageLabel(image.tag) }}</div>
                  </slide>
                </carousel>
              </div>
            </div>

            <div class="inner-panel">
              <div class="content-header">
                <h1 class="title">{{ product.name }}</h1>
                <el-rate
                  v-model="product.rating_score"
                  disabled
                  disabled-void-color="#c0c4cc"
                  >
                </el-rate>
                <small>
                  <span v-if="!product.rating_count">Ainda sem avaliações</span>
                  <span v-else>{{ product.rating_count }} {{ !product.rating_count === 1 ? ' avaliação' : ' avaliações' }}</span>
                </small>
              </div>

              <el-tabs v-model="activeName">
                <el-tab-pane label="Descrição" name="description">
                  <div class="box-txt">
                    <div class="sec">
                      <el-row :gutter="20">
                        <el-col :span="12">
                          <ul>
                            <li><strong>Ano de Fabricação:</strong> {{ product.year }} </li>
                            <li><strong>Modelo:</strong> {{ product.model }} </li>
                            <li><strong>Fabricante:</strong> {{ product.brand }} </li>
                            <li><strong>Tipo:</strong> {{ product.type_formatted }} </li>
                            <li><strong>Piso:</strong> {{ product.floor_formatted }} </li>
                            <li><strong>Suspensão:</strong> {{ product.suspension_formatted }} </li>
                            <li><strong>Pneus:</strong> {{ product.with_tires ? 'inclusos' : 'não inclusos' }} </li>
                          </ul>
                        </el-col>
                        <el-col :span="12">
                          <ul>
                            <li><strong>Eixos:</strong> {{ product.axes }} </li>
                            <li>
                              <strong>Dimensões:</strong>
                              <ul>
                                <li><strong>Comprimento:</strong> {{ product.length }} m </li>
                                <li><strong>Largura:</strong> {{ product.width }} m </li>
                                <li v-if="product.height"><strong>Altura:</strong> {{ product.height }} m </li>
                                <li v-if="product.cubing"><strong>Cubagem:</strong> {{ product.cubing }} m </li>
                              </ul>
                            </li>
                          </ul>
                        </el-col>
                      </el-row>
                    </div>

                    <div class="sec">
                      <h2>Sobre esta carreta:</h2>
                      <div v-html="product.content"></div>
                    </div>
                  </div>

                </el-tab-pane>
                <el-tab-pane label="Avaliações" name="evaluations">
                  <el-alert v-if="!product.ratings.length" type="warning" title="Até o momento esta carreta não recebeu avaliações." show-icon :closable="false" />
                  <app-rate-list-item v-for="(rating, index) in product.ratings" :key="`product-rating-${index}`" :product="product" :is-rateable="false" :rating="rating" view-type="full" />
                </el-tab-pane>
              </el-tabs>
            </div>

            <app-questions :location="`${this.product.city} - ${this.product.state_code}`" :product_uid="`${this.product.uid}`" :questions="this.product.questions" @update-question="onUpdateQuestion"/>
          </div>
        </div>
        <div class="inner-right">
          <div class="inner-sidebar">
            <div class="sidebar-item">
              <div class="sidebar-form">
                <el-form :model="form" label-position="top">
                  <el-form-item label="Data de retirada">
                    <div class="el-input-date">
                      <svg-calendar class="el-input-date__icon" />
                      <el-date-picker v-model="form.order_date_start" type="date" placeholder="Data" prefix-icon="el-icon-arrow-down" :picker-options="dateIniOptions" format="dd/MM/yyyy" value-format="yyyy-MM-dd" @change="checkDateEnd"></el-date-picker>
                    </div>
                  </el-form-item>
                  <el-form-item label="Data de devolução">
                    <div class="el-input-date">
                      <svg-calendar class="el-input-date__icon" />
                      <el-date-picker v-model="form.order_date_end" type="date" placeholder="Data" prefix-icon="el-icon-arrow-down" :default-value="dateEndDefault" :picker-options="dateEndOptions" format="dd/MM/yyyy" value-format="yyyy-MM-dd" @change="checkOverlappingRentedInterval"></el-date-picker>
                    </div>
                  </el-form-item>
                </el-form>
              </div>
            </div>
            <div class="sidebar-item">
              <div class="sidebar-panel">
                <div class="sidebar-values">
                  <div class="row">
                    <small>Valor a partir de:</small>
                    R$ <span class="value">{{ product.price_from_formatted }}</span>/mês
                  </div>
                  <div class="row" v-if="$auth.loggedIn">
                    <div v-if="$auth.user.status !== 'active'">
                      <small>Seu cadastro ainda não está ativo. Por favor verifique se há alguma pendência <nuxt-link to="/minha-conta/cadastro">clicando aqui</nuxt-link>.</small>
                    </div>
                    <div v-else-if="$auth.user.uid === product.locator.uid">
                      <small>Você não pode alugar esta carreta, pois é o dono desta. Prefere <nuxt-link :to="`/locador/carretas/${product.uid}/editar`">editá-la</nuxt-link>?.</small>
                    </div>
                    <div v-else>
                      <div v-if="totalDays">
                        <div v-if="isOverlappingRentedInterval">
                          <small>O período selecionado é inválido, pois engloba datas em que a carreta estará indisponível.</small>
                        </div>
                        <div v-else-if="totalDays < 1">
                          <small>O período selecionado é inválido, pois a data de retirada é maior ou igual à data de entrega.</small>
                        </div>
                        <div v-else>
                          <small>Valor total ({{ totalDays }} dias):</small>
                          <div class="col">R$ <span class="value -negative">{{ priceTotal.formatted }}</span></div>
                        </div>
                      </div>
                      <div v-else>
                        <small>Você precisa definir a data de retirada e de devolução para poder efetuar a reserva.</small>
                      </div>
                    </div>
                  </div>
                  <div class="row" v-else>
                    <small>Você precisa estar logado para fazer a reserva. <span class="fake-link" @click="openModalLogin">Clique aqui</span> para fazer login.</small>
                  </div>
                </div>
                <div class="sidebar-buttons">
                  <el-button type="primary" :disabled="!totalDays || !$auth.loggedIn || isOverlappingRentedInterval" @click="confirmReservation"> Fazer reserva </el-button>
                  <el-button icon="el-icon-star-on" v-if="product.is_favorite" @click="onRemoveFavorite">- Favorito</el-button>
                  <el-button icon="el-icon-star-off" v-else @click="onAddFavorite">+ Favorito</el-button>
                </div>
              </div>
            </div>
            <div class="sidebar-item">
              <div class="sidebar-panel">
                <h4 class="title">Meios de pagamento</h4>

                <div class="sidebar-payments">
                  <span class="title">Cartões de crédito</span>
                  <img src="~assets/images/img-cards.png"/>
                </div>

                <div class="sidebar-payments">
                  <span class="title">Boleto Bancário</span>
                  <img src="~assets/images/img-ticket.png"/>
                </div>

                <a href="#" class="sidebar-link">Mais informações sobre meios de pagamento</a>
              </div>
            </div>

            <div class="sidebar-item">
              <app-profile :user="product.locator" profile="locator" />
            </div>

            <div class="sidebar-item">
              <div class="sidebar-panel">
                <h4 class="title">Dicas de segurança</h4>

                <ul class="sidebar-list">
                  <li>A Vialoc não é detentora dos veículos.</li>
                  <li>Desconfie de ofertas abaixo do preço de mercado.</li>
                  <li>Verifique se há pendências da carreta, como multas ou impostos.</li>
                  <li>Ao agendar a entrega e retirada da carreta, certifique-se da segurança do local.</li>
                  <li>Para garantir sua segurança, realize todo o processo de locação somente pela plataforma da Vialoc.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="container">
        <a href="" @click.prevent="toPrevious" class="inner-more"><i class="el-icon-arrow-left"></i> Voltar para lista</a>
      </div>
    </div>

    <el-dialog :visible.sync="showZoomImage" width="90%">
      <img width="100%" :src="zoomImageUrl" alt="Preview da Imagem">
    </el-dialog>

    <el-dialog :visible.sync="showReservation" width="726px" class="c7-modal-generic">
      <el-row>
        <app-card :product="product" extra-class="-flat" process="only-view" />
      </el-row>
      <el-row>
        <app-alert ref="formAlert" />
        <el-table :data="reservationData" style="width: 100%">
          <el-table-column prop="attribute" label="Item" width="180"> </el-table-column>
          <el-table-column prop="value" label="Valor"> </el-table-column>
        </el-table>
      </el-row>
      <el-row>
        <el-button type="primary" @click="doReservation" :loading="form.loading"> Confirmar reserva </el-button>
        <el-button type="text danger" @click="showReservation = false"> Cancelar </el-button>
      </el-row>
    </el-dialog>

  </div>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'
import { addDays, differenceInDays, format } from 'date-fns'
import { errorsMixin, inputDateMixin } from '@/mixins'
import { floatFormatted } from '@/utils/helpers'

import AppCard from '@/components/AppCard'
import AppAlert from '@/components/AppAlert'
import AppProfile from '@/components/AppProfile'
import AppQuestions from '@/components/AppQuestions'
import AppRateListItem from '@/components/AppRateListItem'
import SvgCalendar from '@/assets/svg/calendar.svg?inline'

const viewImagesLabel = {
  left: 'Vista lateral esquerda',
  front: 'Vista frontal',
  right: 'Vista lateral direita',
  interior: 'Vista interior',
  back: 'Vista traseira',
  axes: 'Eixos',
}

export default {
  layout: 'inner',

  mixins: [errorsMixin, inputDateMixin],

  components: {
    AppAlert,
    AppCard,
    AppProfile,
    AppQuestions,
    AppRateListItem,
    SvgCalendar,
  },

  meta: {
    breadcrumb: [
      { name: 'Carretas', path: '/carretas' },
      { name: 'Detalhes da carreta', path: null },
    ]
  },

  data() {
    return {
      mediaBaseUrl: process.env.MEDIA_BASE_URL,
      activeName: 'description',
      product: null,
      viewMainImage: null,
      viewMainImageCaption: null,
      zoomImageUrl: null,
      showZoomImage: false,
      showReservation: false,

      form: {
        order_date_start: '',
        order_date_end: '',
        loading: false,
      },

      rating: {
        score: 4.6
      },

      reservationData: []
    }
  },

  asyncData (context) {
    return context.app.$axios.$get(`common/product/${context.params.product_slug}`)
      .then(data => {
        return {
          product: data,
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  computed: {
    priceTotal () {
      if (!this.totalDays || this.totalDays < 1) {
        return null
      }

      let selectedPrice;
      this.product.prices.forEach(price => {
        if (this.totalDays < price.more_than) {
            return
        }
        selectedPrice = price
      })

      let priceTotal = selectedPrice.price_per_day * this.totalDays

      return {
        value: priceTotal,
        formatted: floatFormatted(priceTotal)
      }
    }
  },

  mounted () {
    let mainImage = this.product.images.length ? this.mediaBaseUrl + '/' + this.product.images[0].metadata.thumbnails['retangle-medium'].path : null
    let mainViewImage = this.product.view_images.length ? this.mediaBaseUrl + '/' + this.product.view_images[0].metadata.thumbnails['retangle-medium'].path : null
    let zoomImage = this.product.images.length ? this.product.images[0].url : null
    let zoomViewImage = this.product.view_images.length ? this.product.view_images[0].url : null
    this.viewMainImage = (mainImage || mainViewImage) || require('~/assets/images/img-unavailable-720x400.png')
    this.zoomImageUrl = (zoomImage || zoomViewImage) || require('~/assets/images/img-unavailable-720x400.png')
  },

  methods: {
    openModalLogin() {
      this.$store.dispatch('events/setModal', { id: 'login', redirect: false })
    },

    toPrevious() {
      this.$router.back()
    },

    onAddFavorite() {
      this.$axios.$post('tenant/favorites/create', { product_uid:  this.product.uid })
        .then(
          response => {
            this.product.is_favorite = true;
          },
          error => {
            this.errorsAlert(error)
          }
        )
    },

    onRemoveFavorite() {
      this.$axios.$delete(`tenant/favorites/product/${this.product.uid}`)
        .then(
          response => {
            this.product.is_favorite = false;
          },
          error => {
            this.errorsAlert(error)
          }
        )

    },

    setViewMainImage(dataset) {
      this.viewMainImage = dataset.image
      this.viewMainImageCaption = this.getViewImageLabel(dataset.tag)
      this.zoomImageUrl = dataset.zoom
    },

    getViewImageLabel(tag) {
      return tag ? viewImagesLabel[tag] : null
    },

    zoomImage(image) {
      this.zoomImageUrl = image.url
      this.showZoomImage = true
    },

    onUpdateQuestion(question) {
      this.product.questions.unshift(question)
    },

    confirmReservation() {
      this.reservationData = [
        { attribute: 'Data de retirada', value: format(this.form.order_date_start, 'DD/MM/YYYY') },
        { attribute: 'Data de entrega', value: format(this.form.order_date_end, 'DD/MM/YYYY') },
        { attribute: 'Total de dias', value: `${this.totalDays} dias` },
        { attribute: 'Valor total da locação', value: `R$ ${floatFormatted(this.priceTotal.value)}` },
      ]

      this.showReservation = true
    },

    doReservation() {
      this.form.loading = true
      this.$axios.$post('tenant/order', { product_uid:  this.product.uid, date_start: this.form.order_date_start, date_end: this.form.order_date_end })
        .then(
          response => {
            this.$router.push(`/locatario/locacoes/${response.id}`)
            this.form.loading = false
          },
          error => {
            this.errorsAlert(error)
            this.form.loading = false
          }
        )
    }
  }
}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }

  .inner-wrapper {
    margin-top: 0;
  }

  .content-header {
    padding-bottom: 1.6rem;
    border-bottom: 1px solid #D8D8D8;
    margin-bottom: 2rem;
    .title {
      font-size: 2.4rem;
    }
    small {
      font-size: 1.2rem;
    }
  }

  .inner-panel {
    margin-bottom: 3rem;
  }

  .sidebar-payments {
    margin-bottom: 2rem;

    > .title {
      display: block;
      font-size: 1.3rem;
      margin-bottom: .7rem;
    }
  }

  .sidebar-values {
    font-size: 1.4rem;
    margin-bottom: 1.6rem;

    > .row {
      padding: .8rem 0;

      &:first-child {
        border-bottom: 1px solid #D8D8D8;

        small {
          margin-top: -10px;
        }
      }
    }

    small {
      display: block;
      font-size: 1.2rem;
      text-align: left;
    }

    .value {
      font-size: 2.8rem;
      color: #5CAF00;
      line-height: 1;
      display: inline-block;
      margin-bottom: 6px;
      font-weight: bold;

      &.-negative {
        color: #D0021B;
      }
    }
  }

  .view-slider {
    background-color: #fff;

    .image {
      height: 400px;
      position: relative;

      img {
        object-fit: cover;
        width: 100%;
        height: 100%;
        cursor: pointer;
      }

      .caption {
        background-color: rgba(0,0,0,.7);
        color: #fff;
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        padding: 1.4rem;
        font-size: 1.2rem;
        opacity: 0;
        visibility: hidden;
        transition: 400ms all;
      }

      &:hover {
        .caption {
          opacity: 1;
          visibility: visible;
        }
      }
    }
    .thumbs {
      padding: 1rem 4rem;
    }
  }

</style>

<style lang="scss">

  .VueCarousel-slide {
    position: relative;
    .caption {
        background-color: rgba(0,0,0,.7);
        color: #fff;
        position: absolute;
        bottom: 0;
        left: 5px;
        width: calc( 100% - 10px );
        height: 100%;
        padding: 1rem;
        font-size: 1.1rem;
        opacity: 0;
        visibility: hidden;
        transition: 400ms all;
        text-align: center;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        display: flex;
    }
    &:hover {
      .caption {
        opacity: 1;
        visibility: visible;
      }
    }
  }

  .view-slider {
    .VueCarousel-pagination {
      display: none;
    }
    .VueCarousel-slide {
      padding: 0 5px;
    }
  }

  .el-table th {
    font-weight: bold;
  }

</style>
