<template>
  <div class="inner-wrapper page-list">
    <app-search-inner :product-type="$route.params.product_type" @do-search="onDoSearch"/>
    <div class="container">
      <div class="inner-left">
        <app-filter :pagination="pagination" :showing-products="products.length" @do-search="onDoSearch"/>
      </div>
      <div class="inner-right">
        <div class="list-card">
          <h1 class="title">Carretas</h1>
          <div class="row">
            <div class="item" v-for="product in products" :key="`product-${product.slug}`">
              <app-card :product="product" />
            </div>
          </div>
          <el-button type="primary" v-if="pagination && pagination.currentPage < pagination.lastPage" @click="loadMoreProducts">Carregar mais</el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'
import { params2Querystring, querystringPayload } from '@/utils/helpers'

import AppCard from '@/components/AppCard'
import AppFilter from '@/components/AppFilter'
import AppSearchInner from '@/components/AppSearchInner'

export default {
  layout: 'inner',

  components: {
    AppCard,
    AppFilter,
    AppSearchInner,
  },

  data () {
    return {
      pagination: null,
      products: [],
    }
  },

  asyncData (context) {
    // limpa os filtros laterais
    context.store.dispatch('base/clearSearchFilters')
    let qsparams = querystringPayload('product', context.store.getters['base/searchFilters'])
    let qs = params2Querystring.convert(qsparams)
    return context.app.$axios.$get(`common/products?${qs}`)
      .then(data => {
        return {
          pagination: data.pagination,
          products: _.reject(data, (v, k) => { return k === 'pagination' }),
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  methods: {
    loadMoreProducts () {
      let qs = params2Querystring.convert(this.$route.params)
      qs += `&page=${this.pagination.currentPage + 1}`
      this.$axios.$get(`common/products?${qs}`)
      .then(data => {
        Vue.set(this, 'pagination', data.pagination)
        _.reject(data, (v, k) => { return k === 'pagination' }).forEach((p) =>{
          this.products.push(p)
        })
      })
      .catch(e => context.error(e.response.data.message))
    },

    onDoSearch (searchFilters) {
      this.$router.push(`/carretas/encontradas`)
    }
  }
}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }
  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }
  .inner-wrapper {
    margin-top: 0;
  }

  .row {
    lost-flex-container: row;
  }
  .item {
    width: 100%;
    @media (min-width: $screen-md) {
      lost-column: 1/2;
    }
    margin-bottom: 3rem;
  }
  .title {
    font-size: 1.9rem;
    margin-bottom: 2rem;
  }
  .link {
    font-size: 1.3rem;
    color: #4A90E2;

    &:hover {
      text-decoration: underline;
    }
  }
</style>