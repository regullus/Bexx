<template>
  <div class="inner-wrapper">
    <div class="container -column">
      <div class="inner-form">
        <div class="header">
          <h2 class="inner-title">Esqueci minha senha</h2>
          <p>Digite a nova senha de acesso ao site da ViaLoc.</p>
        </div>
        <el-form :model="user" :rules="userRules" ref="formUser" class="el-form--label-top">
          <AppAlert ref="formAlert"/>
          <el-row :gutter="10">
            <el-col :span="24">
              <el-form-item label="Senha: * (6 a 12 caracteres) " prop="password">
                <el-input v-model="user.password"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="24">
              <el-form-item label="Confirme a senha:*" prop="new_password">
                <el-input v-model="user.new_password"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-button type="primary" @click="onSubmit" class="submit el-button--block">Enviar</el-button>
            </el-col>
          </el-row>
        </el-form>
        <div class="form-other">
          ou
        </div>
        <el-button-group>
          <el-button class="el-button--face el-button--block">Login com facebook</el-button>
          <el-button class="el-button--google el-button--block">Login com google</el-button>
        </el-button-group>
      </div>
    </div>
  </div>
</template>

<script>
import AppAlert from '@/components/AppAlert'

export default {
  layout: 'inner',

  components: {
    AppAlert
  },

  // meta: {
  //   breadcrumb: [
  //     {name: 'Cadastro carreta', path: '/alterar-senha'},
  //   ]
  // },

  data() {
    return {
      user: {
        password: '',
        new_password: '',
        confirm_password: '',
      },
      userRules: {
        password: [
          {type: 'string', required: true, message: 'Este campo é obrigatório'}
        ],
        new_password: [
          {type: 'string', required: true, message: 'Este campo é obrigatório'}
        ],
        confirm_password: [
          {type: 'string', required: true, message: 'Este campo é obrigatório'}
        ],
      },
    }
  },

  methods: {
    onSubmit() {
    }
  }
}
</script>

<style lang="scss" scoped>
  .header {
    margin-bottom: 2.4rem;
    font-size: 1.4rem;
  }
  .container {
    max-width: 350px;
  }
  .el-button-group {
    .el-button {
      margin-bottom: 1.6rem;
    }
  }
</style>
