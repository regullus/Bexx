<template>
  <div>
    <div class="inner-form">
      <div class="header">
        <h1 class="inner-title">Meus endereços</h1>
      </div>
      <app-manage-addresses :show-edit="true" :show-set-main="true" />
    </div>
  </div>
</template>

<script>
import AppManageAddresses from '@/components/AppManageAddresses'

export default {
  layout: 'panel',
  middleware: ['auth', 'check-auth'],

  components: {
    AppManageAddresses
  },

  meta: {
    breadcrumb: [
      {name: 'Meus endereços', path: '/minha-conta/enderecos'},
    ]
  },
}
</script>

<style lang="scss" scoped>

  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }

  .inner-form {
    > .header {
      margin-bottom: 4rem;
    }
  }

</style>
