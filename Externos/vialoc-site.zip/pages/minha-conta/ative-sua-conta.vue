<template>
  <div class="inner-helper">
    <div class="inner-form">
      <div class="header">
        <h2 class="inner-title">Ative a sua conta</h2>
      </div>
      <div class="inner-content">
        <div v-if="!$auth.user.is_complete" class="box-txt">
          <p>Para utilizar os recursos como: publicar uma carreta para locação ou reservar/contratar uma carreta, é necessário que o seu cadastro esteja completo e confirmado.</p>
          <p>Para finalizar o seu cadastro, você precisa:</p>
          <ul>
            <li>
              <strong>Confirmar o seu endereço de e-mail</strong><br>
              No momento do seu cadastro, foi enviado uma mensagem de confirmação ao seu e-mail. Acesse a sua caixa postal e siga as instruções contidas na mensagem. Caso não tenha recebido, <a href="#" @click="sendConfirmationAgain">clique aqui para solicitar o reenvio da confirmação</a>.
            </li>
            <li>
              <strong>Completar o seu cadastro</strong><br>
              É necessário que você complemente o seu cadastro com algumas informações. <nuxt-link to="/minha-conta/cadastro">Clique aqui para finalizar o seu cadastro</nuxt-link>.
            </li>
          </ul>
        </div>
        <div v-else class="box-txt">
          <p>O seu cadastro já está completo e finalizado.</p>
          <p>Não há pendências no seu usuário.</p>
          <p>Você poderá aproveitar os recursos oferecidos pela plataforma Vialoc.</p>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
export default {
  layout: 'panel',
  middleware: ['auth', 'check-auth'],

  meta: {
    breadcrumb: [
      {name: 'Cadastro', path: '/cadastro'},
    ]
  },

  methods: {
    sendConfirmationAgain() {
      this.$store.dispatch('base/sendConfirmationAgain')
    }
  }
}
</script>

<style lang="scss" scoped>

  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 6/12;
    }
  }

  .inner-form {
    > .header {
      margin-bottom: 4rem;
    }
  }

  .header-action {
    lost-flex-container: row;
    lost-align: center;

    .avatar-uploader {
      margin-right: 2rem;
    }

    .rating {
      text-align: right;
    }
  }

  .rating {
    > .el-rate {
      margin-bottom: .2rem;
    }
    > .text {
      font-size: 1.2rem;
      display: block;
    }
  }
</style>
