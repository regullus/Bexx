<template>
  <div class="inner-helper">
    <div class="inner-form">
      <div class="header">
        <h1 class="inner-title">Alterar senha</h1>
      </div>
      <el-form :model="user" :rules="passwordRules" ref="formPassword" class="el-form--label-top">
        <app-alert ref="formAlert"/>
        <el-row :gutter="10">
          <el-col :span="12">
            <el-form-item label="Senha atual" prop="password_current">
              <el-input :type="passwordCurrentEl.field" v-model="user.password_current"></el-input>
              <i class="show-password el-icon-view" :class="{ '-active': passwordCurrentEl.view }" @click="onPasswordView(passwordCurrentEl)"></i>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="12">
            <el-form-item label="Nova senha" prop="password">
              <el-input :type="passwordEl.field" v-model="user.password"></el-input>
              <i class="show-password el-icon-view" :class="{ '-active': passwordEl.view }" @click="onPasswordView(passwordEl)"></i>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="Confirmar nova senha" prop="password_confirmation">
              <el-input :type="passwordEl.field" v-model="user.password_confirmation"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item>
              <el-button type="primary" @click="onSubmit" class="submit el-button--block">Salvar</el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <small class="form-obs"><span>*</span> Itens obrigatórios.</small>
        </el-row>
      </el-form>
    </div>
  </div>
</template>

<script>
import AppAlert from '@/components/AppAlert'
import { errorsMixin } from '@/mixins'

const passwordDefault = {
  password_current: '',
  password: '',
  password_confirmation: '',
}

export default {
  layout: 'panel',
  middleware: ['auth', 'check-auth'],

  mixins: [errorsMixin],

  components: {
    AppAlert
  },

  meta: {
    breadcrumb: [
      {name: 'Cadastro carreta', path: '/alterar-senha'},
    ]
  },

  data() {
    return {
      passwordCurrentEl: {
        view: false,
        field: 'password',
      },
      passwordEl: {
        view: false,
        field: 'password',
      },

      user: Object.assign({}, passwordDefault),

      passwordRules: {
        password_current: [
          { type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur' }
        ],
        password: [
          { type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur' }
        ],
        password_confirmation: [
          { type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur' }
        ],
      },
    }
  },

  methods: {
    onSubmit() {
      this.$refs['formPassword'].validate((valid) => {
        if (valid) {
          this.$axios.$put('/common/users/update-password', this.user)
          .then(
            response => {
              this.$refs['formAlert'].showAlert({ id: 'alert-success', type: 'success', title: 'Senha alterada!', description: 'Sua senha foi alterada com sucesso!', cleanOtherAlerts: true })
              this.user = Object.assign({}, passwordDefault)
            },
            error => {
              this.errorsAlert(error)
            },
          )
        } else {
          this.$refs['formAlert'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
          return false;
        }
      })
    },

    onPasswordView(passwordObj){
      if (passwordObj.view) {
        passwordObj.view = false
        passwordObj.field = 'password'
      } else {
        passwordObj.view = true
        passwordObj.field = 'text'
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 6/12;
    }
  }

  .inner-form {
    > .header {
      margin-bottom: 4rem;
    }
  }

  .show-password {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 2rem;
    cursor: pointer;

    &.-active {
      color: $primary-color;
    }
  }
</style>
