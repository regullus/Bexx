<template>
  <div class="inner-container">
    <app-alert ref="formAlert"/>
    <div class="inner-row">
      <div class="left">
        <app-panel-user />
        <app-panel-products :products="favorites"/>
      </div>
      <div class="right">
        <div class="dash-item">
          <h2 class="title">
            <svg-alert class="icon dash-color" width="18" height="18"/>
            Notificações
          </h2>
          <app-notes placement="panel" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import _ from 'lodash'
import AppAlert from '@/components/AppAlert'
import AppNotes from '@/components/AppNotes'
import AppPanelUser from '@/components/AppPanelUser'
import AppPanelProducts from '@/components/AppPanelProducts'
import SvgAlert from '@/assets/svg/alert.svg?inline'

export default {
  layout: 'panel',
  middleware: ['auth', 'check-auth'],

  components: {
    AppAlert,
    AppNotes,
    AppPanelUser,
    AppPanelProducts,
    SvgAlert,
  },

  asyncData (context) {
    return context.app.$axios.$get('common/dashboard')
      .then(data => {
        return {
          notifications: data.notifications,
          favorites: data.favorites,
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  mounted () {
    if (!this.$auth.user.is_complete) {
      this.$refs['formAlert'].showAlert({ type: 'warning', id: 'alert-complete-profile', title: 'Complete o seu cadastro', description: 'Você precisa finalizar o seu cadastro.', clickUrl: '/minha-conta/cadastro', timer: 0 })
    }
  },
}

</script>

<style lang="scss" scoped>

  .inner-row {
    lost-flex-container: row;

    @media (max-width: $screen-md - 1px) {

      &:not(:last-child) {
        margin-bottom: 3rem;
      }

    }

    > .left {
      margin-bottom: 3rem;
      @media (min-width: $screen-md) {
        lost-column: 8/12;
      }
    }

    > .right {
      margin-bottom: 3rem;
      @media (min-width: $screen-md) {
        lost-column: 4/12;
      }
    }

    .panel-carts {
      width: 100%;
    }

    .panel-user {
      width: 100%;
      margin-bottom: 3rem;
    }

    .dash-sidebar {
      width: 100%;
      @media (min-width: $screen-md) {
        lost-column: 4/12;
      }
    }
  }

  .dash-color {
    fill: #999;
  }
</style>