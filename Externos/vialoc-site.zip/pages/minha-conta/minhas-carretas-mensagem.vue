<template>
  <div class="inner-wrapper">
    <div class="container">
      <div class="inner-left">
        <div class="inner-sub">Mensagens</div>
        <app-chat/>
      </div>
      <div class="inner-right">
        <div class="inner-sidebar">
          <div class="sidebar-item">
            <app-profile/>
          </div>
          <div class="sidebar-item">
            <app-card/>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import AppProfile from '@/components/AppProfile.vue'
import AppChat from '@/components/AppChat.vue'
import AppCard from '@/components/AppCard.vue'

export default {
  layout: 'inner',

  components: {
    AppProfile,
    AppChat,
    AppCard
  },

  meta: {
    breadcrumb: [
      {name: 'Locador', path: '/locador'},
      {name: 'Minhas carretas', path: '/locador/carretas'},
    ]
  },

  data() {
    return {
    }
  },

}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }
</style>