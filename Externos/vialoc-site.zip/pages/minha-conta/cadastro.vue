<template>
  <div v-if="user" class="inner-helper">
    <div class="inner-form">
      <div class="header">
        <h2 class="inner-title">Dados cadastrais</h2>

        <app-alert ref="formAlert"/>

        <h2 class="inner-title -sub">Dados do contato</h2>
        <div class="header-action">
          <app-avatar-upload :avatar="user.avatar" @avatar-error="avatarError" />
          <div class="rating">
            Perfil locatário
            <el-rate
              v-model="user.rating_tenant_score"
              disabled
              disabled-void-color="#c0c4cc"
              >
            </el-rate>
            <span class="text">
              <template v-if="!user.rating_tenant_count">Sem avaliações</template>
              <template v-else-if="user.rating_tenant_count === 1">1 avaliação</template>
              <template v-else-if="user.rating_tenant_count > 1">{{ user.rating_tenant_count }} avaliações</template>
            </span>
          </div>
        </div>
      </div>
      <el-form :model="user" :rules="userRules" ref="formUser" class="el-form--label-top">
        <el-row :gutter="10">
          <el-col :span="12">
            <el-form-item label="Nome" prop="name">
              <el-input v-model="user.name"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="Sobrenome" prop="last_name">
              <el-input v-model="user.last_name"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="12">
            <el-form-item label="E-mail" prop="email">
              <el-input v-model="user.email"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12" v-if="user.profile.phones">
            <el-form-item label="Telefone/Celular" prop="profile.phones.phone_1">
              <el-input v-model="user.profile.phones.phone_1" v-mask="['(##) ####-####', '(##) #####-####']"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <h2 class="inner-title -sub">Dados {{ user.profile.type === 'company' ? 'da empresa' : 'pessoais' }}</h2>
        <el-row>
          <el-col :span="24">
            <el-form-item class="radio" prop="profile.type">
              <el-radio v-model="user.profile.type" label="person">Pessoa Física</el-radio>
              <el-radio v-model="user.profile.type" label="company">Pessoa Jurídica</el-radio>
            </el-form-item>
          </el-col>
        </el-row>
        <div v-if="user.profile.type === 'person'">
          <el-row :gutter="10">
            <el-col :span="12">
              <el-form-item label="CPF" prop="profile.cpf">
                <el-input type="tel" v-model="user.profile.cpf" v-mask="'###.###.###-##'"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="Data de Nascimento" prop="profile.birthdate">
                <el-input type="tel" v-model="user.profile.birthdate" v-mask="'##/##/####'" key="user.profile.birthdate"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
        <div v-else-if="user.profile.type === 'company'">
          <el-row :gutter="10">
            <el-col :span="12">
              <el-form-item label="CNPJ" prop="profile.cnpj">
                <el-input type="tel" v-model="user.profile.cnpj" v-mask="'##.###.###/####-##'"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="Inscrição Estadual" prop="profile.state_tax_number">
                <el-input v-model="user.profile.state_tax_number" key="user.profile.state_tax_number"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="12">
              <el-form-item label="Razão Social" prop="profile.company_name">
                <el-input v-model="user.profile.company_name"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="Nome Fantasia" prop="profile.trading_name">
                <el-input v-model="user.profile.trading_name"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
        <el-row :gutter="10">
          <el-col :span="12">
            <el-form-item label="CEP" prop="address.zipcode">
              <el-input v-model="user.address.zipcode" v-mask="'#####-###'" @input="getAddressByZipcode"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="18">
            <el-form-item label="Endereço" prop="address.address">
              <el-input v-model="user.address.address"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="Número" prop="address.address_number">
              <el-input v-model="user.address.address_number" ref="address_number"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="12">
            <el-form-item label="Complemento" prop="address.address_complement">
              <el-input v-model="user.address.address_complement"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="Bairro" prop="address.district">
              <el-input v-model="user.address.district"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="12">
            <el-form-item label="Estado" prop="address.state_code">
              <el-select v-model="user.address.state_code" placeholder="Selecione" @change="getCities">
                <el-option v-for="state in states" :key="'state-' + state.value" :label="state.label" :value="state.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="Cidade" prop="city_id">
              <el-select v-model="user.address.city_id" filterable placeholder="Selecione">
                <el-option v-for="city in cities" :key="'city-' + city.id" :label="city.name" :value="city.id"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item class="check">
              <el-checkbox v-model="user.receive_news" :true-label="1" :false-label="0">Quero receber novidades.</el-checkbox>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item>
              <el-button type="primary" @click="onSubmit" class="submit el-button--block">Salvar</el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <small class="form-obs"><span>*</span> Itens obrigatórios.</small>
        </el-row>
      </el-form>
    </div>
  </div>
</template>

<script>
// import Vue from 'vue'
import _ from 'lodash'
import { mask } from 'vue-the-mask'
import { errorsMixin } from '@/mixins'
import AppAlert from '@/components/AppAlert'
import AppAvatarUpload from '@/components/AppAvatarUpload'

export default {
  layout: 'panel',
  middleware: [ 'auth', 'check-auth' ],

  directives: { mask },

  mixins: [ errorsMixin ],

  components: {
    AppAlert,
    AppAvatarUpload,
  },

  meta: {
    breadcrumb: [
      {name: 'Cadastro', path: '/cadastro'},
    ]
  },

  data () {
    return {
      states: [
        { value: 'AC', label: 'Acre' },
        { value: 'AL', label: 'Alagoas' },
        { value: 'AP', label: 'Amapá' },
        { value: 'AM', label: 'Amazonas' },
        { value: 'BA', label: 'Bahia' },
        { value: 'CE', label: 'Ceará' },
        { value: 'DF', label: 'Distrito Federal' },
        { value: 'ES', label: 'Espírito Santo' },
        { value: 'GO', label: 'Goiás' },
        { value: 'MA', label: 'Maranhão' },
        { value: 'MT', label: 'Mato Grosso' },
        { value: 'MS', label: 'Mato Grosso do Sul' },
        { value: 'MG', label: 'Minas Gerais' },
        { value: 'PA', label: 'Pará' },
        { value: 'PB', label: 'Paraíba' },
        { value: 'PR', label: 'Paraná' },
        { value: 'PE', label: 'Pernambuco' },
        { value: 'PI', label: 'Piauí' },
        { value: 'RJ', label: 'Rio de Janeiro' },
        { value: 'RN', label: 'Rio Grande do Norte' },
        { value: 'RS', label: 'Rio Grande do Sul' },
        { value: 'RO', label: 'Rondônia' },
        { value: 'RR', label: 'Roraima' },
        { value: 'SC', label: 'Santa Catarina' },
        { value: 'SP', label: 'São Paulo' },
        { value: 'SE', label: 'Sergipe' },
        { value: 'TO', label: 'Tocantins' },
      ],
      cities: [],
    }
  },

  asyncData (context) {
    return context.app.$axios.$get('common/users/me')
      .then(data => {
        return {
          user: data
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  computed: {
    userRules () {
      return {
        type: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'name': [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'last_name': [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        email: [
          {type: 'email', required: true, message: 'Insira um e-mail válido', trigger: 'blur'}
        ],
        'profile.phones.phone_1': [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        // phones: [
        //   {type: 'object', required: true, message: 'Este campo é obrigatório', trigger: 'blur', fields: {
        //     phone_1: {type: 'string', required: true, message: 'Este campo é obrigatório'}
        //   }}
        // ],
        'profile.cpf': [
          {type: 'string', required: this.user.profile.type === 'person', message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'profile.birthdate': [
          {type: 'string', required: this.user.profile.type === 'person', message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'profile.cnpj': [
          {type: 'string', required: this.user.profile.type === 'company', message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'profile.company_name': [
          {type: 'string', required: this.user.profile.type === 'company', message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'profile.trading_name': [
          {type: 'string', required: this.user.profile.type === 'company', message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'address.zipcode': [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'address.address': [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'address.number': [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'address.district': [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'address.city_id': [
          {type: 'integer', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'address.state_code': [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
      }
    },
  },

  mounted () {
    if (this.user) {
      if (!this.user.is_complete) {
        this.$refs['formAlert'].showAlert({ type: 'warning', id: 'alert-complete-profile', title: 'Complete o seu cadastro', description: 'Para finalizar o seu cadastro, por favor, preencha o formulário abaixo.', timer: 0 })
      }
      this.setProfilePhones()
      this.getCities()
    }
  },

  watch: {
    // workaround para evitar a validação quando exibir os campos de cada perfil
    'user.profile.type': function (type) {
      console.log(type)
      setTimeout(() => {
        this.$refs['formUser'].clearValidate()
      }, 50)
    }
  },

  methods: {
    onSubmit () {
      this.$refs['formUser'].validate((valid) => {
        if (valid) {
          // Envia os dados ao endpoint
          this.$store.dispatch('base/updateUser', {
            ...this.user
          }).then(
            response => {
              this.$refs['formAlert'].closeAlert('alert-complete-profile')
              this.$store.dispatch('events/deleteAlertMaster', 'alert-master-confirm-email-success')
              this.$refs['formAlert'].showAlert({ id: 'alert-user-registered', type: 'success', title: 'Usuário atualizado!', description: 'Os dados foram gravados com sucesso.', cleanOtherAlerts: true })
            },
            error => {
              this.errorsAlert(error)
            }
          )
        } else {
          this.$refs['formAlert'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
          return false;
        }
      })
    },

    avatarError(error) {
      this.errorsAlert(error)
    },

    getCities () {
      if (!this.user.address.state_code) {
        return
      }
      let citiesMessage = this.$message({ message: 'Por favor aguarde, estamos carregando a lista de cidades.' })

      this.$axios.$get(`/common/utils/cities-by-state/${this.user.address.state_code}`)
      .then(
        response => {
          this.cities = response
          citiesMessage.close()
          this.$message({ message: 'Cidades carregadas!', type: 'success' })
        },
        error => {
          citiesMessage.close()
          this.errorsAlert(error)
        }
      )
    },

    getAddressByZipcode () {
      if (this.user.address.zipcode.length === 9) {
        let addressMessage = this.$message({ message: 'Por favor aguarde, estamos carregando o endereço referente ao CEP.' })
        this.$axios.$get(`/common/utils/zipcode/${this.user.address.zipcode}`).then(
          response => {
            addressMessage.close()
            this.user.address = { ...this.user.address, ...response }
            this.$message({ message: 'Endereço carregado!', type: 'success' })
            this.getCities()
          },
          error => {
            addressMessage.close()
            this.$refs['formAlert'].showAlert({ id:'alert-zipcode-not-found', type: 'error', title: 'CEP não encontrado', description: 'Por favor, verifique se o CEP foi digitado corretamente.' })
          }
        )
      }
    },

    setProfilePhones () {
      if (!this.user.profile.phones || typeof this.user.profile.phones === 'undefined') {
        this.user.profile.phones = {
          phone_1: ''
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>

  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 6/12;
    }
  }

  .inner-form {
    > .header {
      margin-bottom: 4rem;
    }
  }

  .header-action {
    lost-flex-container: row;
    lost-align: center;

    .avatar-uploader {
      margin-right: 2rem;
    }

    .rating {
      text-align: right;
    }
  }

  .rating {
    > .el-rate {
      margin-bottom: .2rem;
    }
    > .text {
      font-size: 1.2rem;
      display: block;
    }
  }
</style>
