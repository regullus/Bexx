<template>
  <div class="inner-wrapper">
    <div class="container -column">
      <div class="inner-sub-header">
        <h2 class="inner-sub">Dados para sua nota fiscal</h2>
        <p>Usaremos os dados abaixo para gerar a sua fatura. Por isso, confirme se as informações estão corretas antes de prosseguir.</p>
      </div>
    </div>
    <div class="container">
      <div class="inner-left">
        <el-form :model="invoice" :rules="invoiceRules" class="el-form--label-top">
          <app-alert ref="formAlert"/>
          <el-form-item>
          <div class="inner-panel">
            <el-row :gutter="50">
              <el-col :span="5">
                <el-form-item label="Tipo">
                  <el-select v-model="invoice.type">
                    <el-option label="CNPJ" value="CNPJ"></el-option>
                    <el-option label="CPF" value="CPF"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="9">
                <el-form-item label="Número">
                  <el-input v-model="invoice.number"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="10">
                <div class="inner-box -gray">
                  <div class="header">DADOS PARA A SUA NOTA FISCAL</div>
                  <div class="ctn">
                    <div class="line">CNPJ 58.855.139/0001-05</div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </div>
          </el-form-item>
          <el-row>
            <el-col :span="24">
              <el-form-item class="-right">
                <el-button type="primary" class="submit">Continuar</el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div class="inner-right">
        <div class="inner-sidebar">
          <div class="sidebar-item">
            <app-card-checkout/>
          </div>
        </div>
      </div>
   </div>
  </div>
</template>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) { 
      lost-column: 9/12;
    }
  }
  .inner-right {
    @media (min-width: $screen-md) { 
      lost-column: 3/12;
    }
  }
  .table-price {
    background-color: #fff;
  }
</style>

<script>
import AppAlert from '@/components/AppAlert'
import AppCardCheckout from '@/components/AppCardCheckout.vue'

export default {
  layout: 'inner',

  components: {
    AppAlert,
    AppCardCheckout
  },

  meta: {
    breadcrumb: [
      {name: 'Cadastro carreta', path: '/alterar-senha'},
    ]
  },

  data() {
    return {
      invoice: {
        type: '',
        number: '58.855.139/0001-05',
      }
    }
  }
}

</script>
