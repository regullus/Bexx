<template>
    <div>
      <app-header/>
      <header class="home-header">
        <div class="wrp">
          <h2 class="title">Aluguel de carretas.</h2>
          <div class="text">Conectamos quem tem carreta com quem precisa.</div>
          <app-search @do-search="onDoSearch"/>

          <div class="img"><img src="~assets/images/vialoc-tag.png"/></div>
        </div>
      </header>

      <section class="sec sec-intro">
        <div class="container -column">
          <h2 class="sec-title">Tem carreta ou precisa de uma? Conheça a Vialoc!</h2>
          <p class="txt">A forma mais inteligente para quem quer economizar ou ganhar dinheiro.</p>

          <div class="btns">

            <div class="group">
              <a href="" @click.prevent="scrollToAnchor('#quero-uma-carreta')" class="btn">
                Quero uma carreta
              </a>
              <small>(Sou locatário)</small>
            </div>

            <div class="group">
              <a href="" @click.prevent="scrollToAnchor('#tenho-uma-carreta')" class="btn -primary">
                Tenho uma carreta
              </a>
              <small>(Sou locador)</small>
            </div>

          </div>
        </div>
      </section>

      <section class="sec -gray -text-center">
        <div class="container -column">
          <h2 class="sec-title">Como funciona?</h2>
          <div class="box-txt">
            <p>A Vialoc é uma plataforma online que conecta pessoas que querem disponibilizar suas carretas para locação com quem precisa de uma. De forma rápida, fácil e intuitiva, encontre várias opções de equipamentos rodoviários, diferentes preços e ainda opte por aquela que está mais perto de você. Saiba como!</p>
          </div>
        </div>
      </section>

      <section class="sec -text-center" id="quero-uma-carreta">
        <div class="container -column">
          <h2 class="sec-title -border">Quero uma carreta</h2>
          <div class="txt"><strong>Por que comprar uma carreta se você pode alugar e garantir muitas vantagens?</strong></div>
          <div class="box-txt -default">
            <div class="row">
              <div class="col">
                <img src="~assets/images/box.png"/>
              </div>
              <div class="col">
                <ul>
                  <li>Esteja preparado para as sazonalidades do mercado.</li>
                  <li>Alugue pelo período de sua necessidade.</li>
                  <li>Conte com várias opções de carretas disponíveis.</li>
                  <li>É pessoa jurídica? Deduza o aluguel no IRPJ e garanta o direito a crédito de PIS e Cofins.</li>
                  <li>Encontre locadores perto de você.</li>
                </ul>
              </div>
            </div>
          </div>
          <h2 class="sec-title -border">Passo a passo</h2>
          <ul class="list-icons">
            <li>
              <div class="icon">
                <svg-cart width="71" height="49"/>
              </div>
              <div class="desc">Encontre a carreta desejada.</div>
            </li>
            <li>
              <div class="icon">
                <svg-reserve width="46" height="40"/>
              </div>
              <div class="desc">Reserve a carreta e informe o período de locação.</div>
            </li>
            <li>
              <div class="icon">
                <svg-pay width="48" height="43"/>
              </div>
              <div class="desc">Realize o pagamento conforme a forma escolhida.</div>
            </li>
            <li>
              <div class="icon">
                <svg-chat-two width="48" height="42"/>
              </div>
              <div class="desc">Combine com o proprietário onde retirar e entregar a carreta.</div>
            </li>
          </ul>
          <div>
            <nuxt-link to="/carretas" class="btn">
              Procurar carreta
            </nuxt-link>
          </div>
        </div>
      </section>

      <section class="sec -text-center -white" id="tenho-uma-carreta">
        <div class="container -column">
          <h2 class="sec-title -border -primary">Tenho uma carreta</h2>
          <div class="txt"><strong>Pronto para ganhar dinheiro com sua carreta? Comece já!</strong></div>
          <div class="box-txt -primary">
            <div class="row">
              <div class="col">
                <ul>
                  <li>Garanta uma renda extra com suas carretas paradas.</li>
                  <li>Processo online, ágil e seguro.</li>
                  <li>Anuncie gratuitamente e só pague uma pequena taxa quando alugar.</li>
                  <li>Receba o dinheiro de forma rápida e sem burocracia.</li>
                  <li>Aproveite as vantagens de uma plataforma específica para locação.</li>
                </ul>
              </div>
              <div class="col">
                <img src="~assets/images/two-box.png"/>
              </div>
            </div>
          </div>
          <h2 class="sec-title -border -primary">Passo a passo</h2>
          <ul class="list-icons -primary">
            <li>
              <div class="icon">
                <svg-reserve-two width="71" height="49"/>
              </div>
              <div class="desc">Cadastre-se para receber solicitações de reserva.</div>
            </li>
            <li>
              <div class="icon">
                <svg-approve width="46" height="40"/>
              </div>
              <div class="desc">Aprove a solicitação e aguarde a confirmação de pagamento pela plataforma.</div>
            </li>
            <li>
              <div class="icon">
                <svg-maps width="48" height="43"/>
              </div>
              <div class="desc">Combine com o locatário o local de retirada e entrega da carreta.</div>
            </li>
            <li>
              <div class="icon">
                <svg-wallet width="48" height="42"/>
              </div>
              <div class="desc">Receba o pagamento da locação.</div>
            </li>
          </ul>
          <div>
            <button @click.prevent="addNewProduct" class="btn -primary">
              Quero ganhar dinheiro
            </button>
          </div>
        </div>
      </section>

      <section class="sec-highlights">
        <div class="container -column">
          <h2 class="sec-title -text-center -border">Destaques</h2>
          <div class="list-categ">
            <div class="item" v-for="(category, category_slug) in categories" :key="`category-${category_slug}`">
              <div class="title">
                {{ category.label }} <nuxt-link :to="`/carretas/${category_slug}`" class="link"> - Ver lista completa</nuxt-link>
              </div>
              <app-card :product="category.product" />
            </div>
          </div>
          <div class="bottom">
            <nuxt-link to="/carretas" class="btn">
              Ver mais carretas
            </nuxt-link>
          </div>
        </div>
      </section>

      <section class="sec-types">
        <div class="container -column">
          <h2 class="sec-title">Tipos de carretas disponíveis</h2>
          <ul class="list-types">
            <li v-for="(label, key) in types" :key="`btn-home-${key}`">
              <nuxt-link :to="`/carretas/${key}`">{{ label }}</nuxt-link>
            </li>
          </ul>
        </div>
      </section>
    </div>
</template>

<script>
import VueScrollTo from 'vue-scrollto'

import { hashScrollMixin, socialLoginMixin } from '@/mixins'
import AppCard from '@/components/AppCard'
import AppHeader from '@/components/partials/AppHeader'
import AppSearch from '@/components/AppSearch'

import SvgCart from '@/assets/svg/cart.svg?inline'
import SvgReserve from '@/assets/svg/reserve.svg?inline'
import SvgPay from '@/assets/svg/pay.svg?inline'
import SvgChatTwo from '@/assets/svg/chat-two.svg?inline'
import SvgReserveTwo from '@/assets/svg/reserve-two.svg?inline'
import SvgApprove from '@/assets/svg/approve.svg?inline'
import SvgMaps from '@/assets/svg/maps.svg?inline'
import SvgWallet from '@/assets/svg/wallet.svg?inline'

export default {
  mixins: [ hashScrollMixin, socialLoginMixin ],

  components: {
    AppCard,
    AppHeader,
    AppSearch,
    SvgCart,
    SvgReserve,
    SvgPay,
    SvgChatTwo,
    SvgReserveTwo,
    SvgApprove,
    SvgMaps,
    SvgWallet,
  },

  data () {
    return {
      categories: []
    }
  },

  asyncData (context) {
    return context.app.$axios.$get('common/home')
      .then(data => {
        return {
          categories: data
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  computed: {
    types () {
      return  this.$store.state.base.productInfo.types
    },
  },

  mounted () {
    // redefinir a senha
    if (this.$route.query['redefinir-senha']) {
      this.$store.dispatch('events/setModal', { id: 'redefine-password' })
    }

    // login e redirect
    if (this.$route.query['login-para']) {
      this.$store.dispatch('events/setModal', { id: 'login', title: 'Faça o login', message: 'Para acessar o recurso desejado você precisa fazer o login.', redirect: this.$route.query['login-para'] })
    }

    // acesso negado
    if (this.$route.query['acesso-negado']) {
      this.$store.dispatch('events/addAlertMaster', { id: 'forbidden-access', title: 'Acesso negado', description: 'Infelizmente, você não possui permissão para o recurso que tentou acessar.' })
    }

    // ativar conta
    if (this.$route.query['ativar-conta']) {
      this.$axios.$get('common/users/confirm-email/' + this.$route.query['ativar-conta'])
      .then(
        response => {
          if (this.$auth.user.is_complete) {
            this.$store.dispatch('events/addAlertMaster', { id: 'confirm-email-success', type: 'success', title: 'Confirmação efetuada com sucesso!', description: 'O seu e-mail foi confirmado com sucesso para utilizar na Vialoc.' })
          } else {
            this.$store.dispatch('events/addAlertMaster', { id: 'confirm-email-success', type: 'warning', title: 'Confirmação efetuada com sucesso!', description: 'Agora só falta você completar o seu cadastro para utilizar todas as funcionalidades disponíveis da Vialoc.' })
          }
          this.$auth.user.email_confirmed = 1
          this.$auth.fetchUser()
        },
        error => {
          this.$store.dispatch('events/addAlertMaster', { id: 'confirm-email-success', type: 'error', title: 'Erro na confirmação', description: error.response })
        }
      )
    }

    // social login
    if (this.$route.query['login']) {
      this.doSocialLoginCallback(this.$route.query['login'])
    }
  },

  methods: {
    onDoSearch (searchFilters) {
      this.$router.push(`/carretas/encontradas`)
    },

    addNewProduct () {
      if (!this.$auth.loggedIn) {
        this.$store.dispatch('events/setModal', { id: 'login', redirect: '/locador/carretas/nova-carreta' })
        return
      }

      this.$router.push('/locador/carretas/nova-carreta')
    }
  }
}
</script>

<style lang="scss" scoped>
  .home-header {
    background: #000 url('~assets/images/bg-home.png') no-repeat;
    background-size: cover;
    lost-flex-container: row;
    lost-align: middle-center;
    min-height: 540px;

    @media (min-width: $screen-md) {
      height: 70vh;
    }

    .title {
      color: #fff;
      text-align: center;
      font-size: 2rem;
      margin-bottom: .6rem;

      @media (min-width: $screen-md) {
        font-size: 3.6rem;
      }
    }

    .text {
      margin-bottom: 1rem;
      text-align: center;
      font-size: 1.8rem;
      color: #fff;

      @media (min-width: $screen-md) {
        margin-bottom: 4rem;
      }
    }

    .wrp {
      width: 100%;
      padding-top: 6rem;
    }

    .search {
      margin-bottom: 3.4rem;
    }

    .img {
      text-align: center;

      img {
        display: inline-block;
      }
    }
  }

  .list-icons {
    counter-reset: section;
    lost-flex-container: row;
    lost-align: top-center;

    li {
      width: 150px;
      position: relative;
      margin-bottom: 3rem;

      @media (max-width: $screen-md - 1px) {
        margin-left: 1.6rem;
        margin-right: 1.6rem;
      }

      @media (min-width: $screen-md) {

        &:not(:last-child) {
          margin-right: 7rem;
        }

      }

      &:before {
        counter-increment: section;
        content: counters(section,".") " ";
        width: 33px;
        height: 33px;
        background-color: $secondary-color;
        display: block;
        border-radius: 50%;
        font-size: 2.2rem;
        color: #fff;
        font-weight: 600;
        position: absolute;
        left: 7px;
        top: 0;
        z-index: 1;
      }

      .icon {
        border-radius: 50%;
        width: 128px;
        height: 128px;
        background-color: #fff;
        border: 1px solid $secondary-color;
        position: relative;
        margin: 0 auto 1rem auto;

        svg {
          display: block;
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%,-50%);
        }
      }

    }

    &.-primary {
      li {
        &:before {
          background-color: $primary-color;
        }

        .icon {
          border-color: $primary-color;
        }
      }
    }
  }

  .list {
    background-color: #F2F2F2;
    padding: 5rem 0;
  }

  .sec-title {
    font-size: 2.2rem;
    margin-bottom: 3rem;

    &.-text-center {
      text-align: center;
    }

    &.-border {
      &:after {
        content: '';
        height: 2px;
        display: block;
        width: 100px;
        background-color: $secondary-color;
        margin: 1rem auto;
      }
      &.-primary {
        &:after {
          background-color: $primary-color;
        }
      }
    }

  }

  .sec {
    padding: 6rem 0;

    .container {
      max-width: 860px;
    }

    .txt {
      margin-top: -25px;
      margin-bottom: 3rem;
      font-size: 1.6rem;
    }

    &.-gray {
      background-color: #8794A0;
      color: #fff;
    }

    &.-white {
      background-color: #fff;
    }

    &.-text-center {
      text-align: center;
    }
  }

  .sec-intro {
    background-color: #fff;
    text-align: center;
    lost-flex-container: row;
    lost-align: middle-center;

    @media (min-width: $screen-md) {
      height: 30vh;
      min-height: 280px;
    }

    .container {
      width: 100%;
    }

    .btns {
      lost-flex-container: row;
      lost-align: center;

      .btn {
        width: 200px;
      }

      .group {
        margin: 0 3rem;

        @media (max-width: $screen-md - 1px) {
          margin-bottom: 2rem;
        }
      }

      small {
        font-size: 1.3rem;
        display: block;
        padding-top: .4rem;
      }
    }
  }

	.steps {
    padding: 4rem 0;

    .title {
      font-size: 2.2rem;
      text-align: center;
      text-transform: none;
      margin-bottom: 2.6rem;
    }
    .number {
      color: $primary-color;
      font-size: 6rem;
      display: block;
      line-height: 1;
      margin-bottom: 1rem;
      font-weight: bold;
    }
    .item {
      border: 1px solid #CDD1D5;
      background-color: #fff;;
      text-align: center;
      line-height: 1.3;
      padding: .6rem 0 2rem 0;
      margin-bottom: 1.6rem;
      position: relative;

      @media (min-width: $screen-md) {
        lost-column: 1/3;

        &:not(:last-child) {
          &:after {
            content: '';
            width: 42px;
            height: 10px;
            display: block;
            position: absolute;
            z-index: -1;
            right: -30px;
            top: 50%;
            transform: translateY(-50%);
            background: url('data:image/svg+xml;utf8,<svg width="44px" height="10px" viewBox="0 0 44 10" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> <defs></defs><g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="square"><g id="home-vialoc-aluga" transform="translate(-539.000000, -698.000000)" stroke="#4A90E2" stroke-width="3"><path d="M541,703 L577,703" id="Line"></path><path id="Line-decoration-1" d="M577,703 L566.2,700 L566.2,706 L577,703 Z"></path></g></g></svg>') no-repeat;
          }
        }
      }
    }
  }

  .sec-highlights {
    padding: 6rem 0;

    .title {
      font-size: 2.2rem;
      margin-bottom: 2rem;
    }

    .bottom {

      .btn {
        max-width: 500px;
        display: block;
        margin: 0 auto;
      }
    }
  }

  .list-categ {
    lost-flex-container: row;
    .item {
      margin-bottom: 3rem;
      width: 100%;

      @media (min-width: $screen-md) {
        lost-column: 1/3;
      }
    }
    .title {
      font-size: 1.9rem;
      margin-bottom: 2rem;
      font-weight: bold;
    }
    .link {
      font-size: 1.3rem;
      color: #4A90E2;
      font-weight: 300;
      font-style: italic;

      &:hover {
        text-decoration: underline;
      }
    }
  }

  .sec-types {
    background-color: #8794A0;
    padding: 6rem 0;
    text-align: center;

    .sec-title {
      color: #fff;
    }
  }

  .list-types {
    lost-flex-container: row;
    lost-align: center;
    li {
      margin: 0 .8rem 1.4rem .8rem;
      a {
        border: 1px solid #fff;
        color: #fff;
        display: block;
        width: 165px;
        line-height: 40px;
        font-weight: bold;

        &:hover {
          color: $primary-color;
          border-color: $primary-color;
        }
      }
    }
  }
</style>

