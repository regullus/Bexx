<template>
  <div class="inner-wrapper">
    <div class="container">
      <article class="inner-article">
        <header class="inner-header">
          <h1 class="inner-title">Por que alugar?</h1>
          <img src="~assets/images/vialoc-alugar.png"/>
        </header>
        <div class="inner-content">
          <div class="box-txt">
            <p>Imagine o seguinte cenário: chegou a Black Friday e você não tem as carretas necessárias para atender a alta demanda. O que fazer? Entrar em desespero e compra uma nova? Saiba que existe uma alternativa mais econômica, prática e simples: o aluguel!</p>
            <p>Nem sempre comprar uma carreta é um investimento. Dependendo da sua necessidade, a aquisição pode ser apenas um gasto - e dos grandes. Então, antes de qualquer coisa, coloque tudo na ponta do lápis. E é importante lembrar: carreta parada também traz gastos.</p>
            <h2>Vantagens de alugar uma carreta</h2>
            <ul>
              <li>
                <h3>Sempre preparado</h3>
                Não importa se é Natal, Dia das Mães ou qualquer outra data que aumente a quantidade de vendas, nada é justificativa para deixar o seu cliente infeliz, não é mesmo? Então esteja equipado! Aqui você sempre encontrará diversas carretas, de tipos, tamanhos e marcas diferentes.
              </li>
              <li>
                <h3>Flexibilidade no aluguel</h3>
                Precisa de uma carreta por apenas alguns dias ou vários meses? Não tem problema! Busque por sua localização e tipo de carreta para encontrar a que supre suas necessidades.
              </li>
              <li>
                <h3>Plataforma intuitiva e segura</h3>
                Alugar uma carreta do modo tradicional pode ser uma tarefa árdua, mas não com a Vialoc. Sem sair de casa e em poucos cliques é possível encontrar vários equipamentos perto de você, todos com fotos e mais detalhes para encontrar o que procura.
              </li>
              <li>
                <h3>Lucratividade</h3>
                Comprar uma carreta para usar com pouca frequência pode ser bem desvantajoso. Alugue uma usando a plataforma da Vialoc e lucre ainda mais!
              </li>
              <li>
                <h3>Dedução no IRPJ</h3>
                É pessoa jurídica? Então você ainda pode deduzir o valor do aluguel da carreta no IRPJ e garantir o direito de crédito de PIS e Cofins.
              </li>
            </ul>
          </div>
        </div>
      </article>
    </div>
  </div>
</template>

<script>
  export default {
    layout: 'inner',
  }
</script>

