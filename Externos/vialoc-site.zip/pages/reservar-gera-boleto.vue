<template>
  <div class="inner-wrapper">
    <div class="container -column">
      <div class="inner-intro">
        <h2 class="title">Você está próximo de alugar uma carreta.</h2>
        <div class="sub">Pague R$ 2.300,00 com boleto para efetivar o seu aluguel.</div>
      </div>

      <div class="inner-panel">
        <p>Utilize a numeração do código de barras abaixo para realizar o pagamento via internet banking ou imprima o boleto.</p>
        <p>Você tem 3 dias para pagar. O pagamento é aprovado em 1 ou 2 dias úteis. </p>
        <p>
          <strong>
          Importante:<br/>
          O aluguel só estará garantido após a aprovação do pagamento.
          </strong>
        </p>
        <p>
          Numeração do código de barras:
          <span class="number">12345.12345 12345.123456 12345.123456 1 12345678910234</span>
        </p>
        <div class="panel-link">Copiar código</div>
      </div>

      <div class="inner-bottom">
        <el-button type="primary">Imprimir boleto</el-button>
        <el-button>Ver detalhe da reserva</el-button>
      </div>
    </div>
  </div>
</template>


<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) { 
      lost-column: 9/12;
    }
  }
  .inner-right {
    @media (min-width: $screen-md) { 
      lost-column: 3/12;
    }
  }
  .container {
    max-width: 740px;
  }
  .item {
    margin-bottom: 6rem;
  }
  .inner-intro {
    text-align: center;
  }
  .number {
    font-size: 1.8rem;
    font-weight: 600;
    display: block;
  }
</style>

<script>

export default {
  layout: 'inner',

  meta: {
    breadcrumb: [
      {name: 'Cadastro carreta', path: '/alterar-senha'},
    ]
  },

  data() {
    return {
    }
  }
}

</script>

