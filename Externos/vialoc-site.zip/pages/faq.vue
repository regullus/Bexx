<template>
  <div class="inner-wrapper">
    <div class="container -column">
      <div class="title">
        Como podemos ajudar você?
      </div>
      <app-faq v-if="faqList.length" :faq-list="faqList" @faqRated="updateQuestion" />
    </div>
  </div>
</template>

<script>

import AppFaq from '@/components/AppFaq'
import { faqMixin } from '@/mixins'

export default {
  layout: 'inner',
  mixins: [faqMixin],
  components: {
    AppFaq
  },
}
</script>

<style lang="scss" scoped>
  .title {
    text-align: center;
    margin-bottom: 2rem;
    font-size: 2rem;
  }
  .container {
    max-width: 650px;
  }
</style>
