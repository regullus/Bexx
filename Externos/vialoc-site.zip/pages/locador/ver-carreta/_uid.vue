<template>
  <div>
    <h2 class="profile-title -locator">Minhas carretas</h2>
    <app-nav-inner/>
    <div class="inner-content">
      <app-search-inner-carts/>
      <app-card extra-class="-flat" :product="product"/>
      <app-card-details/>
    </div>
  </div>
</template>

<script>

import AppCard from '@/components/AppCard'
import AppCardDetails from '@/components/AppCardDetails'
import AppNavInner from '@/components/AppNavInner'
import AppSearchInnerCarts from '@/components/AppSearchInnerCarts'

export default {
  layout: 'panel',
  head: {
    bodyAttrs: {
      class: '-locator',
    }
  },

  components: {
    AppCard,
    AppCardDetails,
    AppNavInner,
    AppSearchInnerCarts,
  },

  meta: {
    breadcrumb: [
      { name: 'Minhas carretas', path: '/minhas-carretas' },
      { name: 'Detalhes da carreta', path: null },
    ]
  },

  data() {
    return {
      formSearch: {
        search: '',
      },
    }
  },

  asyncData (context) {
    return context.app.$axios.$get(`locator/product/${context.params.uid}/view`)
    .then(data => {
      return {
        product: data
      }
    })
    .catch(e => context.error(e.response.data.message))
  },

}
</script>