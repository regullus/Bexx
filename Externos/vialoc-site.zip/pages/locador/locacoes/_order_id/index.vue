<template>
  <div class="inner-wrapper">
    <div class="container -column">
      <h2 class="profile-title -locator">Pedido de locação #{{ order.id }} - {{ order.order_date }}</h2>

      <app-timeline :logs="order.logs" :order-status="order.status"/>

      <app-order-message :order="order" profile="locator" @do-action="doAction" ref="appOrderMessage" />
    </div>
    <div class="container">
      <div class="inner-left">
        <app-alert ref="formAlert" />

        <app-card-details
          :order="order"
          :overlapping="overlapping"
          profile="locator"
          @change-status="changeStatus"
          @set-rating="setRating"
          />
      </div>

      <div class="inner-right">
        <div class="inner-sidebar">
          <div class="sidebar-item">
            <app-card-checkout
              :order="order"
              :show-header="false"
              profile="locator"
              @do-action="doAction"
              />
          </div>
          <div class="sidebar-item">
            <app-profile :user="order.user" profile="tenant" />
          </div>
        </div>
      </div>
    </div>

    <!-- <el-dialog :visible.sync="showConfirm" width="726px" class="c7-modal-generic"> -->
    <el-dialog :visible.sync="confirm.show" :title="confirm.title" :close-on-click-modal="confirm.easyClose" :close-on-press-escape="confirm.easyClose" width="726px" class="c7-modal-generic" :class="confirm.class">
      <!-- Confirmar reserva -->
      <template v-if="confirm.action === 'confirm'">
        <el-row>
          <p>Ao autorizar este pedido de reserva, o Locatário será notificado para efetuar o pagamento para garantir esta reserva. <strong>Atenção:</strong> esta ação não poderá ser revertida.</p>
        </el-row>
        <el-row>
          <app-card :product="order.product" extra-class="-flat" process="only-view" />
        </el-row>
        <el-row>
          <el-table :data="orderTableData" :show-header="false" style="width: 100%">
            <el-table-column prop="attribute_a" width="180"> </el-table-column>
            <el-table-column prop="value_a" class-name="c7-table-value"> </el-table-column>
            <el-table-column prop="attribute_b" width="180"> </el-table-column>
            <el-table-column prop="value_b" class-name="c7-table-value"> </el-table-column>
          </el-table>
        </el-row>
        <el-row>
          <el-button type="primary" @click="doConfirmation" :loading="confirm.loading"> Autorizar reserva </el-button>
          <el-button type="text info" @click="showConfirm = false"> Cancelar </el-button>
        </el-row>
      </template>

      <!-- Confirmar recusa de reserva -->
      <template v-else-if="confirm.action === 'refuse'">
        <el-row>
          <p>Ao <strong>recusar</strong> esta reserva, o locatário será informado sobre a decisão. <strong>Atenção:</strong> esta ação não poderá ser revertida.</p>
        </el-row>
        <el-row>
          <app-card :product="order.product" extra-class="-flat" process="only-view" />
        </el-row>
        <el-row>
          <el-table :data="orderTableData" :show-header="false" style="width: 100%">
            <el-table-column prop="attribute_a" width="180"> </el-table-column>
            <el-table-column prop="value_a" class-name="c7-table-value"> </el-table-column>
            <el-table-column prop="attribute_b" width="180"> </el-table-column>
            <el-table-column prop="value_b" class-name="c7-table-value"> </el-table-column>
          </el-table>
        </el-row>
        <el-row>
          <el-button type="danger" @click="doRefuse" :loading="confirm.loading"> Recusar reserva </el-button>
          <el-button type="text info" @click="showConfirm = false"> Cancelar </el-button>
        </el-row>
      </template>

      <!-- Informar retirada de carreta -->
      <template v-else-if="confirm.action === 'takeout'">
        <el-row>
          <p>Ao informar a retirada da carreta pelo locatário, será enviada uma mensagem a este solicitando a confirmação da retirada. Assim que o locatário confirmar, o pagamento será transferido para você. <strong>Atenção:</strong> esta ação não poderá ser revertida.</p>
        </el-row>
        <el-row>
          <app-card :product="order.product" extra-class="-flat" process="only-view" />
        </el-row>
        <el-row>
          <el-table :data="orderTableData" :show-header="false" style="width: 100%">
            <el-table-column prop="attribute_a" width="180"> </el-table-column>
            <el-table-column prop="value_a" class-name="c7-table-value"> </el-table-column>
            <el-table-column prop="attribute_b" width="180"> </el-table-column>
            <el-table-column prop="value_b" class-name="c7-table-value"> </el-table-column>
          </el-table>
        </el-row>
        <el-row>
          <el-button type="primary" @click="doInformTakeout" :loading="confirm.loading"> Confirmar retirada </el-button>
          <el-button type="text info" @click="showConfirm = false"> Cancelar </el-button>
        </el-row>
      </template>

      <!-- Confirmar devolução -->
      <template v-else-if="confirm.action === 'devolution'">
        <el-row>
          <p>Ao confirmar a devolução da carreta pelo locatário, será enviada uma mensagem a este confirmando a devolução. <strong>Atenção:</strong> esta ação não poderá ser revertida.</p>
        </el-row>
        <el-row>
          <app-card :product="order.product" extra-class="-flat" process="only-view" />
        </el-row>
        <el-row>
          <el-table :data="orderTableData" :show-header="false" style="width: 100%">
            <el-table-column prop="attribute_a" width="180"> </el-table-column>
            <el-table-column prop="value_a" class-name="c7-table-value"> </el-table-column>
            <el-table-column prop="attribute_b" width="180"> </el-table-column>
            <el-table-column prop="value_b" class-name="c7-table-value"> </el-table-column>
          </el-table>
        </el-row>
        <el-row>
          <el-button type="primary" @click="doDevolution" :loading="confirm.loading"> Confirmar a devolução </el-button>
          <el-button type="text info" @click="showConfirm = false"> Cancelar </el-button>
        </el-row>
      </template>

      <!-- Confirmar envio de avaliação de usuário -->
      <template v-else-if="confirm.action === 'rating'">
        <el-row>
          <p>Por favor, confirme o envio da seguinte avaliação. <strong>Atenção:</strong> esta ação não poderá ser revertida.</p>
        </el-row>
        <el-row>
          <app-rate-user v-if="rating" :user="order.user" profile="tenant" :is-rateable="false" :rating="rating" view-type="full-preview" />
        </el-row>
        <el-row>
          <el-button type="primary" @click="doRating" :loading="confirm.loading"> Enviar avaliação do locatário </el-button>
          <el-button type="text info" @click="confirm.show = false"> Cancelar </el-button>
        </el-row>
      </template>

    </el-dialog>

    <app-modal-manage-addresses @define-address="defineAddress" />
  </div>
</template>

<script>
import Vue from 'vue'
import { errorsMixin } from '@/mixins'
import { floatFormatted } from '@/utils/helpers'

import AppAlert from '@/components/AppAlert'
import AppCard from '@/components/AppCard'
import AppCardCheckout from '@/components/AppCardCheckout'
import AppCardDetails from '@/components/AppCardDetails'
import AppModalManageAddresses from '@/components/AppModalManageAddresses'
import AppOrderMessage from '@/components/AppOrderMessage'
import AppProfile from '@/components/AppProfile'
import AppRateUser from '@/components/AppRateUser'
import AppTimeline from '@/components/AppTimeline'

const defaultConfirm = {
  show: false, // mostra o modal de confirmação
  title: '', // título do modal de confirmação
  action: '', // ação que determinará o conteúdo do modal a ser apresentado
  easyClose: true, // se true permitirá que o usuário feche o modal clicando fora dele
  loading: false, // se true, mostrará um looper no botão
  class: '', // classes extras no modal
}

export default {
  layout: 'inner',
  head: {
    bodyAttrs: {
      class: '-locator',
    }
  },

  mixins: [ errorsMixin ],

  head: {
    bodyAttrs: {
      class: '-locator',
    }
  },

  meta: {
    breadcrumb: [
      { name: 'Locador', path: '/locador' },
      { name: 'Minhas Locações', path: '/locador/locacoes' },
      { name: 'Pedido detalhes' , path: '#' },
    ]
  },

  components: {
    AppAlert,
    AppCard,
    AppCardCheckout,
    AppCardDetails,
    AppModalManageAddresses,
    AppOrderMessage,
    AppProfile,
    AppRateUser,
    AppTimeline,
  },

  data() {
    return {
      confirm: Object.assign({}, defaultConfirm),
      orderTableData: [],
      ordersOverlapping: [],
      rating: null,
    }
  },

  asyncData (context) {
    return context.app.$axios.$get(`locator/order/${context.params.order_id}`)
      .then(data => {
        return {
          order: data.order,
          overlapping: data.overlapping,
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  created() {
      this.orderTableData = [
        {
          attribute_a: 'Data de retirada', value_a: this.order.date_start,
          attribute_b: 'Data de entrega', value_b: this.order.date_end,
        },
        {
          attribute_a: 'Total de dias', value_a: `${this.order.days_total} dias`,
          attribute_b: 'Valor total da locação', value_b: `R$ ${this.order.price_total_formatted}`,
        },
      ]
  },

  methods: {
    changeStatus(status) {
      this.order.status = status
    },

    doAction(action) {
      switch (action) {
        case 'primary': // Ação primária emitida pelo app-order-message
          this.actionPrimary()
          break
        case 'secondary': // Ação secundária emitida pelo app-order-message
          this.actionSecondary()
          break
        case 'confirm': // Confirmar autorização do pedido de reserva
          this.doConfirmation()
          break
        case 'refuse': // Recusar o pedido de reserva
          this.doRefuse()
          break
        case 'confirm-devolution':
          this.confirmConfirmDevolution()
          break
      }
    },

    actionPrimary() {
      switch(this.order.status) {
        case 'pending-confirmation':
          this.setConfirm({ show: true, title: 'Autorizar o pedido de reserva', action: 'confirm' })
          break
        case 'pending-takeout':
          this.setConfirm({ show: true, title: 'A carreta foi retirada pelo locatário?', action: 'takeout' })
          break
        case 'active':
          this.confirmConfirmDevolution()
          break
      }
    },

    actionSecondary() {
      switch(this.order.status) {
        case 'pending-confirmation':
          this.setConfirm({ show: true, title: 'Recusar o pedido de reserva', action: 'refuse' })
          break
        case 'pending-payment':
          break
      }
    },

    // AVALIAÇÃO LOCATÁRIO
    setRating(rating) {
      this.rating = rating
      this.askRating()
    },

    askRating () {
      this.setConfirm({ show: true, title: 'Confirme a avaliação do Locatário', action: 'rating'})
    },

    doRating () {
      this.confirm.loading = true
      this.$axios.$post(`locator/order/${this.order.id}/rate-tenant`, this.rating)
        .then(
          response => {
            this.order.ratings.push(response)
            this.$refs.formAlert.showAlert({ type: 'success', title: 'Avaliação enviada com sucesso', description: 'O locatário será informado do envio da sua avaliação, assim que esta for aprovada.' })
          },
          error => {
            this.errorsAlert(error)
          }
        )

      this.setConfirm({ show: false, loading: false })
    },

    doConfirmation() {
      this.confirm.loading = true
      this.$axios.$put(`locator/order/${this.order.id}/confirm`)
        .then(
          response => {
            this.confirm.loading = false
            this.order = response
            this.$refs.formAlert.showAlert({ type: 'success', title: 'Sucesso', description: 'O pedido de locação foi autorizado com sucesso. E informamos ao locatário para efetuar o pagamento.' })
          },
          error => {
            this.confirm.loading = false
            this.errorsAlert(error)
          }
        )
      this.confirm.show = false
    },

    doRefuse() {
      this.confirm.loading = true
      this.$axios.$put(`locator/order/${this.order.id}/refuse`)
        .then(
          response => {
            this.confirm.loading = false
            this.order = response
            this.$refs.formAlert.showAlert({ type: 'success', title: 'Sucesso', description: 'O pedido de locação foi recusado com sucesso. E informamos ao locatário sobre a recusa do pedido de reserva.' })
          },
          error => {
            this.confirm.loading = false
            this.errorsAlert(error)
          }
        )
      this.confirm.show = false
    },

    doInformTakeout() {
      this.confirm.loading = true
      this.$axios.$put(`locator/order/${this.order.id}/takeout`)
        .then(
          response => {
            Vue.set(this.order, 'locator_takeout_informed', true)
            this.$refs.formAlert.showAlert({ type: 'success', title: 'Sucesso', description: 'Foi solicitada uma confirmação da retirada da carreta ao Locatário. Informaremos a você quando houver a confirmação.' })
            this.updateOrderMessages()
          },
          error => {
            this.errorsAlert(error)
          }
        )
      this.confirm.loading = false
      this.confirm.show = false
    },

    confirmConfirmDevolution() {
      this.setConfirm({ show: true, title: 'A carreta foi devolvida pelo locatário?', action: 'devolution' })
    },
    doDevolution() {
      this.confirm.loading = true
      this.$axios.$put(`locator/order/${this.order.id}/devolution`)
        .then(
          response => {
            this.order = response
            this.$refs.formAlert.showAlert({ type: 'success', title: 'Devolução da carreta confirmada', description: 'O locatário foi informado sobre este confirmação de devolução.' })
            this.updateOrderMessages()
          },
          error => {
            this.errorsAlert(error)
          }
        )
      this.confirm.loading = false
      this.confirm.show = false
    },

    defineAddress(address) {
      this.$axios.$put(`locator/order/${this.order.id}/change-address`, { address_id: address.id })
        .then(
          response => {
            Vue.set(this.order, 'address', address)
            this.$store.dispatch('events/cleanModal')
          },
          error => {
            this.errorsAlert(error)
          })
    },

    setConfirm (params) {
      this.confirm = {...defaultConfirm, ...params}
    },

    updateOrderMessages() {
      setTimeout(() => {
        this.$refs.appOrderMessage.setMessages()
      }, 50)
    },
  }
}

</script>

<style lang="scss">
  .el-table .c7-table-value {
    font-weight: bold;
  }

  .inner-left .item {
    margin-bottom: 3rem;
  }
</style>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }
</style>