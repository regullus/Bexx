<template>
  <div class="inner-wrapper">
    <div class="container -column">
      <h2 class="profile-title -locator">Pedido de locação #{{ order.id }} - {{ order.order_date }} - Mensagens</h2>
    </div>
    <div class="container">

      <div class="inner-left">
        <app-chat :order="order" profile="locator" />
      </div>
      <div class="inner-right">
        <div class="inner-sidebar">
          <div class="sidebar-item">
            <app-card-checkout
              :order="order"
              :show-header="false"
              profile="locator"
              />
          </div>
          <div class="sidebar-item">
            <app-profile :user="order.user" profile="tenant" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import AppCardCheckout from '@/components/AppCardCheckout'
import AppChat from '@/components/AppChat'
import AppProfile from '@/components/AppProfile'

export default {
  layout: 'inner',

  head: {
    bodyAttrs: {
      class: '-locator',
    }
  },

  meta: {
    breadcrumb: [
      { name: 'Locador', path: '/locador' },
      { name: 'Minhas locações', path: '/locador/locacoes' },
      { name: 'Detalhes do pedido' , path: '/locador/locacoes/[order_id]' },
      { name: 'Mensagens' , path: '#' },
    ]
  },

  components: {
    AppCardCheckout,
    AppChat,
    AppProfile,
  },

  data() {
    return {

    }
  },

  asyncData (context) {
    return context.app.$axios.$get(`locator/order/${context.params.order_id}/messages`)
      .then(data => {
        return {
          order: data,
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }
</style>