<template>
  <div>
    <h2 class="profile-title -locator">Perguntas recebidas</h2>
    <div class="inner-panel">
      <app-questions-item v-for="(question, index) in questions" :question="question" :productUid="question.product.uid" type="view-locator" :key="`question-${index}`" @update-question="onUpdateQuestion" />
      <el-alert v-if="!questions.length" type="info" title="Você ainda não recebeu perguntas sobre as suas carretas." show-icon :closable="false"></el-alert>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'
import AppQuestionsItem from '@/components/AppQuestionsItem'

export default {
  layout: 'panel',
  head: {
    bodyAttrs: {
      class: '-locator',
    }
  },

  components: {
    AppQuestionsItem,
  },

  async asyncData (context) {
    return context.app.$axios.$get(`locator/products/messages`)
      .then(data => {
        return {
          questions: data,
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  methods: {
    onUpdateQuestion(question) {
      let index = _.findIndex(this.questions, q => q.id === question.id)
      Vue.set(this.questions, index, question)
    }
  }

}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }
</style>
