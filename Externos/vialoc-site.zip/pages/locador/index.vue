<template>
  <div>
    <div class="dash -locator">
      <el-menu :default-active="activeIndex" class="dash-menu" mode="horizontal">
        <el-menu-item index="locator">Painel Locador</el-menu-item>
        <el-menu-item index="tenant"><nuxt-link to="/locatario">Painel Locatário</nuxt-link></el-menu-item>
      </el-menu>
      <div class="dash-wrp">
        <div class="dash-ctn">
          <div class="dash-row -inline">
            <app-dash-questions profile="locator" :counter="questions_unanswered"/>
            <app-dash-messages profile="locator" :counter="orders_messages_unread"/>
          </div>
          <div class="dash-row">
            <app-dash-orders profile="locator" subject="unconfirmed" :orders="orders_unconfirmed" :counter="orders_unconfirmed_count"/>
          </div>
          <div class="dash-row">
            <app-dash-orders profile="locator" subject="takeout" :orders="orders_takeout" :counter="orders_takeout_count"/>
          </div>
          <div class="dash-row">
            <app-dash-orders profile="locator" subject="finishing" :orders="orders_finishing" :counter="orders_finishing_count"/>
          </div>
        </div>
        <div class="dash-sidebar">
          <div class="dash-item">
            <h2 class="title">
              <svg-alert class="icon dash-color" width="18" height="18"/>
              Notificações
            </h2>
            <app-notes placement="panel" profile="locator"/>
          </div>
        </div>
      </div>
    </div>
    <!-- DASH -->
  </div>
</template>

<script>

import _ from 'lodash'
import AppDashMessages from '@/components/AppDashMessages'
import AppDashOrders from '@/components/AppDashOrders'
import AppDashQuestions from '@/components/AppDashQuestions'
import AppNotes from '@/components/AppNotes'
import SvgAlert from '@/assets/svg/alert.svg?inline'

export default {
  layout: 'panel',
  middleware: ['auth', 'check-auth'],

  head: {
    bodyAttrs: {
      class: '-locator',
    }
  },

  meta: {
    breadcrumb: [
      { name: 'Locador', path: '#' },
    ]
  },

  components: {
    AppDashMessages,
    AppDashOrders,
    AppDashQuestions,
    AppNotes,
    SvgAlert,
  },

  data() {
    return {
      activeIndex: 'locator',
    };
  },

  async asyncData (context) {
    return context.app.$axios.$get(`locator/dashboard`)
      .then(data => {
        return {
          orders_messages_unread: data.orders_messages_unread,
          orders_unconfirmed: data.orders_unconfirmed,
          orders_unconfirmed_count: data.orders_unconfirmed_count,
          orders_takeout: data.orders_takeout,
          orders_takeout_count: data.orders_takeout_count,
          orders_finishing: data.orders_finishing,
          orders_finishing_count: data.orders_finishing_count,
          questions_unanswered: data.questions_unanswered,
        }
      })
      .catch(e => context.error(e.response.data.message))
  },
}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }
</style>


