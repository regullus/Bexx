<template>
  <div>
      <div>
        <div class="inner-form">
          <div class="header">
            <h2 class="profile-title -locator">Minhas carretas</h2>
            <h3 class="inner-title">
              Editar carreta: {{ product.name }}
              <el-popover placement="top" width="360" v-model="productPublishPopover">
                <div v-if="product.status === 'draft'">
                  <div v-if="!product.is_complete">  <!-- Carreta em rascunho e incompleta -->
                    <p>Para publicar a sua carreta, você precisa:</p>
                    <ul>
                      <li>Definir as informações básicas da sua carreta.</li>
                      <li>Definir as informações adicionais da sua carreta.</li>
                      <li>Cadastrar ao menos um valor de locação para a sua carreta.</li>
                      <li>Cadastrar as imagens das vistas da sua carreta.</li>
                    </ul>
                  </div>
                  <div v-else>  <!-- Carreta em rascunho e completa -->
                    <p>Sua carreta está pronta para ser publicada.</p>
                    <p>Assim que publicar, a sua carreta ficará disponível publicamente para locação.</p>
                    <p><strong>Deseja publicar esta carreta?</strong></p>
                    <div style="text-align: right; margin: 0">
                      <el-button size="mini" type="text" @click="productPublishPopover = false">Cancelar</el-button>
                      <el-button type="primary" size="mini" @click="setProductStatus('active')">Sim, publicar esta carreta</el-button>
                    </div>
                  </div>
                </div>
                <div v-else-if="product.status === 'active'"> <!-- Carreta publicada -->
                  <p>Atualmente, sua carreta está <strong>ativa</strong> e disponível para locação.</p>
                  <p>Se por algum motivo deseja ocultar esta carreta, por favor utilize a opção abaixo.</p>
                  <p><strong>Deseja inativar esta carreta?</strong></p>
                  <p><em>Atenção: uma carreta inativa não receberá propostas de locação.</em></p>
                  <div style="text-align: right; margin: 0">
                    <el-button size="mini" type="text" @click="productPublishPopover = false">Cancelar</el-button>
                    <el-button type="danger" size="mini" @click="setProductStatus('inactive')">Sim, inativar esta carreta</el-button>
                  </div>
                </div>
                <div v-else-if="product.status === 'inactive'"> <!-- Carreta inativa -->
                  <p>Atualmente, sua carreta está <strong>inativa</strong> e não está acessível ao público.</p>
                  <p>Caso deseje ativar esta carreta, por favor utilize a opção abaixo.</p>
                  <p><strong>Deseja reativar a sua carreta?</strong></p>
                  <div style="text-align: right; margin: 0">
                    <el-button size="mini" type="text" @click="productPublishPopover = false">Cancelar</el-button>
                    <el-button type="primary" size="mini" @click="setProductStatus('active')">Sim, reativar esta carreta</el-button>
                  </div>
                </div>
                <el-button plain :type="productPublishButton.color" size="small" :icon="productPublishButton.icon" slot="reference">{{ productPublishButton.label }}</el-button>
              </el-popover>
            </h3>
            <app-card :product="product" extra-class="-flat" process="owner" />
          </div>

          <el-tabs type="card" v-if="product" @tab-click="tabActions">
            <app-alert ref="formAlert"/>

            <!-- Step 1 -->
            <el-tab-pane label="Informações básicas" data-tab-form="Step1">
              <el-form :model="product" :rules="step1Rules" ref="formStep1" class="el-form--label-top -step-1">
                <el-col :span="16">
                  <div class="form-sec">
                    <h4 class="form-title">Informações sobre sua carreta</h4>
                    <el-row :gutter="10">
                      <el-col :span="24">
                        <el-form-item label="Crie um nome para esta carreta" prop="name">
                          <el-input v-model="product.name"></el-input>
                        </el-form-item>
                      </el-col>
                    </el-row>
                    <el-row :gutter="10">
                      <el-col :span="12">
                        <el-form-item label="Fabricante" prop="brand_id">
                          <el-select v-model="product.brand_id">
                            <el-option v-for="brand in formEl.brands" :key="'brand-' + brand.id" :label="brand.name" :value="brand.id"></el-option>
                          </el-select>
                        </el-form-item>
                      </el-col>
                      <el-col :span="12">
                        <el-form-item label="Tipo" prop="type">
                          <el-select v-model="product.type">
                            <el-option v-for="(value, key) in formEl.types" :key="'type-' + key" :label="value" :value="key"></el-option>
                          </el-select>
                        </el-form-item>
                      </el-col>
                    </el-row>
                    <el-row :gutter="10">
                      <el-col :span="8">
                        <el-form-item label="Ano" prop="year">
                          <el-input type="tel" v-model="product.year" v-mask="'####'" key="product.year"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span="8">
                        <el-form-item label="Modelo" prop="model">
                          <el-input v-model="product.model"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span="8">
                        <el-form-item label="Eixos" prop="axes">
                          <el-input v-model="product.axes" number></el-input>
                        </el-form-item>
                      </el-col>
                    </el-row>
                    <el-row :gutter="10">
                      <el-col :span="6">
                        <el-form-item label="Comprimento (m)" prop="length">
                          <el-input type="tel" v-model.lazy="product.length" v-money="moneyFormat"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span="6">
                        <el-form-item label="Largura (m)" prop="width">
                          <el-input type="tel" v-model.lazy="product.width" v-money="moneyFormat"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span="6">
                        <el-form-item label="Altura (m)" prop="height">
                          <el-input type="tel" v-model.lazy="product.height" v-money="moneyFormat"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span="6">
                        <el-form-item label="Cubagem (m³)" prop="cubing">
                          <el-input type="tel" v-model.lazy="product.cubing" v-money="moneyFormat"></el-input>
                        </el-form-item>
                      </el-col>
                    </el-row>
                    <el-row :gutter="10">
                      <el-col :span="8">
                        <el-form-item label="Assoalho" prop="floor">
                          <el-select v-model="product.floor">
                            <el-option v-for="(value, key) in formEl.floors" :key="'floor-' + key" :label="value" :value="key"></el-option>
                          </el-select>
                        </el-form-item>
                      </el-col>
                      <el-col :span="8">
                        <el-form-item label="Suspensão" prop="suspension">
                          <el-select v-model="product.suspension">
                            <el-option v-for="(value, key) in formEl.suspensions" :key="'suspension-' + key" :label="value" :value="key"></el-option>
                          </el-select>
                        </el-form-item>
                      </el-col>
                      <el-col :span="8">
                        <el-form-item label="Pneus" prop="with_tires">
                          <el-checkbox v-model="product.with_tires">Pneus incluídos</el-checkbox>
                        </el-form-item>
                      </el-col>
                    </el-row>
                  </div>
                  <div class="form-sec">
                    <h4 class="form-title">Localização da sua carreta</h4>

                    <p>Caso queira utilizar outro endereço já cadastrado ou adicionar um novo, clique em "Alterar o endereço":</p>
                    <app-card-address :address="product.address"></app-card-address>
                    <el-button size="mini" type="info" plain @click="openModalManageAddresses">Alterar o endereço</el-button>
                  </div>
                  <div class="form-sec">
                    <h4 class="form-title">Descreva a sua carreta</h4>
                    <p>
                      Elabore uma descrição detalhada da sua carreta e aumente suas chances de locação.
                    </p>
                    <div class="form-example">
                      <el-button size="mini" type="info" plain @click.stop="show_content_example = !show_content_example">Veja um exemplo</el-button>
                      <el-card class="form-desc" :class="{ '-active': show_content_example }">
                        - Contrato mínimo de 4 meses.<br/>
                        - Pessoa jurídica ou física.<br/>
                        - Sem pneus. Consulte-nos para locação com pneus.<br/><br/>

                        <strong>Informações técnicas</strong><br/><br/>

                        Para 26 paletes 1.050mm x 1.250mm invertidos.<br/>
                        Altura interna: 2.700mm.<br/>
                        Laterais: lona vinílica reforçada, sustentada por rodízios e tracionada longitudinalmente pela dianteira e vertical por catracas de polietileno.<br/><br/>

                        O assoalho do semirreboque sider é fabricado em chapa de aço xadrez 4.75mm, para resistir ao trânsito de empilhadeiras com até 950 kg por ponto de apoio.<br/><br/>

                        A porta traseira do sider possui revestimento externo em chapa de aço lisa, pré-pintada na cor branca.. A porta possui travas com espera para  cadeado com varões de travamento. Com abertura translúcida, que facilita a dissipação de calor e permite aproveitamento de iluminação interna, o teto é encaixado por um sistema hermético, sem a utilização de rebites, que confere ao conjunto maior resistência e menor manutenção.
                      </el-card>
                    </div>
                    <el-form-item label="Descrição" prop="content">
                      <el-input type="textarea" v-model="product.content" :autosize="{ minRows: 6 }"></el-input>
                    </el-form-item>
                  </div>
                  <div class="form-sec">
                    <el-form-item>
                      <el-button type="primary" @click="onSubmit('Step1')" class="el-button--block">Salvar as alterações</el-button>
                    </el-form-item>
                  </div>
                </el-col>
              </el-form>
            </el-tab-pane>
            <!-- / Step 1 -->

            <!-- Step 2 -->
            <el-tab-pane label="Informações Adicionais" data-tab-form="Step2">
              <el-form :model="product" :rules="step2Rules" ref="formStep2" class="el-form--label-top -step-2">
                <el-col :span="16">
                  <div class="form-sec">
                    <h4 class="form-title">Dados do Proprietário da Carreta</h4>
                    <el-row :gutter="10">
                      <el-col :span="12">
                        <el-form-item label="Nome completo / Razão Social" prop="owner_name">
                          <el-input v-model="product.owner_name"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span="12">
                        <el-form-item label="CPF/CNPJ" prop="owner_cpf_cnpj" v-mask="['###.###.###-##', '##.###.###/####-##']">
                          <el-input v-model="product.owner_cpf_cnpj"></el-input>
                        </el-form-item>
                      </el-col>
                    </el-row>
                  </div>

                  <div class="form-sec">
                    <h4 class="form-title">Dados da Carreta</h4>
                    <el-row :gutter="10">
                      <el-col :span="8">
                        <el-form-item label="Placa" prop="license_plate">
                          <el-input v-model="product.license_plate" v-mask="'AAA-#X##'" maxlength="8"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span="8">
                        <el-form-item label="Chassi" prop="chassis">
                          <el-input v-model="product.chassis"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span="8">
                        <el-form-item label="Renavam" prop="renavam">
                          <el-input v-model="product.renavam"></el-input>
                        </el-form-item>
                      </el-col>
                    </el-row>
                    <el-row :gutter="10">
                      <el-col :span="12">
                        <el-form-item label="ANTT" prop="antt">
                          <el-input v-model="product.antt"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span="12">
                        <el-form-item label="Licenciamento (mm/aaaa)" prop="licensing">
                          <el-input v-model="product.licensing" v-mask="'##/####'"></el-input>
                        </el-form-item>
                      </el-col>
                    </el-row>
                  </div>
                  <div class="form-sec">
                    <h4 class="form-title">Documentos</h4>
                    <el-form-item label="Imagem da CRLV da Carreta">
                      <el-upload class="c7-imgbox-uploader" action="/" :show-file-list="false" :before-upload="beforeCrlvUpload">
                        <img v-if="doc_crlv" :src="doc_crlv" class="c7-imgbox">
                        <i v-else class="el-icon-plus c7-imgbox-uploader-icon"></i>
                      </el-upload>
                    </el-form-item>
                  </div>

                  <div class="form-sec">
                    <el-form-item>
                      <el-button type="primary" @click="onSubmit('Step2')" class="el-button--block">Salvar as alterações</el-button>
                    </el-form-item>
                  </div>
                </el-col>
              </el-form>
            </el-tab-pane>
            <!-- / Step 2 -->

            <!-- Step 3 -->
            <el-tab-pane label="Valores" data-tab-form="Step3">
              <el-form :model="product" :rules="step3Rules" ref="formStep3" class="el-form--label-top -step-3">
                <el-col :span="24">
                  <div class="form-steps -step-3">
                    <div class="form-sec">
                      <h4 class="form-title">Valor do aluguel da sua carreta</h4>
                      <div v-if="!product.prices.length">
                        <p>Você ainda não cadastrou os preços para esta carreta.</p>
                      </div>
                      <div>
                        <el-row :gutter="10" class="c7-list-head">
                          <el-col :span="9"><h6 class="c7-list-head-title">Valor por dia</h6></el-col>
                          <el-col :span="5"><h6 class="c7-list-head-title">Preço a partir de</h6></el-col>
                          <el-col :span="10"><h6 class="c7-list-head-title">Valor do período</h6></el-col>
                        </el-row>
                        <el-row :gutter="10" v-for="(price, index) in product.prices" :key="'product-price-' + index">
                          <el-col :span="9">
                            <el-form-item prop="prices.price_per_day_formatted">
                              <el-input v-model="price.price_per_day_formatted" v-money="moneyFormat" @blur="setPrice(price)">
                                <template slot="prepend">
                                  R$
                                </template>
                                <template slot="append">/dia</template>
                              </el-input>
                            </el-form-item>
                          </el-col>
                          <el-col :span="5">
                            <el-form-item prop="prices.more_than">
                              <el-input type="number" v-model="price.more_than" number min="1" readonly class="c7-input-disabled" >
                                <template slot="append">
                                  <span v-if="index === 0 && price.more_than === 1">dia</span>
                                  <span v-else>dias</span>
                                </template>
                              </el-input>
                            </el-form-item>
                          </el-col>
                          <el-col :span="10">
                            <el-form-item prop="prices.price_period_formatted">
                              <el-input v-model="price.price_period_formatted" readonly class="c7-input-disabled">
                                <template slot="prepend">
                                  <el-popover placement="top" width="240" v-model="price['popover-info-' + index]">
                                    <div v-html="getMonthlyValue(price)"></div>
                                    <span class="el-icon-info" slot="reference" @click="price['popover-info-' + index] = true"></span>
                                  </el-popover> &nbsp;
                                  R$
                                </template>
                              </el-input>
                            </el-form-item>
                          </el-col>
                          <!--
                          <el-col :span="2">
                            <el-popover placement="top" width="240" v-model="price['popover-' + index]" v-if="index !== 0 && price.more_than > 1">
                              <p>Deseja realmente remover este valor?</p>
                              <div style="text-align: right; margin: 0">
                                <el-button size="mini" type="text" @click="price['popover-' + index] = false">Cancelar</el-button>
                                <el-button type="primary" size="mini" @click="removePrice(index)">Sim</el-button>
                              </div>
                              <el-button slot="reference" type="danger" icon="el-icon-delete" @click="price['popover-' + index] = true" plain circle></el-button>
                            </el-popover>
                          </el-col>
                          -->
                        </el-row>
                      </div>
                    </div>
                  </div>

                  <!--
                  <div class="form-sec">
                    <el-form-item>
                      <el-button type="primary" @click="addPrice()" class="el-button" plain>Adicionar preço</el-button>
                      <el-button v-if="product.prices.length > 1" type="info" @click="orderPrices()" class="el-button" plain>Ordenar preços</el-button>
                    </el-form-item>
                  </div>
                 -->

                  <div class="form-sec">
                    <el-form-item>
                      <el-button type="primary" @click="onSubmit('Step3')" class="el-button--block">Salvar as alterações</el-button>
                    </el-form-item>
                  </div>
                </el-col>
              </el-form>
            </el-tab-pane>
            <!-- / Step 3 -->

            <!-- Step 4 -->
            <el-tab-pane label="Imagens e vídeo" data-tab-form="Step4">
              <el-form :model="product" :rules="step4Rules" ref="formStep4" class="el-form--label-top -step-4">
                <el-col :span="24">
                  <div class="form-sec">
                    <h4 class="form-title">Adicione até 5 fotos da sua carreta</h4>
                    <p>Boas imagens valorizam sua carreta! Não inclua logos, banners, textos promocionais, bordas nem marcas d’água.</p>

                    <el-upload
                      v-if="product.images.length < 5"
                      multiple
                      drag
                      action="/"
                      :class="'c7-upload-full'"
                      :show-file-list="false"
                      :before-upload="beforeImageUpload">
                      <i class="el-icon-upload"></i>
                      <div class="el-upload__text">Arraste as imagens para cá ou <em>clique para fazer o envio</em></div>
                    </el-upload>

                    <p v-if="product.images.length">Arraste as suas fotos para organizá-las.</p>

                    <Container v-if="product.images.length" @drop="onImageDrop" class="c7-sortable" :orientation="'horizontal'">
                      <Draggable v-for="image in product.images" :key="`product-image-${image.id}`" :class="'thumb'" :style="`background-image: url(${documentBaseUrl}/${image.metadata.thumbnails.default.path})`">
                        <app-image-upload-overlay :product-featured-image="product.featured_image" :image="image" type="image" @set-featured-image="setFeaturedImage" @remove-image="removeImage" @preview-image="previewImage"/>
                      </Draggable>
                    </Container>

                    <h5 class="form-title">Imagens das vistas da carreta <small>(obrigatório)</small></h5>

                    <div class="c7-form-upload">
                      <el-upload
                        drag
                        action="/"
                        :class="'c7-upload'"
                        :show-file-list="false"
                        :before-upload="beforeImageViewUploadLeft">
                          <div class="c7-view-image wrp-image" v-if="viewImageLeft">
                            <img :src="`${documentBaseUrl}/${viewImageLeft.metadata.thumbnails.default.path}`" alt="Vista lateral esquerda">
                            <app-image-upload-overlay :product-featured-image="product.featured_image" :image="viewImageLeft" title="Vista lateral esquerda" type="view-image" @set-featured-image="setFeaturedImage" @remove-image="removeImage" @preview-image="previewImage"/>
                          </div>
                          <div class="wrp" v-else>
                            <div class="title">Vista lateral esquerda</div>
                            <div class="img"><img src="~assets/images/truck-left.png"/></div>
                            <div class="bottom">
                              <i class="el-icon-upload"></i>
                              <div class="el-upload__text">Arraste as imagens para cá ou <br/><em>clique para fazer o envio</em></div>
                            </div>
                          </div>
                      </el-upload>

                      <el-upload
                        drag
                        action="/"
                        :class="'c7-upload'"
                        :show-file-list="false"
                        :before-upload="beforeImageViewUploadFront">
                          <div class="c7-view-image wrp-image" v-if="viewImageFront">
                            <img :src="`${documentBaseUrl}/${viewImageFront.metadata.thumbnails.default.path}`" alt="Vista frontal">
                            <app-image-upload-overlay :product-featured-image="product.featured_image" :image="viewImageFront" title="Vista frontal" type="view-image" @set-featured-image="setFeaturedImage" @remove-image="removeImage" @preview-image="previewImage"/>
                          </div>
                          <div class="wrp" v-else>
                            <div class="title">Vista Frontal</div>
                            <div class="img"><img src="~assets/images/truck-front.png"/></div>
                            <div class="bottom">
                              <i class="el-icon-upload"></i>
                              <div class="el-upload__text">Arraste as imagens para cá ou <br/><em>clique para fazer o envio</em></div>
                            </div>
                          </div>
                      </el-upload>

                      <el-upload
                        drag
                        action="/"
                        :class="'c7-upload'"
                        :show-file-list="false"
                        :before-upload="beforeImageViewUploadRight">
                          <div class="c7-view-image wrp-image" v-if="viewImageRight">
                            <img :src="`${documentBaseUrl}/${viewImageRight.metadata.thumbnails.default.path}`" alt="Vista lateral direita">
                            <app-image-upload-overlay :product-featured-image="product.featured_image" :image="viewImageRight" title="Vista lateral direita" type="view-image" @set-featured-image="setFeaturedImage" @remove-image="removeImage" @preview-image="previewImage"/>
                          </div>
                          <div class="wrp" v-else>
                            <div class="title">Vista lateral direita</div>
                            <div class="img"><img src="~assets/images/truck-right.png"/></div>
                            <div class="bottom">
                              <i class="el-icon-upload"></i>
                              <div class="el-upload__text">Arraste as imagens para cá ou <br/><em>clique para fazer o envio</em></div>
                            </div>
                          </div>
                      </el-upload>

                      <el-upload
                        drag
                        action="/"
                        :class="'c7-upload'"
                        :show-file-list="false"
                        :before-upload="beforeImageViewUploadInterior">
                          <div class="c7-view-image wrp-image" v-if="viewImageInterior">
                            <img :src="`${documentBaseUrl}/${viewImageInterior.metadata.thumbnails.default.path}`" alt="Vista interior">
                            <app-image-upload-overlay :product-featured-image="product.featured_image" :image="viewImageInterior" title="Vista interior" type="view-image" @set-featured-image="setFeaturedImage" @remove-image="removeImage" @preview-image="previewImage"/>
                          </div>
                          <div class="wrp" v-else>
                            <div class="title">Vista interior</div>
                            <div class="img"><img src="~assets/images/truck-interior.png"/></div>
                            <div class="bottom">
                              <i class="el-icon-upload"></i>
                              <div class="el-upload__text">Arraste as imagens para cá ou <br/><em>clique para fazer o envio</em></div>
                            </div>
                          </div>
                      </el-upload>

                      <el-upload
                        drag
                        action="/"
                        :class="'c7-upload'"
                        :show-file-list="false"
                        :before-upload="beforeImageViewUploadBack">
                          <div class="c7-view-image wrp-image" v-if="viewImageBack">
                            <img :src="`${documentBaseUrl}/${viewImageBack.metadata.thumbnails.default.path}`" alt="Vista traseira">
                            <app-image-upload-overlay :product-featured-image="product.featured_image" :image="viewImageBack" title="Vista traseira" type="view-image" @set-featured-image="setFeaturedImage" @remove-image="removeImage" @preview-image="previewImage"/>
                          </div>
                          <div class="wrp" v-else>
                            <div class="title">Vista traseira</div>
                            <div class="img"><img src="~assets/images/truck-back.png"/></div>
                            <div class="bottom">
                              <i class="el-icon-upload"></i>
                              <div class="el-upload__text">Arraste as imagens para cá ou <br/><em>clique para fazer o envio</em></div>
                            </div>
                          </div>
                      </el-upload>

                      <el-upload
                        drag
                        action="/"
                        :class="'c7-upload'"
                        :show-file-list="false"
                        :before-upload="beforeImageViewUploadAxes">
                          <div class="c7-view-image wrp-image" v-if="viewImageAxes">
                            <img :src="`${documentBaseUrl}/${viewImageAxes.metadata.thumbnails.default.path}`" alt="Eixos">
                            <app-image-upload-overlay :product-featured-image="product.featured_image" :image="viewImageAxes" title="Eixos" type="view-image" @set-featured-image="setFeaturedImage" @remove-image="removeImage" @preview-image="previewImage"/>
                          </div>
                          <div class="wrp" v-else>
                            <div class="title">Eixos</div>
                            <div class="img"><img src="~assets/images/truck-axes.png"/></div>
                            <div class="bottom">
                              <i class="el-icon-upload"></i>
                              <div class="el-upload__text">Arraste as imagens para cá ou <br/><em>clique para fazer o envio</em></div>
                            </div>
                          </div>
                      </el-upload>
                    </div>

                  </div>
                </el-col>
                <el-col :span="16">
                  <div class="form-sec">
                    <h4 class="form-title">Adicione um vídeo</h4>
                    <el-form-item label="Link do Vídeo (Youtube/Vimeo):" prop="link_video">
                      <el-input v-model="product.link_video"></el-input>
                    </el-form-item>
                    <div v-if="product.link_video" v-html="videoOutput"></div>
                  </div>
                  <div class="form-sec">
                    <el-form-item>
                      <el-button type="primary" @click="onSubmit('Step4')" class="el-button--block">Salvar as alterações</el-button>
                    </el-form-item>
                  </div>
                </el-col>
              </el-form>
            </el-tab-pane>
            <!-- Step 4 -->
          </el-tabs>
        </div>
      </div>
      <el-dialog :visible.sync="imagePreview" width="90%">
        <img width="100%" :src="imagePreviewUrl" alt="Preview da Imagem">
      </el-dialog>
      <app-modal-manage-addresses @define-address="defineAddress" />
  </div>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'
import { mask } from 'vue-the-mask'
import { VMoney } from 'v-money'
import { Container, Draggable } from 'vue-smooth-dnd'
import { applyDrag, floatFormatted, formatted2Float, videoUtils } from '@/utils/helpers'
import { documentImageMixin, errorsMixin } from '@/mixins'

import AppAlert from '@/components/AppAlert'
import AppCard from '@/components/AppCard'
import AppCardAddress from '@/components/AppCardAddress'
import AppImageUploadOverlay from '@/components/AppImageUploadOverlay'
import AppModalManageAddresses from '@/components/AppModalManageAddresses'

const defaultProduct = {
  uid: null,
  name: '',
  content: '',
  link_video: '',
  // city_id: '',
  // state_code: '',
  address_id: null,
  address: {
    label: null,
    zipcode: null,
    address: null,
    address_number: null,
    address_complement: null,
    district: null,
    city_id: null,
    state: null,
  },
  type: '',
  brand_id: null,
  height: null,
  width: null,
  length: null,
  weight: null,
  cubing: null,
  axes: null,
  licensing: '',
  model: '',
  chassis: '',
  renavam: '',
  antt: '',
  owner_name: '',
  owner_cpf_cnpj: '',
  license_plate: '',
  floor: '',
  suspension: '',
  prices: [
    { price_per_day: 0, more_than: 1 },
    { price_per_day: 0, more_than: 7 },
    { price_per_day: 0, more_than: 30 },
  ],
  images: [],
  view_images: [],
  featured_image: null,
  is_complete: false,
}

export default {
  layout: "panel",
  middleware: ['auth', 'check-auth'],
  head: {
    bodyAttrs: {
      class: '-locator',
    }
  },

  directives: {mask, money: VMoney},

  mixins: [documentImageMixin, errorsMixin],

  components: {
    AppAlert,
    Container,
    Draggable,
    AppCard,
    AppCardAddress,
    AppImageUploadOverlay,
    AppModalManageAddresses
  },

  meta: {
    breadcrumb: [
      { name: 'Minhas carretas', path: '/carretas' },
      { name: 'Editar carreta', path: null },
    ]
  },

  data () {
    return {
      show_content_example: false,
      documentBaseUrl: process.env.MEDIA_BASE_URL,
      productPublishPopover: false,
      moneyFormat: {
        decimal: ',',
        thousands: '.',
        // prefix: 'R$ ',
        // suffix: '',
        precision: 2,
        masked: false /* doesn't work with directive */
      },
      imagePreview: false,
      imagePreviewUrl: null,
      doc_crlv: null
    }
  },

  async asyncData (context) {
    // faz as duas requisições simultaneamente
    // let [ addressesData, productData ] = await Promise.all([
    //   context.app.$axios.$get('common/users/addresses'),
    //   context.app.$axios.$get(`product/${context.params.uid}/owner-details`)
    // ])

    // return {
    //   addresses: addressesData,
    //   product: { ...productData, step: 'Step1' },
    // }

    return context.app.$axios.$get(`locator/product/${context.params.uid}/view`)
      .then(data => {
        if (!data.prices.length) {
          data.prices = defaultProduct.prices
        }
        return {
          product: { ...defaultProduct, ...data, step: 'Step1' },
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  mounted () {
    if (this.product.uid) {
      this.getDocumentImage('product', this.product.uid, 'doc_crlv', 'default')
    }
  },

  computed: {
    formEl() {
      return this.$store.state.base.productInfo
    },

    productPublishButton() {
      if (this.product.status === 'draft' && this.product.is_complete) { // em rascunho e completa
        return {
          icon: 'el-icon-upload2',
          color: 'primary',
          label: 'Publicar carreta',
        }
      } else if (this.product.status === 'active') {
        return {
          icon: 'el-icon-circle-check',
          color: 'success',
          label: 'Carreta publicada',
        }
      } else if (this.product.status === 'inactive') {
        return {
          icon: 'el-icon-download',
          color: 'warning',
          label: 'Carreta inativa',
        }
      }

      // em rascunho e incompleta
      return {
        icon: 'el-icon-circle-close',
        color: '',
        label: 'Publicar carreta',
      }
    },

    step1Rules() {
      return {
        name: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        brand_id: [
          {type: 'integer', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        type: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        year: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        model: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        axes: [
          {type: 'integer', required: true, message: 'Preencha este campo com um número', trigger: 'blur'}
        ],
        length: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'},
        ],
        width: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        floor: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        suspension: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        address_id: [
          {type: 'string', required: true, message: 'Você precisa selecionar um endereço ou cadastrar um novo endereço.', trigger: 'blur'}
        ],
        'address.zipcode': [
          {type: 'string', required: !this.product.address_id, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'address.address': [
          {type: 'string', required: !this.product.address_id, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'address.address_number': [
          {type: 'string', required: !this.product.address_id, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'address.district': [
          {type: 'string', required: !this.product.address_id, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'address.city_id': [
          {type: 'integer', required: !this.product.address_id, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        'address.state_code': [
          {type: 'string', required: !this.product.address_id, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        content: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
      }
    },

    step2Rules() {
      return {
        owner_name: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        owner_cpf_cnpj: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        license_plate: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        chassis: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        renavam: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        antt: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        licensing: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
      }
    },

    step3Rules() {
      return {}
    },

    step4Rules() {
      return {}
    },

    videoOutput() {
      if (!this.product.link_video) {
        return ''
      }
      let videoEmbed = videoUtils.embed(this.product.link_video, '100%', '280')
      return videoEmbed
    },

    viewImageLeft() {
      return _.find(this.product.view_images, { 'tag': 'left' })
    },
    viewImageRight() {
      return _.find(this.product.view_images, { 'tag': 'right' })
    },
    viewImageFront() {
      return _.find(this.product.view_images, { 'tag': 'front' })
    },
    viewImageBack() {
      return _.find(this.product.view_images, { 'tag': 'back' })
    },
    viewImageInterior() {
      return _.find(this.product.view_images, { 'tag': 'interior' })
    },
    viewImageAxes() {
      return _.find(this.product.view_images, { 'tag': 'axes' })
    },
  },

  methods: {
    openModalManageAddresses() {
      this.$store.dispatch('events/setModal', { id: 'manage-address' })
    },

    defineAddress(address) {
      Vue.set(this.product, 'address', address)
      Vue.set(this.product, 'address_id', address.id)
      this.$store.dispatch('events/cleanModal')
    },

    getMonthlyValue(price) {
      if (price.price_per_day === '0,00' || price.more_than < 1) {
        return '<p>Você precisa definir um valor válido!</p>'
      }

      let priceFloat = formatted2Float(price.price_per_day_formatted)
      let monthlyValue = floatFormatted((priceFloat * 30))

      return `
        <p>O valor de R$ <strong>${price.price_per_day_formatted}/dia</strong> será aplicado quando o período de locação for igual ou superior a <strong>${price.more_than} ${(price.more_than === 1 ? 'dia' : 'dias')}</strong></p>
      `
    },

    tabActions(tab, event) {
      // submete o form da última tab
      this.onSubmit(this.product.step, true)

      this.$refs['formAlert'].clearAlerts()
      // define o lastTab com a tab atual
      setTimeout(() => {
        this.product.step = tab.$el.dataset.tabForm
      }, 1000)
    },

    setProductStatus(status) {
      this.$axios.$put(`locator/product/${this.product.uid}/set-status`, { status: status })
      .then(
        response => {
          this.productPublishPopover = false
          Vue.set(this.product, 'status', status)
          this.$refs['formAlert'].showAlert({ id: 'alert-prices-success', type: 'success', title: response.message, cleanOtherAlerts: true })
        },
        error => {
          this.errorsAlert(error)
        }
      )
    },

    onSubmit(step, hideAlertInfo) {
      if (typeof hideAlertInfo === 'undefined') {
        hideAlertInfo = false
      }
      this.$refs['formAlert'].closeAlert('alert-errors-found')

      if (step === 'Step3') {
        this.onSubmitPrices(hideAlertInfo)
        return
      }

      this.$refs['form' + step].validate((valid) => {
        if (valid) {
          // Envia os dados ao endpoint
          this.$axios.$put(`locator/product/${this.product.uid}/update`, this.product)
          .then(
            response => {
              let product = { ...this.product, ...response }
              if (!product.prices.length) {
                product.prices = _.clone(defaultProduct.prices)
              }
              Vue.set(this, 'product', product)

              this.$axios.$get('common/users/addresses')
                .then(data => {
                  this.addresses = data
                })
                .catch(e => context.error(e.response.data.message))

              if (!hideAlertInfo) {
                this.$refs['formAlert'].showAlert({ id: 'alert-update-success', type: 'success', title: 'Atualização efetuada!', description: 'A sua carreta foi atualizada com sucesso.', cleanOtherAlerts: true })
              }
            },
            error => {
              this.errorsAlert(error)
            }
          )
        } else {
          this.$refs['formAlert'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados!', description: 'Por favor, verifique os campos preenchidos abaixo:' })
          return false;
        }
      })
    },

    beforeDocumentUpload (file, documentType) {
      const isLt2M = file.size / 1024 / 1024 < 2
      let errors = []

      if (!isLt2M) {
        errors.push('A imagem precisa ter no máximo 2MB.')
      }

      if (errors.length) {
        this.$refs['formAlert'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados', description: _.join(errors, "\n") })
        return false
      }

      // envia através do axios ao invés da função nativa do element-ui
      let requestHeaders = {
        headers: { 'Content-Type': 'multipart/form-data' }
      }

      let data = new FormData()
      data.append('image', file, file.filename)
      data.append('document_type', documentType)

      this.$axios.$post(`locator/product/${this.product.uid}/upload-documents`, data, requestHeaders).then(
        response => {
          this.doc_crlv = response
        },
        error => {
          this.errorsAlert(error)
        }
      )

      return false;
    },

    beforeCrlvUpload (file) {
      this.beforeDocumentUpload (file, 'doc_crlv')
    },

    onSubmitPrices (hideAlertInfo) {
      if (!this.checkPrices()) {
        return false
      }

      // monta o payload
      let payload = []
      _.each(this.product.prices, (p) => {
        payload.push({
          id: p.id || null,
          price_per_day: p.price_per_day,
          more_than: p.more_than,
        })
      })

      // Envia os dados ao endpoint
      this.$axios.$post(`locator/product/${this.product.uid}/prices`, payload)
      .then(
        response => {
          let price_from = _.find(response, { 'more_than': 30 })
          Vue.set(this.product, 'prices', response)
          Vue.set(this.product, 'price_from', price_from.price_period)
          if (!hideAlertInfo) {
            this.$refs['formAlert'].showAlert({ id: 'alert-prices-success', type: 'success', title: 'Preços salvos com sucesso', description: 'Os preços foram atualizados com sucesso', cleanOtherAlerts: true })
          }
        },
        error => {
          this.errorsAlert(error)
        }
      )
    },

    checkPrices () {
      let errorDescription = ''

      // checagem de quantidade de dias repetidos
      let moreThanCounter = _.countBy(this.product.prices, (p) => p.more_than)
      if (_.find(moreThanCounter, (m) => m > 1)) {
        errorDescription += '- Há quantidades de dias repetidas, por favor altere a quantidade ou remova as entradas repetidas. <br>'
      }

      // checagem de valores zerados
      if (_.find(this.product.prices, (p) => {
          console.log('checkPrices', p)
          return p.price_per_day === 0 || p.price_per_day === 0.00 || p.price_per_day === '0,00'
        }
      )) {
        errorDescription += '- Há valores zerados, por favor defina um valor válido.'
      }

      if (_.find(this.product.prices, { price_period: '' })) {
        errorDescription += '- Há valores nulos, por favor defina um valor válido.'
      }

      // se houver erros, exibe os erros
      if (errorDescription) {
        this.$refs['formAlert'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados', description: errorDescription })
        return false
      }

      return true
    },

    checkMoreThan (price) {
      if (_.filter(this.product.prices, { more_than: price.more_than }).length > 1) {
        this.$refs['formAlert'].showAlert({ id: 'errors-found', type: 'error', title: 'Erros encontrados', description: `Já existe um valor definido para períodos a partir de ${price.more_than} dias. Por favor, altere a quantidade de dias ou remova esta entrada.` })
      }
    },

    setPrice (price) {
      price.price_per_day = formatted2Float(price.price_per_day_formatted)
      price.price_period_formatted = floatFormatted(price.price_per_day * price.more_than)
    },

    addPrice () {
      let more_than_days = 1
      if (this.product.prices.length) {
        more_than_days = (Math.floor((_.maxBy(this.product.prices, 'more_than')).more_than/10) + 1) * 10
      }
      this.product.prices.push({ price_per_day: 0, more_than: more_than_days })
    },

    /**
     * Efetua o upload das imagens
     *
     * @param {object} file - The image file
     * @param {string} viewTag - tag to view image
     */
    beforeImageUpload (file, viewTag) {
      if (typeof viewTag === 'undefined') {
        viewTag = null
      }

      const isLt2M = file.size / 1024 / 1024 < 2
      let errors = []

      if (!isLt2M) {
        errors.push('A imagem precisa ter no máximo 2MB.')
      }

      if (errors.length) {
        this.$refs['formAlert'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados', description: _.join(errors, "\n") })
        return false
      }

      // envia através do axios ao invés da função nativa do element-ui
      let requestHeaders = {
        headers: { 'Content-Type': 'multipart/form-data' }
      }
      let data = new FormData()
      data.append('image', file, file.filename)

      let uploadUrl = `locator/product/${this.product.uid}/upload-image`
      if (viewTag) {
        uploadUrl = `locator/product/${this.product.uid}/upload-image/${viewTag}`
      }

      this.$axios.$post(uploadUrl, data, requestHeaders).then(
        response => {
          if (viewTag) { // se for uma imagem de view
            // adiciona a viewTag na response, pois não virá pelo back
            response.tag = viewTag
            let index = _.findIndex(this.product.view_images, { 'tag': viewTag })
            if (index === -1) {
              this.product.view_images.push(response)
            } else {
              Vue.set(this.product.view_images, index, response)
            }
          } else { // se for uma imagem extra
            this.product.images.push(response)
            // se não tiver imagem de destaque configurada, define a primeira imagem como
            if (!this.product.featured_image) {
              Vue.set(this.product, 'featured_image', response)
            }
          }
        },
        error => {
          this.errorsAlert(error)
        }
      )

      return false;
    },

    beforeImageViewUploadLeft(file) { this.beforeImageUpload(file, 'left') },
    beforeImageViewUploadRight(file) { this.beforeImageUpload(file, 'right') },
    beforeImageViewUploadFront(file) { this.beforeImageUpload(file, 'front') },
    beforeImageViewUploadBack(file) { this.beforeImageUpload(file, 'back') },
    beforeImageViewUploadInterior(file) { this.beforeImageUpload(file, 'interior') },
    beforeImageViewUploadAxes(file) { this.beforeImageUpload(file, 'axes') },

    /**
     * type {String} 'image' ou 'view-image'
     */
    removeImage ({image, type}) {
      console.log('removeImage', type)
      if (!image.id) {
        return
      }
      if (typeof type === 'undefined') {
        type = image
      }
      this.$axios.$delete(`locator/product/${this.product.uid}/delete-image/${image.id}`).then(
        response => {
          let typeContainer = type === 'image' ? 'images' : 'view_images'
          let index = _.findIndex(this.product[typeContainer], i => i.id === image.id)
          if (index !== - 1) {
            this.product[typeContainer].splice(index, 1)
          }
          this.$refs['formAlert'].showAlert({ id: 'alert-image-delete-success', type: 'success', title: response.message })
        },
        error => {
          this.errorsAlert(error)
        }
      )
    },

    previewImage (image) {
      this.imagePreviewUrl = image.url
      this.imagePreview = true
    },

    onImageDrop (dropResult) {
      applyDrag(this.product.images, dropResult).then((images) => {
        this.product.images = images
        let image_ids = _.map(images, 'id')
        this.$axios.$put(`locator/product/${this.product.uid}/order-images`, { ids: image_ids  }).then((response) => {
          this.$refs['formAlert'].showAlert({ id: 'alert-order-images-success', type: 'success', title: response.message })
        })
      })
    },

    setFeaturedImage (image) {
      this.$axios.$put(`locator/product/${this.product.uid}/set-featured-image`, { image_id: image.id  }).then((response) => {
        // this.product.featured_image = response
        Vue.set(this.product, 'featured_image', response)
        Vue.set(this.product, 'featured_image_path', response.metadata.thumbnails['retangle-small']['path'])
      })
    },

    isFeaturedImage (image) {
      return this.product.featured_image && this.product.featured_image.id === image.id
    }
  }
}
</script>

<style lang="scss" scoped>
  .inner-form {
    > .header {
      margin-bottom: 4rem;
    }
  }

  .inner-title {
    text-align: left;
  }

  .form-example {
    margin-bottom: 1.6rem;
  }

  .form-sec {
    margin-bottom: 2rem;
    font-size: 1.4rem;
    line-height: 1.4;

    p {
      margin-bottom: 1.6rem;
    }
  }

  .form-desc {
    line-height: 1.3;
    font-size: 1.2rem;
    display: none;
    margin-bottom: 1rem;

    &.-active {
      display: block;
    }
  }

  .form-title {
    font-size: 1.6rem;
    color: #576674;
    margin-bottom: 1.6rem;
  }

</style>

<style lang="scss">
  // .el-upload--picture-card span {
  //   display: block;
  //   line-height: 1;
  //   font-size: 14px;
  //   position: relative;
  //   top: -30px;
  // }

  .el-form-item {
    &.-right {
      .el-form-item__label {
        width: 120px;
        line-height: 40px;
        vertical-align: middle;
        float: left;
      }
      .el-form-item__content {
        margin-left: 120px;
      }
    }
  }

  .c7-input-disabled input {
    background-color: #f5f7fa !important;
  }

  .c7-upload {
    .el-upload {
      margin-bottom: 3rem;
    }

    .el-upload, .el-upload-dragger {
      display: block;
      width: 100%;
    }

    .el-upload-dragger {
      height: 240px;
      font-size: 1.2rem;

      .wrp-image {
        height: 100%;

        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
      }

      .wrp {
        height: 100%;
        padding: 2rem;
      }

      .title {
        font-size: 1.2rem;
      }

      .img {
        height: 120px;
        lost-align: center;
      }

      .bottom {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        margin-bottom: 2rem;
      }

      .el-icon-upload {
        margin: 0;
        font-size: 32px;
        line-height: 32px;
      }

      .el-upload__text {
        font-size: 1.2rem;
      }
    }

  }

  .c7-form-upload {
    lost-flex-container: row;

    .c7-upload {
      lost-column: 1/3;
    }
  }

  .c7-upload-full {
    .el-upload {
      margin-bottom: 3rem;
    }

    .el-upload, .el-upload-dragger {
      display: block;
      width: 100%;
      height: 120px;
    }

    .el-icon-upload {
      margin-top: 20px;
    }
  }

  .c7-view-image {
    &:hover {
      .overlay {
        display: block;
      }
    }
  }

  .c7-sortable {
    padding-bottom: 1.2rem;
    margin-bottom: 5rem;
    overflow-x: auto;
    width: 100%;

    > .thumb {
      display: inline-block !important;
      position: relative;
      width: 120px;
      height: 120px !important;
      vertical-align: top;
      margin-left: 1.2rem;
      border-radius: 10px;
      overflow: hidden;
      background: no-repeat center center;
      background-size: cover;

      // &:nth-child(5n + 1) {
      //   margin-left: 0;
      // }

      &:hover {
        .overlay {
          display: block;
        }
      }
    }

    i {
      cursor: pointer;
      margin-left: 1rem;

      &:hover {
        color: #ffffff;
      }

      &.el-icon-zoom-in {
        margin-left: 0;
      }
    }

  }

  .c7-list-head {
    color: #888;
  }

  .c7-list-head-title {
    font-size: 1.4rem;
  }

.c7-imgbox-uploader {
  .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;

    &:hover {
      border-color: #409EFF;
    }
  }
}

.c7-imgbox-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 160px;
  height: 160px;
  line-height: 160px;
  text-align: center;
}

.c7-imgbox {
  width: 160px;
  height: 160px;
  display: block;
}

.el-radio.c7-option-box {
  position: relative;
  width: 100%;
  height: auto;
  padding: 12px 20px 12px 36px;
  line-height: 1.5;

  .el-radio__input {
    position: absolute;
    top: 16px;
    left: 12px;
  }

  .el-radio__label {
    padding-left: 0;
  }

  small {
    font-size: 1.2rem;
  }

  & + .el-radio.c7-option-box {
    margin-left: 0;
  }
}
</style>
