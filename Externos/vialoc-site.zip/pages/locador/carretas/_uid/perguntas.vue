<template>
  <div>
    <h2 class="profile-title -locator">Perguntas recebidas</h2>
    <div class="list-card" style="margin-bottom: 2rem;">
      <div class="row">
        <app-card :product="product" extra-class="-flat" process="owner" />
      </div>
    </div>
    <div class="inner-panel">
      <app-questions-item v-for="(question, index) in product.questions" :question="question" :productUid="product.uid" type="view-locator" :key="`question-${index}`" @update-question="onUpdateQuestion" :id="`pergunta-${question.id}`" />
      <el-alert v-if="!product.questions.length" type="info" title="Esta carreta ainda não recebeu mensagens." show-icon :closable="false"></el-alert>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'
import { hashScrollMixin } from '@/mixins'
import AppCard from '@/components/AppCard'
import AppQuestionsItem from '@/components/AppQuestionsItem'

export default {
  layout: 'panel',
  head: {
    bodyAttrs: {
      class: '-locator',
    }
  },

  mixins: [ hashScrollMixin ],

  components: {
    AppCard,
    AppQuestionsItem,
  },

  async asyncData (context) {
    return context.app.$axios.$get(`locator/product/${context.params.uid}/messages`)
      .then(data => {
        return {
          product: data,
        }
      })
      .catch(e => {
        context.error(e.response.data.message)
        })
  },

  methods: {
    onUpdateQuestion(question) {
      let index = _.findIndex(this.product.questions, q => q.id === question.id)
      Vue.set(this.product.questions, index, question)
    }
  }
}
</script>
