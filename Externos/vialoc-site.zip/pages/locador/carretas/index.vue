<template>
  <div>
    <h2 class="profile-title -locator">Minhas carretas</h2>

    <el-menu :default-active="tabIndex" class="inner-nav el-menu-desc" mode="horizontal" @select="tabHandler">
      <el-menu-item index="0">Ativas ({{ activeTotal }})
        <div class="desc">Carretas cadastradas disponíveis para locação.</div>
      </el-menu-item>
      <el-menu-item index="1">Inativas ({{ inactiveTotal }})
        <div class="desc">Carretas cadastradas que não estão mais disponíveis para locação.</div>
      </el-menu-item>
      <el-menu-item index="2">Em rascunho ({{ draftTotal }})
        <div class="desc">Carretas ainda não publicadas.</div>
      </el-menu-item>
      <el-menu-item index="3">Todas ({{ allTotal }})
        <div class="desc">Compilado de todas suas carretas já cadastradas na Vialoc.</div>
      </el-menu-item>
    </el-menu>

    <div class="inner-content">
      <app-search-inner-carts/>
      <app-card v-for="product in productsFiltered" extra-class="-flat" process="owner" :product="product" :key="`product-${product.uid}`" />
      <el-card class="box-card" v-if="!productsFiltered.length">
        Não há carretas cadastradas nesta busca.
      </el-card>
    </div>
  </div>
</template>

<script>

import _ from 'lodash'
import AppCard from '@/components/AppCard'
import AppSearchInnerCarts from '@/components/AppSearchInnerCarts'

export default {
  layout: 'panel',
  middleware: ['auth', 'check-auth'],
  head: {
    bodyAttrs: {
      class: '-locator',
    }
  },

  components: {
    AppCard,
    AppSearchInnerCarts,
  },

  meta: {
    breadcrumb: [
      { name: 'Minhas carretas', path: '/locador/carretas' },
    ]
  },

  data() {
    return {
      tabIndex: '0',
      status: [
        { slug: 'active', label: 'Ativas', },
        { slug: 'inactive', label: 'Inativas', },
        { slug: 'draft', label: 'Em rascunho', },
        { slug: '', label: 'All', },
      ],
      statusFilter: 'active',
      products: [],
      formSearch: {
        search: '',
      },
    }
  },

  asyncData (context) {
    return context.app.$axios.$get('locator/products')
      .then(data => {
        return {
          products: data
        }
      })
      .catch(e => context.error(e.response.data.message))
  },

  computed: {
    productsFiltered () {
      if (!this.statusFilter) {
        return this.products
      }
      return _.filter(this.products, { status: this.statusFilter })
    },

    activeTotal () {
      return _.filter(this.products, { status: 'active' }).length
    },

    inactiveTotal () {
      return _.filter(this.products, { status: 'inactive' }).length
    },

    draftTotal () {
      return _.filter(this.products, { status: 'draft' }).length
    },

    allTotal () {
      return this.products.length
    },
  },

  methods: {
    tabHandler (key, keyPath) {
      this.statusFilter = this.status[parseInt(key)].slug
    },
  }

}
</script>

<style lang="scss" scoped>
  .inner-content {
    padding-top: 4rem;
  }
  .el-menu {
    background-color: transparent;
  }
  .el-menu-item {
    font-size: 12px;
  }
  .el-menu--horizontal {
    border-color: #979797;

    > .el-menu-item {
      border: none;
      height: 32px;
      line-height: 32px;
      border: 1px solid #979797;
      border-bottom: none;
      color: #4A4A4A;

      &:not(:last-child) {
        margin-right: 10px;
        // @media (min-width: $screen-md) {
        //   margin-right: 40px;
        // }
      }

      &:hover, &:focus, &.is-active {
        background-color: #4AB5E2;
        color: #fff;
        border-color: #4AB5E2;
      }
    }
  }
</style>