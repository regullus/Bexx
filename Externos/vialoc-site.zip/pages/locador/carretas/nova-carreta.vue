<template>
  <div>
    <div class="inner-form">
      <div class="header">
        <h2 class="profile-title -locator">Cadastre sua carreta</h2>
        <div>Para começar a ganhar dinheiro, você precisa cadastrar as carretas disponíveis para locação. Preencha os campos abaixo com as informações necessárias e prossiga clicando em “Cadastrar carreta”.</div>
      </div>

      <el-tabs type="card" v-if="product">

        <app-alert ref="formAlert"/>

        <el-tab-pane label="Informações básicas">
          <!-- Step 1 -->
          <el-form :model="product" :rules="step1Rules" ref="formProduct" class="el-form--label-top -step-1">

            <el-col :span="16">
              <div class="form-sec">
                <h4 class="form-title">Informações sobre sua carreta</h4>
                <el-row :gutter="10">
                  <el-col :span="24">
                    <el-form-item label="Crie um nome para esta carreta" prop="name">
                      <el-input v-model="product.name"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="10">
                  <el-col :span="12">
                    <el-form-item label="Fabricante" prop="brand_id">
                      <el-select v-model="product.brand_id">
                        <el-option v-for="brand in formEl.brands" :key="'brand-' + brand.id" :label="brand.name" :value="brand.id"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="Tipo" prop="type">
                      <el-select v-model="product.type">
                        <el-option v-for="(value, key) in formEl.types" :key="'type-' + key" :label="value" :value="key"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="10">
                  <el-col :span="8">
                    <el-form-item label="Ano" prop="year">
                      <el-input type="tel" v-model="product.year" v-mask="'####'" key="product.year"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8">
                    <el-form-item label="Modelo" prop="model">
                      <el-input v-model="product.model"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8">
                    <el-form-item label="Eixos" prop="axes">
                      <el-input v-model.number="product.axes"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="10">
                  <el-col :span="6">
                    <el-form-item label="Comprimento (m)" prop="length">
                      <el-input type="tel" v-model.lazy="product.length" v-money="moneyFormat"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="6">
                    <el-form-item label="Largura (m)" prop="width">
                      <el-input type="tel" v-model.lazy="product.width" v-money="moneyFormat"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="6">
                    <el-form-item label="Altura (m)" prop="height">
                      <el-input type="tel" v-model.lazy="product.height" v-money="moneyFormat"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="6">
                    <el-form-item label="Cubagem (m³)" prop="cubing">
                      <el-input type="tel" v-model.lazy="product.cubing" v-money="moneyFormat"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="10">
                  <el-col :span="8">
                    <el-form-item label="Assoalho" prop="floor">
                      <el-select v-model="product.floor">
                        <el-option v-for="(value, key) in formEl.floors" :key="'floor-' + key" :label="value" :value="key"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8">
                    <el-form-item label="Suspensão" prop="suspension">
                      <el-select v-model="product.suspension">
                        <el-option v-for="(value, key) in formEl.suspensions" :key="'suspension-' + key" :label="value" :value="key"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8">
                    <el-form-item label="Pneus" prop="with_tires">
                      <el-checkbox v-model="product.with_tires">Pneus inclusos</el-checkbox>
                    </el-form-item>
                  </el-col>
                </el-row>
              </div>
              <div class="form-sec">
                <h4 class="form-title">Localização da sua carreta</h4>

                <p>Caso queira utilizar outro endereço já cadastrado ou adicionar um novo, clique em <br/>"Alterar o endereço".</p>

                <app-card-address :address="product.address"></app-card-address>
                <el-button size="mini" type="info" plain @click="openModalManageAddresses">Alterar o endereço</el-button>
              </div>

              <div class="form-sec">
                <h4 class="form-title">Descreva a sua carreta</h4>
                <p> Elabore uma descrição detalhada da sua carreta e aumente suas chances de locação. </p>
                <div class="form-example">
                  <el-button size="mini" type="info" plain @click.stop="show_content_example = !show_content_example">Veja um exemplo</el-button>
                  <el-card class="form-desc" :class="{ '-active': show_content_example }">
                    - Contrato mínimo de 4 meses.<br/>
                    - Pessoa jurídica ou física.<br/>
                    - Sem pneus. Consulte-nos para locação com pneus.<br/><br/>

                    <strong>Informações técnicas</strong><br/><br/>

                    Para 26 paletes 1.050mm x 1.250mm invertidos.<br/>
                    Altura interna: 2.700mm.<br/>
                    Laterais: lona vinílica reforçada, sustentada por rodízios e tracionada longitudinalmente pela dianteira e vertical por catracas de polietileno.<br/><br/>

                    O assoalho do semirreboque sider é fabricado em chapa de aço xadrez 4.75mm, para resistir ao trânsito de empilhadeiras com até 950 kg por ponto de apoio.<br/><br/>

                    A porta traseira do sider possui revestimento externo em chapa de aço lisa, pré-pintada na cor branca.. A porta possui travas com espera para  cadeado com varões de travamento. Com abertura translúcida, que facilita a dissipação de calor e permite aproveitamento de iluminação interna, o teto é encaixado por um sistema hermético, sem a utilização de rebites, que confere ao conjunto maior resistência e menor manutenção.
                  </el-card>
                </div>
                <el-form-item label="Descrição" prop="content">
                  <el-input type="textarea" v-model="product.content" :autosize="{ minRows: 6 }"></el-input>
                </el-form-item>
              </div>
              <div class="form-sec">
                <el-form-item>
                  <el-button type="primary" @click="onSubmit" class="el-button--block">Cadastrar carreta</el-button>
                </el-form-item>
              </div>
              <el-row>
                <small class="form-obs"><span>*</span> Itens obrigatórios.</small>
              </el-row>
            </el-col>
          </el-form>
        </el-tab-pane>
        <!-- / Step 1 -->
      </el-tabs>
    </div>
    <app-modal-manage-addresses @define-address="defineAddress" />
  </div>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'
import { mask } from 'vue-the-mask'
import { VMoney } from 'v-money'
import { errorsMixin } from '@/mixins'
import AppAlert from '@/components/AppAlert'
import AppCardAddress from '@/components/AppCardAddress'
import AppModalManageAddresses from '@/components/AppModalManageAddresses'

const defaultProduct = {
  uid: null,
  name: '',
  content: '',
  link_video: '',
  // city_id: '',
  // state_code: '',
  address_id: null,
  address: {
    zipcode: null,
    address: null,
    address_number: null,
    address_complement: null,
    district: null,
    city_id: null,
    state: null,
  },
  type: '',
  brand_id: null,
  height: null,
  width: null,
  length: null,
  weight: null,
  cubing: null,
  axes: null,
  licensing: '',
  model: '',
  chassis: '',
  renavam: '',
  antt: '',
  owner_name: '',
  owner_cpf_cnpj: '',
  license_plate: '',
  floor: '',
  suspension: '',
  prices: [
    { price_per_day: 0, more_than: 1 },
    { price_per_day: 0, more_than: 7 },
    { price_per_day: 0, more_than: 30 },
  ],
  images: [],
  featured_image: null,
  is_complete: false,
}

export default {
  layout: 'panel',
  middleware: ['auth', 'check-auth'],
  head: {
    bodyAttrs: {
      class: '-locator',
    }
  },

  directives: {mask, money: VMoney},

  mixins: [errorsMixin],

  components: {
    AppAlert,
    AppCardAddress,
    AppModalManageAddresses
  },

  meta: {
    breadcrumb: [
      {name: 'Minhas Carretas', path: '/minhas-carretas'},
      {name: 'Cadastrar Nova Carreta', path: '/minhas-carretas/nova-carreta'},
    ]
  },

  data () {
    return {
      show_content_example: false,

      moneyFormat: {
        decimal: ',',
        thousands: '.',
        // prefix: 'R$ ',
        // suffix: '',
        precision: 2,
        masked: false /* doesn't work with directive */
      },

      product: { ..._.clone(defaultProduct), address_id: this.$auth.user.address.id, address: this.$auth.user.address }
    }
  },

  asyncData (context) {
    // return context.app.$axios.$get('common/users/addresses')
    //   .then(data => {
    //     return {
    //       addresses: data
    //     }
    //   })
    //   .catch(e => context.error(e.response.data.message))
  },

  computed: {
    formEl () {
      return this.$store.state.base.productInfo
    },

    step1Rules () {
      return {
        name: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        brand_id: [
          {type: 'integer', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        type: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        year: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        model: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        axes: [
          {type: 'integer', required: true, message: 'Preencha este campo com um número', trigger: 'blur'}
        ],
        length: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'},
        ],
        width: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        floor: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        suspension: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        address_id: [
          {type: 'string', required: true, message: 'Você precisa selecionar um endereço ou cadastrar um novo endereço.', trigger: 'blur'}
        ],
        content: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
      }

    },
  },

  methods: {
    openModalManageAddresses() {
      this.$store.dispatch('events/setModal', { id: 'manage-address' })
    },

    defineAddress (address) {
      Vue.set(this.product, 'address', address)
      Vue.set(this.product, 'address_id', address.id)
      this.$store.dispatch('events/cleanModal')
    },

    onSubmit () {
      this.$refs['formProduct'].validate((valid) => {
        if (valid) {
          this.submitProduct()
        } else {
          this.$refs['formAlert'].showAlert({ id: 'errors-found', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
          return false;
        }
      })
    },

    submitProduct () {
      // Envia os dados ao endpoint
      this.$axios.$post('locator/product/create', this.product)
      .then(
        response => {
          this.$router.push(`/locador/carretas/${response.uid}/editar/`)
        },
        error => {
          this.errorsAlert(error)
        }
      )
    }
  }
}
</script>

<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) {
      lost-column: 3/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) {
      lost-column: 9/12;
    }
  }

  .inner-form {
    > .header {
      margin-bottom: 4rem;
    }
  }

  .inner-title {
    text-align: left;
  }

  .form-sec {
    margin-bottom: 2rem;
    font-size: 1.4rem;
    line-height: 1.4;

    p {
      margin-bottom: 1.6rem;
    }
  }

  .form-title {
    font-size: 1.6rem;
    color: #576674;
    margin-bottom: 1.6rem;
  }

  .form-example {
    margin-bottom: 1.6rem;
  }

  .form-desc {
    line-height: 1.3;
    font-size: 1.2rem;
    display: none;
    margin-bottom: 1rem;

    &.-active {
      display: block;
    }
  }

</style>

<style lang="scss">

  .el-form-item {
    &.-right {
      .el-form-item__label {
        width: 120px;
        line-height: 40px;
        vertical-align: middle;
        float: left;
      }
      .el-form-item__content {
        margin-left: 120px;
      }
    }
  }

  .el-radio.c7-option-box {
    position: relative;
    width: 100%;
    height: auto;
    padding: 12px 20px 12px 36px;
    line-height: 1.5;

    .el-radio__input {
      position: absolute;
      top: 16px;
      left: 12px;
    }

    .el-radio__label {
      padding-left: 0;
    }

    small {
      font-size: 1.2rem;
    }

    & + .el-radio.c7-option-box {
      margin-left: 0;
    }
  }
</style>
