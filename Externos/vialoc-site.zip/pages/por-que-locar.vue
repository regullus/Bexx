<template>
  <div class="inner-wrapper">
    <div class="container">
      <article class="inner-article">
        <header class="inner-header">
          <h2 class="inner-title">Por que locar?</h2>
          <img src="~assets/images/vialoc-carreta.png"/>
        </header>
        <div class="inner-content">
          <div class="box-txt">
            <p>explorations vanquish the impossible permanence of the stars decipherment
              preserve and cherish that pale blue dot. Venture at the edge of forever something
              incredible is waiting to be known worldlets tingling of the spine Ut enim ad minima veniam?
              Adipisci velit cosmic ocean the only home we've ever known emerged into consciousness bits
              of moving fluff with pretty stories for which there's little good evidence. Nisi ut aliquid ex
              ea commodi consequatur the ash of stellar alchemy Neque porro quisquam est sed quia consequuntur
              magni dolores eos qui ratione voluptatem sequi nesciunt Sea of Tranquility adipisci velit.</p>
            <p>Galaxies intelligent beings Rig Veda finite but unbounded with pretty stories for which there's little good evidence Cambrian explosion. Tendrils of gossamer clouds across the centuries the only home we've ever known hearts of the stars nisi ut aliquid ex ea commodi consequatur birth. How far away how far away paroxysm of global death network of wormholes Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium how far away.</p>
          </div>
        </div>
      </article>
    </div>
  </div>
</template>

<script>
  export default {
    layout: 'inner',
  }
</script>

