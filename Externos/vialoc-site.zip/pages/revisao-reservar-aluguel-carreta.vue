<template>
  <div class="inner-wrapper">
    <div class="container -column">
      <h2 class="inner-sub">Revise e confirme a reserva da carreta</h2>
    </div>
    <div class="container">
      <div class="inner-left">
        <div class="item">
          <p><strong>Detalhes da reserva</strong></p>
          <div class="inner-panel">
            <div class="header">
              <div class="title">Endereço de retirada da carreta:</div>

              <span class="action">Retirar em outro endereço</span>
            </div>
            <div class="link">Av Educador Paulo Freire S/N - Guarulhos - CEP 07033-179</div>
          </div>
        </div>

         <div class="item">
          <p><strong>Detalhe do pagamento</strong></p>
          <div class="inner-panel">
            <div class="header">
              <div class="title">Boleto</div>

              <span class="action">Modificar</span>
            </div>
            <p>Você pagará 6x R$2.300,00</p>
            <p>O boleto tem prazo de compensação de 1 a 2 dias úteis. Nós não garantimos o aluguel até que o pagamento seja aprovado. Não perca tempo!</p>
          </div>
        </div>


      </div>
      <div class="inner-right">
        <div class="inner-sidebar">
          <div class="sidebar-item">
            <app-card-checkout/>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<style lang="scss" scoped>
  .inner-left {
    @media (min-width: $screen-md) { 
      lost-column: 9/12;
    }
  }

  .inner-right {
    @media (min-width: $screen-md) { 
      lost-column: 3/12;
    }
  }
  .item {
    margin-bottom: 6rem;
  }
  .card-checkout {
    .header {
      margin-top: -12px;
    }
  }
</style>

<script>

import AppCardCheckout from '@/components/AppCardCheckout.vue'

export default {
  layout: 'inner',

  components: {
    AppCardCheckout
  },

  meta: {
    breadcrumb: [
      {name: 'Cadastro carreta', path: '/alterar-senha'},
    ]
  },

  data() {
    return {
    }
  }
}

</script>

