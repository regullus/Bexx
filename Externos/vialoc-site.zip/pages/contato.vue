<template>
  <div class="inner-wrapper">
    <div class="container -column -small">
      <div class="inner-form">
        <div class="header">
          <h2 class="inner-title">Contato</h2>
          <div v-if="$auth.loggedIn">
            <p>Tem alguma dúvida, sugestão ou recado? Preencha o campo abaixo e aguarde nosso contato.</p>
          </div>
          <div v-else>
            <p>Está ansioso para usar a plataforma Vialoc, mas tem alguma dúvida? Pode ficar tranquilo! Preparamos este espaço para você enviar perguntas, sugestões, elogios e o que precisar. </p>
          </div>
        </div>
        <el-form :model="contact" :rules="contactRules" class="el-form--label-top" ref="formContact">
          <app-alert ref="formAlert"/>

          <div v-if="!$auth.loggedIn">
            <el-row :gutter="10">
              <el-col :span="12">
                <el-form-item label="Nome" prop="name">
                  <el-input v-model="contact.name"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="E-mail" prop="email">
                  <el-input v-model="contact.email"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="10">
              <el-col :span="24">
                <el-form-item label="Assunto" prop="subject">
                  <el-select v-model="contact.subject">
                    <el-option label="Zone one" value="shanghai"></el-option>
                    <el-option label="Zone two" value="beijing"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
          </div>

          <el-row>
            <el-col :span="24">
              <el-form-item label="Mensagem" prop="message">
                <el-input type="textarea" v-model="contact.message" rows="5"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item class="-right">
                <el-button type="primary" class="submit" @click="onSubmit">Enviar</el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import _ from 'lodash'
import { errorsMixin } from '@/mixins'
import AppAlert from '@/components/AppAlert'

const defaultContact = {
  name: '',
  email: '',
  subject: '',
  message: '',
}

export default {
  layout: 'inner',

  mixins: [errorsMixin],

  components: {
    AppAlert
  },

  meta: {
    breadcrumb: [
      {name: 'Contato', path: '/contato'},
    ]
  },

  data() {
    return {
      contact: _.clone(defaultContact),
    }
  },

  computed: {
    contactRules () {
      return {
        name: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        email: [
          { type: 'email', required: true, message: 'Insira um e-mail válido', trigger: 'blur' }
        ],
        subject: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
        message: [
          {type: 'string', required: true, message: 'Este campo é obrigatório.', trigger: 'blur'}
        ],
      }
    }
  },

  methods: {
    onSubmit () {
      // this.$refs['formContact'].closeAlert('alert-errors-found')

      this.$refs['formContact'].validate((valid) => {
        if (valid) {
          // Envia os dados ao endpoint
          this.$axios.$post(`contact`, this.contact)
            .then(
              response => {
                this.$refs['formAlert'].showAlert({ id: 'alert-message-success', type: 'success', title: 'Mensagem enviada com sucesso', description: 'Obrigado. Em breve retornaremos o seu contato.', cleanOtherAlerts: true })
                this.contact = _.clone(defaultContact)
              },
              error => {
                this.errorsAlert(error)
              }
            )
        } else {
          this.$refs['formAlert'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
          return false;
        }
      })
    },
  },
}
</script>
