# Site Vialoc

> Nuxt.js project

## Requirements

- NodeJS 12.18.3
- Yarn
## Build Setup

``` bash
# install dependencies
$ yarn install # Or yarn install

# serve with hot reload at localhost:3000
$ yarn run dev

# build for production and launch server
$ yarn run build
$ yarn start

# generate static project
$ yarn run generate
```

For detailed explanation on how things work, checkout the [Nuxt.js docs](https://github.com/nuxt/nuxt.js).

## Publicar em produção

Caso não tenha o projeto configurado no pm2

1. Vá até o diretório do projeto

2. Execute o comando
`pm2 start npm --name "<nome da instância>" -- start`


Para publicar no servidor (PM2 "proxeado" no NGinx):

1. Execute o comando build
`yarn build`

2. Verifique se há uma instância iniciada:
`pm2 ls`

3. Depois:
  - Caso não tenha uma instância iniciada, inicie a instancia nova no PM2
`pm2 run <nome da instancia>`

  - Se já existir, apenas faça o reload
`pm2 reload <nome da instância> --update-env`


### Comandos Básicos do PM2

#### Process list

```
# start and add a process to your list
pm2 start app.js

# show your list
pm2 ls

# stop and delete a process from the list
pm2 delete app
```

#### Logs
```
# see the log of app
pm2 logs app
```

#### Routine

```
# kill the process but keep it in the process list
pm2 stop app

# start the process again
pm2 start app

# both stop and start
pm2 restart app
```

Múltiplos apps podem ser especificados de uma só vez

```
pm2 restart app1 app2 app3
```

Para mais informações, acesse <https://pm2.io/doc/en/runtime/guide/process-management/>