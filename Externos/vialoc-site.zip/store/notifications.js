import Vue from 'vue'
import _ from 'lodash'

export default {
  namespaced: true,
  state: () => {
    return {
      container: [],
    }
  },

  getters: {
    getNotifications (state) {
      return state.container
    },

    getNotificationsByProfile: (state) => (profile) => {
      console.log('getNotificationsByProfile', profile)
      return _.filter(state.container, (n) => {
        return n.profile_recipient === profile
      })
    },
  },

  mutations: {
    setNotifications(state, notifications) {
      state.container = notifications
    },

    addNotification(state, notification) {
      state.container.unshift(notification)
    },

    setNotificationRead (state, notification) {
      let index = _.findIndex(state.container, (n) => (n.id === notification.id))
      Vue.set(state.container, index, { ...notification, is_unread: 0 })
    },

    removeNotifications (state, notificationIds) {
      let index = null
      console.log('removeNotifications', notificationIds)
      _.each(notificationIds, (nId) => {
        index = _.findIndex(state.container, (nc) => {
          return nc.id === nId
        })
        console.log('removeNotifications after each', nId, index)
        Vue.delete(state.container, index)
      })
    }
  },

  actions: {
    setNotifications(vuexContext, notifications) {
      vuexContext.commit('setNotifications', notifications)
    },

    addNotification(vuexContext, notification) {
      vuexContext.commit('addNotification', notification)
    },

    setNotificationRead (vuexContext, notification) {
      let notificationId = notification.id

      this.$axios.$put('/common/notifications/' + notificationId)
        .then(response => {
          vuexContext.commit('setNotificationRead', notification)
        }
      )
    },

    removeNotifications (vuexContext, notifications) {
      let notificationId = null
      let notificationIds = []
      let notificationOriginalIds = []

      if (_.isArray(notifications)) {
        notificationIds = _.map(notifications, 'id')
        notificationIds = notificationIds.concat(notificationOriginalIds)
      } else {
        notificationId = notifications.id
        notificationIds = [ notificationId ]
      }


      this.$axios.$delete('/common/notifications', {
        data: {
          notificationIds: notificationIds
        }
      }).then(() => {
        console.log('removeNotifications', notificationIds)
        vuexContext.commit('removeNotifications', notificationIds)
      })
    },
  }
}
