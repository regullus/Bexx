import Vue from 'vue'
import base from './base'
import events from './events'
import notifications from './notifications'

export const modules = {
  base,
  events,
  notifications,
}

export const actions = {
  // o nuxtServerInit não funciona dentro do módulo
  nuxtServerInit (vuexContext, context) {
    return context.app.$axios
      .$get('common/utils/products-form-data').then(data => {
        vuexContext.commit('base/setProductInfo', data)
      })
  },
}
