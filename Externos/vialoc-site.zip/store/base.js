import _ from 'lodash'

const defaultSearchFilters = {
  product_price_range: [10, 90000],
  product_brand: '',
  product_year_range: [1900, 2020],
  product_order_by: 'price',
}

const defaultLocationFilters = {
  address_radius: {
    latitude: null,
    longitude: null,
    radius: 1000,
  },
}

const defaultStateFactory =  {
  breadcrumb: [],
  productInfo: {},
  locationLabel: null,
  searchFilters: {
    product_type: 'all',
    order_date_start: '',
    order_date_end: '',
    ...defaultSearchFilters,
    ...defaultLocationFilters,
  },
  navAccountOpen: {
    main: true,
    common: false,
    locator: false,
    tenant: false,
  }
}

export default {
  namespaced: true,
  state: () => {
    return defaultStateFactory
  },

  getters: {
    breadcrumb (state) {
      return state.breadcrumb
    },

    categoryTitle (state) {
      return type => state.productInfo.types[type]
    },

    filterBaseData (state) {
      return state.productInfo.filters
    },

    hasFiltersActive (state) {
      return !_.isEqual(state.searchFilters.product_price_range, [10, 90000]) ||
      state.searchFilters.product_brand ||
      !_.isEqual(state.searchFilters.product_year_range, [1900, 2020])
    },

    isLocationDefined (state) {
      return typeof state.searchFilters.address_radius !== 'undefined' && state.searchFilters.address_radius.latitude !== null
    },

    locationLabel (state) {
      return state.locationLabel
    },

    searchFilters (state) {
      return state.searchFilters
    },

    platformVersion (state) {
      return state.productInfo.platform_version
    },

    navAccountOpen (state) {
      return state.navAccountOpen
    },
  },

  mutations: {
    setStore (state, {targetStore, items}) {
      state[targetStore] = items
    },

    resetStore (state) {
      Object.assign(state, defaultStateFactory())
    },

    setBreadcrumb (state, breadcrumb) {
      state.breadcrumb = breadcrumb
    },

    setProductInfo (state, productInfo) {
      state.productInfo = productInfo
    },

    setSearchFilters (state, searchFilters) {
      let mergedFilters = { ...state.searchFilters, ...searchFilters }
      state.searchFilters = mergedFilters
      // setBaseStorageItem('searchFilters', mergedFilters)
    },

    /**
     * Limpa apenas os filtros da lateral esquerda, não limpa os dados de location, type, date
     * @param {Object} state
     */
    clearSearchFilters (state) {
      let mergedFilters = { ...state.searchFilters, ...defaultSearchFilters}
      state.searchFilters = mergedFilters
      // setBaseStorageItem('searchFilters', mergedFilters)
    },

    setLocationLabel (state, locationLabel) {
      state.locationLabel = locationLabel
      // setBaseStorageItem('locationLabel', locationLabel)
    },

    setNavAccountOpen (state, sectionInfo) {
      state.navAccountOpen[sectionInfo.section] = sectionInfo.isOpen
      // setBaseStorageItem('navAccountOpen', state.navAccountOpen)
    }
  },

  actions: {
    setStore (vuexContext, { targetStore, items }) {
      vuexContext.commit('setStore', { targetStore, items })
    },

    resetStore (vuexContext) {
      vuexContext.commit('resetStore')
    },

    initAuth (vuexContext, req) {
      let token;

      // Caso seja uma requisição server side, captura o token via cookie
      if (req) {
        if (!req.headers.cookie) {
          return
        }
        const tokenCookie = req.headers.cookie
          .split(';')
          .find(c => c.trim().startsWith('auth.token.local='))
        if (!tokenCookie) {
          return
        }
        token = decodeURI(tokenCookie.split('=')[1])
        // expirationDate = req.headers.cookie
        //   .split(';')
        //   .find(c => c.trim().startsWith('expirationDate='))
        //   .split('=')[1]

      } else { // se form via client site, captura o token via localStorage
        token = localStorage.getItem('auth.token.local')
        // expirationDate = localStorage.getItem('tokenExpiration')
      }
      // if (new Date().getTime() > +expirationDate || !token) {
      //   vuexContext.dispatch('logout')
      //   return
      // }
      if (token) {
        vuexContext.dispatch('setToken', token)
      }
    },

    setToken (vuexContext, token) {
      return new Promise(async (resolve, reject) => {
        if (token.indexOf('bearer ') === -1) {
          token = 'bearer ' + token
        }
        await this.$auth.setToken('local', token)
        await this.$axios.setToken(token)
        resolve()   
      })
    },

    doLoginOnly (vuexContext, response) {
      return new Promise(async (resolve, reject) => {
          vuexContext.dispatch('setToken', response.auth.access_token)
            .then(
              async () => {
                await this.$auth.$storage.setState('loggedIn', true)
                await this.$auth.$storage.setState('user', response.user)
                resolve()
              },
              error => reject(error)
            )
      })
    },

    registerUser (vuexContext, authData) {
      return new Promise(async (resolve, reject) => {
        await this.$axios
          .$post('/common/users/create-user-logged', authData)
          .then(
            response => {
              vuexContext.dispatch('doLoginOnly', response).then(async () => {
                resolve()
              })

              // //test send data to server
              // this.$axios.$post('http://localhost:3000/api/track-data', { data: 'Test Authentication!' })
            },
            error => reject(error)
          )
      })
    },

    // usuário foi cadastrado por rede social
    completeRegister (vuexContext, authData) {
      return new Promise((resolve, reject) => {
        this.$axios
          .$put('/common/users/complete-registration', authData)
          .then(
            response => {
              this.$auth.fetchUser()
              resolve()
            },
            error => {
              reject(error)
            }
          )
      })
    },

    redefinePassword (vuexContext, redefinePasswordData) {
      return new Promise((resolve, reject) => {
        this.$axios
          .$put('/common/auth/redefine-password', redefinePasswordData)
          .then(
            response => {
              vuexContext.dispatch('setToken', response.auth.access_token).then(() => {
                this.$auth.$storage.setState('loggedIn', true)
                this.$auth.$storage.setState('user', response.user)
                resolve()
              })
            },
            error => reject(error)
          )
      })
    },

    logout (vuexContext) {
      this.$router.push('/')
      this.$auth.logout()
      this.$axios.setToken(false)
      vuexContext.dispatch('events/cleanAlertsMaster', null, { root: true })
    },

    // only for logout on client side
    clientLogout(vuexContext) {
      // this.$auth.setToken('local', null)
      // this.$auth.$storage.setState('loggedIn', false)
      // this.$auth.$storage.setState('user', null)
      // this.$axios.setToken(false)
      // vuexContext.dispatch('events/cleanAlertsMaster', null, { root: true })
    },

    updateUser (vuexContext, userData) {
      return new Promise((resolve, reject) => {
        this.$axios
          .$put('/common/users/update-profile', userData)
          .then(
            response => {
              this.$auth.fetchUser()
              resolve()
            },
            error => {
              reject(error)
            }
          )
      })
    },

    updateUserAddress (vuexContext, zipcode) {
      return new Promise((resolve, reject) => {
        this.$axios
          .$get(`/common/utils/zipcode/${zipcode}`)
          .then(
            response => {
              this.$auth.fetchUser()
              resolve()
            },
            error => {
              reject(error)
            }
          )
      })
    },

    sendConfirmationAgain (vuexContext) {
      this.$axios.$post('/common/users/resend-confirm-email')
      .then(response => {
        vuexContext.dispatch('events/addAlertMaster', {
          id: 'confirm-email',
          type: 'success',
          title: 'Mensagem de confirmação enviada com sucesso',
          description: `Uma nova mensagem de confirmação foi enviada para ${response.to_email}. Aguardamos a sua confirmação.`
        },
        { root: true })
      })
    },

    setProductInfo (vuexContext, productInfo) {
      vuexContext.commit('setProductInfo', productInfo)
    },

    setSearchFilters (vuexContext, searchFilters) {
      vuexContext.commit('setSearchFilters', searchFilters)
    },

    clearSearchFilters (vuexContext) {
      vuexContext.commit('clearSearchFilters')
    },

    setLocationLabel (vuexContext, locationLabel) {
      vuexContext.commit('setLocationLabel', locationLabel)
    },

    setNavAccountOpen (vuexContext, sectionInfo) {
      vuexContext.commit('setNavAccountOpen', sectionInfo)
    }
  }
}
