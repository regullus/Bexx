import Vue from 'vue'
import _ from 'lodash'

const defaultModal = {
  id: null, // login, generic, etc
  type: null, // success, error, info, warning
  typeMessage: null, // string
  title: null, // string
  message: null, // string
}

export default {
  namespaced: true,
  state: () => {
    return {
      alertsMaster: [],
      alerts: [],
      modal: null,
    }
  },

  getters: {
    //
  },

  mutations: {
    setAlertMaster (state, alertsMaster) {
      state.alertsMaster = alertsMaster
    },

    addAlertMaster(state, alertMaster) {
      state.alertsMaster.push(alertMaster)
    },

    updateAlertMaster(state, {index, alertMaster}) {
      if (index === -1) {
        throw new Error(`STORE_ERROR - alertMaster with id #${alertMaster.id} does not exist`)
      }

      Vue.set(state.alertsMaster, index, alertMaster)
    },

    deleteAlertMaster(state, alertMasterId) {
      let index = _.findIndex(state.alertsMaster, a => a.id === alertMasterId)
      Vue.delete(state.alertsMaster, index)
    },

    cleanAlertsMaster(state) {
      state.alertsMaster = []
    },

    setModal(state, modal) {
      state.modal = modal
    }
  },

  actions: {
    nuxtServerInit (vuexContext, context) {
      //
    },

    addAlertMaster (vuexContext, alertMaster) {
      if (typeof alertMaster.id === 'undefined') {
        alertMaster.id = 'alert-master-' + (new Date()).getTime()
      } else {
        alertMaster.id = 'alert-master-' + alertMaster.id
      }

      const alertNew = { ...{ show: true, title: '', type: 'error', description: '', showIcon: true, closable: true, }, ...alertMaster }

      let index = _.findIndex(vuexContext.state.alertsMaster, a => a.id === alertNew.id)
      if (index === -1) {
        vuexContext.commit('addAlertMaster', alertNew)
      } else {
        vuexContext.commit('updateAlertMaster', { index: index, alertMaster: { ...alertNew, ...alertMaster, show: true } })
      }
    },

    deleteAlertMaster (vuexContext, alertMasterId) {
      vuexContext.commit('deleteAlertMaster', alertMasterId)
    },

    cleanAlertsMaster (vuexContext) {
      vuexContext.commit('cleanAlertsMaster')
    },

    setModal (vuexContext, modal) {
      vuexContext.commit('setModal', { ...defaultModal, ...modal})
    },

    cleanModal (vuexContext) {
      vuexContext.commit('setModal', defaultModal)
    }
  }
}
