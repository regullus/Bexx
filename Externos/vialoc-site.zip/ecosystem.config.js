module.exports = {
  apps: [{
    name: "vialoc_site",
    script: "./node_modules/nuxt/bin/nuxt-start",
    env: {
      "HOST": "localhost",
      "PORT": 8080,
      "NODE_ENV": "production",
    }
  }]
}