<template>
  <div class="card-details">

    <!-- LOCATOR / TENANT | RATING -->
    <div class="item" v-if="order.status === 'finished'">
      <el-row :gutter="30">
        <el-col :span="profile === 'tenant' ? 12 : 24">
          <div class="inner-panel">
            <app-rate-user :user="(profile === 'tenant' ? order.locator : order.user)" :profile="profileCounterPart" :is-rateable="!ratingUser" :rating="ratingUser" @set-rating="setRating" :viewType="profile === 'tenant' ? 'block' : 'full'" />
          </div>
        </el-col>
        <el-col :span="12" v-if="profile === 'tenant'">
          <div class="inner-panel">
            <app-rate-product :product="order.product" :is-rateable="!ratingProduct" :rating="ratingProduct" @set-rating="setRating" />
          </div>
        </el-col>
      </el-row>
    </div>

    <div class="item">
      <div class="inner-panel">
        <div class="row">
          <div class="col">
            <h2 class="panel-title">Resumo da reserva</h2>

            <div class="panel-txt">
              <div><strong>Período do aluguel</strong></div>
              <div><span class="secondary-color">{{ order.date_start }}</span> até <span class="secondary-color">{{ order.date_end }}</span></div>
            </div>

            <div class="panel-txt">
              <div>{{ order.product.name }}</div>
              <div>{{ order.product.brand }} - {{ order.product.year }}</div>
              <div>{{ order.product.city }} - {{ order.product.state_code }}</div>
            </div>

            <div
              class="panel-txt"
              v-if="['pending-confirmation', 'pending-payment'].indexOf(order.status) !== -1"
              >
              <strong>Importante:<br/>O aluguel só estará garantido após a confirmação do pagamento.</strong>
            </div>

            <div
              class="panel-link"
              v-if="profile === 'tenant' && ['pending-confirmation', 'pending-payment'].indexOf(order.status) !== -1" @click="$emit('do-action', 'cancel')"
              >
              Cancelar reserva
            </div>
          </div>

          <div class="col">
            <h3 class="panel-title">{{ order.status_formatted }}</h3>

            <div class="table-price">
              <div class="tr">
                <div>
                  <small>R$</small><span class="price"> {{ pricePeriodFormatted }}</span> <small>/{{ pricePeriodLabel.singular }}</small>
                </div>
              </div>
              <div class="tr">
                <div>
                  x<span class="price"> {{ pricePeriodChunks.total }} </span> <small> {{ (pricePeriodChunks.total > 1 ? pricePeriodLabel.plural : pricePeriodLabel.singular) }} </small>
                  <template v-if="pricePeriodChunks.remainingDays > 0"><small>e</small><span class="price"> {{ pricePeriodChunks.remainingDays }} </span><small>dias</small>
                  </template>
                </div>
              </div>
              <div class="tr -col">
                <div>Total</div>
                <div>
                  <small>R$</small> <span class="price"> {{ priceTotalFormatted }} </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- LOCATOR -->
    <div class="item" v-if="overlapping && overlapping.length">
      <div class="inner-panel">
        <div class="panel-header">
          <h2 class="panel-title">Pedidos de reserva concorrentes</h2>
        </div>
        <p>Este pedido de reserva está concorrendo com <strong>{{ overlappingLabel }}</strong> que possuem os períodos de locação que coincidem a este pedido. Após autorizar esta reserva e assim que o locatário fizer o pagamento, os pedidos abaixo serão cancelados:</p>
        <el-table
          class="c7-table"
          :data="overlapping"
          style="width: 100%">
          <el-table-column
            width="80"
            label="Pedido">
            <template slot-scope="scope">
              <nuxt-link :to="`/locador/locacoes/${scope.row.id}`" target="_blank">#{{ scope.row.id }}</nuxt-link>
            </template>
          </el-table-column>
          <el-table-column
            label="Período"
          >
            <template slot-scope="scope">
              de {{ scope.row.date_start }} à {{ scope.row.date_end }} <br> ({{ scope.row.days_total }} dia{{ (scope.row.days_total > 1 ? 's' : '') }})
            </template>
          </el-table-column>
          <el-table-column
            label="Status"
            prop="status_formatted"
          />
          <el-table-column
            width="120"
            label="Valor">
            <template slot-scope="scope">
              <strong>R$ {{ scope.row.price_total_formatted }}</strong>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>

    <!-- TENANT -->
    <div class="item" v-if="order.payment_logs && order.payment_logs.length">
      <div class="inner-panel">
        <div class="panel-header">
          <div class="panel-title">Detalhes do pagamento</div>
          <span class="panel-action" v-if="order.status === 'pending-payment' && ['bank-slip', 'debit-card'].indexOf(order.payment.payment_method_slug) !== -1 && order.payment.status === 'processing'" @click="$emit('do-action', 'change-payment')">Modificar</span>
        </div>
        <el-table
          class="c7-table -payment"
          :data="order.payment_logs"
          stripe
          style="width: 100%;">
          <el-table-column
            label="Método de Pagamento"
            width="220">
            <template slot-scope="scope">
              {{ scope.row.payment_method_formatted }}<br>
              <small v-if="scope.row.payment_method_option_formatted">{{ scope.row.payment_method_option_formatted }} {{ scope.row.credit_card_number }}</small>
              <small v-if="scope.row.payment_method_slug === 'bank-slip' && scope.row.status === 'processing' && !scope.row.is_expired"><a :href="scope.row.url" target="_blank">Ver o boleto</a></small>
              <small v-if="scope.row.payment_method_slug === 'debit-card' && scope.row.status === 'processing'"><a :href="scope.row.url" target="_blank">Autorizar o pagamento no banco</a></small>
            </template>
          </el-table-column>
          <el-table-column
            prop="created_at_formatted"
            label="Data"
            width="150">
          </el-table-column>
          <el-table-column
            label="Status">
            <template slot-scope="scope">
              <div v-html="getPaymentStatus(scope.row)"></div>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>

    <!-- LOCATOR/TENANT -->
    <div class="item" v-if="(profile === 'locator' && ['pending-confirmation', 'pending-payment', 'refused', 'canceled'].indexOf(order.status) === -1) || (profile === 'tenant' && ['pending-takeout', 'active', 'finished'].indexOf(order.status) !== -1)">
      <div class="inner-panel">
        <div class="panel-header">
          <h2 class="panel-title">Endereço de retirada/entrega da carreta</h2>
          <span class="panel-action" v-if="profile === 'locator' && ['active', 'finished'].indexOf(order.status) === -1" @click="openModalManageAddresses">Alterar o endereço de retirada</span>
        </div>
        <div class="box-txt" v-if="profile === 'locator'">
          <p>Este endereço será apresentado ao locatário, somente após a confirmação do pagamento deste pedido.</p>
        </div>
        <div class="box-txt">
          {{ order.address.address }}, {{ order.address.address_number }} {{ order.address.address_complement ? '- ' + order.address.address_complement : '' }}<br>
          {{ order.address.district }} - {{ order.address.city }} - {{ order.address.state_code }} - CEP {{ order.address.zipcode }}<br>
          <a v-if="order.address.latitude" :href="`https://www.google.com/maps/search/?api=1&query=${order.address.latitude},${order.address.longitude}`" target="_blank">Ver mapa</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import _ from 'lodash'
import { floatFormatted } from '@/utils/helpers'
import AppRateProduct from '@/components/AppRateProduct'
import AppRateUser from '@/components/AppRateUser'

export default {
  components: { AppRateProduct, AppRateUser },

  props: {
    order: {
      type: Object,
      required: true,
    },
    profile: {
      type: String,
      default: 'tenant',
    },
    overlapping: {
      type: Array,
      default: null
    },
  },

  data() {
    return {
      rating: {
        user: 0,
        product: 0,
      },
    }
  },

  computed: {
    overlappingLabel () {
      let suffix = ''
      if (this.overlapping.length > 1) {
        suffix = 's'
      }
      return this.overlapping.length + ' pedido' + suffix
    },

    priceTotalFormatted () {
      return floatFormatted(this.order.price_total)
    },

    pricePeriodFormatted () {
      return floatFormatted(this.order.price.price_period)
    },

    pricePeriodChunks() {
      return {
        total: Math.floor(this.order.days_total / this.order.price.more_than),
        remainingDays: this.order.days_total % this.order.price.more_than
      }
    },

    pricePeriodLabel () {
      let periodLabel = {
        singular: 'dia',
        plural: 'dias'
      }

      switch (this.order.price.more_than) {
        case 7:
          periodLabel.singular = 'semana'
          periodLabel.plural = 'semanas'
          break
        case 30:
          periodLabel.singular = 'mês'
          periodLabel.plural = 'meses'
          break
      }

      return periodLabel
    },

    profileCounterPart() {
      return (this.profile === 'tenant' ? 'locator' : 'tenant')
    },

    ratingProduct() {
      if (!this.order.ratings) {
        return null
      }
      return _.find(this.order.ratings, (r) => r.subtype === 'product')
    },

    ratingUser() {
      if (!this.order.ratings) {
        return null
      }
      return _.find(this.order.ratings, (r) => r.subtype === this.profileCounterPart)
    },
  },

  methods: {
    getPaymentStatus (payment) {
      let op = ''
      switch (payment.payment_method_slug) {
        case 'bank-slip':
          op = payment.status_formatted + '<br>'
          if (payment.status === 'processing') {
            op += '<small>Aguardando a compensação do pagamento</small>'
          }
          break;
        case 'credit-card':
          op = payment.status_formatted + '<br>'

          if (payment.status !== 'finished') {
            op += '<small>' + payment.status_authorization_message + '</small>'
          }
          break;
        case 'debit-card':
          op = payment.status_formatted + '<br>'
          if (payment.status === 'processing') {
            op += '<small>Aguardando a autenticação do pagamento com o banco</small>'
          }
          break;
      }

      return op
    },

    openModalManageAddresses () {
      this.$store.dispatch('events/setModal', { id: 'manage-address' })
    },

    setRating (rating) {
      this.$emit('set-rating', rating)
    },
  }
}
</script>


<style lang="scss" scoped>
  .row {
    lost-flex-container: row;
    justify-content: space-between;

    .col {
      max-width: 50%;
      &:last-child {
        text-align: right;
        padding-left: 6rem;
      }
    }
  }
</style>

<style lang="scss">
  .c7-table {
    .cell {
      word-break: normal;
    }

    small {
      font-size: 11px;
    }
  }
</style>
