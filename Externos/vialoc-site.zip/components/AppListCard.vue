<template>
  <div class="list-card">
    <div class="title">
      Slider
    </div>
    <div class="row">
      <div class="item">
        <appCard />
      </div>
      <div class="item">
        <appCard />
      </div>
      <div class="item">
        <appCard />
      </div>
      <div class="item">
        <appCard />
      </div>
      <div class="item">
        <appCard />
      </div>
      <div class="item">
        <appCard />
      </div>
    </div>
    <el-button type="primary">Carregar mais</el-button>
  </div>
</template>

<script>
import AppCard from '@/components/AppCard'

export default {
  components: {
    AppCard
  }
}
</script>

<style lang="scss" scoped>
  .row {
    lost-flex-container: row;
  }
  .item {
    lost-column: 1/2;
    margin-bottom: 3rem;
  }
  .title {
    font-size: 1.9rem;
    margin-bottom: 2rem;
  }
  .link {
    font-size: 1.3rem;
    color: #4A90E2;

    &:hover {
      text-decoration: underline;
    }
  }
</style>
