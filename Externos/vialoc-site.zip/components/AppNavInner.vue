<template>
  <el-menu :default-active="activeIndex" class="inner-nav" mode="horizontal" @select="handleSelect">
    <el-menu-item index="1">Publicadas (6)</el-menu-item>
    <el-menu-item index="2">Pausada (0)</el-menu-item>
    <el-menu-item index="3">Em locação (2)</el-menu-item>
  </el-menu>
</template>

<style lang="scss" scoped>
  .el-menu {
    background-color: transparent;
  }
  .el-menu-item {
    font-size: 12px;
  }
  .el-menu--horizontal {
    border-color: #979797;

    > .el-menu-item {
      border: none;
      height: 32px;
      line-height: 32px;
      border: 1px solid #979797;
      border-bottom: none;
      color: #4A4A4A;

      &:not(:last-child) {
        margin-right: 40px;
      }

      &:hover, &:focus, &.is-active {
        background-color: #4AB5E2;
        color: #fff;
        border-color: #4AB5E2;
      }
    }
  }
</style>

<script>
  export default {
    data() {
      return {
        activeIndex: '2',
      };
    },
    methods: {
      handleSelect(key, keyPath) {
        console.log(key, keyPath);
      }
    }
  }
</script>
