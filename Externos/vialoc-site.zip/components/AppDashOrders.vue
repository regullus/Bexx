<template>
  <div class="dash-item">
    <h2 class="title">
      <template v-if="subject === 'unconfirmed'">
        <svg-request class="icon dash-color" width="18" height="18"/>
        <span v-if="profile === 'tenant'">Pedidos aguardando confirmação</span>
        <span v-else>Pedidos para confirmar</span>
      </template>
      <template v-else-if="subject === 'takeout'">
        <svg-delivered class="icon dash-color" width="12" height="12"/> Carretas a serem retiradas
      </template>
      <template v-else-if="subject === 'finishing'">
        <svg-removed class="icon dash-color" width="12" height="12"/> Carretas a serem devolvidas
      </template>
      &nbsp; <span class="dash-color" v-show="counter > 0">{{ counter }}</span>
    </h2>
    <ul class="dash-list">
      <li is="app-dash-list-line" v-for="order in orders" :order="order" :key="`list-item-${order.id}`"/>
      <li v-show="counter === 0" class="dash-list-line">Não há pedidos no momento.</li>
    </ul>
    <div class="dash-bottom">
      <el-button type="primary" @click="goTo" size="small" v-if="counter > 0">Ver todas</el-button>
    </div>
  </div>
</template>

<script>
import AppDashListLine from '@/components/AppDashListLine'
import SvgRequest from '@/assets/svg/request.svg?inline'
import SvgDelivered from '@/assets/svg/delivered.svg?inline'
import SvgRemoved from '@/assets/svg/removed.svg?inline'

export default {
  components: {
    AppDashListLine,
    SvgRequest,
    SvgDelivered,
    SvgRemoved,
  },

  props: {
    profile: {
      type: String,
      default: 'tenant',
    },
    subject: {
      type: String,
      default: 'unconfirmed',
    },
    orders: {
      type: Array,
      required: true,
    },
    counter: {
      type: Number,
      default: 0
    }
  },

  methods: {
    goTo() {
      switch(this.subject) {
        case 'unread':
          this.$router.push(`/locador/pedidos#nao-lidos`)
          break;
        case 'takeout':
          this.$router.push(`/locador/pedidos#a-retirar`)
          break;
        case 'finishing':
          this.$router.push(`/locador/pedidos#ativas`)
          break;
      }
    }
  }
}
</script>

