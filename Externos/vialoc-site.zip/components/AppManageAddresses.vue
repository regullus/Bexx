<template>
  <el-tabs type="card" v-model="tabActive">
    <el-tab-pane label="Endereços cadastrados" name="list">
      <app-alert ref="listAlert" />

      <app-card-address v-for="address in addresses" :key="`card-address-${address.id}`" :address="address" :show-edit="showEdit" :show-select="showSelect" :show-set-main="showSetMain" @define-address="defineAddress(address)" @edit-address="editAddress(address)" @define-address-main="defineAddressMain(address)"></app-card-address>
    </el-tab-pane>
    <el-tab-pane :label="inputAddress.id ? 'Editar endereço' : 'Adicionar novo endereço'" name="form">
      <el-form :model="inputAddress" :rules="inputAddressRules" ref="formInputAddress" class="el-form--label-top">
        <div class="form-group" v-if="inputAddress.id">
          <h4 class="form-title">Editar endereço: {{ inputAddress.label }}</h4>
          <p>Para editar, preencha os campos abaixo e clique em Salvar endereço:</p>
        </div>
        <div class="form-group" v-else>
          <h4 class="form-title">Cadastrar novo endereço</h4>
          <p>Preencha os campos abaixo para cadastrar um novo endereço:</p>
        </div>

        <app-alert ref="formAlert" />

        <el-col :span="inModal ? 24 : 16">
          <el-row :gutter="10">
            <el-col :span="24">
              <el-form-item label="Identificador" prop="label">
                <el-input v-model="inputAddress.label" placeholder="Ex.: Endereço da Garagem"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="12">
              <el-form-item label="CEP" prop="zipcode">
                <el-input v-model="inputAddress.zipcode" v-mask="'#####-###'" @input="getAddressByZipcode"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="18">
              <el-form-item label="Endereço" prop="address">
                <el-input v-model="inputAddress.address"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="Número" prop="address_number">
                <el-input v-model="inputAddress.address_number" ref="address_number"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="12">
              <el-form-item label="Complemento" prop="address_complement">
                <el-input v-model="inputAddress.address_complement"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="Bairro" prop="district">
                <el-input v-model="inputAddress.district"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="10">
              <el-form-item label="Estado" prop="state_code">
                <el-select v-model="inputAddress.state_code" @change="getCities">
                  <el-option v-for="state in states" :key="'state-' + state.value" :label="state.label" :value="state.value"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="14">
              <el-form-item label="Cidade" prop="city_id">
                <el-select v-model="inputAddress.city_id" filterable placeholder="Selecione">
                  <el-option v-for="city in cities" :key="'city-' + city.id" :label="city.name" :value="city.id"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item>
            <el-button @click="onCancel">Cancelar</el-button>
            <el-button type="primary" @click="onSubmit">{{ inputAddress.id ? 'Salvar endereço' : 'Inserir endereço' }}</el-button>
          </el-form-item>
        </el-col>
      </el-form>

    </el-tab-pane>
  </el-tabs>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'
import { mask } from 'vue-the-mask'
import AppAlert from '@/components/AppAlert'
import AppCardAddress from '@/components/AppCardAddress'
import { errorsMixin } from '@/mixins'

const defaultAddress = {
  id: null,
  label: null,
  zipcode: null,
  address: null,
  address_number: null,
  address_complement: null,
  district: null,
  city_id: null,
  state: null,
}

export default {
  directives: {mask},

  mixins: [ errorsMixin ],

  components: {
    AppAlert,
    AppCardAddress
  },

  props: {
    inModal: {
      type: Boolean,
      default: false
    },
    showSelect: {
      type: Boolean,
      default: false
    },
    showSetMain: {
      type: Boolean,
      default: false
    },
    showEdit: {
      type: Boolean,
      default: false
    },
  },

  data() {
    return {
      tabActive: 'list', // list | form
      states: [
        { value: 'AC', label: 'Acre' },
        { value: 'AL', label: 'Alagoas' },
        { value: 'AP', label: 'Amapá' },
        { value: 'AM', label: 'Amazonas' },
        { value: 'BA', label: 'Bahia' },
        { value: 'CE', label: 'Ceará' },
        { value: 'DF', label: 'Distrito Federal' },
        { value: 'ES', label: 'Espírito Santo' },
        { value: 'GO', label: 'Goiás' },
        { value: 'MA', label: 'Maranhão' },
        { value: 'MT', label: 'Mato Grosso' },
        { value: 'MS', label: 'Mato Grosso do Sul' },
        { value: 'MG', label: 'Minas Gerais' },
        { value: 'PA', label: 'Pará' },
        { value: 'PB', label: 'Paraíba' },
        { value: 'PR', label: 'Paraná' },
        { value: 'PE', label: 'Pernambuco' },
        { value: 'PI', label: 'Piauí' },
        { value: 'RJ', label: 'Rio de Janeiro' },
        { value: 'RN', label: 'Rio Grande do Norte' },
        { value: 'RS', label: 'Rio Grande do Sul' },
        { value: 'RO', label: 'Rondônia' },
        { value: 'RR', label: 'Roraima' },
        { value: 'SC', label: 'Santa Catarina' },
        { value: 'SP', label: 'São Paulo' },
        { value: 'SE', label: 'Sergipe' },
        { value: 'TO', label: 'Tocantins' },
      ],
      cities: [],
      addresses: [],
      inputAddress: _.clone(defaultAddress),

      inputAddressRules: {
        label: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        zipcode: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        address: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        address_number: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        district: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        city_id: [
          {type: 'integer', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
        state_code: [
          {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
        ],
      },
    }
  },

  mounted () {
    this.$axios.$get('common/users/addresses')
      .then(
        response => {
          this.addresses = response
        },
        error => {
          this.errorsAlert(error)
        }
      )
  },

  methods: {
    defineAddress (address) {
      this.$emit('define-address', address)
    },

    editAddress (address) {
      this.$refs['formInputAddress'].clearValidate()
      Vue.set(this, 'inputAddress', address)
      this.tabActive = 'form'
      this.getCities()
    },

    defineAddressMain (address) {
      this.$axios.$put(`/common/users/address/${address.id}/set-main`).
        then(
          response => {
            Vue.set(this, 'addresses', response)
          },
          error => {
            this.errorsAlert(error)
          }
        )
    },

    getCities () {
      if (!this.inputAddress.state_code) {
        return
      }
      let citiesMessage = this.$message({ message: 'Por favor aguarde, estamos carregando a lista de cidades.' })

      this.$axios.$get(`/common/utils/cities-by-state/${this.inputAddress.state_code}`)
      .then(
        response => {
          this.cities = response
          citiesMessage.close()
        },
        error => {
          citiesMessage.close()
          this.errorsAlert(error)
        }
      )
    },

    getAddressByZipcode () {
      if (this.inputAddress && this.inputAddress.zipcode.length === 9) {
        let addressMessage = this.$message({ message: 'Por favor aguarde, estamos carregando o endereço referente ao CEP.' })
        this.$axios.$get(`/common/utils/zipcode/${this.inputAddress.zipcode}`).then(
          response => {
            addressMessage.close()
            Vue.set(this, 'inputAddress', { ...this.inputAddress, ...response })
            this.getCities()
          },
          error => {
            addressMessage.close()
            this.$refs['formAlert'].showAlert({ id:'alert-zipcode-not-found', type: 'error', title: 'CEP não encontrado', description: 'Por favor, verifique se o CEP foi digitado corretamente.' })
          }
        )
      }
    },

    onCancel() {
      this.tabActive = 'list'
      this.inputAddress = _.clone(defaultAddress)
      this.$refs['formInputAddress'].clearValidate()
    },

    onSubmit() {
      this.$refs['formInputAddress'].validate((valid) => {
        if (valid) {
          if (this.inputAddress.id) {
            this.updateAddress()
          } else {
            this.createAddress()
          }
        } else {
          this.$refs['formAlert'].showAlert({ id: 'alert-address-submit-errors', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
          return false;
        }
      })
    },

    createAddress() {
      this.$axios.$post('/common/users/address', this.inputAddress)
        .then(
          response => {
            this.addresses.push(response)
            this.tabActive = 'list'
            this.$emit('define-address', response)
            this.$refs['formInputAddress'].clearValidate()
            this.inputAddress = _.clone(defaultAddress)
            this.$refs['listAlert'].showAlert({ id: 'alert-address-success', type: 'success', title: 'Endereço criado', description: `O endereço "${response.label}" foi criado com sucesso.` })
          }, error => {
            this.errorsAlert(error)
          }
        )
    },

    updateAddress() {
      this.$axios.$put(`/common/users/address/${this.inputAddress.id}`, this.inputAddress)
        .then(
          response => {
            let index = _.findIndex(this.addresses, (a) => a.id === response.id)
            Vue.set(this.addresses, index, response)
            this.tabActive = 'list'
            this.$emit('define-address', response)
            this.$refs['formInputAddress'].clearValidate()
            this.inputAddress = _.clone(defaultAddress)
            this.$refs['listAlert'].showAlert({ id: 'alert-address-success', type: 'success', title: 'Endereço atualizado', description: `O endereço "${response.label}" foi atualizado com sucesso.` })
          }, error => {
            this.errorsAlert(error)
          }
        )
    },
  }
}
</script>

<style lang="scss" scoped>
</style>
