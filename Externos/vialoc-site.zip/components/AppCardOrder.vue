<template>
<!--
  Propriedades:
    Type: flat - Muda estilo do card para flat ( add class '-flat')
          Padrao não flat
    Process: owner - Opcoes de visualizacao do card para o proprietário
             only-view - remove os links, pois é somente para visualização
             Padrao null
-->
  <div class="card" :class=" type === 'flat' ? '-flat' : '' ">
    <figure v-if="order.product.featured_image_path" class="figure" :style="`background-image: url(${mediaBaseUrl}/${order.product.featured_image_path})`">
      <img :src="`${mediaBaseUrl}/${order.product.featured_image_path}`" :alt="order.product.name">
    </figure>
    <figure v-else class="figure" :style="`background-image: url(${require('~assets/images/img-unavailable-360.png')})`">
      <img :src="require('@/assets/images/img-unavailable-360.png')" :alt="order.product.name">
    </figure>
    <div class="ctn">
      <div class="info">
        <ul class="list">
          <li>{{ order.product.name }}</li>
          <li>{{ order.product.type_formatted }} - {{ order.product.brand }} - {{ order.product.year }}</li>
          <li>
            {{ order.product.city }} - {{ order.product.state_code }}
          </li>
        </ul>
      </div>
      <div class="bottom">
        <div class="price" v-if="showPrice">
          <template v-if="priceFormatted">
            <small>a partir de</small>
            R$ <span class="value">{{ priceFormatted }}</span>/mês
          </template>
          <template v-else>
            <span class="default">Preço indefinido</span>
          </template>
        </div>
        <el-rate
          v-model="rating.score"
          disabled
          disabled-void-color="#c0c4cc"
          >
        </el-rate>
      </div>
      <div class="btns" v-if="process == 'owner'">
        <el-button size="small" type="text" icon="el-icon-view" @click="goTo('owner-order')">Detalhes do pedido</el-button>
        <el-button size="small" type="text" icon="el-icon-message" @click="goTo('owner-messages')">Mensagens</el-button>
        <el-button size="small" type="text" icon="el-icon-info" @click="goTo('page')">Ver página</el-button>
      </div>
      <div class="btns" v-else>
        <el-button size="small" type="text" icon="el-icon-view" @click="goTo('order')">Detalhes do pedido</el-button>
        <el-button size="small" type="text" icon="el-icon-message" @click="goTo('messages')">Mensagens</el-button>
        <el-button size="small" type="text" icon="el-icon-info" @click="goTo('page')">Ver página</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'
import { floatFormatted } from '@/utils/helpers'

export default {
  props: {
    type: {
      type: String,
      default: null
    },
    process: {
      type: String,
      default: null
    },
    order: {
      type: Object,
      // required: true,
      default: null,
    },
    showPrice: {
      type: Boolean,
      default: true,
    },
  },

  data() {
    return {
      mediaBaseUrl: process.env.MEDIA_BASE_URL,

      rating: {
        score: 5
      }
    }
  },

  computed: {
    priceFormatted () {
      if (!this.order.product.price_from) {
        return null
      }
      let price = floatFormatted(this.order.product.price_from)
      return price.toString().replace(',00', '')
    },

  },

  methods: {
    goTo (action) {
      switch (action) {
        case 'messages':
          this.$router.push(`/locatario/locacoes/${this.order.id}/mensagens`)
          break;
        case 'owner-messages':
          this.$router.push(`/locador/locacoes/${this.order.id}/mensagens`)
          break;
        case 'order':
          this.$router.push(`/locatario/locacoes/${this.order.id}`)
          break;
        case 'owner-order':
          this.$router.push(`/locador/locacoes/${this.order.id}`)
          break;
        case 'page':
          // let routePage = this.$router.resolve(`/carreta/${this.order.product.slug}`)
          window.open(`/carreta/${this.order.product.slug}`, '_blank')
          break;
      }
    },
  }
}
</script>

<style lang="scss" scoped>
  .ctn {
    padding: 1.2rem;
    position: relative;
  }

  .info {
    font-size: 1.4rem;
    padding-top: .8rem;
    position: relative;

    small {
      font-size: 1.2rem;
      color: #666;
    }
  }

  .price {
    line-height: 1;

    small {
      display: block;
      font-size: 1.1rem;
      color: #999;
    }

    .value {
      color: #5CAF00;
      font-size: 2.2rem;
    }

    .default {
      font-size: 1.4rem;
    }
  }

  .bottom {
    padding: 1rem 0;
    lost-flex-container: row;
    justify-content: space-between;
    align-items: center;

    .el-rate {
      pointer-events: auto;
    }
  }

  .figure {
    display: block;
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;

    img {
      object-fit: cover;
      width: 100%;
      height: 100%;
    }
  }

  .btns {
    lost-flex-container: row;
    align-items: center;
    .wrp {
      .el-button {
        margin-right: 2rem;
      }
    }
  }

  .card {
    background-color: #fff;
    transition: all 300ms ease-in-out;
    cursor: pointer;
    position: relative;

    &:hover {
      box-shadow: 0 3px 20px 0 rgba(0,0,0,0.25);

      .details {
        opacity: 1;
      }

    }

    // &:not(.-flat) {
    //   &:before {
    //     content: '';
    //     display: block;
    //     width: 100%;
    //     height: 100%;
    //     background-color: rgba(0,0,0,.6);
    //     position: absolute;
    //     top: 0;
    //     left: 0;
    //     z-index: 1;
    //     visibility: hidden;
    //     opacity: 0;
    //     transition: all 300ms ease-in-out;
    //   }
    //   &:hover {
    //     &:before {
    //       visibility: visible;
    //       opacity: 1;
    //     }
    //   }
    // }

    &.-flat {
      lost-flex-container: row;

      .figure {
        @media (min-width: $screen-md) {
          width: 215px;
        }
      }

      .info {
        padding-top: 0;
      }

      .ctn {
        @media (min-width: $screen-md) {
          width: calc( 100% - 215px );
        }
      }

    }
  }
</style>
