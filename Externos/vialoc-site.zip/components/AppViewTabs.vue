<template>
  <el-tabs v-model="activeName" @tab-click="handleClick">
    <el-tab-pane label="Descrição" name="first">
      <div class="box-txt">
        <div class="sec">
          <ul>
            <li>Contrato mínimo 4 meses</li>
            <li>Pessoa jurídica ou física</li>
            <li>Sem pneus. Consulte-nos para locação com pneus.</li>
            <li>Incluso Proteção patrimonial.</li>
          </ul>

          <p>Para contratos acima de 6 meses, revisão de freios e parte elétrica gratuita. Incluso na revisão:
          Troca das lonas de freio, graxa, retentores, trava aranha, e molas de retenção dos patins.</p>
        </div>

        <div class="sec">
          <h2>Informações técnicas:</h2>

          <p>Para 26 paletes 1.050mm x 1.250mm, invertidos.
          Altura interna: 2.700mm
          Laterais: lona vinílica reforçada, sustentada por rodízios e tracionadas longitudinalmente pela dianteira e na vertical por catracas de polietileno.</p>

          <p>O assoalho do semi-reboque sider é fabricado em chapa de aço xadrez 4,75mm, para resistir ao trânsito de empilhadeiras com até 950 kg por ponto de apoio, quando necessário disponibilizamos do assoalho ômega (aço + madeira).</p>

          <p>A porta traseira dos siders possui revestimento externo em chapa de aço lisa, pré-pintada na cor branca. Esta superfície lisa garante uma perfeita visualização para divulgação e/ou identificação de frota. A porta possui travas com espera para cadeado com varões de travamento. Com cobertura translúcida, que facilita a dissipação de calor e permite aproveitamento de iluminação interna, o teto é encaixado através de sistema hermético, sem a utilização de rebites, que confere ao conjunto maior resistência e menor manutenção.</p>
        </div>

        <div class="sec">
          <h2>Vantagens:</h2>

          <ul>
            <li>Rapidez nas operações de carga e descarga; </li>
            <li>Nova coluna móvel “easy lock” – Patente Requerida; </li>
            <li>Engate da coluna móvel easy lock – Patente Requerida; </li>
            <li>Proteção total à Carga;</li>
          </ul>
        </div>
      </div>

    </el-tab-pane>
    <el-tab-pane label="Avaliações" name="second">
      Config
    </el-tab-pane>
  </el-tabs>
</template>

<script>
  export default {
    data() {
      return {
        activeName: 'first'
      };
    },
    methods: {
      handleClick(tab, event) {
        console.log(tab, event);
      }
    }
  };
</script>
