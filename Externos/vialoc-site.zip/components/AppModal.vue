<template>
    <div class="c7-modal" v-if="modal">
      <el-dialog :visible="modal.id === 'login'" @close="$store.dispatch('events/cleanModal')">
        <el-row v-if="modal && modal.message" class="dialog-header">
          <h2 class="title" v-if="modal.title">{{ modal.title }}</h2>
          <p>{{ modal.message }}</p>
        </el-row>
        <el-row class="dialog-buttons">
          <el-button class="el-button--face" @click="doSocialLogin('facebook')"><svg-facebook class="icon" /> Login com Facebook</el-button>
          <el-button class="el-button--google" @click="doSocialLogin('google')"><svg-google class="icon" /> Login com Google</el-button>
        </el-row>
        <el-row class="dialog-other">
          ou
        </el-row>
        <el-row class="dialog-form">
          <app-alert ref="alertLogin"/>
          <el-form :model="login" :rules="loginRules" ref="formLogin" class="el-form--label-top">
            <el-row :gutter="10">
              <el-col :span="12">
                <el-form-item label="E-mail" prop="email">
                  <el-input v-model="login.email"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="Senha" prop="password">
                  <el-input :type="formEl.passwordField" v-model="login.password"></el-input>
                  <i class="show-password el-icon-view" :class="{ '-active': formEl.passwordView }" @click="onPasswordView"></i>
                </el-form-item>
              </el-col>
            </el-row>

            <!--
            <el-row>
              <el-col :span="24">
                <el-form-item class="check">
                  <el-checkbox v-model="login.remember" true-label="1" false-label="0">Lembre-me</el-checkbox>
                </el-form-item>
              </el-col>
            </el-row>
            -->
            <el-row>
              <small class="form-obs"><span>*</span> Itens obrigatórios.</small>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item>
                  <el-button type="primary" @click="onLoginSubmit" class="submit el-button--block">Login</el-button>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </el-row>
        <el-row class="dialog-remember">
          <span @click="changeModal('forgot-password')" class="fake-link">Esqueceu sua senha?</span>
        </el-row>
        <span slot="footer" class="dialog-footer">
          Não tem uma conta? <span class="fake-link" @click="goRegister">Crie aqui</span>.
        </span>
      </el-dialog>

      <el-dialog :visible="modal.id === 'forgot-password'" @close="$store.dispatch('events/cleanModal')">
        <el-row class="dialog-header">
          <h2 class="title">Esqueci minha senha</h2>
          <p>Por favor, preencha o campo com o E-mail da conta cadastrada no site.</p>
        </el-row>
        <el-row class="dialog-form">
          <app-alert ref="alertForgot"/>
          <el-form :model="login" :rules="forgotRules" ref="formForgot" class="el-form--label-top">
            <el-row :gutter="10">
              <el-col :span="18">
                <el-form-item label="E-mail" prop="email">
                  <el-input v-model="login.email"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <el-form-item>
                  <el-button type="primary" @click="onForgotSubmit" class="submit el-button--block">Continuar</el-button>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </el-row>
        <span slot="footer" class="dialog-footer">
          Já possui uma conta? <span class="fake-link" @click="modal = 'login'">Faça o login</span> ou  <span class="fake-link" @click="goRegister">cadastre-se</span>.
        </span>
      </el-dialog>

      <el-dialog :visible="modal.id === 'redefine-password'" @open="setRedefinePasswordToken()" @close="$store.dispatch('events/cleanModal')">
        <el-row class="dialog-form">
          <el-row class="dialog-header">
            <h2 class="title">Criar nova senha</h2>
            <p>Preencha os campos abaixo para redefinir a sua senha de acesso:</p>
          </el-row>
          <app-alert ref="alertRedefinePassword"/>
          <el-form :model="redefinePassword" :rules="redefinePasswordRules" ref="formRedefinePassword" class="el-form--label-top">
            <el-row>
              <el-col :span="24">
                <el-form-item label="E-mail" prop="email">
                  <el-input v-model="redefinePassword.email"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="10">
              <el-col :span="12">
                <el-form-item label="Senha" prop="password">
                  <el-input :type="formEl.redefinePasswordField" v-model="redefinePassword.password"></el-input>
                  <i class="show-password el-icon-view" :class="{ '-active': formEl.passwordView }" @click="onRedefinePasswordView"></i>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="Confirmar a senha" prop="password_confirmation">
                  <el-input :type="formEl.redefinePasswordField" v-model="redefinePassword.password_confirmation"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item>
                  <el-button type="primary" @click="onRedefinePasswordSubmit" class="submit el-button--block">Redefinir a senha</el-button>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </el-row>
        <el-row class="dialog-remember">
          <span @click="changeModal('forgot-password')">Esqueceu sua  senha?</span>
        </el-row>
        <span slot="footer" class="dialog-footer">
          Não tem uma conta? <span class="link" @click="goRegister">Clique aqui</span>.
        </span>
      </el-dialog>

      <el-dialog :visible="modal.id === 'generic'" @close="$store.dispatch('events/cleanModal')">
        <el-row v-if="modal && modal.message" class="dialog-header">
          <h2 class="title" v-if="modal.title">{{ modal.title }}</h2>
          <el-alert class="modal-generic-alert" :closable="false" v-if="modal.type" :title="modal.typeLabel || 'Sucesso!'" :type="modal.type" show-icon></el-alert>
          <div v-html="modal.message"></div>
        </el-row>
      </el-dialog>
    </div>
</template>

<script>
  import _ from 'lodash'
  import AppAlert from '@/components/AppAlert'
  import { errorsMixin, socialLoginMixin } from '@/mixins'
  import SvgFacebook from '@/assets/svg/facebook.svg?inline'
  import SvgGoogle from '@/assets/svg/google.svg?inline'

  export default {
     mixins: [ errorsMixin, socialLoginMixin ],

    components: {
      AppAlert,
      SvgFacebook,
      SvgGoogle,
    },

    data() {
      return {
        formEl: {
          passwordView: false,
          passwordField: 'password',
          redefinePasswordField: 'password',
        },
        login: {
          // email: this.$auth.user && this.$auth.user.email ? this.$auth.user.email || '',
          email: '',
          password: '',
        },
        redefinePassword: {
          token: '',
          email: '',
          password: '',
          password_confirmation: '',
        },
        loginRules: {
          email: [
            {type: 'email', required: true, message: 'Insira um e-mail válido', trigger: 'blur'}
          ],
          password: [
            {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
          ],
        },
        forgotRules: {
          email: [
            {type: 'email', required: true, message: 'Insira um e-mail válido', trigger: 'blur'}
          ],
        },
        redefinePasswordRules: {
          email: [
            {type: 'email', required: true, message: 'Insira um e-mail válido', trigger: 'blur'}
          ],
          password: [
            {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
          ],
          password_confirmation: [
            {type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur'}
          ],
        },
      }
    },

    computed: {
      modal () {
        return this.$store.state.events.modal
      }
    },

    mounted() {
      if (this.$auth.loggedIn) {
        this.login.email = this.$auth.user.email
      }
    },

    methods: {
      onPasswordView(){
        if (!this.formEl.passwordView) {
          this.formEl.passwordView = true
          this.formEl.passwordField = 'text'
        } else {
          this.formEl.passwordView = false
          this.formEl.passwordField = 'password'
        }
      },

      onRedefinePasswordView(){
        if (!this.formEl.redefinePasswordView) {
          this.formEl.redefinePasswordView = true
          this.formEl.redefinePasswordField = 'text'
        } else {
          this.formEl.redefinePasswordView = false
          this.formEl.redefinePasswordField = 'password'
        }
      },

      onLoginSubmit() {
        //força a desconexão do $echo
        this.$echo.disconnect()

        this.$refs['formLogin'].validate((valid) => {
          if (valid) {
            this.$auth.loginWith('local', {
              data: this.login
            }).then(
              (response) => {
                // atualiza o $echo com o novo token
                this.$echo.options.auth.headers.Authorization = localStorage.getItem('auth.token.local')
                // inicia o listening para as notifications
                console.log('conecta o $echo e inicia o listening para as notifications', 'users.' + this.$auth.user.uid)
                this.$echo.connector.connect()
                this.$echo.private('users.' + this.$auth.user.uid).notification((notification) => {
                  console.log('echo notification', notification)
                  this.$store.dispatch('notifications/addNotification', notification);
                })

                if (this.$auth.user.status === 'to-complete') {
                  this.$router.push('/complete-seu-cadastro')
                } else {
                  if (this.modal.redirect !== false) { // se false, não redireciona, apenas fecha o modal
                    if (this.modal.redirect) {
                      this.$router.push(this.modal.redirect)
                    } else {
                      this.$router.push('/minha-conta')
                    }
                  }
                }

                this.$store.dispatch('events/cleanModal')
              },
              error => {
                this.login.password = ''
                this.$refs['formLogin'].validate()
                this.errorsAlert(error, { ref: 'alertLogin' })
              }
            )
          } else {
            this.$refs['alertLogin'].showAlert({ id: 'alert-login-errors', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
            return false;
          }
        })
      },

      onForgotSubmit() {
        this.$refs['formForgot'].validate((valid) => {
          if (valid) {
            // Envia os dados ao endpoint
            this.$axios.$post('/common/auth/forgot-password', {
              email: this.login.email,
            }).then(
              response => {
                this.changeModal({
                  id: 'generic',
                  type: 'success',
                  typeLabel: 'E-mail enviado com sucesso!',
                  title: 'Esqueci minha senha',
                  message: 'Uma mensagem contendo o link de redefinição de senha foi enviada para o email cadastrado. Verifique a sua caixa postal e siga as instruções.',
                })
              },
              error => {
                this.errorsAlert(error, { ref: 'alertForgot' })
              }
            )
          } else {
            this.$refs['alertForgot'].showAlert({ id: 'alert-login-errors', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
            return false
          }
        })
      },

      onRedefinePasswordSubmit() {
        this.$refs['formRedefinePassword'].validate((valid) => {
          if (valid) {
            // Envia os dados ao endpoint
            this.$store.dispatch('base/redefinePassword', this.redefinePassword)
            .then(
              response => {
                this.changeModal({
                  id: 'generic',
                  type: 'success',
                  typeLabel: 'Sua senha foi alterada com sucesso!',
                  title: 'Senha redefinida',
                  message: 'E a sua sessão já foi iniciada. Agora você poderá aproveitar dos recursos oferecidos pela Vialoc.',
                })
              },
              error => {
                this.errorsAlert(error, { ref: 'alertRedefinePassword' })
              }
            )
          } else {
            this.$refs['alertRedefinePassword'].showAlert({ id: 'alert-login-errors', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
            return false;
          }
        })
      },

      setRedefinePasswordToken() {
        this.redefinePassword.token = this.$route.query['redefinir-senha']
      },

      goRegister() {
        this.$store.dispatch('events/cleanModal')
        this.$router.push('/cadastro')
      },

      changeModal(modal) {
        let modalObj = modal
        if (_.isString(modal)) {
          modalObj = { id: modal }
        }

        this.$store.dispatch('events/cleanModal')
        setTimeout(() => {
          this.$store.dispatch('events/setModal', modalObj)
        }, 500)
      },

      setLoginEmail(email) {
        this.login.email = email
      },
    }

  };
</script>

<style lang="scss" scoped>
  .dialog-footer {
    display: block;
    border-top: 1px solid #D3D3D3;
    padding-top: 2.4rem;
    span {
      color: #468EE5;
      text-decoration: underline;
    }
  }
  .dialog-remember {
    text-align: center;
    color: #468EE5;
    text-decoration: underline;
  }
  // .el-form-item {
  //   margin-bottom: 14px;
  // }
  .dialog-buttons {
    .el-button {
      width: calc( 100% / 2 - 7px );
    }
  }
  .dialog-other {
    text-align: center;
    font-size: 12px;
    position: relative;
    margin: 3rem 0;

    &:before, &:after {
      content: '';
      display: block;
      height: 1px;
      background: #D3D3D3;
      position: absolute;
      top: 9px;
      width: 47%;
    }

    &:after {
      right: 0;
    }
  }
  .dialog-header {
    margin-bottom: 1.6rem;
    > .title {
      font-size: 2rem;
    }
    p {
      line-height: 1.4;
      margin-bottom: 1.6rem;
    }
  }
  .dialog-obs {
    font-size: 1.1rem;
    line-height: 1.2;
    display: block;
    margin-top: .7rem;
  }
  .show-password {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 2rem;
    cursor: pointer;

    &.-active {
      color: $primary-color;
    }
  }

  .c7-modal {
    .modal-generic-alert {
      margin: 2rem 0;
    }
  }
</style>
