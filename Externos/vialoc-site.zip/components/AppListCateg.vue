<template>
  <div class="list-categ">
    <div class="container">
      <div class="item">
        <div class="title">
          Slider <a href="#" class="link"> - Ver Lista completa</a>
        </div>
        <appCard />
      </div>
      <div class="item">
        <div class="title">
          Slider <a href="#" class="link"> - Ver Lista completa</a>
        </div>
        <appCard />
      </div>
      <div class="item">
        <div class="title">
          Slider <a href="#" class="link"> - Ver Lista completa</a>
        </div>
        <appCard />
      </div>
      <div class="item">
        <div class="title">
          Slider <a href="#" class="link"> - Ver Lista completa</a>
        </div>
        <appCard />
      </div>
      <div class="item">
        <div class="title">
          Slider <a href="#" class="link"> - Ver Lista completa</a>
        </div>
        <appCard />
      </div>
      <div class="item">
        <div class="title">
          Slider <a href="#" class="link"> - Ver Lista completa</a>
        </div>
        <appCard />
      </div>
    </div>
  </div>
</template>

<script>
import AppCard from '@/components/AppCard.vue'

export default {
  components: {
    AppCard
  }
}
</script>

<style lang="scss" scoped>
  .item {
    lost-column: 1/3;
    margin-bottom: 3rem;
  }
  .title {
    font-size: 1.9rem;
    margin-bottom: 2rem;
  }
  .link {
    font-size: 1.3rem;
    color: #4A90E2;

    &:hover {
      text-decoration: underline;
    }
  }
</style>
