<template>
  <div class="overlay" :class="`overlay-${type}`">
    <div class="title">
      {{ title }}
    </div>
    <div class="actions">
      <span class="action-click" @click.stop="previewImage()">
        <i class="el-icon-zoom-in"></i> {{ labels.zoom }}
      </span>

      <el-popover placement="top" width="240" trigger="manual" v-model="popover">
        <p>Deseja realmente remover esta imagem?</p>
        <div style="text-align: right; margin: 0">
          <el-button size="mini" type="text" @click="setPopover(false)">Cancelar</el-button>
          <el-button type="primary" size="mini" @click="removeImage()">Sim</el-button>
        </div>
        <span slot="reference" class="action-click" @click="setPopover(true)">
          <i class="el-icon-delete"></i> {{ labels.delete }}
        </span>
      </el-popover>

      <span class="action-click" @click.stop="setFeaturedImage()">
        <i :class="isFeaturedImage ? 'el-icon-star-on' : 'el-icon-star-off'"></i>
        <span v-if="isFeaturedImage"> {{ labels.isFeatured }}</span>
        <span v-else> {{ labels.feature }}</span>
      </span>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'

export default {
  props: {
    image: {
      type: Object,
      required: true
    },
    title: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: 'image'
    },
    productFeaturedImage: {
      type: Object,
      default: () => {}
    },
  },

  data() {
    return {
      popover: false,
    }
  },

  computed: {
    isFeaturedImage() {
      return this.productFeaturedImage && this.image.id === this.productFeaturedImage.id
    },

    labels() {
      let actionLabels = {
        zoom: 'Ampliar',
        delete: 'Remover',
        feature: 'Destacar',
        isFeatured: 'É a principal',
      }

      if (this.type === 'view-image') {
        actionLabels = {
          zoom: 'Ampliar imagem',
          delete: 'Remover imagem',
          feature: 'Definir como imagem principal',
          isFeatured: 'É a imagem principal',
        }
      }

      return actionLabels
    }
  },

  methods: {
    setFeaturedImage() {
      this.$emit('set-featured-image', this.image)
    },

    previewImage() {
      this.$emit('preview-image', this.image)
    },

    removeImage() {
      this.$emit('remove-image', { image: this.image, type: this.type })
    },

    setPopover(openPopover) {
      console.log('setPopover', openPopover)
      this.popover = openPopover
    },
  }
}
</script>

<style lang="scss" scoped>
  .overlay {
    display: none;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    color: #ccc;
    background-color: rgba(0, 0 , 0, 0.8);
    font-size: 1.4rem;
    vertical-align: middle;

    .title {
      position: absolute;
      top: 1rem;
      width: 100%;
      padding: 0 10px;
      text-align: center;
      font-size: 1.6rem;
    }

    &.overlay-image {
      font-size: 1.1rem;

      .title {
        display: none;
      }
    }

    .actions {
      position: absolute;
      bottom: 1rem;
      width: 100%;
      text-align: center;

      span  {
        cursor: pointer;
      }
    }

    .action-click {
      display: block;
      margin-bottom: 10px;

      &:hover {
        color: #fc0;
      }
    }
  }
</style>