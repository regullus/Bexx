<template>
  <div class="panel-user" v-if="$auth.loggedIn">
    <div class="panel-user-image">
      <app-avatar-upload :avatar="$auth.user.avatar" @avatar-error="avatarError" />
    </div>
    <div class="panel-user-ctn">
      <div class="panel-user-header">
        <div class="name">{{ $auth.user.name }} {{ $auth.user.last_name }}</div>
        <div class="register">Cadastrado desde {{ profileCreatedDate }}</div>
      </div>
      <div class="panel-user-bottom">
        <div class="item">
          <el-rate
            v-model="rating.score"
            disabled
            disabled-void-color="#c0c4cc"
            class="item"
            >
          </el-rate>
        </div>
        <div class="item">
          <i class="el-icon-message"></i>
          {{ $auth.user.email }}
        </div>
        <div class="item" v-if="$auth.user.address.city">
          <i class="el-icon-location-outline"></i>
          {{ $auth.user.address.city }} - {{ $auth.user.address.state_code }}
        </div>
        <div class="item" v-if="$auth.user.profile.phones">
          <i class="el-icon-mobile-phone"></i>
          {{ $auth.user.profile.phones.phone_1 }}
        </div>
      </div>
    </div>
    <el-button class="panel-button" size="small" type="text" icon="el-icon-edit" @click="$router.push('/minha-conta/cadastro')">Editar perfil</el-button>
  </div>
</template>

<script>
import AppAvatarUpload from '@/components/AppAvatarUpload'
import { errorsMixin } from '@/mixins'
import { format } from 'date-fns'
import ptLocale from 'date-fns/locale/pt'

export default {
  mixins: [ errorsMixin ],

  components: {
    AppAvatarUpload
  },

  data() {
    return {
      rating: {
        score: 5
      },

      profileCreatedDate: ''
    }
  },

  created() {
    this.profileCreatedDate = format(this.$auth.user.created_at, 'MMMM [de] YYYY', { locale: ptLocale })
  },

  methods: {
    avatarError(error) {
      this.errorsAlert(error)
    },
  },
}
</script>

<style lang="scss">
  .panel-user {
    background-color: #fff;
    padding: 2rem;
    color: #8794A0;
    position: relative;

    @media (min-width: $screen-md) {
      lost-flex-container: row;
    }
  }
  .panel-user-image {
    @media (max-width: $screen-md - 1px) {
      margin-bottom: .8rem;
    }
    @media (min-width: $screen-md) {
      width: 154px;
    }
    .avatar-uploader {
      .avatar {

        @media (min-width: $screen-md) {
          width: 126px;
          height: 126px;
        }
      }
    }
  }
  .panel-user-ctn {

    @media (min-width: $screen-md) {
      width: calc( 100% -  154px );
    }
  }
  .panel-user-header {
    margin-bottom: 12px;

    @media (min-width: $screen-md) {
      padding-right: 95px;
      margin-bottom: 25px;
    }

    > .name {
      font-size: 2rem;
      font-weight: bold;
      color: $text-color;
    }

    >.register {
      font-size: 11px;
      font-style: italic;
    }
  }
  .panel-user-bottom {

    @media (min-width: $screen-md) {
      lost-flex-container: row;
      justify-content: space-between;
    }

    > .item {
      margin-bottom: .7rem;
      font-size: 1.2rem;
      font-weight: 600;

      @media (min-width: $screen-md) {
        width: 50%;
      }
    }
  }
  .panel-button {
    position: absolute;
    top: 10px;
    right: 15px;
  }
</style>
