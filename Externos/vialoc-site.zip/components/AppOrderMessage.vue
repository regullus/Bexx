<template>
  <div class="message" v-if="message.show">
    <div>
      <p class="intro">{{ message.title }}</p>
      <p>{{ message.description }}</p>
    </div>
    <div class="action">
      <el-button type="primary" class="el-button--block" @click="$emit('do-action', 'primary')">{{ message.buttonLabel }}</el-button>

      <small v-if="message.buttonObsHasAction" class="obs -cursor" @click="$emit('do-action', 'secondary')">{{ message.buttonObs }}</small>
      <small v-else class="obs">{{ message.buttonObs }}</small>
    </div>
  </div>
</template>

<script>
const defaultMessage = {
  profile: 'tenant',
  title: '',
  description: '',
  buttonLabel: '',
  buttonObs: '',
  buttonObsHasAction: false,
  show: false,
}

export default {
  props: {
    order: {
      type: Object,
      required: true
    },
    profile: {
      type: String,
      default: 'tenant'
    }
  },

  data() {
    return {
      message: Object.assign({}, defaultMessage)
    }
  },

  mounted() {
    this.setMessages()
  },

  watch: {
    'order.status' () {
      this.setMessages()
    }
  },

  methods: {
    /**
     * define
     */
    setMessages() {
      // console.log('setMessages true', this.profile, this.message.profile, !this.order.payment, this.order.payment.status, this.order.payment.status !== 'processing', this.profile === this.message.profile && (!this.order.payment || (this.order.payment && this.order.payment.status !== 'processing')))

      switch (this.profile + '-' + this.order.status) {

        /*********************************************************************************************
         * LOCATOR
         *********************************************************************************************/

        case 'locator-pending-confirmation':
          this.message.profile = 'locator'
          this.message.title = 'Deseja autorizar este pedido de reserva?'
          this.message.description = 'Ao autorizar, o pedido de reserva é liberado para o locatário efetuar o pagamento.'
          this.message.buttonLabel = 'Autorizar o pedido'
          this.message.buttonObs = 'Recusar esta reserva'
          this.message.buttonObsHasAction = true
          this.message.show = this.profile === this.message.profile
          break;

        case 'locator-pending-takeout':
          this.message.profile = 'locator'
          this.message.title = 'A carreta foi retirada pelo locatário?'
          this.message.description = 'Ao informar a retirada da carreta, será enviada uma mensagem ao locatário solicitando a confirmação da retirada.'
          this.message.buttonLabel = 'Informar retirada'
          this.message.buttonObs = ''
          this.message.buttonObsHasAction = true
          this.message.show = (this.profile === this.message.profile && !this.order.locator_takeout_informed)
          break;

        case 'locator-active':
          this.message.profile = 'locator'
          this.message.title = 'A carreta foi devolvida pelo locatário?'
          this.message.description = 'Ao confirmar a devolução da carreta, o locatário será informado sobre a confirmação da devolução.'
          this.message.buttonLabel = 'Confirmar devolução'
          this.message.buttonObs = ''
          this.message.buttonObsHasAction = true
          this.message.show = this.profile === this.message.profile
          break;

        /*********************************************************************************************
         * TENANT
         *********************************************************************************************/

        case 'tenant-pending-payment':
          this.message.profile = 'tenant'
          this.message.title = 'Escolha o método de pagamento'
          this.message.description = 'Faça o pagamento agora para garantir a sua reserva.'
          this.message.buttonLabel = 'Efetuar pagamento'
          this.message.buttonObs = ''
          this.message.buttonObsHasAction = false
          this.message.show = this.profile === this.message.profile && (!this.order.payment || (this.order.payment && this.order.payment.status !== 'processing'))
          break;

        case 'tenant-pending-takeout':
          this.message.profile = 'tenant'
          this.message.title = 'Você já retirou a carreta?'
          this.message.description = 'Ao confirmar a retirada da carreta, o pagamento será liberado ao locador.'
          this.message.buttonLabel = 'Confirmar a retirada'
          this.message.buttonObs = ''
          this.message.buttonObsHasAction = false
          this.message.show = this.profile === this.message.profile
          break;

        case 'tenant-active':
          this.message.profile = 'tenant'
          this.message.title = 'Você já devolveu a carreta?'
          this.message.description = 'Ao informar a devolução da carreta, será enviada uma mensagem ao locador solicitando a confirmação da devolução.'
          this.message.buttonLabel = 'Informar a devolução'
          this.message.buttonObs = ''
          this.message.buttonObsHasAction = false
          this.message.show = (this.profile === this.message.profile && !this.order.tenant_devolution_informed)
          break;

        default:
          this.message = Object.assign({}, defaultMessage)
          break;
      }
    }
  }
}
</script>


<style lang="scss" scoped>
  .message {
    margin-bottom: 7rem;
    background-color: #FFF3E2;
    border: 1px solid #F5A623;
    padding: 2.6rem 2.6rem 1.8rem 2.6rem;
    font-size: 1.6rem;

    @media (min-width: $screen-sm) {
      display: flex;
      justify-content: space-between;
    }

    .intro {
      font-weight: bold;
      font-size: 1.8rem;
    }
    .el-button {
      margin-bottom: 2rem;
    }
    .obs {
      display: block;
      font-size: 1.2rem;
      color: $secondary-color;
      text-align: center;

      &.-cursor {
        cursor: pointer;
      }
    }

    .action {
      @media (min-width: $screen-sm) {
        margin-left: 2rem;
      }
    }
  }
</style>