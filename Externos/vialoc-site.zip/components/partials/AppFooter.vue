<template>
    <footer class="footer">
        <div class="container">
            © 2019 VIALOC • Todos os direitos reservados • <nuxt-link to="/politica-de-privacidade" class="link">Política de Privacidade</nuxt-link>
            <a href="https://citrus7.com.br/" class="link cop" target="_blank">Web by Citrus7</a>
        </div>
    </footer>
</template>

<style lang="scss" scoped>
  .footer {
      background-color: rgb(68, 76, 83);
      font-size: 1.1rem;
      color: #fff;
      padding: 1rem 0;
      position: relative;
      z-index: 2000;
  }
  .link {
      color: #fff;
      margin-left: 3px;
  }
  .cop {
      margin-left: auto;
  }

</style>
