<template>
  <header id="inner-header" class="inner-header">
    <div class="container">
			<nuxt-link to="/" class="logo"> <img src="~assets/images/logo.svg" title="Vialoc Locação de Carretas" alt="Vialoc Locação de Carretas" /> </nuxt-link>

			<div class="menu">
				<ul class="nav -login" v-if="$auth.loggedIn  && $auth.user && $auth.user.status === 'to-complete'">
					<li> <a href="#" class="link">Olá, {{ $auth.user.name }}</a> </li>
				</ul>
				<ul class="nav -login" v-else-if="$auth.loggedIn  && $auth.user">
					<li> <nuxt-link to="/minha-conta" class="link">Olá, {{ $auth.user.name }}</nuxt-link> </li>
					<li> <app-notes placement="header" /> </li>
				</ul>
				<ul class="nav" v-else>
					<li> <a href="#" class="link">Seja um Locatário</a> </li>
					<li> <span class="link" @click="openModalLogin">Login</span> </li>
					<li> <nuxt-link to="/cadastro" class="link">Cadastre-se</nuxt-link> </li>
				</ul>

				<app-nav-sub />
			</div>
    </div>
  </header>
</template>

<script>
import AppNavSub from '@/components/AppNavSub'
import AppNotes from '@/components/AppNotes'

export default {
	components: {
		AppNavSub,
		AppNotes,
	},

	methods: {
    openModalLogin() {
      this.$store.dispatch('events/setModal', { id: 'login', redirect: '/minha-conta' })
    }
	}
}

</script>

<style lang="scss" scoped>
	.container {
		// justify-content: space-between;
		lost-align: middle-left;
	}
	.logo {
		width: 100px;
		height: 30px;
		margin-bottom: 0;

		@media (min-width: $screen-md) {
			width: 123px;
			height: 40px;
		}
	}
	.menu {
		width: calc( 100% - 100px );
		lost-align: right;
		padding-right: 4rem;

		@media (min-width: $screen-md) {
			width: calc( 100% - 123px );
			padding-right: 5rem;
		}
	}
	.nav {
		lost-flex-container: row;
		lost-align: middle-left;

		.link {
			color: #fff;
			font-size: 1.2rem;
			padding: 0 1rem;
			display: block;
			cursor: pointer;
			line-height: 68px;

			&:hover {
				color: $primary-color;
			}
		}
	}
	.inner-header {
		position: relative;
		background-color: #8794A0;
    z-index: 2000;
	}
</style>

<style lang="scss">
	.main-sub {
		.sub {
			background-color: #7A8793;
			top: 68px;
		}
	}
	.sub-nav  {
		.link {
			color: #fff;

			&:hover {
				color: $primary-color;
			}
		}
	}
	.el-badge__content {
		border: none;
		background-color: #D0021B;
	}
</style>
