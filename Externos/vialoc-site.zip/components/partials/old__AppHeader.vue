<template>
	<div class="main-header-container">
		<div class="main-header">
			<div class="wrapper">
				<ul class="nav" v-if="$device.isDesktop">
					<li> <nuxt-link to="/sobre-vialoc" class="link">Sobre</nuxt-link> </li>
					<li> <nuxt-link to="/faq" class="link">Perguntas Frequentes</nuxt-link> </li>
					<li> <nuxt-link to="/contato" class="link">Contato</nuxt-link> </li>
				</ul>

				<nuxt-link to="/" class="logo">
					<img src="~assets/images/logo.svg"/>
				</nuxt-link>

        <ul class="nav -right" v-if="$auth.loggedIn">
					<li> <a href="#" class="link">Olá, {{ $auth.user.name }}</a> </li>
					<li> <app-notes/> </li>
				</ul>

				<ul class="nav -right" v-else>
					<li> <span class="link" @click="openModalLogin">Login</span> </li>
					<li> <nuxt-link to="/cadastro" class="link">Cadastre-se</nuxt-link> </li>
				</ul>

				<app-nav-sub/>

			</div>
		</div>
	</div>
</template>

<script>

import AppNavSub from '@/components/AppNavSub'
import AppNotes from '@/components/AppNotes'

export default {

	components: {
		AppNavSub,
		AppNotes
	},

	methods: {
    openModalLogin() {
      this.$store.dispatch('events/setModal', { id: 'login', redirect: '/minha-conta/cadastro' })
    }
	}
}

</script>

<style lang="scss" scoped>
  .main-header-container {
    position: relative;
  }
  .main-header {
	  position: absolute;
	  top: 0;
	  left: 0;
		width: 100%;

		@media (min-width: $screen-md) {
			top: 30px;
		}

		.app-notes {
			border-color: transparent;
		}

		.notes {
			border-color: transparent;
		}
  }
  .wrapper {
	  lost-center: 1010px;
	  padding: 0 1.5rem;
	  position: relative;
	  lost-align: middle-left;
  }
  .logo {
	  margin-bottom: 0;
		width: 100px;

		@media (min-width: $screen-md) {
			position: absolute;
			width: 170px;
			left: 50%;
			transform: translateX(-50%);
			top: 6px;
		}
  }
  .nav {
	  lost-flex-container: row;

	  &.-right {
			margin-left: auto;
			padding-right: 4rem;

			@media (min-width: $screen-md) {
				padding-right: 5rem;
			}
		}

		.notes {
			> .icon {
				width: 20px;
				height: 20px;
			}
		}
  }
  .link {
		color: #fff;
		font-size: 1.2rem;
		font-weight: 600;
		padding: 0 1rem;
		cursor: pointer;
		line-height: 68px;

		@media (min-width: $screen-md) {
			font-size: 1.4rem;
			padding: 0 1.6rem;
		}

		&:hover {
			color: $primary-color;
		}
	}
</style>

<style lang="scss">
	.main-sub {
		.ham {
			@media (min-width: $screen-md) {
				top: 22px;
			}
		}
		.sub {
			background-color: #fff;
			border-radius: 10px;
			top: 65px;
		}
	}
	.sub-nav  {
		.link {
			color: inherit;

			&:hover {
				color: $primary-color;
			}
		}
	}
	.el-badge__content {
		border: none;
		background-color: #D0021B;
	}
</style>
