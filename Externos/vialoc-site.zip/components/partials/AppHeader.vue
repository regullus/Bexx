<template>
	<div class="main-header-container">
		<div class="main-header">
			<div class="wrapper">

				<nuxt-link to="/" class="logo">
					<img src="~assets/images/logo.svg" title="Vialoc Locação de Carretas" alt="Vialoc Locação de Carretas" />
				</nuxt-link>

        <ul class="nav -right" v-if="$auth.loggedIn && $auth.user">
					<li> <nuxt-link to="/minha-conta" class="link">Olá, {{ $auth.user.name }}</nuxt-link> </li>
					<li>
						<client-only>
							<app-notes placement="header" ref="appNotes" />
						</client-only>
					</li>
				</ul>

				<ul class="nav -right" v-else>
					<li> <span class="link" @click="openModalLogin">Login</span> </li>
					<li> <nuxt-link to="/cadastro" class="link">Cadastre-se</nuxt-link> </li>
				</ul>

				<app-nav-sub/>

			</div>
		</div>
	</div>
</template>

<script>
import AppNavSub from '@/components/AppNavSub'
import AppNotes from '@/components/AppNotes'

export default {
	components: {
		AppNavSub,
		AppNotes
	},

	methods: {
    openModalLogin() {
      this.$store.dispatch('events/setModal', { id: 'login', redirect: '/minha-conta' })
		},
	}
}
</script>

<style lang="scss" scoped>
  .main-header-container {
    position: relative;
  }
  .main-header {
	  position: absolute;
	  top: 0;
	  left: 0;
		width: 100%;

		@media (min-width: $screen-md) {
			top: 30px;
		}

		.app-notes {
			border-color: transparent;
		}

		.notes {
			border-color: transparent;
		}
  }
  .wrapper {
	  lost-center: 1010px;
	  padding: 0 1.5rem;
	  position: relative;
	  lost-align: middle-left;
  }
  .logo {
	  margin-bottom: 0;
		width: 105px;

		@media (min-width: $screen-md) {
			width: 146px;
		}
  }
  .nav {
	  lost-flex-container: row;

	  &.-right {
			margin-left: auto;
			padding-right: 4rem;

			@media (min-width: $screen-md) {
				padding-right: 5rem;
			}
		}

		.notes {
			> .icon {
				width: 20px;
				height: 20px;
			}
		}
  }

  .link {
		color: #fff;
		font-size: 1.2rem;
		font-weight: 600;
		padding: 0 1rem;
		cursor: pointer;
		line-height: 68px;

		@media (min-width: $screen-md) {
			font-size: 1.4rem;
			padding: 0 1.6rem;
		}

		&:hover {
			color: $primary-color;
		}
	}
</style>

<style lang="scss">
	.main-sub {
		.sub {
			box-shadow: inset 0 5px 5px rgba(0, 0, 0, 0.2), inset 0 -5px 5px rgba(0, 0, 0, 0.2);
			background-color: #fff;
			top: 65px;
		}
	}
	.sub-nav  {
		.link {
			color: inherit;

			&:hover {
				color: $primary-color;
			}
		}
	}
	.el-badge__content {
		border: none;
		background-color: #D0021B;
	}
</style>
