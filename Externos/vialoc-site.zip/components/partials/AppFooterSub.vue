<template>
  <div class="sub-footer">
    <div class="container">
      <div class="item">
        <nuxt-link to="/" class="logo">
          <img src="~assets/images/logo.svg" class="default"/>
          <img src="~assets/images/logo-gray.svg" class="gray"/>
        </nuxt-link>
      </div>
      <div class="item">
        <h4 class="title">Quero uma carreta</h4>
        <ul class="list">
          <li><nuxt-link to="/carretas" class="link">Encontre uma carreta</nuxt-link></li>
          <li><nuxt-link to="/por-que-alugar" class="link">Por que alugar?</nuxt-link></li>
          <li><nuxt-link to="/faq" class="link">Perguntas frequentes</nuxt-link></li>
        </ul>
      </div>

      <div class="item">
        <h4 class="title">Tenho uma carreta</h4>
        <ul class="list">
          <li><nuxt-link to="/minhas-carretas/nova-carreta" class="link">Cadastre uma carreta</nuxt-link></li>
          <li><nuxt-link to="/por-que-locar" class="link">Por que locar?</nuxt-link></li>
          <li><nuxt-link to="/faq" class="link">Perguntas frequentes</nuxt-link></li>
        </ul>
      </div>

      <div class="item">
        <h4 class="title">Vialoc</h4>
        <ul class="list">
          <li><nuxt-link to="/sobre-vialoc" class="link">Sobre</nuxt-link></li>
          <li><nuxt-link to="/contato" class="link">Contato</nuxt-link></li>
          <li><nuxt-link to="/suporte" class="link">Suporte</nuxt-link></li>
        </ul>
      </div>

      <div class="item">
        <h4 class="title">Newsletter</h4>
        <div class="newsletter">
          <el-form :model="formNewsletter" :rules="newsletterRules" ref="formNewsletter">
            <el-form-item prop="email">
              <el-input v-model="formNewsletter.email" placeholder="Seu email">
                <el-button slot="append" icon="el-icon-check" @click="onSubmit"></el-button>
              </el-input>
            </el-form-item>
          </el-form>
        </div>

        <div class="social-list">
          <h4 class="title">Siga-nos:</h4>
          <ul class="list">
            <li>
              <a href="https://www.facebook.com/vialoc/" class="link -facebook" target="_blank">
                <svg-facebook class="icon" />
              </a>
            </li>
            <li>
              <a href="https://www.linkedin.com/company/vialoclocacao/" class="link -in" target="_blank">
                <svg-linkedin class="icon" />
              </a>
            </li>
          </ul>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
import SvgFacebook from '@/assets/svg/facebook.svg?inline'
import SvgLinkedin from '@/assets/svg/in.svg?inline'

export default {
  components: {
    SvgFacebook,
    SvgLinkedin,
  },

  data() {
    return {
      formNewsletter: {
          email: ''
      },

    };
  },

  computed: {
    newsletterRules () {
      return {
        email: [
          {type: 'email', required: true, message: 'Insira um e-mail válido.', trigger: 'blur'}
        ],
      }
    }
  },

  methods: {
    onSubmit () {
      // this.$refs['formContact'].closeAlert('alert-errors-found')

      this.$refs['formNewsletter'].validate((valid) => {
        if (valid) {
          // Envia os dados ao endpoint
          this.$axios.$post(`common/newsletter`, this.formNewsletter)
            .then(
              response => {
                this.$store.dispatch('events/setModal', {
                  id: 'generic',
                  type: 'success',
                  typeLabel: 'E-mail cadastrado com sucesso!',
                  title: 'Newsletter Vialoc',
                  message: 'Em breve você receberá as novidades da Vialoc em sua caixa postal!'
                })
                this.formNewsletter.email = ''
              },
              error => {
                this.errorsAlert(error)
              }
            )
        } else {
          this.$refs['formAlert'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
          return false;
        }
      })
    },
  },
}
</script>

<style lang="scss" scoped>

  .sub-footer {
    padding: 5rem 0 3rem 0;
    position: relative;
    z-index: 2000;
  }

  .container {
    align-items: center;
    justify-content: space-between;
  }

  .logo {
    width: 146px;
    margin-bottom: 0;
    display: block;

    .default {
      display: none;
    }
  }

  .title {
    font-size: 1.3rem;
    text-transform: uppercase;
    margin-bottom: 1.4rem;
  }

  .item {
    @media (max-width: $screen-md - 1px) {
      margin-bottom: 3rem;
    }
    @media (min-width: $screen-md) {
      // lost-column: 3/12;
      &:not(:last-child) {
        margin-right: 5rem;
      }
    }
  }

  .list {
    li {
      margin-bottom: 1rem;
    }
  }

  .link {
    color: inherit;
    font-size: 1.2rem;
  }

  .social-list {
    lost-flex-container: row;
    lost-align: middle-left;

    .list {
      lost-flex-container: row;
      margin-left: 5px;
    }

    .title {
      font-size: 1.3rem;
      text-transform: uppercase;
      margin-bottom: 0;
    }

    .link {
      display: block;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      padding: 7px;
      margin: 0 5px;
      text-align: center;

      &.-facebook {
        background-color: #3B5998;
      }

      &.-in {
        background-color: #0077B5;
      }
    }

    .icon {
      fill: #fff;
    }
  }

  .newsletter {
    position: relative;
    margin-bottom: 2rem;
  }
  .form-control {
    height: 4rem;
    padding-right: 35px;
  }
  .submit {
    position: absolute;
    top: 0;
    right: 0;
  }
  .btn {
    background-color: transparent;
    border: none;
    height: 4rem;
    line-height: 4rem;
    padding: 0;
    width: 35px;
    height: 40px;
  }
</style>

<style lang="scss">
  .newsletter {
    .el-input__inner {
      border-right-color: #fff;
      padding-right: 0;

      &:focus ~ div {
        border-color: #409EFF;
      }
    }
    .el-input-group__append {
      background-color: #fff;
    }
    button.el-button {
      padding: 12px;
      color: $secondary-color;
      font-size: 1.8rem;
    }
  }
</style>