 <template>
  <div class="timeline">
    <div class="timeline-wrap">
      <div class="timeline-item" :class="getClass(index, statusItem.status)" v-for="(statusItem, index) in listStatusDynamic" :key="`status-item-${statusItem.status}`">
        <div class="txt">{{ statusItem.label }}</div>
        <div class="icon">
          <i class="el-icon-check"></i>
        </div>
        {{ getDate(index) }}
      </div>
    </div>

    <!--
    <div class="timeline-item -previous">
      <div class="txt">Pedido<br/>realizado</div>
      <div class="icon">
        <i class="el-icon-check"></i>
      </div>
      {{ getDate('pending-confirmation') }}
    </div>
    <div class="timeline-item -previous">
      <div class="txt">Confirmação do locador</div>
      <div class="icon">
        <i class="el-icon-check"></i>
      </div>
      {{ getDate('pending-payment') }}
    </div>
    <div class="timeline-item -current">
      <div class="txt">Processando pagamento</div>
      <div class="icon">
        <i class="el-icon-check"></i>
      </div>
      {{ getDate('pending-takeout') }}
    </div>
    <div class="timeline-item">
      <div class="txt">Aguardando retirada</div>
      <div class="icon">
        <i class="el-icon-check"></i>
      </div>
    </div>
    <div class="timeline-item">
      <div class="txt">Locação em andamento</div>
      <div class="icon">
        <i class="el-icon-check"></i>
      </div>
    </div>
    <div class="timeline-item">
      <div class="txt">Locação finalizada</div>
      <div class="icon">
        <i class="el-icon-check"></i>
      </div>
    </div>
    -->
  </div>
 </template>

<script>
import _ from 'lodash'

export default {
  props: {
    logs: {
      type: Array,
      required: true
    },
    orderStatus: {
      type: String,
      required: true
    }
  },

  data() {
    return {
      listStatus: [
        { status: 'initial', label: 'Pedido realizado' },
        { status: 'pending-confirmation', label: 'Confirmação do locador' },
        { status: 'pending-payment', label: 'Aguardando pagamento' },
        { status: 'pending-takeout', label: 'Aguardando retirada' },
        { status: 'active', label: 'Locação em andamento' },
        { status: 'finished', label: 'Locação finalizada' },
      ],
    }
  },

  computed: {
    listStatusDynamic() {
      if (['canceled', 'refused'].indexOf(this.orderStatus) === -1) {
        return this.listStatus
      }

      let listDynamic = _.clone(this.listStatus)
      if (this.orderStatus == 'canceled') {
        listDynamic[this.logs.length - 1] = { status: 'canceled', label: 'Cancelado pelo locatário' }
      } else if (this.orderStatus == 'refused') {
        listDynamic[this.logs.length - 1] = { status: 'refused', label: 'Recusado pelo locador' }
      }
      return listDynamic
    }
  },

  methods: {
    getDate(index) {
      let statusItem = this.listStatus[index + 1]

      if (!statusItem) {
        return null
      }

      let entry = _.findLast(this.logs, (l) => l.status === statusItem.status)

      // se o pedido tiver sido cancelado ou recusado puxa a data deste (caso seja o último)
      if (['canceled', 'refused'].indexOf(this.orderStatus) !== -1 && (index + 1) == this.logs.length) {
        entry = _.findLast(this.logs, (l) => l.status === this.orderStatus)
      }

      if (!entry) {
        return null
      }

      return entry.created_at
    },

    getClass(statusIndex, status) {
      let logsTotal = this.logs.length

      if (['canceled', 'refused'].indexOf(status) !== -1) {
        return '-danger'
      }

      if (statusIndex < logsTotal) {
        return '-previous'
      } else if (statusIndex === logsTotal && this.orderStatus === 'finished') {
        return '-previous'
      } else if (statusIndex === logsTotal && ['canceled', 'refused'].indexOf(this.orderStatus) === -1) {
        return '-current'
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  $timeline-previous: #2EBA1A;
  $timeline-current: #FFD400;
  $timeline-next: #D6E0EA;
  $timeline-danger: #D0021B;

  .timeline-item {
    line-height: 1.2;
    position: relative;

    > .txt {
      height: 26px;
      lost-align: bottom-center;
    }
    > .icon {
      width: 30px;
      height: 30px;
      line-height: 30px;
      border-radius: 50%;
      background-color: $timeline-next;
      margin: 1rem auto;
      color: #fff;

      .el-icon-check {
        font-weight: bold;
        font-size: 18px;
        vertical-align: middle;
        visibility: hidden;
      }
    }

    &.-current {
      > .icon {
        background-color: $timeline-current;
      }
      .el-icon-check {
        visibility: visible;
      }
    }

    &.-previous {
      > .icon {
        background-color: $timeline-previous;
      }
      .el-icon-check {
        visibility: visible;
      }
    }

    &.-danger {
      > .icon {
        background-color: $timeline-danger;
      }
      .el-icon-check {
        visibility: visible;
      }
    }

    &:not(:last-child) {
      &:after {
        content: '';
        display: block;
        height: 2px;
        width: 100%;
        position: absolute;
        top: 50%;
        margin-top: -1px;
        left: 50%;
        background-color: $timeline-next;
        z-index: -1;

        @media (min-width: $screen-md) {
          width: calc( 100% + 90px);
        }
      }
    }
  }

  .timeline {
    font-size: 1.1rem;
    text-align: center;
    margin: 0 auto 4rem auto;
    width: 100%;
    overflow: auto;

    .timeline-item {
      width: 75px;
      flex-shrink: 0;
      &:not(:last-child) {
        @media (min-width: $screen-xs) {
          margin-right: 14px;
        }
        @media (min-width: $screen-md) {
          margin-right: 80px;
        }
      }
    }
  }

  .timeline-wrap {
    lost-flex-container: row;
    flex-wrap: nowrap;
    text-align: center;
    padding-bottom: 2rem;

    @media (min-width: $screen-xs) {
      justify-content: center;
    }
  }
</style>