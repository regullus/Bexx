<template>
  <div class="card-checkout" v-if="order">
    <div class="header" v-if="showHeader">
      <strong>Reserva de aluguel</strong><br/>
      <span class="quaternary-color">{{ order.date_start }}</span> até <span class="quaternary-color">{{ order.date_end }}</span>
    </div>

    <app-card extra-class="process -no-shadow" process="only-view" :product="order.product" :show-price="false"/>

    <div class="table-price" v-if="showTablePrice">
      <div class="tr -col">
        <div>
          <small>R$</small><span class="price"> {{ pricePerDayFormatted }} </span>
        </div>
        <div>
          <div>x<span class="price"> {{ order.days_total }} </span> <small>dias</small></div>
        </div>
      </div>
      <div class="tr -col">
        <div>Total</div>
        <div>
          <small>R$</small><span class="price"> {{ priceTotalFormatted }} </span>
        </div>
      </div>
    </div>

    <ul class="card-menu">
      <li>
        <nuxt-link v-if="profile === 'locator'" :to="`/locador/locacoes/${order.id}`" exact @click.native="linkToSelf">Detalhes do pedido</nuxt-link>
        <nuxt-link v-else :to="`/locatario/locacoes/${order.id}`" exact @click.native="linkToSelf">Detalhes do pedido</nuxt-link>
      </li>
      <li v-if="['pending-confirmation', 'pending-payment', 'canceled', 'refused'].indexOf(order.status) === -1">
        <nuxt-link v-if="profile === 'locator'" :to="`/locador/locacoes/${order.id}/mensagens`" exact @click.native="linkToSelf">Mensagens</nuxt-link>
        <nuxt-link v-else :to="`/locatario/locacoes/${order.id}/mensagens`" exact @click.native="linkToSelf">Mensagens</nuxt-link>
      </li>
      <li v-if="order.status === 'active'">
        <span class="link" v-if="profile === 'locator'" @click="$emit('do-action', 'confirm-devolution')">Registrar devolução</span>
        <span class="link" v-else @click="$emit('do-action', 'inform-devolution')">Informar devolução</span>
      </li>
    </ul>
  </div>
</template>

<script>
import VueScrollTo from 'vue-scrollto'
import { floatFormatted } from '@/utils/helpers'
import AppCard from '@/components/AppCard.vue'

export default {
  components: {
    AppCard
  },

  props: {
    order: {
      type: Object,
      required: true,
    },
    profile: {
      type: String,
      default: 'tenant',
    },
    showHeader: {
      type: Boolean,
      default: true,
    },
    showTablePrice: {
      type: Boolean,
      default: false,
    },
    showMenu: {
      type: Boolean,
      default: false,
    },
  },

  computed: {
    pricePerDayFormatted () {
      if (!this.order.price) {
        return null
      }
      let price = floatFormatted(this.order.price.price_per_day)
      return this.removeZeroCents(price)
    },
    priceTotalFormatted () {
      if (!this.order.price_total) {
        return null
      }
      let price = floatFormatted(this.order.price_total)
      return this.removeZeroCents(price)
    },
  },

  methods: {
    linkToSelf (event) {
      console.log(this.$route, event)
      // se for a mesma página "scrolla" para o topo
      if (this.$route.path === event.target.pathname) {
        VueScrollTo.scrollTo('#__nuxt')
      }
    },
    removeZeroCents (floatFormatted) {
      return floatFormatted.toString().replace(',00', '')
    },
  }
}
</script>

<style lang="scss" scoped>
  .header {
    margin-bottom: 8px;
    margin-top: -46px;
  }
  .table-price {
    background-color: #fff;
  }
</style>

<style lang="scss">
  .card-menu .nuxt-link-active {
    font-weight: bold;
  }
</style>
