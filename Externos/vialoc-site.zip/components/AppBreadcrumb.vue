<template>
  <div class="breadcrumbs">
    <div class="container">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">home</el-breadcrumb-item>
        <el-breadcrumb-item v-for="(bc, idx) in breadcrumb" :to="{path: bc.path}" :key="idx">{{ bc.name }}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  computed: {
    ...mapGetters({
      breadcrumb: 'base/breadcrumb'
    })
  },
}
</script>

<style lang="scss">
  .el-breadcrumb {
    font-size: 11px;
    padding: 1rem 0;
    text-transform: lowercase;
  }
  .el-breadcrumb__separator {
    margin: 0 4px;
  }
  .el-breadcrumb__inner a, .el-breadcrumb__inner.is-link {
    font-weight: 300;
  }
  .breadcrumbs {
    .container {
      lost-align: right;
    }
  }
</style>