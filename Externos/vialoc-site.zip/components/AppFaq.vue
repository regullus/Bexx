<template>
  <div class="faq">
    <div class="faq-form">
      <el-form>
        <el-form-item>
          <el-input placeholder="Digite sua dúvida" class="input-with-select" v-model="filter">
            <el-button slot="append" icon="el-icon-search"></el-button>
          </el-input>
        </el-form-item>
        <el-form-item class="radio" prop="profileTarget">
          <el-radio label="tenant" v-model="profileTarget">Quero uma carreta</el-radio>
          <el-radio label="locator" v-model="profileTarget">Tenho uma carreta</el-radio>
        </el-form-item>
      </el-form>
    </div>
    <div class="faq-title">Perguntas frequentes</div>
    <el-collapse accordion v-if="faqFiltered.length">
      <el-collapse-item v-for="(faq, index) in faqFiltered" :key="`faq-${index}`" :title="faq.question" :name="`faq-element-${index}`">
        <div class="el-collapse-item__desc" v-html="faq.answer"></div>
        <div class="el-collapse-item__util">
          <span class="name">Esta resposta foi útil?</span>
          <template v-if="typeof faq.rating === 'undefined'">
            <el-button type="success" @click="makeRate(faq, 1)" icon="el-icon-check">Sim</el-button>
            <el-button type="danger" @click="makeRate(faq, 0)" icon="el-icon-delete">Não</el-button>
          </template>
          <template v-else>
            <span v-if="faq.rating.rating === 1"> <strong>Sim.</strong></span>
            <span v-if="faq.rating.rating === 0"> <strong>Não.</strong></span>
          </template>
        </div>
      </el-collapse-item>
    </el-collapse>
    <el-alert v-else type="warning" title="Não foram encontradas questões para a sua busca. Por favor, tente novamente utilizando outros termos." style="margin-bottom: 30px;"></el-alert>
    <div class="faq-bottom">
      <span class="name">Ainda precisa de ajuda?</span>
      <el-button type="primary" @click="goToContact()">Entre em contato</el-button>
    </div>
  </div>
</template>

<script>
import _ from 'lodash';

export default {
  props: {
    faqList: {
      type: Array,
      required: true
    }
  },

  data() {
    return {
      filter: '',
      profileTarget: 'tenant',
    };
  },

  computed: {
    faqFiltered () {
      return _.filter(this.faqList, faq => {
        return ((faq.question.indexOf(this.filter) >= 0 || faq.answer.indexOf(this.filter) >= 0) && (faq.target === 'both' || faq.target === this.profileTarget));
      })
    }
  },

  methods: {
    makeRate(faq, rate) {
      this.$axios.$post(`common/faq/${faq.id}/rating`, { rating: rate })
        .then(
          data => {
            this.$emit('faqRated', data)
          },
          error => {
            /* quando uma requisição à API der erro, preciso marcar no objeto faq algo que aponte que a requisição deu erro para AQUELE faq porém, alterar o objeto dinamicamente não está funcionando. Ver se o Edson ajuda. */
          }
        )
    },

    goToContact () {
      this.$router.push('/contato')
    }
  }
}
</script>

<style lang="scss">
  .faq-title {
    margin-bottom: 20px;
  }
  .faq-form {
    margin-bottom: 4rem;
  }
  .faq-bottom {
    border-top: 1px solid #C0C0C0;
    padding-top: 20px;
    lost-align: right;

    > .name {
      margin-right: 2rem;
    }
  }
</style>

<style lang="scss">
  .el-collapse {
    border: none;
    margin-bottom: 40px;
  }
  .el-collapse-item {
    margin-bottom: .2rem;
    &__header {
      background-color: #DDDDDD;
      padding: 1.4rem;
      border-color: transparent;
      font-size: 14px;
      height: auto;
      line-height: 1.4;

      &.is-active {
        color: #1B67BF;
      }
    }
    &__content {
      padding: 0;
      font-size: 14px;
      line-height: 1.4;
    }
    &__desc {
      padding: 1.4rem;
      background-color: #fff;
    }
    &__wrap {
      background-color: transparent;
      width: 100%;
    }
    &__arrow {
      line-height: 1;
    }
    &__util {
      padding: 2rem 1.4rem;

      > .name {
        font-size: 1.2rem;
        margin-right: 1.2rem;
      }
    }
  }
</style>
