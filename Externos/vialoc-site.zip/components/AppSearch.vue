<template>
	<div class="search">
		<el-form :inline="true" :model="form" label-position="top">
			<el-form-item label="Localização">
				<client-only>
					<div class="el-input">
							<gmap-autocomplete :value="locationLabel" @place_changed="selectLocation" class="el-input__inner"></gmap-autocomplete>
					</div>
				</client-only>
			</el-form-item>
			<el-form-item label="Tipo de carreta">
					<client-only>
						<el-select v-model="form.product_type" filterable placeholder="Escolha o tipo" @change="setSearchFilters">
							<el-option v-for="(label, key) in types" :key="`option-type-${key}`" :label="label" :value="key"></el-option>
						</el-select>
					</client-only>
			</el-form-item>
			<el-form-item>
					<el-button type="primary" @click="onSubmit">Procurar</el-button>
			</el-form-item>
		</el-form>
	</div>
</template>

<script>
import { formSearchMixin } from '@/mixins'

export default {
  mixins: [ formSearchMixin ],
}
</script>

<style lang="scss">
	.search {
		padding: 0 1.5rem;
		.el-form {
			@media (min-width: $screen-md) {
				lost-align: bottom;
			}
			.el-form-item {
				@media (max-width: $screen-md - 1px) {
					margin-right: 0;
					width: 100%;
				}
				@media (min-width: $screen-md) {
					&:not(:last-child) {
						width: 340px;
					}
				}
			}
      .el-autocomplete {
        display: block;
      }
			.el-select {
				width: 100%;
			}
			.el-form-item__label {
				color: #fff;
				font-size: 1.4rem;
				font-weight: bold;
			}
			.el-input__inner {
				height: 5rem;
				line-height: 5rem;
			}
			.el-button {
				height: 5rem;
				border-radius: 0px;

				@media (max-width: $screen-md - 1px) {
					width: 100%;
				}
			}
		}
	}
</style>

