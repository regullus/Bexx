<template>
  <div class="alert-master">
    <el-alert v-for="alert in alerts" :key="alert.id" v-show="alert.show" :title="alert.title" class="alert-master" :type="alert.type" :show-icon="alert.showIcon" :closable="false">
      <div class="el-alert__description" :class="{ isClickable: (typeof alert.action !== 'undefined') }" v-html="alert.description" @click="doAlertMasterAction(alert.action || null)"></div>
      <i class="el-alert__closebtn el-icon-close" v-if="alert.closable" @click.stop="closeAlertMaster(alert.id)"></i>
    </el-alert>
  </div>
</template>

<script>
import VueScrollTo from 'vue-scrollto'

export default {
  computed: {
    alerts() {
      let getAlerts = this.$store.state.events.alertsMaster
      if (getAlerts.length) {
        VueScrollTo.scrollTo(this.$el)
      }
      return getAlerts
    },
  },

  methods: {
    doAlertMasterAction(action) {
      if (!action) {
        return
      }

      this.$store.dispatch(action)
    },

    closeAlertMaster(alertId) {
      this.$store.dispatch('events/deleteAlertMaster', alertId)
    }
  },
}
</script>

<style lang="scss">
  .el-alert {
    border-radius: 0;
    .el-alert__description {
      margin: 0;

      &.isClickable {
        cursor: pointer;
      }
    }
  }
</style>
