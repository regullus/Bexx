<template>
  <div class="panel-carts">
    <h2 class="title">
      <svg-truck-favorites class="icon dash-color" width="55" height="20"/> Carretas favoritas
      <!-- <i class="el-icon-edit"></i> -->
    </h2>

    <ul class="panel-carts-list">
      <li is="app-panel-products-item" v-for="product in products" :key="`product-${product.uid}`" :product="product" @favorite-delete="favoriteDelete"></li>
      <li v-if="!products.length" style="padding: 10px;">Ainda não há carretas marcadas como favoritas. <nuxt-link to="/carretas">Navegue pelo site</nuxt-link> e marque as carretas que tiver interesse.</li>
    </ul>

  </div>
</template>

<script>
import { favoritesMixin } from '@/mixins'

import AppPanelProductsItem from '@/components/AppPanelProductsItem'
import SvgTruckFavorites from '@/assets/svg/truck-favorites.svg?inline'

export default {
  mixins: [favoritesMixin],

  components: {
    AppPanelProductsItem,
    SvgTruckFavorites,
  },

  props: {
    products: {
      type: Array,
      required: true
    }
  }
}
</script>

<style lang="scss">
  .panel-carts {
    padding: 20px;
    background-color: #fff;
    color: #8794A0;

    > .title {
      font-size: 2rem;
      position: relative;
      padding-left: 70px;

      .icon {
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
      }

      .el-icon-edit {
        font-size: 16px;
        color: $secondary-color;
        position: absolute;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
      }
    }
  }
  .panel-carts-list {
    border-top: 1px solid #D6E0EA;

    .panel-carts-item {
      border-bottom: 1px solid #D6E0EA;
    }
  }
</style>