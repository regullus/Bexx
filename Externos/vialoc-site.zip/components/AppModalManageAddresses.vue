<template>
  <div class="c7-modal" v-if="modal">
    <el-dialog :visible="modal.id === 'manage-address'" @close="$store.dispatch('events/cleanModal')" :close-on-click-modal="false">
      <app-manage-addresses :in-modal="true" @define-address="defineAddress" :show-edit="true" :show-select="true" />
    </el-dialog>
  </div>
</template>

<script>
import AppManageAddresses from '@/components/AppManageAddresses'
export default {
  components: {
    AppManageAddresses
  },

  computed: {
    modal () {
      return this.$store.state.events.modal
    }
  },

  methods: {
    defineAddress (address) {
      this.$emit('define-address', address)
    }
  }
}
</script>

<style lang="scss" scoped>
  .el-dialog {
    width: 800px;
  }
</style>
