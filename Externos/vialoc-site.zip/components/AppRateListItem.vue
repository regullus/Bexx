<template>
  <div class="rating" :class="`-${profile}`" v-if="rating">
    <div class="rating-wrp">
      <div class="comment">
        <div class="comment-text" v-html="rating.comment"></div>
      </div>
      <div class="commenter">
        <div class="image">
          <img :src="avatar" :alt="rating.user.short_name"/>
        </div>
        <div class="info">
          <span>{{ rating.user.short_name }} avaliou em {{ dateFormatted }}</span>
          <div>
            <el-rate
              v-model="rating.score"
              :colors="['#c00', '#f60', '#f7ba2a']"
              :texts="['Péssimo', 'Ruim', 'Regular', 'Bom', 'Excelente']"
              :disabled="true"
              show-text
              :allow-half="true"
              text-color="#666"
              >
            </el-rate>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import Vue from 'vue'
  import _ from 'lodash'
  import { format } from 'date-fns'

  export default {
    props: {
      rating: {
        type: Object,
        default: null,
      },
      profile: {
        type: String,
        default: 'tenant'
      },
    },

    computed: {
      avatar () {
        return this.rating.user.avatar || require('~/assets/images/anonymous-user-240x240.png')
      },

      dateFormatted() {
        return !this.rating.created_at ? null : format(this.rating.created_at, 'DD/MM/YYYY')
      }
    },
  }
</script>

<style lang="scss" scoped>
  .rating {
    background-color: #fff;
    padding: 2rem;

    .image img {
      border-radius: 50%;
    }
  }

  .rating-wrp {
    .comment {
      position: relative;
      padding: 2rem;
      margin-bottom: 1.5rem;
      background-color: #ececec;
      border-radius: 1rem;

      &:after, &:before {
        top: 100%;
        left: 3.9rem;
        border: solid transparent;
        content: " ";
        height: 0;
        width: 0;
        position: absolute;
        pointer-events: none;
      }

      &:after {
        border-color: rgba(236, 236, 236, 0);
        border-top-color: #ececec;
        border-width: 1rem;
        margin-left: -1rem;
      }
      &:before {
        border-color: rgba(236, 236, 236, 0);
        border-top-color: #ececec;
        border-width: 1rem;
        margin-left: -1rem;
      }
    }

    > .commenter {
      position: relative;
      margin: 0 0 0 2rem;
      min-height: 3.6rem;
      padding-left: 4.2rem;

      > .image {
        position: absolute;
        top: 0;
        left: 0;
        width: 3.6rem;
        height: 3.6rem;
      }

      > .info {
        display: table-cell;
        min-height: 3rem;
        font-size: 1.2rem;
        line-height: 1.8rem;
        vertical-align: middle;
      }
    }
  }

  .comment-text {
    font-style: italic;
  }
</style>

<style lang="scss">
  .rating-wrp .commenter .el-rate__text {
    display: inline-block;
    font-size: 1.2rem;
    line-height: 1.8rem;

    &::before {
      content: " - ";
    }
  }
</style>