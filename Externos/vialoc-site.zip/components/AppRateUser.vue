<template>
  <div class="profile -rateable" :class="`-${profile} -view-${viewType}`" v-if="user">
    <h2 class="panel-title" v-if="isRateable">Avalie o {{ profileLabel }}</h2>
    <h2 class="panel-title" v-else>Sua avaliação do {{ profileLabel }}</h2>
    <div class="profile-wrp">
      <div class="header">
        <div class="image">
          <img :src="avatar" :alt="user.short_name || user.full_name"/>
        </div>
        <div class="rating">
          <span>{{ user.short_name || user.full_name }}</span>
          <el-rate
            v-model="form.score"
            :colors="['#c00', '#f60', '#f7ba2a']"
            :texts="['Péssimo', 'Ruim', 'Regular', 'Bom', 'Excelente']"
            :disabled="!isRateable"
            show-text
            text-color="#666"
            >
          </el-rate>
        </div>
      </div>

      <div class="comment" v-if="isRateable">
        <strong>Sua avaliação (opcional)</strong>
        <el-input type="textarea" v-model="form.comment" :maxlength="140" show-word-limit></el-input>
        <p><small>O seu comentário aparecerá publicamente no perfil do {{ profile === 'tenant' ? 'locatário' : 'locador' }}.</small></p>
        <div>
          <el-button class="el-button--block" type="primary" @click="setRating" :disabled="!this.form.score">
            <span v-if="this.form.score">Enviar a avaliação do {{ profile === 'tenant' ? 'locatário' : 'locador' }}</span>
            <span v-else>Defina uma nota</span>
          </el-button>
        </div>
      </div>
      <div class="comment" v-else>
        <strong>
          Sua avaliação
          <span :class="rating.status === 'pending' ? 'color-warning' : 'color-success'">({{ rating.status === 'pending' ? 'Em revisão' : 'Publicada' }})</span>
        </strong>
        <div class="comment-text" v-if="rating.comment" v-html="rating.comment"></div>
        <div class="comment-text" v-else>
          Nenhum comentário foi publicado.
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import Vue from 'vue'
  import _ from 'lodash'

  export default {
    props: {
      user: {
        type: Object,
        default: null,
      },
      rating: {
        type: Object,
        default: null,
      },
      profile: { // profile da contra-parte
        type: String,
        default: 'tenant'
      },
      viewType: { // block, full, full-preview, listing ou listing-preview
        type: String,
        default: 'block'
      },
      showTitle: {
        type: Boolean,
        default: true
      },
      isRateable: {
        type: Boolean,
        default: false
      },
    },

    data() {
      return {
        form: {
          score: 0,
          comment: '',
          status: 'pending',
        },
        profileLabel: 'Locatário',
        buttonLoading: false,
      }
    },

    computed: {
      avatar () {
        return this.user.avatar || require('~/assets/images/anonymous-user-240x240.png')
      }
    },

    created () {
      if (this.profile === 'locator') {
        this.profileLabel = 'Locador'
      }

      if (!this.isRateable) {
        this.form = _.cloneDeep(this.rating)
      }
    },

    methods: {
      setRating () {
        this.$emit('set-rating', { subtype: this.profile, ...this.form })
      },
    },

    watch: {
      rating: function (rating) {
        if (!this.isRateable) {
          this.form = _.cloneDeep(rating)
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .profile {
    background-color: #fff;
    padding: 0;

    .image img {
      border-radius: 50%;
    }
  }

  .profile-wrp {
    > .header {
      position: relative;
      display: table;
      margin-bottom: 3rem;
      min-height: 90px;
      padding-left: 100px;

      > .image {
        position: absolute;
        top: 0;
        left: 0;
        width: 90px;
        height: 90px;
      }

      > .rating {
        display: table-cell;
        min-height: 90px;
        vertical-align: middle;
      }
    }
  }

  .profile.-view-full, .profile.-view-full-preview, .profile.-view-listing, .profile.-view-listing-preview {
    .profile-wrp {
      lost-flex-container: row;

      .header {
        margin-top: 1rem;
        lost-column: 5/12;
      }
      .comment {
        lost-column: 7/12;
      }
    }
  }

  .profile.-view-full-preview, .profile.-view-listing, .profile.-view-listing-preview {
    padding: 2rem;

    .profile-wrp {
      .header {
        margin-top: 0;
        margin-bottom: 0;
      }
    }

    .panel-title {
      display: none;
    }
  }

  .comment {
    strong {
      display: block;
      margin-bottom: 0.5rem;
    }
    .el-textarea {
      margin-bottom: 0.5rem;
    }
    small {
      font-size: 1.2rem;
    }
  }

  .comment-text {
    font-style: italic;
  }

  .color-warning {
    color: $primary-color;
  }
  .color-success {
    color: $secondary-color;
  }
</style>

<style lang="scss">
.-rateable {
  .el-rate__icon {
    font-size: 28px;
  }
  .el-rate__text {
    display: block;
    margin-top: 0.5rem;
    font-weight: bold;
  }
  .el-rate {
    height: auto;
  }

  &.-view-full-preview {
    .el-rate__icon {
      font-size: 24px;
    }
  }
}

</style>