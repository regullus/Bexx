<template>
  <div class="notes" :class="{ '-active': isActive, '-panel': placement == 'panel' }">
    <div class="notes-icon" @click.stop="toggleActive()" v-if="placement == 'header'">
      <el-badge
        :value="notificationsUnreadTotal"
        class="badge"
        :hidden="notificationsUnreadTotal === 0"
      >
        <svg-message class="notes-svg" />
      </el-badge>
    </div>
    <div class="notes-ctn">
      <div class="notes-wrp">
        <app-notes-item
          v-for="notification in listNotifications"
          :key="`notification-${notification.id}`"
          :notification="notification"
          @notification-is-read="setNotificationRead(notification)"
          @remove-notification="remove(notification)"
        />

        <div
          class="notes-default"
          v-if="!hasNotifications"
        >Você não recebeu nenhuma mensagem até o momento.</div>
      </div>
      <el-button
        size="small"
        class="el-button--block"
        v-if="notificationsUnreadTotal > 1"
        @click="removeAll"
      >Limpar notificações</el-button>
    </div>
  </div>
</template>

<script>
import _ from 'lodash'
import Vue from 'vue'
import ptLocale from 'date-fns/locale/pt'

import AppNotesItem from '@/components/AppNotesItem'
import SvgMessage from '@/assets/svg/message.svg?inline'

import { errorsMixin } from '@/mixins'

export default {
  mixins: [ errorsMixin ],

  components: {
    AppNotesItem,
    SvgMessage,
  },

  props: {
    placement: {
      type: String,
      required: true
    },
    profile: {
      type: String,
      default: null
    },
    notifications: {
      type: Array,
      default: null
    },
  },

  data() {
    return {
      isActive: false,
      echo: null,
    }
  },

  created() {
    if (process.browser) {
      // puxa as notifications do user
      this.$axios.$get('/common/notifications').then(
        response => {
          this.$store.dispatch('notifications/setNotifications', response)
        },
        error => {
          // this.errorsModal(error, { title: 'Erro no envio do avatar' })
          console.log(error)
        }
      )


      window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          this.isActive = false
        }
      })

      // inicia o listening para as notifications
      if (this.placement === 'header') {
        setTimeout(() => {
          let echoSocketId = this.$echo.socketId()

          if (this.$auth.loggedIn && typeof echoSocketId === 'undefined') {
            this.$echo.connector.connect()
          } else if (!this.$auth.loggedIn && typeof echoSocketId !== 'undefined') {
            this.$echo.disconnect()
          }

          if (typeof this.$echo.socketId() !== 'undefined' && !_.has(this.$echo.connector.channels, 'private-users.' + this.$auth.user.uid)) {
            console.log('conecta $echo inicia o listening para as notifications', 'users.' + this.$auth.user.uid)
            this.$echo.private('users.' + this.$auth.user.uid).notification((notification) => {
              this.$store.dispatch('notifications/addNotification', notification);
            })
          }
        }, 1000)
      }
    }
  },

  computed: {
    listNotifications() {
      if (this.placement !== 'header' && this.profile) {
        return this.$store.getters['notifications/getNotificationsByProfile'](this.profile)
      }

      return this.$store.getters['notifications/getNotifications']
    },

    hasNotifications() {
      return this.listNotifications && this.listNotifications.length
    },

    notificationsUnreadTotal() {
      if (!this.hasNotifications) {
        return 0
      }

      return _.filter(this.listNotifications, 'is_unread').length
    },

    // isEchoConnected: {
    //   cache: false,
    //   get(){
    //     return (this.$echo &&  this.$echo.connector.socket.connected === true)
    //   }
    // }
  },

  methods: {
    toggleActive (forceStatus) {
      this.isActive = typeof forceStatus !== 'undefined' ? forceStatus : !this.isActive

      if (process.browser) {
        if (this.isActive) {
          // add listener to clickoutside
          window.addEventListener('click', e => this.outsideClick(e))

        } else {
          // remove listener to clickoutside
          window.removeEventListener('click', e => this.outsideClick(e))
        }
      }
    },

    outsideClick (e) {
      if (e.target.closest('.notes-ctn')) {
        return
      }

      this.toggleActive(false)
    },

    remove (notification) {
      this.$store.dispatch('notifications/removeNotifications', notification)
    },

    removeAll () {
      this.$store.dispatch('notifications/removeNotifications', this.listNotifications)
    },

    setNotificationRead (notification) {
      this.$store.dispatch('notifications/setNotificationRead', notification)
    }
  }
}
</script>

<style lang="scss">
.notes-icon {
  cursor: pointer;
  padding: 0 2rem;
  > .badge {
    line-height: 1;
  }
}
.notes-svg {
  width: 20px;
  height: 20px;
  fill: #fff;
}
.notes-wrp {
  max-height: 350px;
  overflow: auto;
}

.notes-wrp::-webkit-scrollbar-track {
  background-color: #fff;
}

.notes-wrp::-webkit-scrollbar {
  width: 8px;
  background-color: #fff;
}

.notes-wrp::-webkit-scrollbar-thumb {
  background-color: #aaa;
}

.notes-default {
  padding: 1rem 1.2rem;
  color: #4a4a4a;
  font-size: 1.1rem;
  line-height: 1.2;
}

.notes {
  position: relative;

  @media (min-width: $screen-md) {
    z-index: 1;
  }

  &:not(.-panel) {
    line-height: 68px;
    border: 1px solid #8794a0;
    border-bottom: 0;
    .notes-ctn {
      position: absolute;
      width: 260px;
      background-color: #fff;
      top: 68px;
      right: -1px;
      border: 1px solid $primary-color;
      overflow: auto;
      visibility: hidden;
      opacity: 0;
      transition: 400ms all;
    }
  }

  &:after {
    content: "";
    display: block;
    width: 100%;
    height: 1px;
    background-color: transparent;
    position: absolute;
    left: 0;
    bottom: -1px;
  }

  .el-badge__content {
    font-size: 1.1rem;
  }

  &.-active {
    background-color: #fff;
    border-color: $primary-color;
    .notes-ctn {
      opacity: 1;
      visibility: visible;
    }
    .notes-svg {
      fill: $primary-color;
    }
    &:after {
      background-color: #fff;
    }
  }

  .el-button {
    background-color: $primary-color;
    border-color: $primary-color;
    color: #fff;
    font-weight: normal;
    padding: 5px 15px;
    font-size: 10px;
  }
}
</style>
