<template>
  <div class="profile" v-if="user">
    <h4 class="profile-box-title" v-if="showTitle">{{ title }}</h4>

    <div class="profile-wrp">
      <div class="header">
        <div class="image">
          <img :src="avatar" :alt="user.short_name || user.full_name"/>
        </div>
        <div class="rating">
          <el-rate
            v-model="user['rating_' + profile + '_score']"
            disabled
            disabled-void-color="#c0c4cc"
            >
          </el-rate>
          <small>
            <span v-if="!user['rating_' + profile + '_count']">Sem avaliações</span>
            <span v-else>{{ user['rating_' + profile + '_count'] }} {{ !user['rating_' + profile + '_count'] === 1 ? ' avaliação' : ' avaliações' }}</span>
          </small>

        </div>
      </div>
      <p>{{ user.short_name || user.full_name }}</p>
      <template v-if="showDetails">
        <p v-if="user.phones">Telefones: {{ user.phones.join(' / ') }}</p>
      </template>
    </div>

    <ul class="card-menu" v-if="profile === 'locator'">
      <li>
        <nuxt-link :to="`/perfil/${user.slug}/carretas`" class="profile-link">Ver outras carretas deste locador</nuxt-link>
      </li>
    </ul>
  </div>
</template>

<script>
  export default {
    props: {
      user: {
        type: Object,
        default: null,
      },
      profile: {
        type: String,
        default: 'tenant'
      },
      showTitle: {
        type: Boolean,
        default: true
      },
      showDetails: {
        type: Boolean,
        default: true
      },
    },

    data() {
      return {
        title: (this.profile === 'locator' ? 'Locador' : 'Locatário')
      }
    },

    computed: {
      avatar () {
        return this.user.avatar || require('~/assets/images/anonymous-user-240x240.png')
      }
    },
  }
</script>

<style lang="scss" scoped>
  .profile {
    background-color: #fff;
    padding: 2rem;

    .image img {
      border-radius: 50%;
    }
  }

  .profile-box-title {
      display: block;
      font-size: 1.6rem;
      margin-bottom: 2rem;
  }

  .profile-wrp {
    margin-bottom: 2rem;

    > .header {
      margin-bottom: 2rem;
      lost-flex-container: row;
      lost-align: middle-left;

      > .image {
        margin-right: 1rem;
        width: 74px;
        height: 74px;
      }
      > .rating {

      }
    }
    > p {
      display: block;
      line-height: 1.2;
    }
  }

  .profile-link {
    display: block;
    line-height: 1.2;
    font-size: 1.2rem;
    color: #4A90E2;
  }

  .card-menu {
    padding: 0;
  }

  .rating {
    small {
      display: block;
      font-size: 1.1rem;
    }
  }
</style>