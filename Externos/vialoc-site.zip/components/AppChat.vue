<template>
  <div class="chat">
    <div class="chat-header">
      {{ order.product.name }} - {{ order.product.brand }} - {{ order.product.year }} - {{ order.product.city }} - {{ order.product.state_code }}
    </div>
    <div class="chat-content">
      <app-chat-message v-for="message in order.messages" :key="`message-${message.id}`" :message="message" :is-owner="isOwner(message)" :show-date="showDate(message)" />
      <p v-if="!order.messages.length">Ainda não há mensagens nesta conversa.</p>
    </div>
    <div class="chat-footer">
      <el-form :model="chat" :rules="formRules" ref="formChat" class="chat-message">
        <el-form-item prop="content">
          <el-input v-model="chat.content" :placeholder="`Escreva sua mensagem para ${(profile === 'locator' ? order.user.short_name : order.product.user.short_name)}`" />
          <el-button @click="onSubmit" type="primary">Enviar</el-button>
        </el-form-item>
      </el-form>
      <!--
      <div class="chat-actions">
        <el-upload
          class="chat-upload"
          action="https://jsonplaceholder.typicode.com/posts/"
          :show-file-list="false">
          <svg-archive class="icon" />
        </el-upload>
        <div class="chat-more">
          <svg-more class="icon" />
        </div>
      </div>
      -->
    </div>
    <app-alert ref="formAlert" />
  </div>
</template>

<script>
import AppAlert from '@/components/AppAlert'
import AppChatMessage from '@/components/AppChatMessage'

// import SvgArchive from '@/assets/svg/archive.svg?inline'
// import SvgMore from '@/assets/svg/more.svg?inline'

export default {
  props: {
    order: {
      type: Object,
      required: true,
    },
    profile: {
      type: String,
      default: 'tenant',
    }
  },

  components: {
    AppAlert,
    AppChatMessage,
    // SvgArchive,
    // SvgMore,
  },

  data() {
    return {
      messagesDate: null,
      chat: {
        content: null,
      },
    }
  },

  computed: {
    formRules () {
      return {
        content: [
          { type: 'string', required: true, message: 'Este campo é obrigatório', trigger: 'blur' }
        ],
      }
    },
  },

  methods: {
    isOwner (message) {
      return message.user_id === this.$auth.user.id
    },

    showDate (message) {
      let showDate = false;
      if (this.messagesDate !== message.created_at) {
        showDate = true
        this.messagesDate = message.created_at
      }
      return message.user_id === this.$auth.user.id
    },

    onSubmit () {
      this.$refs['formChat'].validate((valid) => {
        if (valid) {
          this.submitMessage()
        } else {
          this.$refs['formAlert'].showAlert({ id: 'errors-found', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
          return false;
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .chat {
    background-color: #fff;
  }
  .chat-header {
    padding: 1.4rem 1rem;
    font-size: 1.4rem;
    font-weight: 700;
    border-bottom: 1px solid #D7D7D7;
  }
  .chat-content {
    padding: 2rem;
  }
  .chat-date {
    text-align: center;
    font-size: 1.4rem;
    color: #9B9B9B;
    padding: .6rem 0;
    margin-bottom: 1.6rem;
  }

  .chat-box {
    padding: 1rem;
    font-size: 1.4rem;
    border-radius: 2px;
    margin-bottom: 2rem;
    width: 417px;

    > .name {
      font-weight: 700;
    }

  }

  .chat-bottom {
    margin-top: 2rem;
    lost-align: right;

    > .time {
      font-size: 1.1rem;
      margin-right: .4rem;
    }
  }

  .chat-status {
    > .icon {
      width: 15px;
      height: 9px;
      display: block;
    }
  }

  .chat-message {
    lost-column: 12/12;

    .el-form-item {
      margin-bottom: 0;
    }

    .el-input {
      width: calc( 100% - 136px );
      margin-right: 1rem;
    }

    .el-button {
      padding-left: 3.6rem;
      padding-right: 3.6rem;
      text-transform: uppercase;
    }
  }

  .chat-footer {
    background-color: #D6E0EA;
    padding: 1.5rem;
    lost-flex-container: row;

    .el-form-item.is-error {
      margin-bottom: 2rem;
    }
  }

  .chat-actions {
    lost-flex-container: row;
    lost-align: middle-right;
    lost-column: 2/12;

    > div {
      width: 28px;
      height: 28px;
    }
  }

  .chat-more {
    padding: .4rem;
    cursor: pointer;
  }

  .chat-upload {
    padding: .2rem;
    margin-right: 1.2rem;
    .el-upload {
      width: 100%;
      height: 100%;
    }
  }

</style>

<style lang="scss">
  .chat-footer {
    .el-form-item__content {
      white-space: nowrap;
    }
  }
</style>