<template>
  <div class="order">
    <div class="header">
      <div class="meta">
        <span class="fake-link" @click="goTo('details')">Pedido <strong>#{{ order.id }}</strong></span> • <small>{{ order.order_date }}</small>
      </div>
      <div :class="['status', '-' + order.status]">{{ order.status_formatted }}</div>
    </div>
    <div class="ctn">
      <div class="col -inline">

        <figure class="figure">
          <img :src="imagePath" :alt="`Pedido #${order.id}`" @click.prevent="goTo('details')" />
        </figure>

        <ul class="cart">
          <li class="title">{{ order.product.name }}</li>

          <li>
            {{ order.product.type_formatted }} - {{ order.product.brand }} - {{ order.product.year }}<br/>
            {{ order.product.city }} - {{ order.product.state_code }}
          </li>

          <li class="price">
            R$ <span>{{ priceFormatted }}</span>
          </li>

        </ul>
      </div>

      <div class="col">
        <ul class="infos">
          <li>
            Retirada: <span class="focus">{{ order.date_start }}</span><br/>
            Entrega: <span class="focus">{{ order.date_end }}</span>
          </li>
          <li v-if="['pending-confirmation', 'pending-payment'].indexOf(order.status) === -1">
            Contato:<br/>
            <!-- Se locador exibe os dados do locatário -->
            <template v-if="profile === 'locator'">
              <strong>{{ order.user.full_name }}</strong><br/>
              <span v-if="order.user.phones">
                Telefone(s): <strong>{{ order.user.phones.join(', ') }}</strong>
              </span>
            </template>
            <template v-else>
              <strong>{{ order.locator.full_name }}</strong><br/>
              <span v-if="order.locator.phones">
                Telefone(s): <strong>{{ order.locator.phones.join(', ') }}</strong>
              </span>
            </template>
          </li>
        </ul>
      </div>
    </div>
    <div class="bottom">
      <el-button size="small" type="text" icon="el-icon-message" @click="goTo('messages')">Mensagens</el-button>
      <el-button size="small" type="text" icon="el-icon-info" @click="goTo('details')">Ver detalhes</el-button>
    </div>
  </div>
</template>

<script>
import { floatFormatted } from '@/utils/helpers'

export default {
  props: {
    order: {
      type: Object,
      required: true
    },
    profile: {
      type: String,
      default: 'tenant'
    }
  },

  computed: {
    imagePath() {
      return (this.order.product.featured_image_path ? process.env.MEDIA_BASE_URL + '/' + this.order.product.featured_image_path : require('@/assets/images/img-unavailable-360.png'))
    },
    priceFormatted() {
      if (!this.order.price_total) {
        return null
      }
      let price = floatFormatted(this.order.price_total)
      return price.toString()
    },
  },

  methods: {
    goTo(action) {
      let targetUrl = (this.profile === 'tenant' ? '/locatario' : '/locador')
      switch(action) {
        case 'messages':
          targetUrl += `/locacoes/${this.order.id}/mensagens`
          break;
        case 'details':
          targetUrl += `/locacoes/${this.order.id}`
          break;
      }
      this.$router.push(targetUrl)
    }
  }
}
</script>

<style lang="scss" scoped>

  $status-pending-confirmation: #FFC214;
  $status-pending-payment: #ff6600;
  $status-pending-takeout: #4190ED;
  $status-refused: #D0021B;
  $status-canceled: #D0021B;
  $status-active: #6CC60A;
  $status-finished: #060;

  .order {
    margin-bottom: 3rem;
    background-color: #fff;

    small {
      font-size: 1.2rem;
    }

    .focus {
      color: #FB9B3C;
      font-weight: bold;
    }

    .header {
      padding: 1.4rem;
      lost-flex-container: row;
      justify-content: space-between;
      font-size: 1.6rem;
    }

    .ctn {
      border-top: 1px solid #D6E0EA;
      border-bottom: 1px solid #D6E0EA;
      padding: 1.4rem;
      lost-flex-container: row;
    }

    .col {
      &:first-child {
        lost-column: 8/12;
        lost-flex-container: row;
      }
      &:last-child {
        lost-column: 4/12;
      }
    }

    .figure {
      width: 155px;
      height: 116px;
      margin-right: 2rem;
      cursor: pointer;

      img {
        object-fit: cover;
        width: 100%;
        height: 100%;
      }
    }

    .status {
      font-weight: bold;
      &.-pending-confirmation {
        color: $status-pending-confirmation;
      }
      &.-pending-payment {
        color: $status-pending-payment;
      }
      &.-pending-takeout {
        color: $status-pending-takeout;
      }
      &.-refused {
        color: $status-refused;
      }
      &.-canceled {
        color: $status-canceled;
      }
      &.-active {
        color: $status-active;
      }
      &.-finished {
        color: $status-finished;
      }
    }

    .cart {
      font-size: 1.2rem;
      li {
        &:not(:last-child) {
          margin-bottom: 1.4rem;
        }
        line-height: 1.6;
      }
    }

    .title {
      font-weight: bold;
      font-size: 1.4rem;
    }

    .infos {
      font-size: 1.2rem;
      li {
        &:not(:last-child) {
          margin-bottom: 1.2rem;
        }
        line-height: 1.6;
      }
    }

    .price {
      span {
        font-weight: bold;
        color: #5CAF00;
        font-size: 2.2rem;
      }
    }

    .bottom {
      padding: 0 1.6rem;
      lost-align: right;

      .el-button {
        margin-left: 3.4rem;
      }
    }
  }
</style>
