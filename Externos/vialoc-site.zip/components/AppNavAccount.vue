<template>
  <div v-if="$auth.loggedIn" class="nav-account" :class="{ '-active': navAccountOpen.main }" ref="navAccount">
    <div class="nav">
      <div class="nav-icon" @click="toggleNav()">
        <div class="ham">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
      <ul class="nav-list">
        <li :class="{ '-active': navAccountOpen.main && navAccountOpen.common }">
          <div class="link -title" @click.stop="toggleSub('common')">
            <el-tooltip :offset="2" effect="dark" placement="right-start" content="Minha conta" :disabled="navAccountOpen.main">
              <div class="icon">
                <svg-card width="25" height="21"/>
              </div>
            </el-tooltip>
            <span>Minha conta</span>
          </div>
          <ul class="nav-sub">
            <li>
              <nuxt-link to="/minha-conta" class="link" exact>Painel</nuxt-link>
            </li>
            <li>
              <nuxt-link to="/minha-conta/cadastro" class="link">Meu cadastro</nuxt-link>
            </li>
            <li>
              <nuxt-link to="/minha-conta/alterar-senha" class="link">Alterar senha</nuxt-link>
            </li>
            <li v-if="$auth.user.address.address">
              <nuxt-link to="/minha-conta/enderecos" class="link">Meus endereços</nuxt-link>
            </li>
          </ul>
        </li>

        <li v-if="!$auth.user.is_complete" class="-primary">
          <div class="link -title" @click="goToCompletionAlert">
            <el-tooltip :offset="2" effect="dark" placement="right-start" content="Tenho uma carreta" :disabled="navAccountOpen.main">
              <div class="icon">
                <svg-locator width="24" height="19"/>
              </div>
            </el-tooltip>
            <span>Tenho uma carreta</span>
          </div>
        </li>
        <li v-else class="-primary" :class="{ '-active': navAccountOpen.main && navAccountOpen.locator }">
          <div class="link -title" @click.stop="toggleSub('locator')">
            <el-tooltip :offset="2" effect="dark" placement="right-start" content="Tenho uma carreta" :disabled="navAccountOpen.main">
              <div class="icon">
                <svg-locator width="24" height="19"/>
              </div>
            </el-tooltip>
            <span>Tenho uma carreta</span>
          </div>
          <ul class="nav-sub">
            <li>
              <nuxt-link to="/locador" class="link" exact>Painel</nuxt-link>
            </li>
            <li>
              <nuxt-link to="/locador/locacoes" class="link">Pedidos de locação</nuxt-link>
            </li>
            <li>
              <nuxt-link to="/locador/carretas" class="link" exact>Minhas carretas</nuxt-link>
            </li>
            <li>
              <nuxt-link to="/locador/carretas/nova-carreta" class="link">Cadastrar carreta</nuxt-link>
            </li>
            <li>
              <nuxt-link to="/locador/avaliacoes" class="link">Avaliações</nuxt-link>
            </li>
            <li>
              <nuxt-link to="/locador/perguntas-recebidas" class="link">Perguntas recebidas</nuxt-link>
            </li>
          </ul>
        </li>

        <li v-if="!$auth.user.is_complete" class="-secondary">
          <div class="link -title" @click="goToCompletionAlert">
            <el-tooltip :offset="2" effect="dark" placement="right-start" content="Quero uma carreta" :disabled="navAccountOpen.main">
              <div class="icon">
                <svg-tenant width="24" height="19"/>
              </div>
            </el-tooltip>
            <span>Quero uma carreta</span>
          </div>
        </li>
        <li v-else class="-secondary" :class="{ '-active': navAccountOpen.main && navAccountOpen.tenant }">
          <div class="link -title" @click.stop="toggleSub('tenant')">
            <el-tooltip :offset="2" effect="dark" placement="right-start" content="Quero uma carreta" :disabled="navAccountOpen.main">
              <div class="icon">
                <svg-tenant width="24" height="19"/>
              </div>
            </el-tooltip>
            <span>Quero uma carreta</span>
          </div>
          <ul class="nav-sub">
            <li>
              <nuxt-link to="/locatario" class="link" exact>Painel</nuxt-link>
            </li>
            <li>
              <nuxt-link to="/locatario/locacoes" class="link">Minhas locações</nuxt-link>
            </li>
            <li>
              <nuxt-link to="/locatario/avaliacoes" class="link">Avaliações</nuxt-link>
            </li>
            <li>
              <nuxt-link to="/locatario/perguntas-enviadas" class="link">Perguntas enviadas</nuxt-link>
            </li>
            <li>
              <nuxt-link to="/locatario/carretas-favoritas" class="link">Favoritas</nuxt-link>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import SvgCard from '@/assets/svg/card.svg?inline'
import SvgLocator from '@/assets/svg/locator.svg?inline'
import SvgTenant from '@/assets/svg/tenant.svg?inline'

export default {
  components: {
    SvgCard,
    SvgLocator,
    SvgTenant,
  },

  data() {
    return {
      navAccountOpen: {
        main: false,
        common: false,
        locator: false,
        tenant: false,
      }
    }
  },

  mounted() {
    this.navAccountOpen = this.$store.getters['base/navAccountOpen']
  },

  methods: {
    toggleSub(section) {
      // this.$refs.navAccount.classList.add("-active");
      // event.target.closest('li').classList.toggle("-active");
      if (this.navAccountOpen.main === false) {
        this.$store.dispatch('base/setNavAccountOpen', { section: 'main', isOpen: true })
        this.$store.dispatch('base/setNavAccountOpen', { section: section, isOpen: true })
        return
      }
      this.$store.dispatch('base/setNavAccountOpen', { section: section, isOpen: !this.navAccountOpen[section] })
    },

    toggleNav() {
      this.$store.dispatch('base/setNavAccountOpen', { section: 'main', isOpen: !this.navAccountOpen['main'] })
      setTimeout(() => {
        console.log('this.navAccountOpen.main', this.navAccountOpen.main)
      }, 1000)
      // this.$refs.navAccount.classList.toggle("-active");
    },

    goToCompletionAlert() {
      this.$router.push('/minha-conta/ative-sua-conta')
    }
  }
}

</script>

<style lang="scss" scoped>
  .nav-icon {
    padding: 10px;
    @media (min-width: $screen-md) {
      display: none;
    }
    .ham {
      span {
        background-color: #4A4A4A;
        margin-bottom: .4rem;
      }
    }
  }

  .nav {
    padding: 2rem 0;
    width: 45px;
    background-color: #fff;
    height: 100%;
    transition: width 0.25s cubic-bezier(0.25, 0.1, 0.25, 1);

    @media (min-width: $screen-md) {
      width: 250px;
    }

    .nav-sub {
      display: none;
      padding-left: 45px;
    }

    .nav-list {

      @media (max-width: $screen-md - 1px) {
        width: 250px;
      }

      &:not(:last-child) {
        border-bottom: 1px solid #ccc;
      }

      .link {
        font-size: 1.3rem;
        padding: .4rem 0;
        display: block;
        color: inherit;
        cursor: pointer;

        &.nuxt-link-active {
          font-weight: bold;
        }

        &:hover {
          color: inherit;
        }

        &.-title {
          lost-flex-container: row;
          lost-align: middle-left;
          font-weight: 600;
        }
      }

      .sub {
        color: $secondary-color;
        margin-bottom: 1.2rem;

        > .link {
          font-weight: bold;
          &.-primary {
            color: $primary-color;
          }
          &.-secondary {
            color: $secondary-color;
          }
        }
      }

      li {
        margin-bottom: .6rem;
        position: relative;

        .icon {
          width: 45px;
          height: 45px;
          font-size: 20px;
          lost-flex-container: row;
          lost-align: center;
        }

        &.-primary {
          .link {
            &.-title {
              color: $primary-color;
            }
            &:hover {
              color: $primary-color;
            }
          }
        }

        &.-secondary {
          .link {
            &.-title {
              color: $secondary-color;
            }
            &:hover {
              color: $secondary-color;
            }
          }
        }

      }

      > li {
        &.-active {
          .nav-sub {
            display: block;
          }
        }
      }

    }
  }

  .nav-account {
    position: relative;
    height: 100%;
    overflow: hidden;
    margin-top: -31px;

    @media (max-width: $screen-md - 1px) {
      position: absolute;
      left: 0;

      &:after {
        content: '';
        background-color: rgba(0,0,0, .4);
        width: 100%;
        height: 100vh;
        display: block;
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        z-index: -1;
        opacity: 0;
        visibility: hidden;
        transition: opacity .3s ease-out;
      }
    }

    &.-active {
      z-index: 1000;
      width: 100%;

      &:after {
        opacity: 1;
        visibility: visible;
      }

      .nav {
        width: 250px;
      }

      .ham {
        span {
          position: absolute;
          top: 8px;
          left: 0;

          &:nth-child(1){
            transform: rotate(45deg);
          }
          &:nth-child(2){
            transform: rotatey(90deg);
            opacity: 0;
          }
          &:nth-child(3){
            transform: rotate(-45deg);
          }
        }
      }
    }

    @media (max-width: $screen-md - 1px) {

      &:not(.-active) {
        .link {
          span {
            display: none;
          }
        }
        .nav-sub {
          display: none;
        }
      }

    }
  }

</style>
