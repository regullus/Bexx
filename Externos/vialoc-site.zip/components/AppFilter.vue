<template>
  <div class="filter" v-if="pagination">
    <div class="qtd">Exibindo de {{ showingProducts }} em {{ pagination.total }} carretas disponíveis</div>
    <div class="clear" @click="clearFilters">Limpar filtro</div>
    <div class="box">
      <el-form v-if="form" :model="form" label-position="top">
        <el-form-item label="Ordenar por:">
          <client-only>
            <el-select v-model="form.product_order_by" @change="onSubmit">
              <el-option label="Menor preço" value="price"></el-option>
              <el-option v-if="isLocationDefined" label="Mais próximos" value="distance"></el-option>
            </el-select>
          </client-only>
        </el-form-item>
        <el-form-item label="Faixa de preços:" class="is-filter">
          <span class="label">R$ {{ priceMin }} - R$ {{ priceMax }}/mês</span>
          <client-only>
            <el-slider v-model="form.product_price_range" range :min="filterBaseData.price_range[0]" :max="filterBaseData.price_range[1]" :step="500" @change="onSubmit"> </el-slider>
          </client-only>
        </el-form-item>
        <el-form-item label="Fabricante:">
          <client-only>
            <el-select v-model="form.product_brand" @change="onSubmit">
              <el-option v-for="brand in brands" :key="`brand-${brand.id}`" :label="brand.name" :value="brand.id"></el-option>
            </el-select>
          </client-only>
        </el-form-item>
        <el-form-item label="Ano de fabricação:" class="is-filter">
          <span class="label">{{ form.product_year_range ? form.product_year_range[0] : filterBaseData.year_range[0] }} - {{ form.product_year_range ? form.product_year_range[1] : filterBaseData.year_range[1] }}</span>
          <client-only>
            <el-slider v-model="form.product_year_range" range :min="filterBaseData.year_range[0]" :max="filterBaseData.year_range[1]" @change="onSubmit"> </el-slider>
          </client-only>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import _ from 'lodash'
import { mapGetters } from 'vuex'
import { floatFormatted } from '@/utils/helpers'

export default {
  props: {
    pagination: {
      type: Object,
    },
    showingProducts: {
      type: Number,
    }
  },

  data() {
    return {
      form: null
    }
  },

  computed: {
    ...mapGetters({
      filterBaseData: 'base/filterBaseData',
      searchFilters: 'base/searchFilters',
    }),

    priceMin() {
      return floatFormatted(this.form.product_price_range ? this.form.product_price_range[0] : this.filterBaseData.price_range[0], false)
    },

    priceMax() {
      let priceMax = this.form.product_price_range ? this.form.product_price_range[1] : this.filterBaseData.price_range[1]
      return floatFormatted(priceMax, false) + (priceMax === this.filterBaseData.price_range[1] ? '+' : '')
    },

    brands() {
      let brands = _.cloneDeep(this.filterBaseData.brands_list)
      brands.unshift({ name: 'Todos os fabricantes', slug: '', })
      return brands
    },

    isLocationDefined() {
      return this.$store.getters['base/isLocationDefined']
    }
  },

  created () {
    this.form = _.cloneDeep(this.searchFilters)
  },

  methods: {
    onSubmit() {
      this.$store.dispatch('base/setSearchFilters', this.form)
      this.$emit('do-search', this.form)
    },

    clearFilters() {
      this.$store.dispatch('base/clearSearchFilters').then(() => this.$emit('do-search', this.form))
    }
  }
}
</script>

<style lang="scss" scoped>
  .qtd {
    font-size: 1.2rem;
    margin-bottom: 1rem;
  }
  .clear {
    font-size: 1.2rem;
    color: $secondary-color;
    text-align: right;
    margin-bottom: 1rem;
    cursor: pointer;
  }
  .box {
    background-color: #fff;
    padding: 1.4rem;
  }
  .title {
    font-size: 1.4rem;
    margin-bottom: 1rem;
  }
  .label {
    display: block;
    text-align: center;
    color: #8794A0;
    font-size: 1.2rem;
    line-height: 1.2;
  }
</style>

<style lang="scss">
  .filter {
    .el-input {
      font-size: 1.2rem;
    }
    .el-form-item__content {
      line-height: 32px;
    }
    .el-input__inner {
      height: 32px;
      line-height: 32px;
    }
    .el-slider {
      padding: 0 1rem;
    }
    .el-form-item {
      margin-bottom: 1.6rem;

      &:not(.is-filter) {
        margin-bottom: 2.4rem;
      }

      &:last-child {
        margin-bottom: 0;
      }
    }
    .el-input__inner {
      height: 3.2rem;
    }
  }
</style>