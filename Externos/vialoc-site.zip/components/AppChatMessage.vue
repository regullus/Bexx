<template>
  <div>
    <div class="chat-date"> 5 de setembro </div>
    <div class="chat-row" :class="(isOwner ? '-left' : '-right')">
      <div class="chat-box">
        <div class="name">Pedro Alves</div>
        <div class="msg">Poderia me enviar, por gentileza a segunda via do boleto?</div>
        <div class="chat-bottom">
          <div class="time">15:08</div>
          <div class="chat-status">
            <svg-chat-status-checked class="icon" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import SvgChatStatusChecked from '@/assets/svg/chat-status-checked.svg?inline'

export default {
  components: {
    SvgChatStatusChecked,
  },

  props: {
    message: {
      type: Object,
      required: true,
    },
    isOwner: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      //
    }
  }
}
</script>

<style lang="scss" scoped>
  .chat-row {
    &.-left {
      lost-align: left;
      .chat-box {
        background-color: #DAE3E6;
      }
    }
    &.-right {
      lost-align: right;
      .chat-box {
        background-color: #F5F5F5;
      }
    }
  }
</style>
