<template>
  <li class="dash-list-line">
    <div class="dash-list-item">
      <span class="id"># {{ order.id }}</span>
    </div>
    <div class="dash-list-item">
      <span class="title">{{ order.product.name }}</span>
      <span class="sub">{{ order.product.type_formatted }} - {{ order.product.brand }} - {{ order.product.year }}</span>
    </div>
    <div class="dash-list-item">
      <span class="link -cursor dash-color" @click="goTo">Ver pedido</span>
    </div>
  </li>
</template>

<script>
export default {
  props: {
    order: {
      type: Object,
      required: true
    },
    type: {
      type: String,
      default: 'tenant'
    }
  },

  methods: {
    goTo() {
      let targetUrl = `locatario/locacoes/${this.order.id}`
      if (this.type === 'locator') {
        targetUrl = `locador/locacoes/${this.order.id}`
      }
      this.$router.push(targetUrl)
    }
  }
}
</script>
