<template>
  <div class="dash-item">
    <h2 class="title">
      <svg-talk class="icon dash-color" width="23" height="23"/>
      Perguntas
    </h2>
    <div class="qtd">{{ (profile === 'locator' ? 'Não respondidas' : 'Respostas não lidas') }} <span class="dash-color">{{ counter }}</span></div>
    <span style="cursor: pointer;" class="link" @click="goTo">Ver todas &raquo;</span>
  </div>
</template>

<script>
import SvgTalk from '@/assets/svg/talk.svg?inline'

export default {
  props: {
    counter: {
      type: Number,
      required: true
    },
    profile: {
      type: String,
      default: 'tenant',
    }
  },

  components: {
    SvgTalk,
  },

  methods: {
    goTo() {
      let targetUrl = 'locatario/perguntas-enviadas'
      if (this.profile == 'locator') {
        targetUrl = 'locador/perguntas-recebidas'
      }

      this.$router.push(targetUrl)
    }
  }
}
</script>
