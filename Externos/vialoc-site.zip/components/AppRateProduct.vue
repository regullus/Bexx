<template>
  <div class="product -rateable" :class="`-view-${viewType}`" v-if="product">
    <h2 class="panel-title" v-if="isRateable">Avalie a carreta</h2>
    <h2 class="panel-title" v-else>Avaliação da carreta</h2>
    <div class="product-wrp">
      <div class="header">
        <div class="image">
          <span :style="`background-image: url(${featuredImage})`"></span>
        </div>
        <div class="rating">
          <span>{{ product.type_formatted }} - {{ product.brand }} - {{ product.year }}</span>
          <el-rate
            v-model="form.score"
            :colors="['#c00', '#f60', '#f7ba2a']"
            :texts="['Péssimo', 'Ruim', 'Regular', 'Bom', 'Excelente']"
            :disabled="!isRateable"
            show-text
            text-color="#666"
            >
          </el-rate>
        </div>
      </div>

      <div class="comment" v-if="isRateable">
        <strong>Sua avaliação (opcional)</strong>
        <el-input type="textarea" v-model="form.comment" :maxlength="140" show-word-limit></el-input>
        <p><small>O seu comentário aparecerá publicamente na página da carreta..</small></p>
        <div>
          <el-button class="el-button--block" type="primary" @click="setRating" :disabled="!this.form.score">
            <span v-if="this.form.score">Enviar a avaliação da carreta</span>
            <span v-else>Defina uma nota</span>
          </el-button>
        </div>
      </div>
      <div class="comment" v-else>
        <strong>
          Sua avaliação
          <span :class="rating.status === 'pending' ? 'color-warning' : 'color-success'">({{ rating.status === 'pending' ? 'Em revisão' : 'Publicada' }})</span>
        </strong>
        <div class="comment-text" v-if="rating.comment" v-html="rating.comment"></div>
        <div class="comment-text" v-else>
          Nenhum comentário foi publicado.
        </div>
      </div>
    </div>

  </div>
</template>

<script>
  export default {
    props: {
      product: {
        type: Object,
        default: null,
      },
      rating: {
        type: Object,
        default: null,
      },
      viewType: {
        type: String,
        default: 'block'
      },
      isRateable: {
        type: Boolean,
        default: false
      },
    },

    data() {
      return {
        mediaBaseUrl: process.env.MEDIA_BASE_URL,

        form: {
          score: 0,
          comment: '',
          status: 'pending',
        },
        buttonLoading: false,
      }
    },

    computed: {
      featuredImage () {
        return this.product.featured_image_path ? `${this.mediaBaseUrl}/${this.product.featured_image_path}` : require('~/assets/images/img-unavailable-360.png')
      }
    },

    created () {
      if (!this.isRateable) {
        this.form = this.rating
      }
    },

    methods: {
      setRating () {
        this.$emit('set-rating', { subtype: 'product', ...this.form })
      },
    },

    watch: {
      rating: function (rating) {
        if (!this.isRateable) {
          this.form = rating
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .product {
    background-color: #fff;
    padding: 0;
  }

  .product-wrp {
    > .header {
      position: relative;
      display: table;
      margin-bottom: 3rem;
      min-height: 90px;
      padding-left: 100px;

      > .image {
        position: absolute;
        top: 0;
        left: 0;
        width: 90px;
        height: 90px;

        span {
          display: block;
          width: 100%;
          height: 100%;
          border-radius: 50%;
          background-position: center center;
          background-repeat: no-repeat;
          background-size: cover;
        }
      }

      > .rating {
        display: table-cell;
        min-height: 90px;
        vertical-align: middle;
      }
    }
  }

  .product.-view-full, .product.-view-full-preview {
    .product-wrp {
      lost-flex-container: row;

      .header {
        margin-top: 1rem;
        lost-column: 5/12;
      }
      .comment {
        lost-column: 7/12;
      }
    }
  }

  .product.-view-full-preview {
    padding: 2rem;

    .product-wrp {
      .header {
        margin-top: 0;
      }
    }

    .panel-title {
      display: none;
    }
  }

  .comment {
    strong {
      display: block;
      margin-bottom: 0.5rem;
    }
    .el-textarea {
      margin-bottom: 0.5rem;
    }
    small {
      font-size: 1.2rem;
    }
  }

  .comment-text {
    font-style: italic;
  }

  .color-warning {
    color: $primary-color;
  }
  .color-success {
    color: $secondary-color;
  }
</style>

<style lang="scss">
.-rateable {
  .el-rate__icon {
    font-size: 28px;
  }
  .el-rate__text {
    display: block;
    margin-top: 0.5rem;
    font-weight: bold;
  }
  .el-rate {
    height: auto;
  }

  &.-view-full-preview {
    .el-rate__icon {
      font-size: 24px;
    }
  }
}
</style>