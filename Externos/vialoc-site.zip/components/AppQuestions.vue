<template>
  <div class="questions">
    <div class="inner-panel">
      <h2 class="questions-title">Perguntas e respostas</h2>

      <div class="questions-header">
        <div class="questions-sub">Qual informação você precisa?</div>
        <div class="questions-infos">
          <div class="wrp">
            <el-button>Meios de pagamento</el-button>
            <el-button>Seguro</el-button>
            <el-button>Ponto de entrega</el-button>
            <div class="questions-alert">
              <span class="name">Tem dúvidas?</span>
              Estes atalhos ajudarão você a encontrar o que busca.
              <span class="close" @click="closeAlert($event)">x</span>
            </div>
          </div>
        </div>
        <div class="questions-address">
          <i class="el-icon-location"></i>
          A carreta está em &nbsp;<strong>{{ location }}</strong>.
        </div>
      </div>

      <div class="questions-wrp">
        <el-form label-position="top" label-width="100px" :model="formInline" class="questions-form" ref="formQuestion" @submit.prevent.native="onSubmit">

          <app-alert ref="formQuestionAlert"/>

          <el-form-item label="Ou pergunte ao locador">
            <el-row :gutter="10">
              <el-col :span="18">
                <el-input v-model="formInline.new_question" placeholder="Escreva uma pergunta…" @focus="checkLoggedIn()"></el-input>
              </el-col>
              <el-col :span="6">
                <el-button type="primary" @click="onSubmit" class="el-button--block">Perguntar</el-button>
              </el-col>
            </el-row>
          </el-form-item>
        </el-form>
      </div>

      <div class="questions-ctn" v-if="questions.length">
        <div class="questions-sub">Últimas perguntas</div>

        <div class="questions-box" v-for="(question, index) in questionsFiltered" :key="`questions-${index}`" :id="`pergunta-${question.id}`">
          <app-questions-item type="view" :question="question" />
        </div>
      </div>

      <div v-if="questions.length > 3">
        <div v-if="showAll == false">
          <div class="questions-more" @click="showAll = true">Ver mais perguntas</div>
        </div>
        <div v-else>
          <div class="questions-more" @click="showAll = false">Reduzir listagem</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import _ from 'lodash';
  import { setTimeout } from 'timers';
  import { hashScrollMixin, errorsMixin } from '@/mixins'
  import AppAlert from '@/components/AppAlert'
  import AppQuestionsItem from '@/components/AppQuestionsItem'

  export default {
    mixins: [hashScrollMixin, errorsMixin],

    components: {
      AppAlert,
      AppQuestionsItem
    },

    props: {
      location: {
        type: String,
        required: true,
      },
      questions: {
        type: Array,
        required: true,
      },
      product_uid: {
        type: String,
        required: true,
      },
    },

    data() {
      return {
        formInline: {
          new_question: '',
          region: ''
        },
        showAll: false,
      }
    },

    computed: {
      questionsFiltered() {
        //return this.questions;
        if(this.showAll == false) {
          return _.slice(this.questions, 0, 3);
        } else {
          return this.questions;
        }
      }
    },

    // override watch
    watch: {
      '$route.hash': function() {
        let routeHash = this.$route.hash
        if (routeHash.indexOf('#pergunta-') !== -1) {
          this.showAll = true
        }
        setTimeout(() => {
          this.scrollToAnchor(routeHash)
        }, 500)
      }
    },

    methods: {
      onSubmit () {
        this.$refs['formQuestion'].validate((valid) => {
          if (valid) {
            // Envia os dados ao endpoint
            this.$axios.$post(`tenant/product/${this.product_uid}/question`, {content: this.formInline.new_question})
              .then(
                response => {
                  this.$refs['formQuestionAlert'].showAlert({ id: 'alert-message-success', type: 'success', title: 'Pergunta enviada com sucesso.', description: 'Obrigado. Em breve o locador irá responder à sua questão.', cleanOtherAlerts: true })
                  this.updateQuestion(response)
                  this.formInline.new_question = ''
                },
                error => {
                  this.errorsAlert(error, { ref: 'formQuestionAlert' })
                }
              )
          } else {
            this.$refs['formQuestionAlert'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados', description: 'Por favor, verifique os campos preenchidos abaixo:' })
            return false
          }
        })
      },

      closeAlert (e) {
        e.target.parentElement.style.display = "none";
      },

      updateQuestion (question) {
        this.$emit('update-question', question)
      },

      checkLoggedIn () {
        if (!this.$auth.loggedIn) {
          this.$store.dispatch('events/setModal', { id: 'login', title: 'Login necessário', message: 'Para enviar a sua dúvida ao locador, você precisa estar logado na Vialoc!' })
        }
      },
    }
  }
</script>


<style lang="scss" scoped>
  .questions-title {
    font-size: 2.4rem;
    margin-bottom: 2.6rem;
  }
  .questions-alert {
    background-color: $secondary-color;
    color: #fff;
    font-size: 1.2rem;
    padding: 1.4rem;
    width: 200px;
    line-height: 1.6;
    position: relative;

    &:before {
      right: 100%;
      bottom: 10%;
      border: solid transparent;
      content: " ";
      height: 0;
      width: 0;
      position: absolute;
      pointer-events: none;
      border-color: rgba(74, 181, 226, 0);
      border-right-color: $secondary-color;
      border-width: 7px;
      margin-top: -7px;
    }

    > .name {
      display: block;
    }

    > .close {
      display: block;
      position: absolute;
      top: 4px;
      right: 8px;
      line-height: 1;
      font-size: 1.6rem;
      cursor: pointer;
    }
  }
  .questions-infos {
    margin-bottom: 2.6rem;
    position: relative;

    > .wrp {
      position: relative;
      display: inline-block;
    }

    .questions-alert {
      position: absolute;
      right: -220px;
      bottom: 0;
    }
  }
  .questions-address {
    font-size: 1.2rem;
    margin-bottom: 2.6rem;
    line-height: 1.4;
    lost-flex-container: row;
    lost-align: middle-left;

    .el-icon-location {
      font-size: 2rem;
      margin-right: .6rem;
      color: #8794A0;
    }
  }
  .questions-sub {
    font-size: 1.6rem;
    margin-bottom: 1.4rem;
  }
  .questions-ctn {
    margin-bottom: 4rem;
  }
  .questions-wrp {
    margin-bottom: 3.6rem;
  }
  .questions-more {
    color: $secondary-color;
    font-size: 1.2rem;
    cursor: pointer;
  }

</style>

<style lang="scss">
  .questions-form {
    .el-form-item__label {
      font-size: 1.6rem;
    }
  }
</style>


