<template>
  <el-tooltip placement="top">
    <div slot="content"><strong>Alterar o avatar</strong><br>A imagem precisa ser maior que 240 x 240 px.</div>
    <el-upload
      class="avatar-uploader"
      action="/"
      :show-file-list="false"
      :before-upload="beforeAvatarUpload">
      <img :src="avatarEl || require('~/assets/images/anonymous-user-240x240.png')" class="avatar" alt="Avatar">
      <i class="el-icon-plus avatar-uploader-icon"></i>
    </el-upload>
  </el-tooltip>
</template>

<script>
import { errorsMixin } from '@/mixins'

export default {
  mixins: [ errorsMixin ],

  props: {
    avatar: {
      type: String,
    }
  },

  data () {
    return {
      avatarEl: this.avatar,
    }
  },

  methods: {
    beforeAvatarUpload (file) {
      const isLt2M = file.size / 1024 / 1024 < 2
      let errors = []

      if (!isLt2M) {
        errors.push('A imagem precisa ter no máximo 2MB.')
      }

      if (errors.length) {
        this.$store.dispatch('events/setModal', { id: 'generic', title: 'Erro no envio do avatar', message: _.join(errors, '<br>') })
        return false
      }

      // envia através do axios ao invés da função nativa do element-ui
      let requestHeaders = {
        headers: { 'Content-Type': 'multipart/form-data' }
      }

      let data = new FormData()
      data.append('avatar', file, file.filename)

      this.$axios.$post('/common/users/change-avatar', data, requestHeaders).then(
        response => {
          this.avatarEl = response.avatar
          this.$auth.fetchUser()
        },
        error => {
          this.errorsModal(error, { title: 'Erro no envio do avatar' })
        }
      )

      return false;
    },

    handleAvatarError (error, file, fileList) {
      console.log(error)
    },
  }
}
</script>
