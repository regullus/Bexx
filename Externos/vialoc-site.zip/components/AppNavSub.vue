<template>
  <div class="main-sub" :class="{ '-is-sub': isSubOpen }">
    <div class="ham" @click.stop="toggleSub()">
      <span></span>
      <span></span>
      <span></span>
    </div>

    <div class="sub" @click="toggleSub(false)" tabindex="0" v-if="$device.isDesktop">
      <!-- LOGADO -->
      <template v-if="$auth.loggedIn && $auth.user">
        <ul class="sub-nav -account">
          <li>
            <span class="link -title -icon">
              <span class="icon">
                <svg-card width="25" height="21"/>
              </span>
              Minha conta
            </span>
            <ul>
              <li>
                <nuxt-link to="/minha-conta" class="link" exact>Painel</nuxt-link>
              </li>
              <li>
                <nuxt-link to="/minha-conta/cadastro" class="link">Meu cadastro</nuxt-link>
              </li>
              <li>
                <nuxt-link to="/minha-conta/alterar-senha" class="link">Alterar senha</nuxt-link>
              </li>
              <li v-if="$auth.user.address.address">
                <nuxt-link to="/minha-conta/enderecos" class="link">Meus endereços</nuxt-link>
              </li>
            </ul>
          </li>
        </ul>
        <ul class="sub-nav -locator" v-if="$auth.user.status !== 'to-complete'">
          <li>
            <span class="link -title -icon">
              <span class="icon">
                <svg-locator width="24" height="19"/>
              </span>
              Tenho uma carreta
            </span>
            <ul>
              <li>
                <nuxt-link to="/locador" class="link" exact>Painel</nuxt-link>
              </li>
              <li>
                <nuxt-link to="/locador/locacoes" class="link">Pedidos de locação</nuxt-link>
              </li>
              <li>
                <nuxt-link to="/locador/carretas" class="link" exact>Minhas carretas</nuxt-link>
              </li>
              <li>
                <nuxt-link to="/locador/carretas/nova-carreta" class="link">Cadastrar carreta</nuxt-link>
              </li>
              <li>
                <nuxt-link to="/locador/avaliacoes" class="link">Avaliações</nuxt-link>
              </li>
              <li>
                <nuxt-link to="/locador/perguntas-recebidas" class="link">Perguntas recebidas</nuxt-link>
              </li>
            </ul>
          </li>
        </ul>
        <ul class="sub-nav -tenant" v-if="$auth.user.status !== 'to-complete'">
          <li>
            <span class="link -title -icon">
              <span class="icon">
                <svg-tenant width="24" height="19"/>
              </span>
              Quero uma carreta
            </span>
            <ul>
              <li>
                <nuxt-link to="/locatario" class="link" exact>Painel</nuxt-link>
              </li>
              <li>
                <nuxt-link to="/locatario/locacoes" class="link">Minhas locações</nuxt-link>
              </li>
              <li>
                <nuxt-link to="/locatario/avaliacoes" class="link">Avaliações</nuxt-link>
              </li>
              <li>
                <nuxt-link to="/locatario/perguntas-enviadas" class="link">Perguntas enviadas</nuxt-link>
              </li>
              <li>
                <nuxt-link to="/locatario/carretas-favoritas" class="link">Favoritas</nuxt-link>
              </li>
            </ul>
          </li>
        </ul>
        <ul class="sub-nav">
          <li>
            <span class="link -title">Mais</span>
            <ul>
              <li> <nuxt-link to="/ajuda" class="link">Ajuda</nuxt-link> </li>
              <li> <nuxt-link to="/faq" class="link">FAQ</nuxt-link> </li>
              <li> <nuxt-link to="/contato" class="link">Contato</nuxt-link> </li>
              <li> <span class="link" @click="logout">Sair (logout)</span> </li>
            </ul>
          </li>
        </ul>
      </template>

      <!-- NÃO LOGADO -->
      <template v-else>
        <ul class="sub-nav">
          <li>
            <span class="link -title">Institucional</span>
            <ul>
              <li> <nuxt-link to="/sobre-vialoc" class="link">Sobre</nuxt-link> </li>
              <li> <nuxt-link to="/termos-de-uso" class="link">Termos de uso</nuxt-link> </li>
              <li> <nuxt-link to="/politica-de-privacidade" class="link">Política de privacidade</nuxt-link> </li>
            </ul>
          </li>
        </ul>
        <ul class="sub-nav">
          <li>
            <span class="link -title">Como alugar</span>
            <ul>
              <li> <nuxt-link to="/locador" class="link">Locador</nuxt-link> </li>
              <li> <nuxt-link to="/locatario" class="link">Locatário</nuxt-link> </li>
            </ul>
          </li>
        </ul>
        <ul class="sub-nav">
          <li>
            <span class="link -title">Central de atendimento</span>
            <ul>
              <li> <nuxt-link to="/ajuda" class="link">Ajuda</nuxt-link> </li>
              <li> <nuxt-link to="/faq" class="link">FAQ</nuxt-link> </li>
              <li> <nuxt-link to="/contato" class="link">Contato</nuxt-link> </li>
            </ul>
          </li>
        </ul>
      </template>
    </div>

    <div class="sub-mobile" tabindex="0" v-if="$device.isMobileOrTablet">
      <ul class="sub-nav">
        <li>
          <span class="link -title" @click="toggleMb($event)">Institucional</span>
          <ul>
            <li> <nuxt-link to="/sobre-vialoc" class="link">Sobre</nuxt-link> </li>
            <li> <nuxt-link to="/termos-de-uso" class="link">Termos de uso</nuxt-link> </li>
            <li> <nuxt-link to="/politica-de-privacidade" class="link">Política de privacidade</nuxt-link> </li>
          </ul>
        </li>
      </ul>
      <ul class="sub-nav">
        <li>
          <span class="link -title" @click="toggleMb($event)">Como alugar</span>
          <ul>
            <li> <nuxt-link to="/locador" class="link">Locador</nuxt-link> </li>
            <li> <nuxt-link to="/locatario" class="link">Locatário</nuxt-link> </li>
          </ul>
        </li>
      </ul>
      <ul class="sub-nav">
        <li>
          <span class="link -title" @click="toggleMb($event)">Central de atendimento</span>
          <ul>
            <li> <nuxt-link to="/ajuda" class="link">Ajuda</nuxt-link> </li>
            <li> <nuxt-link to="/faq" class="link">FAQ</nuxt-link> </li>
            <li> <nuxt-link to="/contato" class="link">Contato</nuxt-link> </li>
          </ul>
        </li>
      </ul>
      <!-- LOGADO -->
      <ul class="sub-nav" v-if="$auth.loggedIn">
        <li>
          <ul>
            <li> <nuxt-link to="/minha-conta/cadastro" class="link -title">Minha conta</nuxt-link> </li>
            <li> <nuxt-link to="/minha-conta/" class="link">Painel Locador</nuxt-link> </li>
            <li> <nuxt-link to="/minha-conta/" class="link">Painel Locatário</nuxt-link> </li>
            <li> <nuxt-link to="/minha-conta/" class="link">Avaliações</nuxt-link> </li>
            <li> <span class="link" @click="logout">Sair (logout)</span> </li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import SvgCard from '@/assets/svg/card.svg?inline'
import SvgLocator from '@/assets/svg/locator.svg?inline'
import SvgTenant from '@/assets/svg/tenant.svg?inline'

export default {
  components: {
    SvgCard,
    SvgLocator,
    SvgTenant,
  },

  data() {
    return {
      isSubOpen: false
    }
  },

  created() {
    if (process.browser) {
      window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          this.isSubOpen = false
        }
      })
    }
  },

  methods: {
    toggleSub(forceStatus) {
      this.isSubOpen = typeof forceStatus !== 'undefined' ? forceStatus : !this.isSubOpen

      if (process.browser) {
        if (this.isSubOpen) {
          // add listener to clickoutside
          window.addEventListener('click', e => this.outsideClickSub(e))

        } else {
          // remove listener to clickoutside
          window.removeEventListener('click', e => this.outsideClickSub(e))
        }
      }
    },

    outsideClickSub(e) {
      if (e.target.closest('.sub')) {
        return
      } else if (e.target.closest('.sub-mobile')) {
        return
      }

      this.toggleSub(false)
    },

    toggleMb(e) {
      event.target.parentElement.classList.toggle("-active");
    },

    logout() {
      this.$store.dispatch('base/logout')
    }
  }
}

</script>

<style lang="scss" scoped>
	.sub {
		position: absolute;
		left: 50%;
		width: 100vw;
    transform: translateX(-50%);
		z-index: 2;
		padding: 6rem 0;
		lost-flex-container: row;
		lost-align: horizontal;
		opacity: 0;
		visibility: hidden;

    .sub-nav {
      padding: 0 1.6rem;

      &:not(:first-child) {
        border-left: 1px solid rgb(207, 214, 221);
      }

      &:not(:last-child) {
        min-width: 205px;
      }

      .link {
        font-size: 1.2rem;
        display: block;
        cursor: pointer;

        &.-title {
          font-size: 1.4rem;
          margin-bottom: 1.6rem;
          font-weight: bold;
        }

        &.-icon {
          position: relative;
          padding-left: 3rem;

          .icon {
            position: absolute;
            top: 50%;
            left: 0;
            transform: translateY(-50%);
          }
        }
      }

      li li {
        &:not(:last-child) {
          margin-bottom: 1.6rem;
        }
      }

      &.-locator {
        .-title {
          color: $primary-color;
        }
      }

      &.-tenant {
        .-title {
          color: $secondary-color;
        }
      }
    }
	}

  .sub-mobile {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background-color: #7A8793;
    padding: 6rem 0;
    transform: translateX(-100%);
    transition: 400ms all;
    visibility: hidden;
    z-index: 9998;

    .sub-nav {
      li {
        &:not(.-active) {
          ul {
            display: none;
          }
        }
      }

      .link {
        display: block;
        padding: 1.6rem 1.6rem;
        border-top: 1px solid #9DACBA;
        color: #fff;

        &.-title {
          font-weight: 700;
        }
      }
    }
  }

  .main-sub {
    .ham {
      position: absolute;
      right: 15px;
      top: 22px;
    }

		&.-is-sub {
      .sub-mobile {
        transform: translateX(0);
        transition: all 400ms;
        visibility: visible;
      }

			.sub {
				opacity: 1;
				visibility: visible;
        transition: all 400ms;
      }

      .ham {
        z-index: 9999;
        span {
          position: absolute;
          top: 8px;
          left: 0;

          &:nth-child(1){
            transform: rotate(45deg);
          }
          &:nth-child(2){
            transform: rotatey(90deg);
            opacity: 0;
          }
          &:nth-child(3){
            transform: rotate(-45deg);
          }
        }
      }
		}
  }
</style>
