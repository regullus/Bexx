<template>
  <div class="notes-line" v-if="notification" :class="{ '-unread': notification.is_unread }" @click="goToNotification(notification)">
    <div class="image">
      <img :src="avatar"/>
    </div>
    <div class="desc">
      <div class="info" v-html="notification.message"></div>
      <div class="time">{{ dateFormatted }}</div>
    </div>
    <div class="close" @click.stop="removeNotification"><span>x</span></div>
  </div>
</template>

<script>
import _ from 'lodash'
import { distanceInWordsToNow } from 'date-fns'
import ptLocale from 'date-fns/locale/pt'

export default {
  props: {
    notification: {
      type: Object,
      required: true,
    }
  },

  data() {
    return {
      //
    }
  },

  computed: {
    avatar()  {
      return this.notification.user && this.notification.user.avatar ? this.notification.user.avatar : require('~/assets/images/anonymous-user-240x240.png')
    },
    dateFormatted() {
      return !this.notification.created_at ? null : distanceInWordsToNow(this.notification.created_at, { locale: ptLocale })
    }
  },

  methods: {
    goToNotification() {
      if (this.notification.is_unread) { // Marca como lido
        this.$emit('notification-is-read')
      }

      switch(this.notification.tag) {
        case 'product-question':
          this.$router.push(`/locador/carretas/${this.notification.product.uid}/perguntas#pergunta-${this.notification.question_id}`)
          break

        case 'product-answer':
          this.$router.push(`/carreta/${this.notification.product.slug}#pergunta-${this.notification.question_parent_id}`)
          break

        case 'order-created':
        case 'order-canceled':
        case 'order-confirm-takeout':
        case 'order-inform-devolution':
          this.$router.push(`/locador/locacoes/${this.notification.order_id}`)
          break

        case 'order-confirmed':
        case 'order-refused':
        case 'order-inform-takeout':
        case 'order-confirm-devolution':
          this.$router.push(`/locatario/locacoes/${this.notification.order_id}`)
          break
      }
    },

    removeNotification() {
      this.$emit('remove-notification')
    }
  }
}
</script>

<style lang="scss">
  .notes-line {
    lost-flex-container: row;
    cursor: pointer;
    padding: 1rem 1.8rem 1rem 1.2rem;
    color: #666;
    position: relative;

    > .image {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      overflow: hidden;
      margin-right: 1rem;
    }

    > .desc {
      width: calc( 100% - 60px );
      line-height: 1.2;
      lost-flex-container: column;
      lost-align: horizontal;
      .info {
        margin-bottom: .6rem;
        font-weight: 600;
        font-size: 1.1rem;
      }
      .time {
        font-size: 1rem;
      }
    }

    > .close {
      position: absolute;
      top: 0;
      right: 0;
      width: 36px;
      height: 36px;
      opacity: 0;
      visibility: hidden;
      transition: 300ms all;
      padding: 12px;
      cursor: pointer;

      span {
        display: block;
        width: 12px;
        height: 12px;
        line-height: 12px;
        border-radius: 50%;
        background-color: #ccc;
        color: #fff;
        font-size: 10px;
        text-align: center;
      }
    }

    &.-unread {
      background-color: #f5a62324;
    }

    &:hover {
      background-color: #F5A623;
      color: #fff;

      > .close {
        opacity: 1;
        visibility: visible;
      }

      > .desc {
        color: #fff;
      }
    }

  }
</style>
