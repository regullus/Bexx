<template>
  <div class="view-slider">
    <div class="image">
      <img src="~assets/images/view.png" alt="">
    </div>
    <div class="thumbs">
      <carousel :per-page="4" :navigationEnabled="true">
          <slide>
            <img src="~assets/images/view-thumb.png" alt="">
          </slide>
          <slide>
            <img src="~assets/images/view-thumb.png" alt="">
          </slide>
          <slide>
            <img src="~assets/images/view-thumb.png" alt="">
          </slide>
          <slide>
            <img src="~assets/images/view-thumb.png" alt="">
          </slide>
          <slide>
            <img src="~assets/images/view-thumb.png" alt="">
          </slide>
          <slide>
            <img src="~assets/images/view-thumb.png" alt="">
          </slide>
        </carousel>
      </div>
  </div>
</template>

<script>
import { Carousel, Slide } from 'vue-carousel';

export default {
  components: {
    Carousel,
    Slide,
  },
}
</script>

<style lang="scss">
  .view-slider {
    background-color: #fff;

    .VueCarousel-pagination {
      display: none;
    }
    .VueCarousel-slide {
      padding: 0 .5rem;
    }

    .image {
      height: 400px;

      img {
        object-fit: cover;
        width: 100%;
        height: 100%;
      }
    }
    .thumbs {
      padding: 1rem 4rem;
    }
  }

</style>
