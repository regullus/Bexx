<template>
  <li class="panel-carts-item">
    <div class="panel-carts-prod">
      <figure class="figure">
        <img :src="image" :alt="product.name"/>
      </figure>
      <div class="infos">
        <div class="name">{{ product.name }}</div>
        <div class="other">
          {{ product.type_formatted }} - {{ product.brand }} - {{ product.year }}<br>
          {{ product.city }} - {{ product.state_code }}
        </div>
        <div class="btns">
          <el-button size="small" type="text" icon="el-icon-info" @click="goTo('page')">Ver página</el-button>
          <el-button size="small" type="text" icon="el-icon-star-off" @click="onRemoveFavorite">Remover dos favoritos</el-button>
        </div>
      </div>
    </div>
    <div class="panel-carts-link">
      <span class="link" @click="goTo('page')">Ver detalhes</span>
    </div>
  </li>
</template>

<script>
export default {
  props: {
    product: {
      type: Object,
      required: true,
    }
  },

  computed: {
    image() {
      return this.product.featured_image_path ? (process.env.MEDIA_BASE_URL + '/' + this.product.featured_image_path) : require('@/assets/images/img-unavailable-360.png')
    }
  },

  methods: {
    goTo (action) {
      switch (action) {
        case 'page':
          window.open(`/carreta/${this.product.slug}`, '_blank')
          break;
      }
    },

    onRemoveFavorite () {
      this.$axios.$delete(`tenant/favorites/product/${this.product.uid}`)
        .then(
          response => {
            this.$emit('favorite-delete', this.product)
          },
          error => {
            this.errorsAlert(error)
          }
        )
    }
  }
}
</script>


<style lang="scss">
  .panel-carts-item {
    lost-flex-container: row;
    justify-content: space-between;
    padding: 10px 0;
  }
  .panel-carts-prod {
    lost-flex-container: row;
    width: calc( 100% - 72px );
    > .figure {
      width: 112px;
      height: 84px;
      margin-right: 10px;

      img {
        object-fit: cover;
        width: 100%;
        height: 100%;
      }
    }
    > .infos {
      .other {
        font-size: 11px;
      }
    }
  }
  .panel-carts-link {
    font-size: 12px;
    font-weight: 600;
    lost-flex-container: row;
    align-items: center;

    > .link {
      cursor: pointer;
    }
  }

  .btns {
    lost-flex-container: row;
    align-items: center;
    .wrp {
      .el-button {
        margin-right: 2rem;
      }
    }
  }
</style>
