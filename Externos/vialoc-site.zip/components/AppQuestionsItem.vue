<template>
  <div class="app-questions-item" :class="{ '-hasAnwers': question.answers }">

    <app-alert ref="questionAnswerAlert"/>

    <div class="question">
      <div class="icon">
        <svg-chat class="icon" />
      </div>
      {{ question.content }}
      <small class="meta" v-if="['view-locator', 'view-tenant'].indexOf(type) !== -1">
        Enviado
        <span v-if="type === 'view-locator' && question.user">por {{ question.user.short_name }}</span>
        em {{ question.created_at }}
        <span  v-if="question.product">
          para a carreta
          <el-popover width="240" trigger="click">
            <app-card :product="question.product" />
            <span slot="reference" class="link">{{ question.product.name }}</span>
          </el-popover>
        </span>
      </small>
    </div>

    <div class="question -last" :class="{ '-edit': edit }" v-if="(question.answers && question.answers.content) || edit">
      <div class="icon">
        <svg-chat class="icon" />
      </div>
      <div class="anwers" v-if="question.answers">
        <div class="txt">
          {{ question.answers.content }}
          <small class="meta" v-if="['view-locator', 'view-tenant'].indexOf(type) !== -1">
            Respondida
            <span v-if="type === 'view-tenant' && question.answers.user">por {{ question.answers.user.short_name }}</span>
            em {{ question.answers.created_at }}
          </small>
        </div>
      </div>
      <div v-if="edit || editingTime">
        <el-form :model="answer" ref="formAnswer" @submit.prevent.native="onSubmit">
          <el-input v-if="edit" type="textarea" placeholder="Sua Resposta" :autosize="{ minRows: 4, maxRows: 8}" v-model="answer.content"></el-input>
          <div class="bottom">
            <el-button type="primary" size="mini" @click="onSubmit()" v-if="edit">Responder</el-button>
            <span class="inner-action" @click="toggleAction" v-if="editingTime">Editar ({{ this.countdown }})</span>
          </div>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import _ from 'lodash'
import { errorsMixin } from '@/mixins'

import AppCard from '@/components/AppCard'
import AppAlert from '@/components/AppAlert'
import SvgChat from '@/assets/svg/chat.svg?inline'

const defaultAnswer = {
  content: ''
}

export default {
  /*
    Valores de type deste componente:
    view-public = somente para visualização pública
    view-locator = somente para visualização locador
    view-tenant = somente para visualização locatário
    edit = para edição
   */

  mixins: [errorsMixin],

  components: {
    AppAlert,
    AppCard,
    SvgChat,
  },

  props: {
    type: {
      type: String,
      default: ''
    },
    question: {
      type: Object,
      required: true
    },
    productUid: {
      type: String,
      default: ''
    }
  },

  data() {
    return {
      answer: _.clone(defaultAnswer),
      edit: this.type === 'view-locator' && !this.question.answers,
      editingTime: false,
      countdown: 0,
    }
  },

  mounted() {
    if (this.question && this.question.is_unread) {
      this.setRead('locator')
    } else if (this.question.answers && this.question.answers.is_unread) {
      this.setRead('tenant')
    }
  },

  methods: {
    toggleAction (e) {
      this.edit = !this.edit
      e.target.innerHTML = this.edit ? 'Editar' : 'Cancelar'
      this.countdown = this.edit ? 0 : 60
    },

    onSubmit() {
      if (this.answer.content === '') {
        this.$refs['questionAnswerAlert'].showAlert({ id: 'alert-errors-found', type: 'error', title: 'Erros encontrados', description: 'Por favor, informe sua resposta.' })
        return false
      }

      this.$refs['questionAnswerAlert'].clearAlerts();

      // Envia os dados ao endpoint
      this.$axios.$post(`locator/product/${this.productUid}/question/${this.question.id}`, this.answer)
        .then(
          response => {
            this.question.answers = response
            this.updateQuestion()
            /*
            this.$refs['formAlert'].showAlert({ id: 'alert-message-success', type: 'success', title: 'Mensagem enviada com sucesso', description: 'Obrigado. Em breve retornaremos o seu contato.', cleanOtherAlerts: true })
            this.contact = _.clone(defaultContact)
            */
          },
          error => {
            this.errorsAlert(error, { ref: 'questionAnswerAlert' })
          }
        )
    },

    updateQuestion () {
      this.$emit('update-question', this.question)
      this.edit = false
      this.startCountdown()
    },

    startCountdown () {
      this.editingTime = true
      this.countdown = 60
      let countdownInterval = setInterval(() => {
        this.countdown--
        if (this.countdown <= 0) {
          clearInterval(countdownInterval)
          this.editingTime = false
        }
      }, 1000)
    },

    setRead (profile) {
      let questionId = profile === 'locator' ? this.question.id : this.question.answers.id
      // Envia os dados ao endpoint
      this.$axios.$put(`${profile}/products/messages/${questionId}/read`)
        .then(
          response => {
            if (profile === 'locator') {
              this.question.is_unread = false
            } else {
              this.question.answers.is_unread = false
            }
          },
          error => {
            // this.errorsAlert(error, { ref: 'questionAnswerAlert' })
            console.log('AppQuestionsItem->setRead', error)
          }
        )
    }
  }
}
</script>

<style lang="scss" scoped>
  .app-questions-item {
    overflow: hidden;
    border-bottom: 1px solid #D5D5D5;
    margin-bottom: 1.6rem;

    &.-hasAnwers {
      .el-textarea, .submit {
        display: none;
      }
    }
  }
  .question {
    position: relative;
    padding-left: 3rem;
    color: #333333;

    &:not(.-last) {
      margin-bottom: 1.6rem;
    }

    .icon {
      width: 18px;
      height: 18px;
      position: absolute;
      top: 1px;
      left: 0;

      svg {
        fill: #9B9B9B;
      }
    }

    &.-last {
      color: #666;
      padding-right: 35px;
      padding-bottom: 1.6rem;

      .icon {
        svg {
          transform: scaleX(-1);
        }
      }
    }

    .link {
      text-decoration: underline;
      color: #F5A623;
      cursor: pointer;
    }

    .txt {
      position: relative;
    }

    .meta {
      font-size: 1.1rem;
      padding-top: .2rem;
      display: block;
      color: #9B9B9B;
    }

    .bottom {
      margin-top: 1rem;
    }

    .inner-action {
      font-size: 1.2rem;
      display: inline-block;
      // position: absolute;
      // top: 0;
      // right: 10px;

      + .inner-action {
        margin-left: 1rem;
      }
    }

    &.-edit {
      .txt {
        display: none;
      }
      .el-textarea {
        display: block;
      }
      .submit {
        display: inline-block;
      }
    }

  }

  // .anwers {
  //   .el-textarea {
  //     position: absolute;
  //     visibility: hidden;
  //     width: calc( 100% - 14px );
  //     opacity: 0;
  //     left: 14px;
  //     top: -6px;
  //   }
  // }

</style>

<style lang="scss">
  .app-questions-item {
    .el-textarea__inner {
      line-height: 1.4;
      color: #9B9B9B;
      font-family: inherit;
      padding-right: 35px;
    }
  }
</style>
