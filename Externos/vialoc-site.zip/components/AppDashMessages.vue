<template>
  <div class="dash-item">
    <h2 class="title">
      <svg-chat class="icon dash-color" width="23" height="23"/>
      Mensagens
    </h2>
    <div class="qtd">Não lidas <span class="dash-color">{{ counter }}</span></div>
    <span style="cursor: pointer;" class="link" @click="goTo">Ver todas &raquo;</span>
  </div>
</template>

<script>
import SvgChat from '@/assets/svg/chat.svg?inline'

export default {
  props: {
    counter: {
      type: Number,
      required: true
    },
    profile: {
      type: String,
      default: 'tenant',
    }
  },

  components: {
    SvgChat,
  },

  methods: {
    goTo() {
      let targetUrl = 'locatario/locacoes'
      if (this.profile == 'locator') {
        targetUrl = 'locador/locacoes'
      }

      this.$router.push(targetUrl)
    }
  }
}
</script>
