<template>
  <div class="inner-alert">
    <el-alert v-for="alert in alerts" :key="alert.id" v-show="alert.show" :title="alert.title" :type="alert.type" :show-icon="alert.showIcon" :closable="alert.closable">
      <p class="el-alert__description">
        <span v-html="alert.description"></span> &nbsp;<a href="#" style="text-decoration: underline;" v-if="alert.clickUrl" @click.prevent="goUrl(alert)">Clique aqui.</a>
      </p>
      <i class="el-alert__closebtn el-icon-close" v-if="alert.closable" @click="alert.show = false"></i>
    </el-alert>
  </div>
</template>

<script>
import Vue from 'vue'
import _ from 'lodash'
import VueScrollTo from 'vue-scrollto'

const defaultAlert = {
  show: false,
  title: '',
  type: 'error',
  description: '',
  showIcon: true,
  closable: true,
  scroll: true,
  cleanOtherAlerts: true,
  clickUrl: null,
  timer: 60000, // milisegundos para o timer ser encerrado - 0 ou false desativa
}

export default {
  data() {
    return {
      alerts: [],
    }
  },

  methods: {
    showAlert(alertInfo) {
      if (typeof alertInfo.id === 'undefined') {
        alertInfo.id = `alert-` + (new Date()).getTime()
      }

      let alert = { ...defaultAlert, ...alertInfo, show: true }

      // se a opção cleanOtherAlerts é verdadeira, limpa todos os alerts existentes
      if (alert.cleanOtherAlerts === true) {
        this.alerts = []
      }

      let index = _.findIndex(this.alerts, a => a.id === alert.id)

      if (index !== -1) {
        alert = { ...this.alerts[index], ...alertInfo, show: true }
        Vue.set(this.alerts, index, alert)
      } else {
        this.alerts.push(alert)
      }

      if (alert.show && alert.scroll) {
        setTimeout(() => {
          VueScrollTo.scrollTo(this.$el)
        }, 500)
      }

      // timer para fechar o alerta
      if (alert.timer) {
        setTimeout(() => {
          this.closeAlert(alert.id)
        }, alert.timer)
      }
    },

    closeAlert(alertId) {
      let index = _.findIndex(this.alerts, a => a.id === alertId)
      if (index !== -1) {
        Vue.delete(this.alerts, index)
      }
    },

    clearAlerts() {
      this.alerts = []
    },

    goUrl(alert) {
      if (!alert.clickUrl) {
        return false
      }

      if (!/^(f|ht)tps?:\/\//i.test(alert.clickurl)) {
        window.open(alert.clickUrl, '_blank')
        return false
      }

      this.$router.push(alert.clickUrl)
    }
  }
}
</script>

<style lang="scss" scoped>
  .el-alert {
    margin-bottom: 2rem;

    .el-alert__description {
      margin: 0;
    }

    + .el-alert {
      margin-top: -1rem;
    }
  }
</style>