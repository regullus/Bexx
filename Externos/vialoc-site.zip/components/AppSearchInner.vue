<template>
  <div class="inner-search">
    <div class="container -column">
      <el-form :model="form" label-position="top">
        <el-row :gutter="10">
          <el-col :md="8">
            <el-form-item label="Localização" class="el-input-address">
              <client-only>
                <svg-pin class="el-input-address__icon" />
                <gmap-autocomplete :value="locationLabel" @place_changed="selectLocation" class="el-input__inner"></gmap-autocomplete>
              </client-only>
            </el-form-item>
          </el-col>
          <el-col :md="6">
            <el-form-item label="Tipo de carreta" class="el-input-cart">
              <client-only>
                <svg-truck class="el-input-cart__icon" />
                <el-select v-model="form.product_type" filterable placeholder="Escolha o tipo" @change="setSearchFilters">
                  <el-option v-for="(label, key) in types" :key="`option-type-${key}`" :label="label" :value="key"></el-option>
                </el-select>
              </client-only>
            </el-form-item>
          </el-col>
          <el-col :md="4">
            <el-form-item label="Data de retirada">
              <div class="el-input-date">
                <client-only>
                  <svg-calendar class="el-input-date__icon" />
                  <el-date-picker prefix-icon="el-icon-arrow-down" v-model="form.order_date_start" type="date" placeholder="Data" :picker-options="dateIniOptions" format="dd/MM/yyyy" value-format="yyyy-MM-dd" @change="checkDateEnd"></el-date-picker>
                </client-only>
              </div>
            </el-form-item>
          </el-col>
          <el-col :md="4">
            <el-form-item label="Data de devolução">
              <div class="el-input-date">
                <client-only>
                  <svg-calendar class="el-input-date__icon" />
                  <el-date-picker prefix-icon="el-icon-arrow-down" v-model="form.order_date_end" type="date" placeholder="Data" :default-value="form.order_date_start" :picker-options="dateEndOptions" format="dd/MM/yyyy" value-format="yyyy-MM-dd"></el-date-picker>
                </client-only>
              </div>
            </el-form-item>
          </el-col>
          <el-col :md="2">
            <el-form-item class="submit">
              <el-button type="primary" @click="onSubmit">
                <client-only>
                  <svg-search class="icon" />
                </client-only>
              </el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>

<script>
import { formSearchMixin, inputDateMixin } from '@/mixins'

import SvgPin from '@/assets/svg/pin.svg?inline'
import SvgTruck from '@/assets/svg/truck.svg?inline'
import SvgCalendar from '@/assets/svg/calendar.svg?inline'
import SvgSearch from '@/assets/svg/search.svg?inline'

export default {
  mixins: [formSearchMixin, inputDateMixin],

  props: {
    productType: {
      type: String,
      default: null
    }
  },

  components: {
    SvgPin,
    SvgTruck,
    SvgCalendar,
    SvgSearch,
  },

  created () {
    this.$store.dispatch('base/setSearchFilters', { product_type: (this.productType || 'all') })
  },
}
</script>

<style lang="scss">
  .inner-search {
    margin-bottom: 3rem;
    .el-form {
      .el-select, .el-autocomplete {
        width: 100%;
      }

      .el-form-item__label {
        font-size: 1.1rem;
      }
    }

    .submit {
      display: block;
      padding-top: 21px;
      .el-form-item__content {
        line-height: 32px;
      }
      .el-button {
        padding: 10px;
        width: 100%;
        height: 42px;
      }
    }
  }

</style>

