<template>
  <el-card class="c7-card-address">
    <strong class="label">{{ address.label }} <small v-if="showSetMain && address.is_main"><i class="el-icon-star-on"></i> Endereço Principal</small></strong> <br>
    <small>
      {{ address.address }}, {{ address.address_number }} {{ (address.address_complement ? ' - ' + address.address_complement : '') }} <br>
      {{ address.district }} - {{ address.city }} - {{ address.state_code }}
    </small>
    <div class="btns">
      <el-button v-if="showSelect" size="small" type="text" icon="el-icon-location" @click="doSelect(address)">Selecionar este endereço</el-button>
      <el-button v-if="showEdit" size="small" type="text" icon="el-icon-edit" @click="doEdit(address)">Editar</el-button>
      <el-button v-if="showSetMain && address.is_main === 0" size="small" type="text" icon="el-icon-star-off" @click="doSetMain(address.id)">Definir como endereço principal</el-button>
    </div>
  </el-card>
</template>

<script>
  export default {
    props: {
      address: {
        type: Object,
        required: true,
      },
      showSelect: {
        type: Boolean,
        default: false,
      },
      showEdit: {
        type: Boolean,
        default: false,
      },
      showSetMain: {
        type: Boolean,
        default: false,
      },
    },

    methods: {
      doEdit (address) {
        this.$emit('edit-address', address)
      },

      doSelect (address) {
        this.$emit('define-address', address)
      },

      doSetMain (address) {
        this.$emit('define-address-main', address)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .label small {
    font-size: 12px;
    color: #666;

    i {
      color: #fc0;
    }
  }
</style>
