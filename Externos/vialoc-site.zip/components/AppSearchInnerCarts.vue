<template>
  <el-form :inline="true" :model="formSearch" label-position="top">
    <el-form-item class="input">
      <el-input v-model="formSearch.search" placeholder="Buscar em minhas carretas"></el-input>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="onSubmit">Buscar</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
export default {
  data() {
    return {
      formSearch: {
        search: '',
      },
    }
  },

  methods: {
    onSubmit () {
      
    }
  }
}
</script>

<style lang="scss" scoped>
  .el-form {
    > .input {
      @media (min-width: $screen-md) { 
        width: 320px;
      }
    }
  }
</style>
