<template>
<!--
  Propriedades:
    extraClass: Adiciona classe adicional
          Padrao não flat
    Process: owner - Opcoes de visualizacao do card para o proprietário
             favorite - Opçòes para a lista de favoritos
             only-view - remove os links, pois é somente para visualização
             Padrao null
-->
  <div class="card" :class="extraClass">
    <figure v-if="product.featured_image_path" class="figure" :style="`background-image: url(${mediaBaseUrl}/${product.featured_image_path})`">
      <img :src="`${mediaBaseUrl}/${product.featured_image_path}`" :alt="product.name">
    </figure>
    <figure v-else class="figure" :style="`background-image: url(${require('~/assets/images/img-unavailable-360.png')})`">
      <img :src="require('~/assets/images/img-unavailable-360.png')" :alt="product.name">
    </figure>
    <div class="ctn">
      <div class="info">
        <ul class="list">
          <li>{{ product.name }}</li>
          <li>{{ product.type_formatted }} - {{ product.brand }} - {{ product.year }}</li>
          <li>
            {{ product.city }} - {{ product.state_code }}
            <small v-if="product.distance">(distância: {{ product.distance.toFixed(2) }} km)</small>
          </li>
        </ul>
      </div>
      <div class="bottom">
        <div class="price" v-if="showPrice">
          <template v-if="priceFormatted">
            <small>a partir de</small>
            R$ <span class="value">{{ priceFormatted }}</span>/mês
          </template>
          <template v-else>
            <span class="default">Preço indefinido</span>
          </template>
        </div>
        <div class="rating">
          <el-rate
            v-model="product.rating_score"
            disabled
            disabled-void-color="#c0c4cc"
            >
          </el-rate>
          <small>
            <span v-if="!product.rating_count">Sem avaliações</span>
            <span v-else>{{ product.rating_count }} {{ product.rating_count === 1 ? ' avaliação' : ' avaliações' }}</span>
          </small>
        </div>
      </div>
      <div class="btns" v-if="process == 'owner'">
        <template v-if="['active', 'inactive'].indexOf(product.status) !== -1">
          <el-button size="small" type="text" icon="el-icon-info" @click="goTo('page')">Ver página</el-button>
          <el-button size="small" type="text" icon="el-icon-message" @click="goTo('questions')">Perguntas recebidas</el-button>
        </template>
        <el-button size="small" type="text" icon="el-icon-edit" @click="goTo('edit')">Editar</el-button>
      </div>
      <div class="btns" v-if="process == 'favorite'">
        <el-button size="small" type="text" icon="el-icon-info" @click="goTo('page')">Ver página</el-button>
        <el-button size="small" type="text" icon="el-icon-star-off" @click="onRemoveFavorite">Remover dos favoritos</el-button>
      </div>
    </div>
    <nuxt-link :to="`/carreta/${product.slug}`" class="details" v-if="['owner', 'only-view', 'favorite'].indexOf(process) === -1">
      <span icon="el-icon-info" class="el-button el-button--primary">Ver detalhes</span>
    </nuxt-link>
  </div>
</template>

<script>
import _ from 'lodash'
import { floatFormatted } from '@/utils/helpers'

export default {
  props: {
    extraClass: {
      type: String,
      default: ''
    },
    process: {
      type: String,
      default: ''
    },
    product: {
      type: Object,
      // required: true,
      default: null,
    },
    showPrice: {
      type: Boolean,
      default: true,
    },
  },

  data() {
    return {
      mediaBaseUrl: process.env.MEDIA_BASE_URL,

      rating: {
        score: 5
      }
    }
  },

  computed: {
    priceFormatted () {
      if (!this.product.price_from) {
        return null
      }
      let price = floatFormatted(this.product.price_from)
      return price.toString().replace(',00', '')
    },

  },

  methods: {
    goTo (action) {
      switch (action) {
        case 'edit':
          this.$router.push(`/locador/carretas/${this.product.uid}/editar`)
          break;
        case 'questions':
          this.$router.push(`/locador/carretas/${this.product.uid}/perguntas`)
          break;
        case 'page':
          // let routePage = this.$router.resolve(`/carreta/${this.product.slug}`)
          window.open(`/carreta/${this.product.slug}`, '_blank')
          break;
      }
    },

    onRemoveFavorite () {
      this.$axios.$delete(`tenant/favorites/product/${this.product.uid}`)
        .then(
          response => {
            this.$emit('favorite-delete', this.product)
          },
          error => {
            this.errorsAlert(error)
          }
        )
    }
  }
}
</script>

<style lang="scss" scoped>
  .ctn {
    padding: 1.2rem;
    position: relative;
  }

  .info {
    font-size: 1.4rem;
    padding-top: .8rem;
    position: relative;

    small {
      font-size: 1.2rem;
      color: #666;
    }
  }

  .price {
    line-height: 1;

    small {
      display: block;
      font-size: 1.1rem;
      color: #999;
    }

    .value {
      color: #5CAF00;
      font-size: 2.2rem;
    }

    .default {
      font-size: 1.4rem;
    }
  }

  .bottom {
    padding: 1rem 0;
    lost-flex-container: row;
    justify-content: space-between;
    align-items: center;
  }

  .rating {
    .el-rate {
      pointer-events: auto;
    }

    small {
      font-size: 1.1rem;
    }
  }

  .figure {
    display: block;
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;

    img {
      object-fit: cover;
      width: 100%;
      height: 100%;
    }
  }

  .btns {
    lost-flex-container: row;
    align-items: center;
    .wrp {
      .el-button {
        margin-right: 2rem;
      }
    }
  }

  .details {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    transition: 400ms all;
    background-color: rgba(0,0,0,.6);
    z-index: 2;
    lost-flex-container: column;
    lost-align: middle-center;
  }

  .card {
    background-color: #fff;
    transition: all 300ms ease-in-out;
    position: relative;

    &:not(.-no-shadow) {
      &:hover {
        box-shadow: 0 3px 20px 0 rgba(0, 0, 0, 0.25);

        .details {
          opacity: 1;
        }
      }
    }

    // &:not(.-flat) {
    //   &:before {
    //     content: '';
    //     display: block;
    //     width: 100%;
    //     height: 100%;
    //     background-color: rgba(0,0,0,.6);
    //     position: absolute;
    //     top: 0;
    //     left: 0;
    //     z-index: 1;
    //     visibility: hidden;
    //     opacity: 0;
    //     transition: all 300ms ease-in-out;
    //   }
    //   &:hover {
    //     &:before {
    //       visibility: visible;
    //       opacity: 1;
    //     }
    //   }
    // }

    &.-flat {
      lost-flex-container: row;

      .figure {
        @media (min-width: $screen-md) {
          width: 215px;
        }
      }

      .info {
        padding-top: 0;
      }

      .ctn {
        @media (min-width: $screen-md) {
          width: calc( 100% - 215px );
        }
      }

    }
  }
</style>
