<template>
  <div class="dash-item">
    <h2 class="title">
      <svg-delivered class="icon dash-color" width="12" height="12"/>
      Carretas a serem entregues
    </h2>
    <ul class="dash-list">
      <app-dash-list-line/>
      <app-dash-list-line/>
      <app-dash-list-line/>
      <app-dash-list-line/>
      <app-dash-list-line/>
    </ul>
    <div class="dash-bottom">
      <el-button type="primary" size="small">Ver todas</el-button>
    </div>
  </div>
</template>

<script>
import AppDashListLine from '@/components/AppDashListLine'
import SvgDelivered from '@/assets/svg/delivered.svg?inline'

export default {
  components: {
    AppDashListLine,
    SvgDelivered,
  }
}
</script>