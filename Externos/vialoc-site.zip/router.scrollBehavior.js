export default function (to, from, savedPosition) {
  return { x: 0, y: 0 }
}