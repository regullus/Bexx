import _ from 'lodash'

export const applyDrag = (arr, dragResult) => {
  return new Promise((resolve, reject) => {
    const { removedIndex, addedIndex, payload } = dragResult
    if (removedIndex === null && addedIndex === null) return arr

    const result = [...arr]
    let itemToAdd = payload

    if (removedIndex !== null) {
      itemToAdd = result.splice(removedIndex, 1)[0]
    }

    if (addedIndex !== null) {
      result.splice(addedIndex, 0, itemToAdd)
    }

    resolve(result)
  })
}

export const floatFormatted = (value, showCents) => {
  if (!value) {
    return null
  }

  if (typeof showCents === 'undefined') {
    showCents = true
  }

  let parts = value.toFixed(2).toString().split('.')
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.')

  if (!showCents) {
    return parts[0]
  }

  return parts.join(',')
}

export const formatted2Float = (value) => {
  if (!value) {
    return null
  }

  return parseFloat(value.replace(/\./g, '').replace(',', '.'))
}

export const params2Querystring = {
  convert: (params, excludeParams) => {
    if (!params) {
      return null
    }

    if (typeof excludeParams === 'undefined') {
      excludeParams = []
    }

    let qs = []
    _.each(params, (v, k) => {
      if (excludeParams.indexOf(k) !== -1 || v === null) {
        return
      }
      let getParam = params2Querystring.getQueryString(v, k)

      if (Array.isArray(getParam)) {
        _.each(getParam, (pv) => {
          qs.push(pv)
        })
      } else {
        qs.push(getParam)
      }
    })

    return qs.join('&')
  },

  getQueryString: (v, k) => {
    let qs = []
    if (Array.isArray(v)) {
      _.each(v, (el) => {
        if (v === null) {
          return
        }
        qs.push(`${k}[]=${el}`)
      })
    } else if (_.isObjectLike(v)){ // se Objeto
      _.each(v, (sv, sk) => {
        if (sv === null) {
          return
        }
        qs.push(`${k}[${sk}]=${sv}`)
      })
    } else { // se String
      if (v !== null) {
        qs.push(`${k}=${v}`)
      }
    }

    return qs
  },
}

export const videoUtils = {
  parser: (url) => {
    // - Supported YouTube URL formats:
    //   - http://www.youtube.com/watch?v=My2FRPA3Gf8
    //   - http://youtu.be/My2FRPA3Gf8
    //   - https://youtube.googleapis.com/v/My2FRPA3Gf8
    // - Supported Vimeo URL formats:
    //   - http://vimeo.com/25451551
    //   - http://player.vimeo.com/video/25451551
    // - Also supports relative URLs:
    //   - //player.vimeo.com/video/25451551

    let type = null

    url.match(/(http:|https:|)\/\/(player.|www.)?(vimeo\.com|youtu(be\.com|\.be|be\.googleapis\.com))\/(video\/|embed\/|watch\?v=|v\/)?([A-Za-z0-9._%-]*)(\&\S+)?/)
    if (RegExp.$3.indexOf('youtu') > -1) {
        type = 'youtube'
    } else if (RegExp.$3.indexOf('vimeo') > -1) {
        type = 'vimeo'
    }

    return {
        type: type,
        id: RegExp.$6
    }
  },

  embed: (url, width, height) => {
    // Returns an iframe of the video with the specified URL.
    let videoObj = videoUtils.parser(url)
    let videoSrc = ''

    if (!videoObj.type) {
      return null
    }

    if (videoObj.type == 'youtube') {
        videoSrc = `//www.youtube.com/embed/${videoObj.id}`
    } else if (videoObj.type == 'vimeo') {
        videoSrc = `//player.vimeo.com/video/${videoObj.id}`
    }

    return `<iframe frameborder="0" src="${videoSrc}" width="${width}" height="${height}"></iframe>`
  },

  getThumb: (url, cb) => {
    // Obtains the video's thumbnail and passed it back to a callback function.
    var videoObj = videoUtils.parser(url)

    if (!videoObj.type) {
      return null
    }

    if (videoObj.type === 'youtube') {
      cb(`//img.youtube.com/vi/${videoObj.id}/maxresdefault.jpg`)
    } else if (videoObj.type === 'vimeo') {
      // Requires Axio
      this.$axios.$get(`http://vimeo.com/api/v2/video/${videoObj.id}.json`).then((response) => {
        cb(response[0].thumbnail_large)
      })
    }
  }
}

export const querystringPayload = (type, params) => {
  let payload = {}

  // trata os parametros, removendo os nulos ou inválidos
  _.each(params, (v, k) => {
    if (v) {
      payload[k] = v
    }
  })

  switch (type) {
    case 'product':
      if (payload.city_id) {
        delete payload.city_state_code
      } else {
        delete payload.city_id
      }
      if (payload.product_type && payload.product_type === 'all') {
        delete payload.product_type
      }
      break
  }

  return payload
}

export const getValuesNonReactive = (obj) => JSON.parse(JSON.stringify(obj))