<template>
  <div class="layout-default c7">
    <app-alert-master/>
    <nuxt/>
    <app-footer-sub/>
    <app-footer/>
    <app-modal ref="appModal"/>
  </div>
</template>

<script>
import AppAlertMaster from '@/components/AppAlertMaster'
import AppModal from '@/components/AppModal'
import AppFooterSub from '@/components/partials/AppFooterSub'
import AppFooter from '@/components/partials/AppFooter'

export default {
  components: {
    AppAlertMaster,
    AppModal,
    AppFooterSub,
    AppFooter
  }
}
</script>



