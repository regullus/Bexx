<template>
  <div class="inner-wrapper c7">
    <div class="container -column">
      <div class="header">
        <template v-if="error.statusCode === 404">
          <h2 class="title">404 - Página não encontrada</h2>
          <p>A página que você acessou não existe<br/>
          Como podemos ajudar você?.</p>
        </template>
        <template v-else-if="error.statusCode === 401">
          <h2 class="title">401 - Sessão expirada</h2>
          <p>Sua sessão expirou.<br>
          Por favor, <span class="link" @click="openModalLogin()">faça o login</span> novamente.</p>
        </template>
        <template v-else-if="error.statusCode === 500">
          <h2 class="title">500 - Erro interno de servidor</h2>
          <p>Ocorreu um erro ao processar esta ação.<br>
          Por favor tente novamente mais tarde.</p>
        </template>
      </div>
      <app-faq v-if="faqList.length" :faq-list="faqList" @faqRated="updateQuestion" />
    </div>
  </div>
</template>

<script>
import AppFaq from '@/components/AppFaq'
import { faqMixin } from '@/mixins'

export default {
  layout: 'inner',
  mixins: [faqMixin],
  props: ['error'],
  components: {
    AppFaq
  },

  methods: {
    openModalLogin() {
      this.$store.dispatch('events/setModal', { id: 'login' })
    }
  }
}
</script>

<style lang="scss" scoped>
  .header {
    text-align: center;
    margin-bottom: 4rem;
  }
  .container {
    max-width: 650px;
  }
</style>
