<template>
  <div class="layout-inner c7">
    <app-alert-master/>
    <app-header-inner/>
    <app-breadcrumb :key="`bc-${$route.path}`"/>
    <nuxt/>
    <app-footer-sub/>
    <app-footer/>
    <app-modal ref="appModal"/>
  </div>
</template>

<script>
import AppAlertMaster from '@/components/AppAlertMaster'
import AppHeaderInner from '@/components/partials/AppHeaderInner'
import AppBreadcrumb from '@/components/AppBreadcrumb'
import AppModal from '@/components/AppModal'
import AppFooterSub from '@/components/partials/AppFooterSub'
import AppFooter from '@/components/partials/AppFooter'

export default {
  components: {
    AppAlertMaster,
    AppHeaderInner,
    AppBreadcrumb,
    AppModal,
    AppFooterSub,
    AppFooter
  }
}
</script>

<style lang="scss">

  .layout-inner {

    .inner-wrapper {
      margin: 5rem 0;

      .profile-title {
        margin-top: -5rem;
      }
    }


  }

</style>



