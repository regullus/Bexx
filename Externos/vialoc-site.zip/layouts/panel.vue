<template>
  <div class="layout-panel c7" :class="{'-scrolled': scrolled }">
    <app-alert-master/>
    <app-header-inner/>
    <app-breadcrumb :key="`bc-${$route.path}`"/>
    <div class="inner-wrapper">
      <div class="inner-left">
        <app-nav-account/>
      </div>
      <div class="inner-right">
        <div class="container">
          <nuxt/>
        </div>
      </div>
    </div>
    <app-footer-sub/>
    <app-footer/>
    <app-modal ref="appModal" />
  </div>
</template>

<script>
import AppAlertMaster from '@/components/AppAlertMaster'
import AppHeaderInner from '@/components/partials/AppHeaderInner'
import AppBreadcrumb from '@/components/AppBreadcrumb'
import AppModal from '@/components/AppModal'
import AppNavAccount from '@/components/AppNavAccount'
import AppFooterSub from '@/components/partials/AppFooterSub'
import AppFooter from '@/components/partials/AppFooter'

export default {
  components: {
    AppAlertMaster,
    AppHeaderInner,
    AppBreadcrumb,
    AppModal,
    AppNavAccount,
    AppFooterSub,
    AppFooter
  },

  data() {
    return {
      scrolled: false
    }
  },

  methods: {
    handleScroll () {
      this.scrolled = window.scrollY > 69;
    },
  },

  created () {
    if (process.browser) {
      window.addEventListener('scroll', this.handleScroll);
    }
  },
  destroyed () {
    if (process.browser) {
      window.removeEventListener('scroll', this.handleScroll);
    }
  }

}
</script>

<style lang="scss">

  .layout-panel {

    .inner-wrapper {
      lost-flex-container: row;

      @media (max-width: $screen-md - 1px) {
        padding-left: 45px;
      }

      .inner-left {
        background-color: #fff;

        @media (min-width: $screen-md) {
          margin-right: 30px;
        }
      }

      .inner-right {
        padding-bottom: 30px;
        width: 100%;

        @media (min-width: $screen-md) {
          width: calc( 100% - 280px );
          padding-right: 50px;
        }

        > .container {
          lost-flex-container: column;
          margin-left: 0;
          @media (min-width: 1500px) {
            left: -110px;
            margin-left: auto;
          }
        }
      }

    }

    .inner-title {
      text-align: left;
    }

    .sub-footer {
      background-color: #8794A0;
      color: #fff;

      .link {
        color: #fff;
      }

      .logo {
        .default {
          display: block;
        }
        .gray {
          display: none;
        }
      }
    }

    &.-scrolled {
      .nav-account {
        @media (max-width: $screen-md - 1px) {
          position: fixed;
          top: 31px;
        }
      }
    }

  }

</style>




