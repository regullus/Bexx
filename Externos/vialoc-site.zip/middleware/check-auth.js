export default function(ctx) {
  console.log('[Middleware] Check Auth');

  ctx.store.dispatch('base/initAuth', ctx.req);

  if (!process.browser || !ctx.app.$auth.loggedIn) {
    return
  }

  if (ctx.app.$auth.user.email_confirmed !== 1) {
    console.log('confirmando', ctx.app.$auth.user.email_confirmed)
    ctx.store.dispatch('events/addAlertMaster', { id: 'confirm-email', type: 'warning', title: 'Mensagem de confirmação enviada ao seu e-mail', description: 'Por favor, clique no link de confirmação presente na mensagem enviada ou clique aqui para enviar novamente.', action: 'base/sendConfirmationAgain' })
  } else if (ctx.app.$auth.user.email_intended) {
    ctx.store.dispatch('events/addAlertMaster', { id: 'confirm-email', type: 'warning', title: 'Mensagem de confirmação enviada ao seu novo e-mail', description: 'Por favor, clique no link de confirmação presente na mensagem enviada ao seu novo e-mail ou clique aqui para enviar novamente.', action: 'base/sendConfirmationAgain' })
  }
}
