export default function ({ route, app }) {
  // Take the last value (latest route child)
  const breadcrumb = route.meta.reduce((breadcrumb, meta) => meta.breadcrumb || breadcrumb, [])
  const bcm = []

  breadcrumb.forEach(function (b, index, breadcrumb) {
    bcm[index] = b
  })

  app.store.commit('base/setBreadcrumb', bcm)
}
