const path = require('path');
const bodyParser = require('body-parser')
require('dotenv').config()

module.exports = {
  mode: 'universal',

  /*
  ** Headers of the page
  */
  head: {
    title: 'Aluguéis de carretas Baú, Sider, Port Container, entre outros. Alugue ou coloque para alugar! Vialoc',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: 'Nuxt.js project' }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' },
      { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css?family=Raleway:400,400i,600,600i,700,700i' }
    ]
  },

  css: [
    // SCSS file in the project
    'element-ui/lib/theme-chalk/index.css',
    '@/assets/sass/main.scss'
  ],

  styleResources: {
    scss: [
      '@/assets/sass/settings/_variables.scss',
    ],
  },

  /*
  ** Customize the progress bar color
  */
  loading: { color: '#3B8070' },

  /*
  ** Server Middleware
  */
  serverMiddleware: [
    bodyParser.json(),
    '~/api'
  ],

  /*
  ** Plugins
  */
  plugins: [
    { src: '~/plugins/axios', mode: 'all' },
    { src: '~/plugins/element-ui', mode: 'all' },
    { src: '~/plugins/initial-loading', mode: 'client' },
    { src: '~/plugins/vue-carousel', mode: 'client' },
    { src: '~/plugins/vue-echo', mode: 'client' },
    // { src: '~/plugins/svg-inline', mode: 'client' },
    { src: '~/plugins/googlemaps', mode: 'client' },
    { src: '~/plugins/vuex-persist', mode: 'client' },
  ],

  /*
  ** Modules
  */
  modules: [
    '@nuxtjs/dotenv',
    '@nuxtjs/axios',
    '@nuxtjs/auth',
    '@nuxtjs/sentry',
    'nuxt-imagemin',
    'nuxt-device-detect',
    '@nuxtjs/style-resources',
    // ['nuxt-sass-resources-loader', '@/assets/sass/settings/_variables.scss'],
    'nuxt-svg',
  ],

  auth: {
    token: {
      prefix: 'token.'
    },

    plugins: [
      '~/plugins/auth',
    ],

    strategies: {
      local: {
        endpoints: {
          login: { url: '/common/auth/login', method: 'post', propertyName: 'access_token' },
          logout: { url: '/common/auth/logout', method: 'post' },
          user: { url: '/common/users/me', method: 'get', propertyName: '' }
        },
        tokenRequired: true,
        tokenType: 'bearer',
        // tokenType: null,
      }
    },

    // redirect: {
    //   login: '/cadastro',
    //   logout: '/',
    //   callback: '/minha-conta/cadastro',
    //   user: '/minha-conta/cadastro'
    // },
    // rewriteRedirects: true,
    redirect: false,
  },

  axios: {
    // baseURL: process.env.AXIOS_BASE_URL || 'http://localhost:8000/api/v1',
    baseURL: process.env.AXIOS_BASE_URL || 'http://vialoc_api.test/api/v1',
    credentials: false,

    // requestInterceptor: (config, {store}) => {
    //   console.log('axios test', store.state.base.token)
    //   if (store.state.base.token) {
    //     config.headers.common['access-token'] = store.state.base.token
    //     config.headers.common['token-type'] = 'bearer'
    //     return config
    //   }
    // }
  },

  sentry: {
    dsn: 'https://0ed8d28a37fd4f3aa98440d61b1cc326@sentry.io/1393490', // Enter your project's DSN here
    config: {}, // Additional config
  },

  /*
  ** Router
  */
  router:{
    middleware: ['breadcrumb']
    // middleware: ['breadcrumb', 'isLoggedIn']
  },

  /*
  ** Build configuration
  */
  build: {
    /*
    ** Run ESLint on save
    */
    // postcss: [
    //   require('lost')
    // ],

    postcss: {
      plugins: {
        'lost' : {},
      }
    },

    extend (config, { isDev, isClient }) {

      if (isDev && isClient) {
        config.module.rules.push({
          enforce: 'pre',
          test: /\.(js|vue)$/,
          loader: 'eslint-loader',
          exclude: /(node_modules)/
        })
      }

      // if (!isClient) {
      //   // This instructs Webpack to include `vue2-google-maps`'s Vue files
      //   // for server-side rendering
      //   config.externals.splice(0, 0, function (context, request, callback) {
      //     if (/^vue2-google-maps($|\/)/.test(request)) {
      //       callback(null, false)
      //     } else {
      //       callback()
      //     }
      //   })
      // }

      // Store Vue loaders
      const vueLoader = config.module.rules.find(function (module) {
        return module.test.toString() === '/\\.vue$/i'
      })

      // Remove SVG from default rules
      // config.module.rules.forEach((rule) => {
      //   if (rule.test.toString() === '/\\.(png|jpe?g|gif|svg|webp)$/i') {
      //     rule.test = /\.(png|jpe?g|gif|webp)$/i
      //   }
      // })

      // Add svg inline loader configuration
      // config.module.rules.push({
      //   test: /\.svg$/,
      //   loader: 'svg-inline-loader'
      // })

      // Important to apply transforms on svg-inline:src
      // vueLoader.options.transformAssetUrls['svg-inline'] = 'src'
    }
  },

  // transpile: [/^vue2-google-maps($|\/)/],
  transpile: [
    'vue2-google-maps'
  ],
}

