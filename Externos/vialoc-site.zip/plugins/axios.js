export default function ({ $axios, redirect, store, route }) {
  $axios.onRequest(config => {
    // Workaround for Bearer duplicated
    // console.log('$axios.onRequest Authorization', config.headers.Authorization)
    // if ((typeof config.headers.Authorization !== 'undefined')) {
    //   console.log('Fix bearer', config.headers.Authorization)
    //   // se o bearer estiver duplicado
    //   if (config.headers.Authorization.search(/bearer bearer /i) !== -1) {
    //     $axios.setHeader('Authorization', 'bearer ' + config.headers.Authorization.substr(0, 14))
    //     console.log('Fixed removing extra bearer', 'bearer ' + config.headers.Authorization.substr(0, 14))
    //   // se o bearer não estiver presente
    //   } else if (config.headers.Authorization.search(/bearer /i) === -1) {
    //     console.log('Fixed adding bearer', 'bearer ' + config.headers.Authorization)
    //     $axios.setHeader('Authorization', 'bearer ' + config.headers.Authorization)
    //   }
    // }
    console.log('Making request to ' + config.url)
  })

  // $axios.onResponse(response => {
  //   const newtoken = get(response, 'headers.authorization')
  //   if (newtoken) store.dispatch('base/setToken', newtoken)
  //   console.log('$axios.onResponse', response.data)
  //   return response
  // })

  $axios.onError(error => {
    const code = parseInt(error.response && error.response.status)

    console.log('$axios.onError', code)
    console.log('$axios.onError -> response', error.response)

    if (code === 401) {
      if (process.browser) {
        store.dispatch('base/clientLogout')
      }
      redirect(`/?login-para=${route.fullPath}`)
    } else if (code === 403) {
      redirect('/?acesso-negado=1')
    } else if (code === 406) {
      store.dispatch('events/setModal', { id: 'login', title: 'Renovar sessão', message: 'Por medida de segurança, para prosseguir com essa ação, você precisa fazer o login novamente.', redirect: false })
    }
  })
}