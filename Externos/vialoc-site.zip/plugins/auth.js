export default function({ $auth }) {
  $auth.onRedirect((to, from) => {
    console.log('plugin auth', to, from)
  })
}
