import VuexPersistence from 'vuex-persist'
// import base from '../store/base'

export default ({ store }) => {
  new VuexPersistence({
    // modules: ['base'],
    reducer: (state) => ({
      base: {
        locationLabel: state.base.locationLabel,
        navAccountOpen: state.base.navAccountOpen,
        searchFilters: state.base.searchFilters
      }
    })
  }).plugin(store)
}