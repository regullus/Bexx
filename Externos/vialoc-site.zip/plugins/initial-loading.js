// export default function ({ store }) {
//     store.dispatch('base/startLoadStores')
// }