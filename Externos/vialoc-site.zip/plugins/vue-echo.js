import Vue from 'vue';
import VueEcho from 'vue-echo'
// import io from 'socket.io-client'

window.io = require('socket.io-client');

Vue.use(VueEcho, {
  authEndpoint: `${process.env.API_BASE_URL}/broadcasting/auth`,
  broadcaster: 'socket.io',
  host: process.env.SOCKETIO_HOST,
  // key: process.env.PUSHER_APP_KEY,
  // cluster: process.env.PUSHER_APP_CLUSTER,
  auth: {
    headers: {
      Authorization: localStorage.getItem('auth.token.local')
    },
  },
});

// window.Echo = new LaravelEcho({
//   authEndpoint: `${process.env.API_BASE_URL}/broadcasting/auth`,
//   broadcaster: 'pusher',
//   key: process.env.PUSHER_APP_KEY,
//   cluster: process.env.PUSHER_APP_CLUSTER,
//   auth: {
//     headers: {
//       Authorization: token
//     },
//   },
// })
